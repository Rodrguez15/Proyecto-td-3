<?php
/**
 * Genera avisos internos en la base de datos para pagos próximos/vencidos y eventos.
 * Preferir ejecución CLI. El acceso web solo se habilita con CRON_KEY configurada
 * y una petición POST con X-Cron-Key o el campo POST "key". Nunca usar GET.
 */
$esCli = PHP_SAPI === 'cli';
require_once __DIR__ . '/config/db_config.php';
$claveEnv = getenv('CRON_KEY');
$claveEsperada = $claveEnv !== false && $claveEnv !== ''
    ? (string)$claveEnv
    : (defined('VILAMIR_CRON_KEY') ? (string)VILAMIR_CRON_KEY : '');

if (!$esCli) {
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
        http_response_code(405);
        header('Allow: POST');
        exit("Método no permitido.\n");
    }

    $claveRecibida = (string)($_SERVER['HTTP_X_CRON_KEY'] ?? $_POST['key'] ?? '');
    if ($claveEsperada === '' || $claveRecibida === '' || !hash_equals($claveEsperada, $claveRecibida)) {
        http_response_code(403);
        exit("Acceso denegado. Configure CRON_KEY y envíe la clave por POST o cabecera.\n");
    }
}

require_once __DIR__ . '/config/conexion.php';
require_once __DIR__ . '/config/notificaciones.php';

$alumnos = $conexion->query('SELECT ID_Alumno FROM ALUMNO ORDER BY ID_Alumno')->fetchAll(PDO::FETCH_COLUMN);
$procesados = 0;
foreach ($alumnos as $idAlumno) {
    vilamirGenerarAvisosAlumno($conexion, (int)$idAlumno);
    $procesados++;
}

$resultado = sprintf("VILAMIR: avisos internos revisados para %d alumnos en %s\n", $procesados, date('Y-m-d H:i:s'));
if ($esCli) {
    fwrite(STDOUT, $resultado);
} else {
    header('Content-Type: text/plain; charset=utf-8');
    echo $resultado;
}
