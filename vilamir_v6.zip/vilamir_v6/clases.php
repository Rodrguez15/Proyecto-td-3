<?php

/*
 * ARCHIVO: clases.php
 * PROPÓSITO: Página o módulo PHP de clases dentro del sistema Academia VILAMIR.
 */
// Página de disciplinas/clases.
// El administrador puede crear y modificar disciplinas.
// El alumno puede consultar las disciplinas e inscribirse.
require_once 'config/autenticacion.php';

$admin = (($_SESSION['usuario_rol'] ?? '') === 'Administrador');

?>
<!DOCTYPE html>
<html lang="es">
<head>
<?php vilamir_enviar_token_csrf(); ?>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Clases y disciplinas - VILAMIR</title>
<link rel="stylesheet" href="css/style.css?v=20261026-etapa2-seminarios-galeria-v1">
<script src="js/csrf.js"></script>
</head>
<body class="about-page classes-page">
<header class="navbar">
<div class="logo">
<img src="images/logo-vilamir.jpg" alt="Escuela Vilamir" class="logo-img">
</div>
<nav>
<a href="index.php">Inicio</a>

            <?php if ($admin): ?>
                <a href="admin.php">Administración</a>
            <?php else: ?>
                <a href="clases.php">Clases</a>
<a href="mis_clases.php">Mis clases</a>
            <?php endif;
?>

            <a href="grupos.php">Grupos</a>
<a href="seminarios.php">Seminarios y eventos</a>
<a href="logout.php">Cerrar sesión</a>
</nav>
</header>
<main class="admin classes-page-container">
<section class="hero classes-hero">
<p class="classes-eyebrow">ACADEMIA VILAMIR · ENTRENAMIENTO</p>
<h1><?= $admin ? 'Gestión de disciplinas y clases' : 'Clases y disciplinas disponibles' ?></h1>
<p><?= $admin ? 'Organizá la oferta de disciplinas, mantené los costos actualizados y gestioná las clases desde un solo lugar.' : 'Conocé nuestras disciplinas, elegí la que más se adapte a vos y gestioná tus inscripciones de forma sencilla.' ?></p>
</section>

        <?php if ($admin): ?>
            <section class="module section-spaced classes-form-panel">
<div class="classes-section-heading"><span class="classes-heading-mark" aria-hidden="true"></span><div><h2>Agregar disciplina</h2><p>Completá los datos principales para publicar una clase.</p></div></div>
<div class="form-stack">
<input
                        id="nombreClase"
                        placeholder="Nombre de la disciplina"
                    >
<textarea
                        id="descripcionClase"
                        placeholder="Descripción"
                    >
</textarea>
<input
                        id="costoClase"
                        type="number"
                        step="0.01"
                        placeholder="Costo"
                    >
<button id="btnGuardarClase">
                        Guardar disciplina
                    </button>
</div>
<p id="mensajeClase">
</p>
</section>
        <?php else: ?>
            <section class="module section-spaced classes-info-panel">
<p class="muted-center">
                    Selecciona una clase para inscribirte.
                    Luego podrás verla en
                    <a href="mis_clases.php">Mis clases</a>.
                </p>
<p id="mensajeClase">
</p>
</section>
        <?php endif;
?>

        <section class="module section-spaced classes-list-panel">
<div class="classes-section-heading"><span class="classes-heading-mark" aria-hidden="true"></span><div><h2><?= $admin ? 'Disciplinas registradas' : 'Explorá nuestras disciplinas' ?></h2><p><?= $admin ? 'Editá los datos de las disciplinas o revisá la información publicada.' : 'Consultá la descripción y el costo antes de inscribirte.' ?></p></div></div>
<!-- js/clases.js genera las tarjetas de disciplinas aquí. -->
<div id="listaClases" class="team cards-grid">
</div>
</section>
</main>
<footer>© 2026 Academia VILAMIR</footer>
<script src="js/clases.js">
</script>
<script src="js/mobile.js">
</script>
</body>
</html>
