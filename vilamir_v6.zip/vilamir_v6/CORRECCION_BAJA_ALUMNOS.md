# Corrección: protección de alumnos frente al borrado físico

## Cambios

- El panel administrativo ya no presenta un botón de eliminación en el módulo Alumnos. En su lugar informa que la ficha se conserva sin borrado físico.
- La función JavaScript `removeRow()` rechaza también cualquier invocación manual cuando el módulo activo es `alumnos`.
- `api/admin.php` responde HTTP 409 ante una petición `accion=eliminar` para `entity=alumnos`, incluso si se envía directamente sin utilizar la interfaz.
- `api/alumnos.php` ya contenía un bloqueo equivalente y se mantiene sin cambios.
- Se conserva la protección existente que impide eliminar desde Usuarios una cuenta vinculada a un alumno.

## Alcance y límites

Esta corrección no crea una baja lógica ni cambia el estado del alumno: únicamente deshabilita el borrado físico desde las rutas revisadas. No se modificaron tablas, columnas, claves foráneas ni datos SQL.

## Pruebas pendientes en entorno real

1. En XAMPP, abrir Administración > Alumnos y comprobar que no aparece el botón Eliminar.
2. Enviar manualmente un POST a `api/admin.php?entity=alumnos` con `accion=eliminar` e `id` de un alumno de prueba; debe responder HTTP 409 y conservar el alumno.
3. Enviar un POST a `api/alumnos.php` con `accion=eliminar`; debe responder HTTP 409.
4. Comprobar que la ficha y sus pagos continúan visibles. No realizar pruebas de borrado contra datos reales de producción.

La revisión estática no sustituye estas pruebas con sesión y base de datos reales.
