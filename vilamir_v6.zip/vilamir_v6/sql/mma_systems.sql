-- ARCHIVO: mma_systems.sql
-- PROPÓSITO: Esquema o migración SQL relacionada con mma systems. Revisar antes de ejecutarla en una base existente.
-- IMPORTANTE: hacer copia de seguridad y revisar dependencias antes de ejecutar.

-- ============================================================
-- ACADEMIA VILAMIR - ESQUEMA CONSOLIDADO V21
-- Instalación nueva y consolidada.
-- MySQL / MariaDB - UTF8MB4 / InnoDB
--
-- IMPORTANTE:
--   * Esta versión NO contiene módulos de exámenes.
--   * El modelo vigente es: DISCIPLINA -> GRUPO -> HORARIO.
--   * Las inscripciones se gestionan por disciplina, grupo y seminario.
--   * Para una base existente, revisar sql/README.md y usar solo la migración correspondiente.
-- ============================================================

CREATE DATABASE IF NOT EXISTS mma_systems
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE mma_systems;
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ============================================================
-- 1. CUENTAS Y PERSONAS
-- ============================================================

-- No se eliminan tablas heredadas aquí. Este archivo no debe usarse para actualizar una base existente.
-- Las tablas heredadas no forman parte de los módulos activos de VILAMIR.

CREATE TABLE IF NOT EXISTS USUARIO (
    ID_Usuario INT AUTO_INCREMENT PRIMARY KEY,
    Email VARCHAR(150) NOT NULL,
    Contraseña VARCHAR(255) NOT NULL,
    Rol ENUM('Administrador','Profesor','Alumno') NOT NULL DEFAULT 'Alumno',
    Creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_usuario_email (Email),
    KEY idx_usuario_rol (Rol)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ALUMNO (
    ID_Alumno INT AUTO_INCREMENT PRIMARY KEY,
    ID_Usuario INT NOT NULL,
    Nombre VARCHAR(100) NOT NULL,
    Apellido VARCHAR(100) NOT NULL,
    Cedula VARCHAR(30) NULL,
    Fecha_nacimiento DATE NULL,
    Direccion VARCHAR(255) NULL,
    Telefono VARCHAR(40) NULL,
    Cobertura_medica VARCHAR(150) NULL,
    Peso DECIMAL(6,2) NULL,
    Categoria VARCHAR(80) NULL,
    Codigo_qr VARCHAR(100) NULL,
    Creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_alumno_usuario (ID_Usuario),
    UNIQUE KEY uq_alumno_qr (Codigo_qr),
    KEY idx_alumno_apellido (Apellido,Nombre),
    CONSTRAINT fk_alumno_usuario FOREIGN KEY (ID_Usuario)
        REFERENCES USUARIO(ID_Usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS RESPONSABLE (
    ID_Responsable INT AUTO_INCREMENT PRIMARY KEY,
    ID_Alumno INT NOT NULL,
    Nombre VARCHAR(100) NOT NULL,
    Apellido VARCHAR(100) NOT NULL,
    Parentesco VARCHAR(60) NOT NULL,
    Cedula VARCHAR(30) NULL,
    Telefono VARCHAR(40) NULL,
    Direccion VARCHAR(255) NULL,
    KEY idx_responsable_alumno (ID_Alumno),
    CONSTRAINT fk_responsable_alumno FOREIGN KEY (ID_Alumno)
        REFERENCES ALUMNO(ID_Alumno) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS PROFESOR (
    ID_Profesor INT AUTO_INCREMENT PRIMARY KEY,
    ID_Usuario INT NULL,
    Nombre VARCHAR(100) NOT NULL,
    Apellido VARCHAR(100) NOT NULL,
    Telefono VARCHAR(40) NULL,
    Cedula VARCHAR(30) NULL,
    Direccion VARCHAR(255) NULL,
    Especialidad VARCHAR(150) NULL,
    Email VARCHAR(150) NULL,
    Creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_profesor_email (Email),
    KEY idx_profesor_usuario (ID_Usuario),
    KEY idx_profesor_apellido (Apellido,Nombre),
    CONSTRAINT fk_profesor_usuario FOREIGN KEY (ID_Usuario)
        REFERENCES USUARIO(ID_Usuario) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 2. OFERTA ACADÉMICA
-- ============================================================

CREATE TABLE IF NOT EXISTS DISCIPLINA (
    ID_Disciplina INT AUTO_INCREMENT PRIMARY KEY,
    Nombre VARCHAR(150) NOT NULL,
    Descripcion TEXT NULL,
    Costo DECIMAL(10,2) NOT NULL DEFAULT 0,
    UNIQUE KEY uq_disciplina_nombre (Nombre)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS GRUPO (
    ID_Grupo INT AUTO_INCREMENT PRIMARY KEY,
    Nombre VARCHAR(100) NOT NULL,
    ID_Disciplina INT NULL,
    Cupo_maximo INT NOT NULL DEFAULT 20,
    Nivel VARCHAR(30) NOT NULL DEFAULT 'Principiante',
    Descripcion TEXT NULL,
    Creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_grupo_disciplina (ID_Disciplina),
    KEY idx_grupo_nombre (Nombre),
    CONSTRAINT fk_grupo_disciplina FOREIGN KEY (ID_Disciplina)
        REFERENCES DISCIPLINA(ID_Disciplina) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS HORARIO (
    ID_Horario INT AUTO_INCREMENT PRIMARY KEY,
    ID_Grupo INT NULL,
    Dia VARCHAR(20) NOT NULL,
    Hora_inicio TIME NOT NULL,
    Hora_fin TIME NOT NULL,
    Creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_horario_grupo (ID_Grupo),
    KEY idx_horario_dia_hora (Dia,Hora_inicio,Hora_fin),
    CONSTRAINT fk_horario_grupo FOREIGN KEY (ID_Grupo)
        REFERENCES GRUPO(ID_Grupo) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS PROFESOR_DISCIPLINA (
    ID_Profesor INT NOT NULL,
    ID_Disciplina INT NOT NULL,
    Fecha_asignacion DATE NOT NULL DEFAULT (CURRENT_DATE),
    PRIMARY KEY (ID_Profesor,ID_Disciplina),
    KEY idx_profdisc_disciplina (ID_Disciplina),
    CONSTRAINT fk_profdisc_profesor FOREIGN KEY (ID_Profesor)
        REFERENCES PROFESOR(ID_Profesor) ON DELETE CASCADE,
    CONSTRAINT fk_profdisc_disciplina FOREIGN KEY (ID_Disciplina)
        REFERENCES DISCIPLINA(ID_Disciplina) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS INSCRIPCION_DISCIPLINA (
    ID_Ins_disciplina INT AUTO_INCREMENT PRIMARY KEY,
    ID_Alumno INT NOT NULL,
    ID_Disciplina INT NOT NULL,
    Fecha_ins DATE NOT NULL,
    Estado VARCHAR(40) NOT NULL DEFAULT 'Activa',
    UNIQUE KEY uq_ins_disciplina (ID_Alumno,ID_Disciplina),
    KEY idx_insdisc_disciplina_estado (ID_Disciplina,Estado),
    KEY idx_insdisc_alumno_estado (ID_Alumno,Estado),
    CONSTRAINT fk_ins_disc_alumno FOREIGN KEY (ID_Alumno)
        REFERENCES ALUMNO(ID_Alumno) ON DELETE CASCADE,
    CONSTRAINT fk_ins_disc_disciplina FOREIGN KEY (ID_Disciplina)
        REFERENCES DISCIPLINA(ID_Disciplina) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS INSCRIPCION_GRUPO_ALUMNO (
    ID_Inscripcion INT AUTO_INCREMENT PRIMARY KEY,
    ID_Alumno INT NOT NULL,
    ID_Grupo INT NOT NULL,
    Fecha_inscripcion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Estado VARCHAR(40) NOT NULL DEFAULT 'Activa',
    UNIQUE KEY uq_alumno_grupo (ID_Alumno,ID_Grupo),
    KEY idx_iga_grupo_estado (ID_Grupo,Estado),
    KEY idx_iga_alumno_estado (ID_Alumno,Estado),
    CONSTRAINT fk_iga_alumno FOREIGN KEY (ID_Alumno)
        REFERENCES ALUMNO(ID_Alumno) ON DELETE CASCADE,
    CONSTRAINT fk_iga_grupo FOREIGN KEY (ID_Grupo)
        REFERENCES GRUPO(ID_Grupo) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS INSCRIPCION_GRUPO_PROFESOR (
    ID_Inscripcion INT AUTO_INCREMENT PRIMARY KEY,
    ID_Profesor INT NOT NULL,
    ID_Grupo INT NOT NULL,
    Fecha_inscripcion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Estado VARCHAR(40) NOT NULL DEFAULT 'Activa',
    UNIQUE KEY uq_profesor_grupo (ID_Profesor,ID_Grupo),
    KEY idx_igp_grupo_estado (ID_Grupo,Estado),
    KEY idx_igp_profesor_estado (ID_Profesor,Estado),
    CONSTRAINT fk_igp_profesor FOREIGN KEY (ID_Profesor)
        REFERENCES PROFESOR(ID_Profesor) ON DELETE CASCADE,
    CONSTRAINT fk_igp_grupo FOREIGN KEY (ID_Grupo)
        REFERENCES GRUPO(ID_Grupo) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 3. SEMINARIOS / EVENTOS
-- ============================================================

CREATE TABLE IF NOT EXISTS SEMINARIO (
    ID_Seminario INT AUTO_INCREMENT PRIMARY KEY,
    Nombre VARCHAR(150) NOT NULL,
    Titulo VARCHAR(150) NULL,
    Descripcion TEXT NULL,
    Costo DECIMAL(10,2) NOT NULL DEFAULT 0,
    Ponente VARCHAR(150) NULL,
    Fecha DATE NOT NULL,
    Hora TIME NULL,
    Lugar VARCHAR(255) NULL,
    Cupo INT NULL,
    Creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_seminario_fecha (Fecha,Hora),
    KEY idx_seminario_vigencia (Fecha,Cupo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS INSCRIPCION_SEMINARIO (
    ID_Ins_seminario INT AUTO_INCREMENT PRIMARY KEY,
    ID_Alumno INT NOT NULL,
    ID_Seminario INT NOT NULL,
    Fecha_ins DATE NOT NULL,
    Estado VARCHAR(40) NOT NULL DEFAULT 'Activa',
    UNIQUE KEY uq_ins_seminario (ID_Alumno,ID_Seminario),
    KEY idx_inssem_seminario_estado (ID_Seminario,Estado),
    KEY idx_inssem_alumno_estado (ID_Alumno,Estado),
    CONSTRAINT fk_ins_sem_alumno FOREIGN KEY (ID_Alumno)
        REFERENCES ALUMNO(ID_Alumno) ON DELETE CASCADE,
    CONSTRAINT fk_ins_sem_seminario FOREIGN KEY (ID_Seminario)
        REFERENCES SEMINARIO(ID_Seminario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS LISTA_ESPERA (
    ID_Espera INT AUTO_INCREMENT PRIMARY KEY,
    ID_Alumno INT NOT NULL,
    ID_Grupo INT NOT NULL,
    Fecha_solicitud TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Estado ENUM('En espera','Admitido','Cancelado') NOT NULL DEFAULT 'En espera',
    UNIQUE KEY uq_espera (ID_Alumno,ID_Grupo),
    KEY idx_espera_grupo_estado (ID_Grupo,Estado,Fecha_solicitud),
    CONSTRAINT fk_espera_alumno FOREIGN KEY (ID_Alumno)
        REFERENCES ALUMNO(ID_Alumno) ON DELETE CASCADE,
    CONSTRAINT fk_espera_grupo FOREIGN KEY (ID_Grupo)
        REFERENCES GRUPO(ID_Grupo) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS LISTA_ESPERA_SEMINARIO (
    ID_Espera INT AUTO_INCREMENT PRIMARY KEY,
    ID_Alumno INT NOT NULL,
    ID_Seminario INT NOT NULL,
    Fecha_solicitud TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Estado ENUM('En espera','Admitido','Cancelado') NOT NULL DEFAULT 'En espera',
    UNIQUE KEY uq_espera_sem (ID_Alumno,ID_Seminario),
    KEY idx_espera_sem_estado (ID_Seminario,Estado,Fecha_solicitud),
    KEY idx_espera_sem_alumno (ID_Alumno,Estado),
    CONSTRAINT fk_espera_sem_alumno FOREIGN KEY (ID_Alumno) REFERENCES ALUMNO(ID_Alumno) ON DELETE CASCADE,
    CONSTRAINT fk_espera_sem_evento FOREIGN KEY (ID_Seminario) REFERENCES SEMINARIO(ID_Seminario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS CERTIFICADO (
    ID_Certificado INT AUTO_INCREMENT PRIMARY KEY,
    ID_Alumno INT NOT NULL,
    ID_Seminario INT NULL,
    Titulo VARCHAR(200) NOT NULL,
    Descripcion VARCHAR(255) NULL,
    Codigo VARCHAR(100) NOT NULL,
    Fecha_emision DATE NOT NULL,
    UNIQUE KEY uq_certificado_codigo (Codigo),
    KEY idx_certificado_alumno (ID_Alumno,Fecha_emision),
    CONSTRAINT fk_cert_alumno FOREIGN KEY (ID_Alumno)
        REFERENCES ALUMNO(ID_Alumno) ON DELETE CASCADE,
    CONSTRAINT fk_cert_seminario FOREIGN KEY (ID_Seminario)
        REFERENCES SEMINARIO(ID_Seminario) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS GALERIA_EVENTO (
    ID_Galeria INT AUTO_INCREMENT PRIMARY KEY,
    ID_Seminario INT NULL,
    Titulo VARCHAR(150) NOT NULL,
    Imagen VARCHAR(255) NOT NULL,
    Descripcion VARCHAR(255) NULL,
    Fecha TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_galeria_seminario (ID_Seminario),
    CONSTRAINT fk_galeria_seminario FOREIGN KEY (ID_Seminario)
        REFERENCES SEMINARIO(ID_Seminario) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 4. PAGOS Y PROMOCIONES
-- ============================================================

CREATE TABLE IF NOT EXISTS PAGO (
    ID_Pago INT AUTO_INCREMENT PRIMARY KEY,
    ID_Alumno INT NOT NULL,
    Tipo VARCHAR(80) NOT NULL,
    Fecha DATE NOT NULL,
    Fecha_vencimiento DATE NULL,
    Importe DECIMAL(10,2) NOT NULL DEFAULT 0,
    Estado VARCHAR(40) NOT NULL DEFAULT 'Pendiente',
    Metodo_pago VARCHAR(60) NULL,
    Numero_comprobante VARCHAR(40) NULL,
    Anulado_en DATETIME NULL,
    Anulado_por INT NULL,
    Motivo_anulacion VARCHAR(255) NULL,
    KEY idx_pago_alumno_fecha (ID_Alumno,Fecha,ID_Pago),
    KEY idx_pago_estado_fecha (Estado,Fecha,Fecha_vencimiento),
    KEY idx_pago_vencimiento (ID_Alumno,Fecha_vencimiento,Estado),
    UNIQUE KEY uq_pago_comprobante (Numero_comprobante),
    KEY idx_pago_anulado (Estado,Anulado_en),
    CONSTRAINT fk_pago_alumno FOREIGN KEY (ID_Alumno)
        REFERENCES ALUMNO(ID_Alumno) ON DELETE CASCADE,
    CONSTRAINT fk_pago_anulado_por FOREIGN KEY (Anulado_por)
        REFERENCES USUARIO(ID_Usuario) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS PROMOCION (
    ID_Promocion INT AUTO_INCREMENT PRIMARY KEY,
    Nombre VARCHAR(150) NOT NULL,
    Descripcion TEXT NULL,
    Descuento DECIMAL(5,2) NOT NULL DEFAULT 0,
    Fecha_inicio DATE NULL,
    Fecha_fin DATE NULL,
    Activa TINYINT(1) NOT NULL DEFAULT 1,
    Imagen VARCHAR(255) NULL,
    KEY idx_promocion_vigencia (Activa,Fecha_inicio,Fecha_fin)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 5. ASISTENCIA
-- ============================================================

CREATE TABLE IF NOT EXISTS ASISTENCIA (
    ID_Asistencia INT AUTO_INCREMENT PRIMARY KEY,
    ID_Alumno INT NOT NULL,
    ID_Grupo INT NOT NULL,
    ID_Horario INT NULL,
    ID_Profesor INT NULL,
    Fecha DATE NOT NULL,
    Estado ENUM('Presente','Ausente','Justificado') NOT NULL DEFAULT 'Presente',
    Observacion VARCHAR(255) NULL,
    Creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_asistencia_horario (ID_Alumno,ID_Grupo,Fecha,ID_Horario),
    KEY idx_asistencia_grupo_fecha_horario (ID_Grupo,Fecha,ID_Horario),
    KEY idx_asistencia_fecha (Fecha),
    KEY idx_asistencia_grupo (ID_Grupo,Fecha),
    KEY idx_asistencia_alumno (ID_Alumno,Fecha),
    KEY idx_asistencia_profesor_fecha (ID_Profesor,Fecha),
    CONSTRAINT fk_asistencia_alumno FOREIGN KEY (ID_Alumno)
        REFERENCES ALUMNO(ID_Alumno) ON DELETE CASCADE,
    CONSTRAINT fk_asistencia_grupo FOREIGN KEY (ID_Grupo)
        REFERENCES GRUPO(ID_Grupo) ON DELETE CASCADE,
    CONSTRAINT fk_asistencia_horario FOREIGN KEY (ID_Horario)
        REFERENCES HORARIO(ID_Horario) ON DELETE SET NULL,
    CONSTRAINT fk_asistencia_profesor FOREIGN KEY (ID_Profesor)
        REFERENCES PROFESOR(ID_Profesor) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 6. NOTIFICACIONES
-- ============================================================

CREATE TABLE IF NOT EXISTS NOTIFICACION (
    ID_Notificacion INT AUTO_INCREMENT PRIMARY KEY,
    ID_Alumno INT NOT NULL,
    Estado VARCHAR(40) NOT NULL DEFAULT 'Pendiente',
    Mensaje TEXT NOT NULL,
    Fecha DATE NOT NULL,
    Leida TINYINT(1) NOT NULL DEFAULT 0,
    KEY idx_notificacion_alumno_fecha (ID_Alumno,Fecha),
    KEY idx_notificacion_lectura (ID_Alumno,Leida,Fecha),
    CONSTRAINT fk_notificacion_alumno FOREIGN KEY (ID_Alumno)
        REFERENCES ALUMNO(ID_Alumno) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS NOTIFICACION_USUARIO (
    ID_Notificacion_Usuario INT AUTO_INCREMENT PRIMARY KEY,
    ID_Usuario INT NOT NULL,
    Titulo VARCHAR(150) NOT NULL DEFAULT 'Aviso de VILAMIR',
    Mensaje TEXT NOT NULL,
    Fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Leida TINYINT(1) NOT NULL DEFAULT 0,
    Clave VARCHAR(64) NOT NULL,
    UNIQUE KEY uq_notificacion_usuario_clave (ID_Usuario,Clave),
    KEY idx_notificacion_usuario_lectura (ID_Usuario,Leida,Fecha),
    CONSTRAINT fk_notificacion_usuario_usuario FOREIGN KEY (ID_Usuario)
        REFERENCES USUARIO(ID_Usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS NOTIFICACION_PROFESOR (
    ID_Notificacion_Profesor INT AUTO_INCREMENT PRIMARY KEY,
    ID_Profesor INT NOT NULL,
    Categoria VARCHAR(40) NOT NULL DEFAULT 'General',
    Mensaje TEXT NOT NULL,
    Fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Leida TINYINT(1) NOT NULL DEFAULT 0,
    KEY idx_notif_profesor_lectura (ID_Profesor,Leida,Fecha),
    CONSTRAINT fk_notif_profesor_profesor FOREIGN KEY (ID_Profesor)
        REFERENCES PROFESOR(ID_Profesor) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 7. AUDITORÍA
-- ============================================================

CREATE TABLE IF NOT EXISTS ACTIVIDAD_SISTEMA (
    ID_Actividad INT AUTO_INCREMENT PRIMARY KEY,
    ID_Usuario INT NULL,
    Accion VARCHAR(150) NOT NULL,
    Detalle VARCHAR(255) NULL,
    Fecha TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_actividad_fecha (Fecha),
    KEY idx_actividad_usuario_fecha (ID_Usuario,Fecha),
    CONSTRAINT fk_actividad_usuario FOREIGN KEY (ID_Usuario)
        REFERENCES USUARIO(ID_Usuario) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 8. DATOS INICIALES
-- ============================================================

INSERT INTO USUARIO (Email,Contraseña,Rol)
VALUES (
    'vilamir@gmail.com',
    '$2y$12$u0kskfOvF15IqaFWQjOp1Ol52hCDGnOEtE05KwDwOP5k7oDbWFc5e',
    'Administrador'
)
ON DUPLICATE KEY UPDATE Rol='Administrador';

UPDATE ALUMNO
SET Codigo_qr = CONCAT(
    'VIL-', ID_Alumno, '-',
    UPPER(SUBSTRING(MD5(CONCAT(ID_Alumno,'-',COALESCE(ID_Usuario,0),'-VILAMIR')),1,10))
)
WHERE Codigo_qr IS NULL OR Codigo_qr='';

-- Valores seguros para instalaciones limpias.
UPDATE GRUPO SET Cupo_maximo=20 WHERE Cupo_maximo IS NULL OR Cupo_maximo<=0;
UPDATE PAGO SET Importe=0 WHERE Importe IS NULL OR Importe<0;
UPDATE PROMOCION SET Descuento=0 WHERE Descuento IS NULL OR Descuento<0;

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- FIN V20
-- ============================================================
