-- OPCIONAL — NO EJECUTAR AUTOMÁTICAMENTE.
-- Compatible con sintaxis MariaDB/MySQL habitual; validar permisos y versión.
-- Solo crea una FUNCTION y un PROCEDURE de lectura; no modifica tablas ni datos.
-- Ver README.md antes de usar. Comprobar primero que los nombres no existan.

DELIMITER //

CREATE FUNCTION fn_vilamir_total_pagado_alumno(
    p_id_alumno INT,
    p_desde DATE,
    p_hasta DATE
)
RETURNS DECIMAL(12,2)
NOT DETERMINISTIC
READS SQL DATA
BEGIN
    DECLARE v_total DECIMAL(12,2) DEFAULT 0.00;

    SELECT COALESCE(SUM(Importe), 0.00)
      INTO v_total
      FROM PAGO
     WHERE ID_Alumno = p_id_alumno
       AND Estado = 'Pagado'
       AND Fecha BETWEEN p_desde AND p_hasta;

    RETURN v_total;
END//

CREATE PROCEDURE sp_vilamir_resumen_pagos_mes(
    IN p_anio SMALLINT,
    IN p_mes TINYINT
)
READS SQL DATA
BEGIN
    SELECT Estado,
           COUNT(*) AS Cantidad,
           COALESCE(SUM(Importe), 0.00) AS Importe_total
      FROM PAGO
     WHERE YEAR(Fecha) = p_anio
       AND MONTH(Fecha) = p_mes
     GROUP BY Estado
     ORDER BY Estado;
END//

DELIMITER ;
