# Rutinas SQL opcionales

`rutinas_informes.sql` contiene una función y un procedimiento de solo lectura para apoyar reportes. Se preparan por separado porque el volcado de referencia no contiene rutinas almacenadas y porque el hosting puede restringir `CREATE ROUTINE`.

- **No se ejecutaron** durante esta revisión.
- No crean, alteran ni eliminan tablas y no modifican filas de datos.
- Sí agregan objetos de rutina al catálogo de la base si se ejecutan; por eso requieren autorización y prueba en una copia.
- No ejecutar en InfinityFree sin confirmar permisos, compatibilidad MariaDB/MySQL y necesidad académica.
- Antes de ejecutarlos, consultar `SHOW FUNCTION STATUS` y `SHOW PROCEDURE STATUS` para evitar nombres ya existentes.
- La función requiere permiso `CREATE ROUTINE`; la política de binary logging del servidor también puede exigir privilegios adicionales.
