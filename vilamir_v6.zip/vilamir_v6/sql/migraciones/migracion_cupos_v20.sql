-- ARCHIVO: migracion_cupos_v20.sql
-- PROPÓSITO: Esquema o migración SQL relacionada con migracion cupos v20. Revisar antes de ejecutarla en una base existente.
-- IMPORTANTE: hacer copia de seguridad y revisar dependencias antes de ejecutar.

-- ============================================================
-- ACADEMIA VILAMIR - V20
-- CUPOS + LISTAS DE ESPERA + PROMOCIÓN AUTOMÁTICA
-- ============================================================
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS LISTA_ESPERA_SEMINARIO (
    ID_Espera INT AUTO_INCREMENT PRIMARY KEY,
    ID_Alumno INT NOT NULL,
    ID_Seminario INT NOT NULL,
    Fecha_solicitud TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Estado ENUM('En espera','Admitido','Cancelado') NOT NULL DEFAULT 'En espera',
    UNIQUE KEY uq_espera_sem (ID_Alumno,ID_Seminario),
    KEY idx_espera_sem_estado (ID_Seminario,Estado,Fecha_solicitud),
    KEY idx_espera_sem_alumno (ID_Alumno,Estado),
    CONSTRAINT fk_espera_sem_alumno FOREIGN KEY (ID_Alumno) REFERENCES ALUMNO(ID_Alumno) ON DELETE CASCADE,
    CONSTRAINT fk_espera_sem_evento FOREIGN KEY (ID_Seminario) REFERENCES SEMINARIO(ID_Seminario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX IF NOT EXISTS idx_espera_alumno_estado_v20 ON LISTA_ESPERA(ID_Alumno,Estado);
CREATE INDEX IF NOT EXISTS idx_iga_grupo_estado_v20 ON INSCRIPCION_GRUPO_ALUMNO(ID_Grupo,Estado,Fecha_inscripcion);
CREATE INDEX IF NOT EXISTS idx_iga_alumno_estado_v20 ON INSCRIPCION_GRUPO_ALUMNO(ID_Alumno,Estado,Fecha_inscripcion);
CREATE INDEX IF NOT EXISTS idx_inssem_seminario_estado_v20 ON INSCRIPCION_SEMINARIO(ID_Seminario,Estado,Fecha_ins);
CREATE INDEX IF NOT EXISTS idx_inssem_alumno_estado_v20 ON INSCRIPCION_SEMINARIO(ID_Alumno,Estado,Fecha_ins);

SET FOREIGN_KEY_CHECKS=1;

-- FIN V20
