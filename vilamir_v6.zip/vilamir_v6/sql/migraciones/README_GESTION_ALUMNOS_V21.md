# Gestión de alumnos y cuenta — V21

## Cambios de esta etapa

- La administración permite buscar por nombre, apellido, correo o teléfono.
- La ficha de listado muestra solo datos de contacto y fecha de nacimiento; nunca expone contraseñas ni hashes.
- La exportación CSV usa el resultado de la búsqueda actual y escapa comillas y celdas que podrían interpretarse como fórmulas.
- La edición de alumno actualiza el nombre/apellido y el correo dentro de una transacción, conservando la identidad del registro y su historial relacionado.
- En `portal.php`, la edición del perfil sigue limitada al alumno asociado a la sesión. La verificación de correo ahora compara sin distinguir mayúsculas/minúsculas.

## ¿Hace falta ejecutar SQL?

No se agrega una migración de estructura en esta etapa. El esquema consolidado ya contiene los campos utilizados por estas pantallas (`ALUMNO.Nombre`, `Apellido`, `Telefono`, `Fecha_nacimiento`, `USUARIO.Email`) y los índices existentes de apellido/nombre y correo único. Evitar una migración innecesaria reduce el riesgo en bases de datos V21 que ya tienen información.

## Seguridad y límites

- La API administrativa continúa limitada al rol Administrador.
- Los datos se consultan con sentencias preparadas y se muestran en el navegador usando `textContent`.
- La exportación CSV no incluye cédula, dirección, cobertura médica, peso, categoría, código QR ni datos de responsables.
- No se incluye un botón de borrado en el listado para evitar eliminar por accidente registros que pueden tener historial de pagos, asistencia e inscripciones.
- No ejecutar `sql/mma_systems.sql` sobre una base existente. Hacer respaldo antes de cualquier actualización de la base.
