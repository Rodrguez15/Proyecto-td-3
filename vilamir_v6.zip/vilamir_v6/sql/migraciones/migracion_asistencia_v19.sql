-- ARCHIVO: migracion_asistencia_v19.sql
-- PROPÓSITO: Esquema o migración SQL relacionada con migracion asistencia v19. Revisar antes de ejecutarla en una base existente.
-- IMPORTANTE: hacer copia de seguridad y revisar dependencias antes de ejecutar.

-- ============================================================
-- ACADEMIA VILAMIR - V19 ASISTENCIA AVANZADA
-- Ejecutar una sola vez sobre una base V18/V17 existente.
-- ============================================================

SET @col_exists := (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='ASISTENCIA' AND COLUMN_NAME='ID_Profesor'
);
SET @sql := IF(@col_exists=0,
  'ALTER TABLE ASISTENCIA ADD COLUMN ID_Profesor INT NULL AFTER ID_Horario',
  'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @idx_exists := (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='ASISTENCIA' AND INDEX_NAME='idx_asistencia_profesor_fecha'
);
SET @sql := IF(@idx_exists=0,
  'ALTER TABLE ASISTENCIA ADD INDEX idx_asistencia_profesor_fecha (ID_Profesor,Fecha)',
  'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @fk_exists := (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
  WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME='ASISTENCIA' AND CONSTRAINT_NAME='fk_asistencia_profesor'
);
SET @sql := IF(@fk_exists=0,
  'ALTER TABLE ASISTENCIA ADD CONSTRAINT fk_asistencia_profesor FOREIGN KEY (ID_Profesor) REFERENCES PROFESOR(ID_Profesor) ON DELETE SET NULL',
  'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Asignamos el profesor cuando sea posible a registros históricos.
UPDATE ASISTENCIA a
JOIN INSCRIPCION_GRUPO_PROFESOR igp ON igp.ID_Grupo=a.ID_Grupo AND igp.Estado='Activa'
SET a.ID_Profesor=igp.ID_Profesor
WHERE a.ID_Profesor IS NULL;

-- Índices útiles para reportes e historial.
SET @idx_exists := (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='ASISTENCIA' AND INDEX_NAME='idx_asistencia_grupo_estado_fecha'
);
SET @sql := IF(@idx_exists=0,
  'ALTER TABLE ASISTENCIA ADD INDEX idx_asistencia_grupo_estado_fecha (ID_Grupo,Estado,Fecha)',
  'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- V19 no crea exámenes ni niveles: la academia utiliza control práctico de asistencia.


-- V19.1: una asistencia corresponde a un grupo, alumno, fecha y horario.
-- La clave anterior no permitía registrar dos clases del mismo grupo en el mismo día.
SET @old_uq := (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='ASISTENCIA'
    AND INDEX_NAME='uq_asistencia'
);
SET @sql := IF(@old_uq>0,
  'ALTER TABLE ASISTENCIA DROP INDEX uq_asistencia',
  'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @new_uq := (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='ASISTENCIA'
    AND INDEX_NAME='uq_asistencia_horario'
);
SET @sql := IF(@new_uq=0,
  'ALTER TABLE ASISTENCIA ADD UNIQUE KEY uq_asistencia_horario (ID_Alumno,ID_Grupo,Fecha,ID_Horario)',
  'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
