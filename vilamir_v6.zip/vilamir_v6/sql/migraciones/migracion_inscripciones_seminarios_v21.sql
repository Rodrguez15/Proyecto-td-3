-- Academia VILAMIR V21
-- Asegura que exista la tabla usada por la lista de espera de seminarios.
-- Es seguro ejecutarla en bases donde la tabla ya existe.
-- Seleccionar primero la base mma_systems en phpMyAdmin.

CREATE TABLE IF NOT EXISTS LISTA_ESPERA_SEMINARIO (
    ID_Espera INT AUTO_INCREMENT PRIMARY KEY,
    ID_Alumno INT NOT NULL,
    ID_Seminario INT NOT NULL,
    Fecha_solicitud TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Estado ENUM('En espera','Admitido','Cancelado') NOT NULL DEFAULT 'En espera',
    UNIQUE KEY uq_espera_sem (ID_Alumno, ID_Seminario),
    KEY idx_espera_sem_estado (ID_Seminario, Estado, Fecha_solicitud),
    KEY idx_espera_sem_alumno (ID_Alumno, Estado),
    CONSTRAINT fk_espera_sem_alumno FOREIGN KEY (ID_Alumno)
        REFERENCES ALUMNO(ID_Alumno) ON DELETE CASCADE,
    CONSTRAINT fk_espera_sem_evento FOREIGN KEY (ID_Seminario)
        REFERENCES SEMINARIO(ID_Seminario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
