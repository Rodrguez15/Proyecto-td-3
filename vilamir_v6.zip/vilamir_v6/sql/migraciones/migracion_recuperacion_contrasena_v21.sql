-- Academia VILAMIR V21: recuperación segura de contraseña por correo.
-- Ejecutar una sola vez en la base de datos mma_systems desde phpMyAdmin.
CREATE TABLE IF NOT EXISTS RECUPERACION_CONTRASENA (
    id_recuperacion BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    id_usuario INT NOT NULL,
    token_hash CHAR(64) NOT NULL,
    creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    vence_en DATETIME NOT NULL,
    usado TINYINT(1) NOT NULL DEFAULT 0,
    PRIMARY KEY (id_recuperacion),
    UNIQUE KEY uq_recuperacion_token_hash (token_hash),
    KEY idx_recuperacion_usuario (id_usuario),
    KEY idx_recuperacion_vencimiento (vence_en),
    CONSTRAINT fk_recuperacion_usuario FOREIGN KEY (id_usuario)
        REFERENCES USUARIO (ID_Usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
