# Corrección de inscripciones a seminarios — V21

## Qué corrige
- La pantalla de seminarios muestra los mensajes de éxito y error a alumnos, no solo al administrador.
- `api/portal.php` carga las funciones compartidas de cupos y promoción de la lista de espera, evitando un error al cancelar una inscripción que libera un lugar.
- Se agrega una migración segura para asegurar la existencia de `LISTA_ESPERA_SEMINARIO`, tabla consultada por el listado y las acciones de espera.

## Instalación
1. Haz una copia de seguridad de `mma_systems`.
2. En phpMyAdmin, selecciona la base `mma_systems`.
3. Importa `migracion_inscripciones_seminarios_v21.sql`. La instrucción usa `CREATE TABLE IF NOT EXISTS`, por lo que no reemplaza una tabla que ya existe.
4. Reemplaza los archivos del proyecto incluidos en el ZIP, manteniendo tus configuraciones locales si fueran distintas.
5. Inicia sesión como alumno, abre Seminarios y eventos y prueba inscribirte en un evento futuro con cupo disponible.

## Comportamiento esperado
- Al inscribirse: aparece un mensaje de confirmación y la tarjeta pasa a «Ya estás inscripto».
- Si el evento está lleno: se ofrece la lista de espera.
- Al cancelar una inscripción activa: aparece una confirmación; si había alguien en espera, el sistema intenta promover a la primera persona de la lista.
- Si hay un error de API/base de datos, se muestra el mensaje en la página en vez de fallar silenciosamente.

La validación estática no sustituye una prueba funcional con tu servidor XAMPP y tu base de datos reales.
