-- ============================================================
-- ACADEMIA VILAMIR V21 - ÍNDICES DE ASISTENCIA POR CLASE
-- ============================================================
-- Objetivo:
--   1. Unificar el nombre de la clave única que identifica una clase.
--   2. Asegurar que una marca se identifique por alumno, grupo, fecha y horario.
--   3. Mejorar las consultas de asistencia por grupo, fecha y horario.
--
-- Requisitos: migración de asistencia V19 aplicada (columnas ID_Horario e
-- ID_Profesor presentes). Hacer respaldo y probar en una copia antes de ejecutar.
-- Este script no elimina registros ni agrega módulos de exámenes.
-- ============================================================

-- Si existe la clave antigua, se elimina el índice redundante y se conserva
-- la información. Luego se asegura la existencia de la clave normalizada.
SET @old_idx := (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ASISTENCIA'
    AND INDEX_NAME = 'uq_asistencia'
);
SET @new_idx := (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ASISTENCIA'
    AND INDEX_NAME = 'uq_asistencia_horario'
);
SET @sql := IF(@old_idx > 0,
  'ALTER TABLE ASISTENCIA DROP INDEX uq_asistencia',
  'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @new_idx := (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ASISTENCIA'
    AND INDEX_NAME = 'uq_asistencia_horario'
);
SET @sql := IF(@new_idx = 0,
  'ALTER TABLE ASISTENCIA ADD UNIQUE KEY uq_asistencia_horario (ID_Alumno, ID_Grupo, Fecha, ID_Horario)',
  'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @idx_exists := (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ASISTENCIA'
    AND INDEX_NAME = 'idx_asistencia_grupo_fecha_horario'
);
SET @sql := IF(@idx_exists = 0,
  'ALTER TABLE ASISTENCIA ADD INDEX idx_asistencia_grupo_fecha_horario (ID_Grupo, Fecha, ID_Horario)',
  'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
