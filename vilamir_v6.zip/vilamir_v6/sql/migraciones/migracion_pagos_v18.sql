-- ARCHIVO: migracion_pagos_v18.sql
-- PROPÓSITO: Esquema o migración SQL relacionada con migracion pagos v18. Revisar antes de ejecutarla en una base existente.
-- IMPORTANTE: hacer copia de seguridad y revisar dependencias antes de ejecutar.

-- ============================================================
-- ACADEMIA VILAMIR - V18 PAGOS Y COMPROBANTES
-- Para bases existentes que ya vienen de V17.
-- NO elimina pagos existentes.
-- ============================================================

USE mma_systems;

SET @db = DATABASE();

-- Agrega columnas solo si todavía no existen.
SET @sql = IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='PAGO' AND COLUMN_NAME='Numero_comprobante')=0,
    'ALTER TABLE PAGO ADD COLUMN Numero_comprobante VARCHAR(40) NULL AFTER Metodo_pago',
    'SELECT 1'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='PAGO' AND COLUMN_NAME='Anulado_en')=0,
    'ALTER TABLE PAGO ADD COLUMN Anulado_en DATETIME NULL AFTER Numero_comprobante',
    'SELECT 1'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='PAGO' AND COLUMN_NAME='Anulado_por')=0,
    'ALTER TABLE PAGO ADD COLUMN Anulado_por INT NULL AFTER Anulado_en',
    'SELECT 1'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='PAGO' AND COLUMN_NAME='Motivo_anulacion')=0,
    'ALTER TABLE PAGO ADD COLUMN Motivo_anulacion VARCHAR(255) NULL AFTER Anulado_por',
    'SELECT 1'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Genera códigos para pagos históricos que todavía no tenían comprobante.
UPDATE PAGO
SET Numero_comprobante = CONCAT('VIL-', DATE_FORMAT(Fecha,'%Y-%m-%d'), '-', LPAD(ID_Pago,6,'0'))
WHERE Numero_comprobante IS NULL OR Numero_comprobante='';

-- Índices/relaciones V18.
SET @sql = IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='PAGO' AND INDEX_NAME='uq_pago_comprobante')=0,
    'ALTER TABLE PAGO ADD UNIQUE KEY uq_pago_comprobante (Numero_comprobante)',
    'SELECT 1'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='PAGO' AND INDEX_NAME='idx_pago_anulado')=0,
    'ALTER TABLE PAGO ADD KEY idx_pago_anulado (Estado,Anulado_en)',
    'SELECT 1'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Agrega FK al usuario que anuló, solo si no existe.
SET @sql = IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA=@db AND TABLE_NAME='PAGO' AND CONSTRAINT_NAME='fk_pago_anulado_por')=0,
    'ALTER TABLE PAGO ADD CONSTRAINT fk_pago_anulado_por FOREIGN KEY (Anulado_por) REFERENCES USUARIO(ID_Usuario) ON DELETE SET NULL',
    'SELECT 1'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Normaliza estados históricos conocidos.
UPDATE PAGO SET Estado='Anulado' WHERE LOWER(TRIM(Estado)) IN ('anulado','cancelado');
UPDATE PAGO SET Estado='Pagado' WHERE LOWER(TRIM(Estado)) IN ('pagado','pago','abonado');
UPDATE PAGO SET Estado='Pendiente' WHERE LOWER(TRIM(Estado)) IN ('pendiente','debe','adeudado');

