# VILAMIR — referencia histórica de SQL V17

La carpeta SQL quedó reorganizada para que sea más fácil mantener la base de datos.

## Instalación nueva

Usar:

`mma_systems.sql`

El esquema consolidado actual está en `mma_systems.sql` y corresponde a V21. Este documento describe la etapa histórica V17.

## Script histórico — no ejecutar como parte de V21

El archivo `legacy_no_ejecutar/NO_EJECUTAR_migracion_v17_limpieza.sql` se conserva únicamente como referencia para instalaciones antiguas. No es una migración normal de V21 y puede eliminar tablas heredadas, incluidas tablas antiguas de exámenes. No lo ejecutes sin identificar previamente el esquema real, preparar y verificar un backup, y revisar cada sentencia con un técnico.

Históricamente, el script:

- completa columnas faltantes;
- migra las antiguas `CLASE` hacia `DISCIPLINA` cuando existen;
- elimina `CLASE` e `INSCRIPCION_CLASE` porque el sistema actual trabaja con `DISCIPLINA → GRUPO → HORARIO`;
- elimina `EXAMEN` y `NIVEL_ALUMNO`;
- conserva `INSCRIPCION_DISCIPLINA`, que todavía utiliza el sistema;
- crea índices para las consultas más frecuentes;
- intenta reparar el vínculo de profesores antiguos con `USUARIO` mediante el correo.

## Modelo vigente

`USUARIO`
→ `ALUMNO / PROFESOR`

`DISCIPLINA`
→ `GRUPO`
→ `HORARIO`
→ `INSCRIPCION_GRUPO_ALUMNO / INSCRIPCION_GRUPO_PROFESOR`

Además:

- `INSCRIPCION_DISCIPLINA`
- `SEMINARIO → INSCRIPCION_SEMINARIO`
- `PAGO`
- `PROMOCION`
- `ASISTENCIA`
- `LISTA_ESPERA`
- `CERTIFICADO`
- `GALERIA_EVENTO`
- `NOTIFICACION`
- `ACTIVIDAD_SISTEMA`

## Exámenes

No forman parte de las funciones activas del proyecto. No agregues módulos de exámenes ni ejecutes el script histórico sobre una base actual.

## Historial

Las migraciones se organizan en `sql/migraciones/`. No ejecutes todas automáticamente: elegí solo las que correspondan a la versión real de tu base y revisá primero las instrucciones de `sql/README.md`.
