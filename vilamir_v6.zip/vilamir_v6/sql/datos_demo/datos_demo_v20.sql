-- ============================================================
-- ACADEMIA VILAMIR - DATOS DE DEMOSTRACIÓN V20
-- ============================================================
-- PROPÓSITO:
--   Cargar cuentas de prueba, alumnos, profesores, disciplinas,
--   grupos, horarios y seminarios/eventos para probar el sistema.
--
-- IMPORTANTE:
--   1. Seleccionar primero la base de datos mma_systems.
--   2. Este archivo NO borra tablas ni registros.
--   3. Está preparado para poder ejecutarse más de una vez sin
--      duplicar los registros identificados por sus emails/nombres.
--   4. Los datos personales son ficticios. Las cédulas usan códigos
--      DEMO, no son documentos de identidad reales.
--   5. Todas las cuentas demo usan la contraseña: Vilamir2026!
--   6. Cambiar las contraseñas antes de usar el sistema públicamente.
--
-- Compatible con el esquema consolidado de sql/mma_systems.sql.
-- ============================================================

USE mma_systems;
SET NAMES utf8mb4;

START TRANSACTION;

-- ------------------------------------------------------------
-- 1. CUENTAS DE ALUMNOS
-- ------------------------------------------------------------
-- El hash corresponde a la contraseña demo Vilamir2026! y es
-- compatible con password_verify() de PHP.
-- En caso de que el email ya exista, no se cambia su contraseña.

INSERT INTO USUARIO (Email, Contraseña, Rol) VALUES
('ana.silva.demo@example.com', '$2y$12$z1DuJhRwn4vDQuR.YgeC.esWizxM2U.qlrm5tEs0NcwyORb50i6VS', 'Alumno'),
('bruno.pereira.demo@example.com', '$2y$12$z1DuJhRwn4vDQuR.YgeC.esWizxM2U.qlrm5tEs0NcwyORb50i6VS', 'Alumno'),
('camila.rodriguez.demo@example.com', '$2y$12$z1DuJhRwn4vDQuR.YgeC.esWizxM2U.qlrm5tEs0NcwyORb50i6VS', 'Alumno'),
('diego.mendez.demo@example.com', '$2y$12$z1DuJhRwn4vDQuR.YgeC.esWizxM2U.qlrm5tEs0NcwyORb50i6VS', 'Alumno'),
('emilia.torres.demo@example.com', '$2y$12$z1DuJhRwn4vDQuR.YgeC.esWizxM2U.qlrm5tEs0NcwyORb50i6VS', 'Alumno'),
('facundo.costa.demo@example.com', '$2y$12$z1DuJhRwn4vDQuR.YgeC.esWizxM2U.qlrm5tEs0NcwyORb50i6VS', 'Alumno'),
('guadalupe.sosa.demo@example.com', '$2y$12$z1DuJhRwn4vDQuR.YgeC.esWizxM2U.qlrm5tEs0NcwyORb50i6VS', 'Alumno'),
('ignacio.martinez.demo@example.com', '$2y$12$z1DuJhRwn4vDQuR.YgeC.esWizxM2U.qlrm5tEs0NcwyORb50i6VS', 'Alumno'),
('julieta.fernandez.demo@example.com', '$2y$12$z1DuJhRwn4vDQuR.YgeC.esWizxM2U.qlrm5tEs0NcwyORb50i6VS', 'Alumno'),
('lautaro.gomez.demo@example.com', '$2y$12$z1DuJhRwn4vDQuR.YgeC.esWizxM2U.qlrm5tEs0NcwyORb50i6VS', 'Alumno')
ON DUPLICATE KEY UPDATE Rol = VALUES(Rol);

-- Crear la ficha de alumno solo si todavía no existe para esa cuenta.
INSERT INTO ALUMNO (ID_Usuario, Nombre, Apellido, Cedula, Fecha_nacimiento, Direccion, Telefono, Cobertura_medica, Peso, Categoria)
SELECT u.ID_Usuario, datos.Nombre, datos.Apellido, datos.Cedula, datos.Fecha_nacimiento,
       datos.Direccion, datos.Telefono, datos.Cobertura_medica, datos.Peso, datos.Categoria
FROM (
    SELECT 'ana.silva.demo@example.com' Email, 'Ana' Nombre, 'Silva' Apellido, 'DEMO-ALU-001' Cedula, '2002-04-12' Fecha_nacimiento, 'Las Piedras, Canelones' Direccion, '099 100 001' Telefono, 'Emergencia Médica (demo)' Cobertura_medica, 58.00 Peso, 'Pluma' Categoria
    UNION ALL SELECT 'bruno.pereira.demo@example.com', 'Bruno', 'Pereira', 'DEMO-ALU-002', '1998-09-21', 'La Paz, Canelones', '099 100 002', 'ASSE (demo)', 74.00, 'Mediano'
    UNION ALL SELECT 'camila.rodriguez.demo@example.com', 'Camila', 'Rodríguez', 'DEMO-ALU-003', '2004-01-30', 'Progreso, Canelones', '099 100 003', 'Sin dato (demo)', 61.00, 'Ligero'
    UNION ALL SELECT 'diego.mendez.demo@example.com', 'Diego', 'Méndez', 'DEMO-ALU-004', '1995-07-08', 'Montevideo', '099 100 004', 'Emergencia Médica (demo)', 82.00, 'Semipesado'
    UNION ALL SELECT 'emilia.torres.demo@example.com', 'Emilia', 'Torres', 'DEMO-ALU-005', '2001-11-16', 'Las Piedras, Canelones', '099 100 005', 'ASSE (demo)', 55.00, 'Mosca'
    UNION ALL SELECT 'facundo.costa.demo@example.com', 'Facundo', 'Costa', 'DEMO-ALU-006', '1999-03-03', 'Canelones', '099 100 006', 'Sin dato (demo)', 77.00, 'Mediano'
    UNION ALL SELECT 'guadalupe.sosa.demo@example.com', 'Guadalupe', 'Sosa', 'DEMO-ALU-007', '2005-06-25', 'La Paz, Canelones', '099 100 007', 'Emergencia Médica (demo)', 52.00, 'Pluma'
    UNION ALL SELECT 'ignacio.martinez.demo@example.com', 'Ignacio', 'Martínez', 'DEMO-ALU-008', '1997-12-10', 'Montevideo', '099 100 008', 'ASSE (demo)', 88.00, 'Pesado'
    UNION ALL SELECT 'julieta.fernandez.demo@example.com', 'Julieta', 'Fernández', 'DEMO-ALU-009', '2003-02-14', 'Las Piedras, Canelones', '099 100 009', 'Sin dato (demo)', 60.00, 'Ligero'
    UNION ALL SELECT 'lautaro.gomez.demo@example.com', 'Lautaro', 'Gómez', 'DEMO-ALU-010', '2000-08-19', 'Progreso, Canelones', '099 100 010', 'Emergencia Médica (demo)', 71.00, 'Welter'
) AS datos
INNER JOIN USUARIO u ON u.Email = datos.Email
LEFT JOIN ALUMNO existente ON existente.ID_Usuario = u.ID_Usuario
WHERE existente.ID_Alumno IS NULL;

-- ------------------------------------------------------------
-- 2. CUENTAS Y FICHAS DE LOS DOS PROFESORES
-- ------------------------------------------------------------
INSERT INTO USUARIO (Email, Contraseña, Rol) VALUES
('martin.acosta.prof.demo@example.com', '$2y$12$z1DuJhRwn4vDQuR.YgeC.esWizxM2U.qlrm5tEs0NcwyORb50i6VS', 'Profesor'),
('valentina.suarez.prof.demo@example.com', '$2y$12$z1DuJhRwn4vDQuR.YgeC.esWizxM2U.qlrm5tEs0NcwyORb50i6VS', 'Profesor')
ON DUPLICATE KEY UPDATE Rol = VALUES(Rol);

INSERT INTO PROFESOR (ID_Usuario, Nombre, Apellido, Telefono, Cedula, Direccion, Especialidad, Email)
SELECT u.ID_Usuario, datos.Nombre, datos.Apellido, datos.Telefono, datos.Cedula,
       datos.Direccion, datos.Especialidad, datos.Email
FROM (
    SELECT 'martin.acosta.prof.demo@example.com' Email, 'Martín' Nombre, 'Acosta' Apellido, '099 200 001' Telefono, 'DEMO-PROF-001' Cedula, 'Las Piedras, Canelones' Direccion, 'MMA y Kickboxing' Especialidad
    UNION ALL SELECT 'valentina.suarez.prof.demo@example.com', 'Valentina', 'Suárez', '099 200 002', 'DEMO-PROF-002', 'Montevideo', 'Muay Thai y Jiu-jitsu brasileño (BJJ)'
) AS datos
INNER JOIN USUARIO u ON u.Email = datos.Email
LEFT JOIN PROFESOR p ON p.Email = datos.Email
WHERE p.ID_Profesor IS NULL;

-- ------------------------------------------------------------
-- 3. LAS CUATRO DISCIPLINAS SOLICITADAS
-- ------------------------------------------------------------
-- Se utiliza la escritura habitual "Kickboxing" y "Muay Thai".

INSERT INTO DISCIPLINA (Nombre, Descripcion, Costo) VALUES
('MMA', 'Artes marciales mixtas: combinación de golpeo, lucha y trabajo en el suelo.', 1800.00),
('Kickboxing', 'Disciplina de combate de pie que combina puños y patadas.', 1600.00),
('Muay Thai', 'Arte marcial tailandés con puños, patadas, rodillas y codos.', 1700.00),
('Jiu-jitsu brasileño (BJJ)', 'Lucha de agarres, controles, posiciones y técnicas de sumisión.', 1800.00)
ON DUPLICATE KEY UPDATE Descripcion = VALUES(Descripcion);

-- Asignar disciplinas a los profesores demo sin duplicar vínculos.
INSERT IGNORE INTO PROFESOR_DISCIPLINA (ID_Profesor, ID_Disciplina)
SELECT p.ID_Profesor, d.ID_Disciplina
FROM PROFESOR p
JOIN DISCIPLINA d
WHERE (p.Email = 'martin.acosta.prof.demo@example.com' AND d.Nombre IN ('MMA', 'Kickboxing'))
   OR (p.Email = 'valentina.suarez.prof.demo@example.com' AND d.Nombre IN ('Muay Thai', 'Jiu-jitsu brasileño (BJJ)'));

-- ------------------------------------------------------------
-- 4. GRUPOS Y HORARIOS DE EJEMPLO
-- ------------------------------------------------------------
-- Se incluyen para que las disciplinas tengan grupos disponibles.

INSERT INTO GRUPO (Nombre, ID_Disciplina, Cupo_maximo, Nivel, Descripcion)
SELECT datos.Nombre, d.ID_Disciplina, datos.Cupo_maximo, datos.Nivel, datos.Descripcion
FROM (
    SELECT 'MMA - Principiantes' Nombre, 'MMA' Disciplina, 20 Cupo_maximo, 'Principiante' Nivel, 'Grupo de iniciación en artes marciales mixtas.' Descripcion
    UNION ALL SELECT 'Kickboxing - Mixto', 'Kickboxing', 20, 'Todos', 'Entrenamiento técnico y físico de kickboxing.'
    UNION ALL SELECT 'Muay Thai - Principiantes', 'Muay Thai', 18, 'Principiante', 'Fundamentos técnicos de Muay Thai.'
    UNION ALL SELECT 'BJJ - Fundamentos', 'Jiu-jitsu brasileño (BJJ)', 18, 'Principiante', 'Posiciones, escapes y fundamentos de BJJ.'
) AS datos
JOIN DISCIPLINA d ON d.Nombre = datos.Disciplina
LEFT JOIN GRUPO g ON g.Nombre = datos.Nombre AND g.ID_Disciplina = d.ID_Disciplina
WHERE g.ID_Grupo IS NULL;

-- Vincular cada profesor con sus grupos correspondientes.
INSERT IGNORE INTO INSCRIPCION_GRUPO_PROFESOR (ID_Profesor, ID_Grupo, Estado)
SELECT p.ID_Profesor, g.ID_Grupo, 'Activa'
FROM PROFESOR p
JOIN GRUPO g
JOIN DISCIPLINA d ON d.ID_Disciplina = g.ID_Disciplina
WHERE (p.Email = 'martin.acosta.prof.demo@example.com' AND d.Nombre IN ('MMA', 'Kickboxing'))
   OR (p.Email = 'valentina.suarez.prof.demo@example.com' AND d.Nombre IN ('Muay Thai', 'Jiu-jitsu brasileño (BJJ)'));

-- Agregar horarios solo cuando no exista ya ese horario para el grupo.
INSERT INTO HORARIO (ID_Grupo, Dia, Hora_inicio, Hora_fin)
SELECT g.ID_Grupo, datos.Dia, datos.Hora_inicio, datos.Hora_fin
FROM (
    SELECT 'MMA - Principiantes' Grupo, 'Lunes' Dia, '18:00:00' Hora_inicio, '19:30:00' Hora_fin
    UNION ALL SELECT 'MMA - Principiantes', 'Miércoles', '18:00:00', '19:30:00'
    UNION ALL SELECT 'Kickboxing - Mixto', 'Martes', '19:00:00', '20:30:00'
    UNION ALL SELECT 'Kickboxing - Mixto', 'Jueves', '19:00:00', '20:30:00'
    UNION ALL SELECT 'Muay Thai - Principiantes', 'Lunes', '19:30:00', '21:00:00'
    UNION ALL SELECT 'Muay Thai - Principiantes', 'Viernes', '18:00:00', '19:30:00'
    UNION ALL SELECT 'BJJ - Fundamentos', 'Martes', '18:00:00', '19:30:00'
    UNION ALL SELECT 'BJJ - Fundamentos', 'Jueves', '18:00:00', '19:30:00'
) AS datos
JOIN GRUPO g ON g.Nombre = datos.Grupo
LEFT JOIN HORARIO h ON h.ID_Grupo = g.ID_Grupo AND h.Dia = datos.Dia
                     AND h.Hora_inicio = datos.Hora_inicio AND h.Hora_fin = datos.Hora_fin
WHERE h.ID_Horario IS NULL;

-- ------------------------------------------------------------
-- 5. INSCRIPCIONES DE EJEMPLO A LOS GRUPOS
-- ------------------------------------------------------------
-- Estas relaciones permiten probar la vista "Mis clases".

INSERT IGNORE INTO INSCRIPCION_DISCIPLINA (ID_Alumno, ID_Disciplina, Fecha_ins, Estado)
SELECT a.ID_Alumno, d.ID_Disciplina, CURRENT_DATE, 'Activa'
FROM ALUMNO a
JOIN USUARIO u ON u.ID_Usuario = a.ID_Usuario
JOIN DISCIPLINA d
WHERE (u.Email IN ('ana.silva.demo@example.com', 'bruno.pereira.demo@example.com', 'diego.mendez.demo@example.com') AND d.Nombre = 'MMA')
   OR (u.Email IN ('camila.rodriguez.demo@example.com', 'emilia.torres.demo@example.com', 'lautaro.gomez.demo@example.com') AND d.Nombre = 'Kickboxing')
   OR (u.Email IN ('facundo.costa.demo@example.com', 'guadalupe.sosa.demo@example.com') AND d.Nombre = 'Muay Thai')
   OR (u.Email IN ('ignacio.martinez.demo@example.com', 'julieta.fernandez.demo@example.com') AND d.Nombre = 'Jiu-jitsu brasileño (BJJ)');

INSERT IGNORE INTO INSCRIPCION_GRUPO_ALUMNO (ID_Alumno, ID_Grupo, Estado)
SELECT a.ID_Alumno, g.ID_Grupo, 'Activa'
FROM ALUMNO a
JOIN USUARIO u ON u.ID_Usuario = a.ID_Usuario
JOIN GRUPO g ON
    (g.Nombre = 'MMA - Principiantes' AND u.Email IN ('ana.silva.demo@example.com', 'bruno.pereira.demo@example.com', 'diego.mendez.demo@example.com')) OR
    (g.Nombre = 'Kickboxing - Mixto' AND u.Email IN ('camila.rodriguez.demo@example.com', 'emilia.torres.demo@example.com', 'lautaro.gomez.demo@example.com')) OR
    (g.Nombre = 'Muay Thai - Principiantes' AND u.Email IN ('facundo.costa.demo@example.com', 'guadalupe.sosa.demo@example.com')) OR
    (g.Nombre = 'BJJ - Fundamentos' AND u.Email IN ('ignacio.martinez.demo@example.com', 'julieta.fernandez.demo@example.com'));

-- ------------------------------------------------------------
-- 6. SEMINARIOS Y EVENTOS DE EJEMPLO
-- ------------------------------------------------------------
-- Las fechas son futuras respecto a octubre de 2026.

INSERT INTO SEMINARIO (Nombre, Titulo, Descripcion, Costo, Ponente, Fecha, Hora, Lugar, Cupo)
SELECT datos.Nombre, datos.Titulo, datos.Descripcion, datos.Costo, datos.Ponente,
       datos.Fecha, datos.Hora, datos.Lugar, datos.Cupo
FROM (
    SELECT 'Seminario de MMA: transición de golpeo a lucha' Nombre,
           'Transiciones de MMA' Titulo,
           'Trabajo técnico de combinaciones, derribos y control en el suelo. Actividad de demostración.' Descripcion,
           650.00 Costo, 'Martín Acosta (demo)' Ponente,
           '2026-11-14' Fecha, '10:00:00' Hora, 'Academia VILAMIR - Dojo principal' Lugar, 25 Cupo
    UNION ALL SELECT 'Workshop de Kickboxing: defensa y contraataque',
           'Defensa y contraataque',
           'Taller técnico de guardia, desplazamientos, defensa y respuestas seguras.',
           500.00, 'Martín Acosta (demo)', '2026-11-28', '15:00:00', 'Academia VILAMIR - Dojo principal', 24
    UNION ALL SELECT 'Seminario de Muay Thai: clinch y rodillas',
           'Clinch y rodillas',
           'Práctica técnica de postura, control del clinch y rodillazos con trabajo supervisado.',
           700.00, 'Valentina Suárez (demo)', '2026-12-12', '10:30:00', 'Academia VILAMIR - Dojo principal', 20
    UNION ALL SELECT 'Open Mat de Jiu-jitsu brasileño (BJJ)',
           'Open Mat de BJJ',
           'Encuentro de práctica guiada, repaso de posiciones y entrenamiento entre compañeros.',
           400.00, 'Valentina Suárez (demo)', '2027-01-16', '16:00:00', 'Academia VILAMIR - Dojo principal', 30
) AS datos
LEFT JOIN SEMINARIO s ON s.Nombre = datos.Nombre
WHERE s.ID_Seminario IS NULL;

COMMIT;

-- ------------------------------------------------------------
-- 7. CONSULTAS PARA COMPROBAR LA CARGA
-- ------------------------------------------------------------
-- Ejecutar estas consultas después de cargar el archivo si se desea
-- comprobar la cantidad de registros de demostración.

SELECT 'Alumnos demo' AS Tipo, COUNT(*) AS Cantidad
FROM ALUMNO a JOIN USUARIO u ON u.ID_Usuario = a.ID_Usuario
WHERE u.Email LIKE '%.demo@example.com' AND u.Rol = 'Alumno'
UNION ALL
SELECT 'Profesores demo', COUNT(*)
FROM PROFESOR WHERE Email LIKE '%.prof.demo@example.com'
UNION ALL
SELECT 'Disciplinas solicitadas', COUNT(*)
FROM DISCIPLINA WHERE Nombre IN ('MMA', 'Kickboxing', 'Muay Thai', 'Jiu-jitsu brasileño (BJJ)')
UNION ALL
SELECT 'Seminarios/eventos demo', COUNT(*)
FROM SEMINARIO WHERE Nombre IN (
    'Seminario de MMA: transición de golpeo a lucha',
    'Workshop de Kickboxing: defensa y contraataque',
    'Seminario de Muay Thai: clinch y rodillas',
    'Open Mat de Jiu-jitsu brasileño (BJJ)'
);
