# Recuperación de contraseña — Academia VILAMIR V21

## Qué incorpora
- Enlace «¿Olvidaste tu contraseña?» en el inicio de sesión.
- Recuperación por correo para cuentas con rol Alumno o Profesor.
- Token aleatorio almacenado solo como hash, válido durante 60 minutos y de un solo uso.
- Contraseña nueva guardada mediante `password_hash()` y validada con mínimo de 8 caracteres.
- Mensaje genérico para no revelar si una dirección está registrada.

## 1. Aplicar la migración de base de datos
1. Haz una copia de seguridad de la base de datos `mma_systems`.
2. Abre phpMyAdmin y selecciona `mma_systems`.
3. Entra en **Importar** y ejecuta `sql/migraciones/migracion_recuperacion_contrasena_v21.sql`.
4. Comprueba que se creó la tabla `RECUPERACION_CONTRASENA`.

La migración no elimina ni modifica las tablas existentes.

## 2. Configurar el envío de correos
El proyecto usa la función `mail()` de PHP. En una instalación nueva de XAMPP, el envío suele requerir configuración SMTP; sin ella, la página puede mostrar la respuesta genérica, pero el correo no llegará.

Configura el envío saliente de PHP en `php.ini`/el servidor de correo según tu proveedor. Para producción, utiliza un servidor SMTP autenticado y un remitente válido. Define también estas variables de entorno del servidor:

- `VILAMIR_MAIL_FROM`: dirección remitente válida, por ejemplo `academia@tu-dominio.uy`.
- `VILAMIR_BASE_URL`: URL pública base del proyecto, sin barra final, por ejemplo `https://tu-dominio.uy` o `http://localhost/vilamir_v3` para pruebas locales.

No publiques credenciales SMTP en el código ni en este ZIP. Reinicia Apache después de modificar la configuración de PHP. Si tu hosting no permite `mail()`, habrá que integrar una biblioteca SMTP autenticada (por ejemplo PHPMailer) con las credenciales guardadas fuera del directorio público.

## 3. Prueba funcional
1. Usa una cuenta de prueba con rol Alumno o Profesor y un correo al que tengas acceso.
2. En `login.html`, pulsa «¿Olvidaste tu contraseña?» e introduce ese correo.
3. Abre el correo y entra al enlace recibido antes de que pasen 60 minutos.
4. Guarda una contraseña nueva de al menos 8 caracteres e inicia sesión con ella.
5. Comprueba que el mismo enlace ya no se puede volver a utilizar.

## Seguridad
El correo de recuperación no incluye la contraseña actual. La contraseña solo cambia después de validar un token vigente. Los errores técnicos se registran en el log del servidor y no se muestran al usuario.
