-- *********************************************************************
-- ARCHIVO HISTORICO POTENCIALMENTE DESTRUCTIVO: NO EJECUTAR EN V18-V21
-- Puede eliminar tablas heredadas, incluidas EXAMEN y NIVEL_ALUMNO.
-- Se conserva solo como referencia para instalaciones antiguas verificadas.
-- Antes de cualquier uso: identificar el esquema, revisar cada sentencia
-- y verificar un backup restaurable. No ejecutar en producción.
-- *********************************************************************

-- ARCHIVO: migracion_v17_limpieza.sql
-- PROPÓSITO: Esquema o migración SQL relacionada con migracion v17 limpieza. Revisar antes de ejecutarla en una base existente.
-- IMPORTANTE: hacer copia de seguridad y revisar dependencias antes de ejecutar.

-- ============================================================
-- ACADEMIA VILAMIR - MIGRACIÓN V17
-- Limpieza de una instalación existente.
--
-- Ejecutar sobre una base V4.x/V14-V16 ya funcional.
-- RECOMENDACIÓN: realizar un backup de mma_systems antes.
-- ============================================================

USE mma_systems;
SET NAMES utf8mb4;

-- ------------------------------------------------------------
-- 1. Completar columnas que puedan faltar en instalaciones antiguas
-- ------------------------------------------------------------
ALTER TABLE ALUMNO ADD COLUMN IF NOT EXISTS Cedula VARCHAR(30) NULL;
ALTER TABLE ALUMNO ADD COLUMN IF NOT EXISTS Fecha_nacimiento DATE NULL;
ALTER TABLE ALUMNO ADD COLUMN IF NOT EXISTS Direccion VARCHAR(255) NULL;
ALTER TABLE ALUMNO ADD COLUMN IF NOT EXISTS Telefono VARCHAR(40) NULL;
ALTER TABLE ALUMNO ADD COLUMN IF NOT EXISTS Cobertura_medica VARCHAR(150) NULL;
ALTER TABLE ALUMNO ADD COLUMN IF NOT EXISTS Peso DECIMAL(6,2) NULL;
ALTER TABLE ALUMNO ADD COLUMN IF NOT EXISTS Categoria VARCHAR(80) NULL;
ALTER TABLE ALUMNO ADD COLUMN IF NOT EXISTS Codigo_qr VARCHAR(100) NULL;

ALTER TABLE PROFESOR ADD COLUMN IF NOT EXISTS ID_Usuario INT NULL;
ALTER TABLE PROFESOR ADD COLUMN IF NOT EXISTS Telefono VARCHAR(40) NULL;
ALTER TABLE PROFESOR ADD COLUMN IF NOT EXISTS Cedula VARCHAR(30) NULL;
ALTER TABLE PROFESOR ADD COLUMN IF NOT EXISTS Direccion VARCHAR(255) NULL;
ALTER TABLE PROFESOR ADD COLUMN IF NOT EXISTS Especialidad VARCHAR(150) NULL;
ALTER TABLE PROFESOR ADD COLUMN IF NOT EXISTS Email VARCHAR(150) NULL;

ALTER TABLE GRUPO ADD COLUMN IF NOT EXISTS ID_Disciplina INT NULL;
ALTER TABLE GRUPO ADD COLUMN IF NOT EXISTS Cupo_maximo INT NOT NULL DEFAULT 20;
ALTER TABLE GRUPO ADD COLUMN IF NOT EXISTS Nivel VARCHAR(30) NOT NULL DEFAULT 'Principiante';
ALTER TABLE GRUPO ADD COLUMN IF NOT EXISTS Descripcion TEXT NULL;

ALTER TABLE HORARIO ADD COLUMN IF NOT EXISTS ID_Grupo INT NULL;
ALTER TABLE HORARIO ADD COLUMN IF NOT EXISTS Dia VARCHAR(20) NULL;
ALTER TABLE HORARIO ADD COLUMN IF NOT EXISTS Hora_inicio TIME NULL;
ALTER TABLE HORARIO ADD COLUMN IF NOT EXISTS Hora_fin TIME NULL;

ALTER TABLE SEMINARIO ADD COLUMN IF NOT EXISTS Nombre VARCHAR(150) NULL;
ALTER TABLE SEMINARIO ADD COLUMN IF NOT EXISTS Descripcion TEXT NULL;
ALTER TABLE SEMINARIO ADD COLUMN IF NOT EXISTS Costo DECIMAL(10,2) NOT NULL DEFAULT 0;
ALTER TABLE SEMINARIO ADD COLUMN IF NOT EXISTS Hora TIME NULL;
ALTER TABLE SEMINARIO ADD COLUMN IF NOT EXISTS Lugar VARCHAR(255) NULL;
ALTER TABLE SEMINARIO ADD COLUMN IF NOT EXISTS Cupo INT NULL;

ALTER TABLE PAGO ADD COLUMN IF NOT EXISTS Fecha_vencimiento DATE NULL;
ALTER TABLE NOTIFICACION ADD COLUMN IF NOT EXISTS Leida TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE PROMOCION ADD COLUMN IF NOT EXISTS Fecha_inicio DATE NULL;
ALTER TABLE PROMOCION ADD COLUMN IF NOT EXISTS Fecha_fin DATE NULL;
ALTER TABLE PROMOCION ADD COLUMN IF NOT EXISTS Activa TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE PROMOCION ADD COLUMN IF NOT EXISTS Imagen VARCHAR(255) NULL;

-- ------------------------------------------------------------
-- 2. Normalizar datos antes de limpiar tablas obsoletas
-- ------------------------------------------------------------
UPDATE SEMINARIO
SET Nombre=COALESCE(NULLIF(Nombre,''),NULLIF(Titulo,''),'Evento')
WHERE Nombre IS NULL OR Nombre='';

UPDATE GRUPO
SET Cupo_maximo=20
WHERE Cupo_maximo IS NULL OR Cupo_maximo<=0;

UPDATE GRUPO
SET Nivel='Principiante'
WHERE Nivel IS NULL OR Nivel='';

UPDATE ALUMNO
SET Codigo_qr=CONCAT(
    'VIL-',ID_Alumno,'-',
    UPPER(SUBSTRING(MD5(CONCAT(ID_Alumno,'-',COALESCE(ID_Usuario,0),'-VILAMIR')),1,10))
)
WHERE Codigo_qr IS NULL OR Codigo_qr='';

-- Migrar clases antiguas a disciplinas antes de eliminar CLASE.
CREATE TABLE IF NOT EXISTS DISCIPLINA (
    ID_Disciplina INT AUTO_INCREMENT PRIMARY KEY,
    Nombre VARCHAR(150) NOT NULL,
    Descripcion TEXT NULL,
    Costo DECIMAL(10,2) NOT NULL DEFAULT 0
) ENGINE=InnoDB;

INSERT INTO DISCIPLINA (Nombre,Descripcion,Costo)
SELECT c.Nombre,
       CONCAT('Migrado desde la estructura antigua CLASE. Días: ',c.Dias,' | Horario: ',c.Horario),
       0
FROM CLASE c
LEFT JOIN DISCIPLINA d ON d.Nombre=c.Nombre
WHERE d.ID_Disciplina IS NULL;

-- ------------------------------------------------------------
-- 3. Eliminar estructuras que ya no forman parte del sistema
-- ------------------------------------------------------------
-- El proyecto actual no utiliza CLASE ni INSCRIPCION_CLASE.
DROP TABLE IF EXISTS INSCRIPCION_CLASE;
DROP TABLE IF EXISTS CLASE;

-- No existen exámenes ni niveles de examen en VILAMIR.
DROP TABLE IF EXISTS EXAMEN;
DROP TABLE IF EXISTS NIVEL_ALUMNO;

-- ------------------------------------------------------------
-- 4. Índices principales
-- ------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_alumno_usuario_v17 ON ALUMNO(ID_Usuario);
CREATE INDEX IF NOT EXISTS idx_profesor_usuario_v17 ON PROFESOR(ID_Usuario);
CREATE INDEX IF NOT EXISTS idx_grupo_disciplina_v17 ON GRUPO(ID_Disciplina);
CREATE INDEX IF NOT EXISTS idx_horario_grupo_v17 ON HORARIO(ID_Grupo);
CREATE INDEX IF NOT EXISTS idx_pago_alumno_fecha_v17 ON PAGO(ID_Alumno,Fecha,ID_Pago);
CREATE INDEX IF NOT EXISTS idx_pago_estado_fecha_v17 ON PAGO(Estado,Fecha,Fecha_vencimiento);
CREATE INDEX IF NOT EXISTS idx_insdisc_alumno_estado_v17 ON INSCRIPCION_DISCIPLINA(ID_Alumno,Estado);
CREATE INDEX IF NOT EXISTS idx_insdisc_disciplina_estado_v17 ON INSCRIPCION_DISCIPLINA(ID_Disciplina,Estado);
CREATE INDEX IF NOT EXISTS idx_iga_grupo_estado_v17 ON INSCRIPCION_GRUPO_ALUMNO(ID_Grupo,Estado);
CREATE INDEX IF NOT EXISTS idx_iga_alumno_estado_v17 ON INSCRIPCION_GRUPO_ALUMNO(ID_Alumno,Estado);
CREATE INDEX IF NOT EXISTS idx_igp_grupo_estado_v17 ON INSCRIPCION_GRUPO_PROFESOR(ID_Grupo,Estado);
CREATE INDEX IF NOT EXISTS idx_igp_profesor_estado_v17 ON INSCRIPCION_GRUPO_PROFESOR(ID_Profesor,Estado);
CREATE INDEX IF NOT EXISTS idx_inssem_seminario_estado_v17 ON INSCRIPCION_SEMINARIO(ID_Seminario,Estado);
CREATE INDEX IF NOT EXISTS idx_inssem_alumno_estado_v17 ON INSCRIPCION_SEMINARIO(ID_Alumno,Estado);
CREATE INDEX IF NOT EXISTS idx_asistencia_grupo_fecha_v17 ON ASISTENCIA(ID_Grupo,Fecha);
CREATE INDEX IF NOT EXISTS idx_asistencia_alumno_fecha_v17 ON ASISTENCIA(ID_Alumno,Fecha);
CREATE INDEX IF NOT EXISTS idx_notificacion_alumno_lectura_v17 ON NOTIFICACION(ID_Alumno,Leida,Fecha);
CREATE INDEX IF NOT EXISTS idx_actividad_usuario_fecha_v17 ON ACTIVIDAD_SISTEMA(ID_Usuario,Fecha);

-- ------------------------------------------------------------
-- 5. Reparación de perfiles docentes antiguos
-- ------------------------------------------------------------
UPDATE PROFESOR p
JOIN USUARIO u ON LOWER(TRIM(u.Email))=LOWER(TRIM(p.Email))
              AND u.Rol='Profesor'
SET p.ID_Usuario=u.ID_Usuario
WHERE p.ID_Usuario IS NULL OR p.ID_Usuario=0;

-- ------------------------------------------------------------
-- 6. Comprobaciones finales rápidas
-- ------------------------------------------------------------
SELECT 'V17 OK - tablas obsoletas eliminadas' AS Resultado;
SELECT TABLE_NAME
FROM information_schema.TABLES
WHERE TABLE_SCHEMA=DATABASE()
  AND TABLE_NAME IN (
      'CLASE','INSCRIPCION_CLASE','EXAMEN','NIVEL_ALUMNO',
      'DISCIPLINA','GRUPO','HORARIO','INSCRIPCION_DISCIPLINA',
      'INSCRIPCION_GRUPO_ALUMNO','INSCRIPCION_GRUPO_PROFESOR'
  )
ORDER BY TABLE_NAME;
