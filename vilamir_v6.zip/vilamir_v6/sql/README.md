# Academia VILAMIR V21 — índice de base de datos

## Estructura

- `mma_systems.sql`: esquema consolidado para una **instalación nueva**.
- `migraciones/`: cambios incrementales para actualizar bases antiguas.
- `datos_demo/`: datos ficticios para pruebas; no son datos reales de la academia.
- `legacy_no_ejecutar/`: scripts históricos potencialmente destructivos; no son migraciones para una instalación actual.
- `README_V17.md` y `README_DATOS_DEMO_V20.md`: instrucciones específicas de etapas anteriores.

## Instalación nueva

1. Crear o seleccionar una base de datos vacía.
2. Importar `sql/mma_systems.sql` desde phpMyAdmin.
3. Configurar las credenciales de conexión en `config/conexion.php`.
4. Iniciar sesión y cambiar cualquier contraseña de demostración antes de publicar el sitio.

**No importes `mma_systems.sql` sobre una base existente.** Aunque el esquema ya no elimina tablas heredadas, no es una herramienta de actualización ni garantiza la compatibilidad de los datos existentes.

## Actualización de una base existente

1. Exportá una copia completa de la base desde phpMyAdmin y verificá que el archivo de respaldo no esté vacío.
2. Identificá la versión real del esquema y revisá las columnas/tablas actuales.
3. Ejecutá únicamente las migraciones que falten y que correspondan a esa versión. No ejecutes todas por rutina.
4. La migración `legacy_no_ejecutar/NO_EJECUTAR_migracion_v17_limpieza.sql` es un script histórico para instalaciones antiguas. Puede eliminar tablas heredadas y **no forma parte de las migraciones normales**. No lo ejecutes sobre una base V18, V19, V20 o V21; no lo uses sin una revisión específica y un respaldo verificado.
5. `migraciones/migracion_pagos_v18.sql` añade campos para comprobantes y anulaciones; aplicala solo si esos campos faltan.
6. `migraciones/migracion_asistencia_v19.sql` y `migraciones/migracion_cupos_v20.sql` se aplican solo si el esquema todavía no contiene esos cambios.
7. `migraciones/migracion_asistencia_v21.sql` normaliza los índices de asistencia. Requiere que la tabla `ASISTENCIA` ya tenga `ID_Horario` e `ID_Profesor` (V19); ejecutala solo después de comprobar el esquema y hacer una copia. No ejecutes V19 si sus columnas y cambios ya existen.
7. Probá primero en una copia de la base. No borres ni reemplaces la base productiva como método de actualización.

Los cambios de asistencia V21 incluyen `migracion_asistencia_v21.sql` para normalizar índices, además de correcciones de consultas del portal docente. Los cambios de pagos, comprobantes e informes usan las columnas que ya forman parte del esquema V21.

## Pagos y comprobantes

La tabla `PAGO` conserva el historial. Los pagos anulados no deben borrarse físicamente. `Numero_comprobante` debe ser único y el historial exportado incluye fecha, vencimiento, estado, método, número de comprobante y datos de anulación.

## Datos de demostración

El script `datos_demo/datos_demo_v20.sql` solo debe ejecutarse en una base de pruebas. Agrega registros ficticios y puede ser reejecutado de acuerdo con las reglas descritas en `README_DATOS_DEMO_V20.md`.

## Módulos no incluidos

VILAMIR no incorpora módulos de exámenes. Las tablas heredadas que pudieran quedar en una base antigua no son utilizadas por las pantallas activas del sistema.

## Gestión de alumnos y cuenta V21

La revisión de gestión de alumnos no requiere alterar el esquema existente: utiliza campos ya presentes en `ALUMNO` y `USUARIO`, y aprovecha los índices de apellido/nombre y correo. Consultá `migraciones/README_GESTION_ALUMNOS_V21.md` para conocer el alcance, los datos incluidos en CSV y las decisiones de seguridad. No se debe importar el esquema de instalación nueva sobre una base en uso.

## Política de mantenimiento V21

Para el procedimiento detallado, consultar `../docs/GUIA_SEGURA_BASE_DATOS_V21.md`. No hay una migración SQL nueva para la etapa 10: esta etapa reorganiza documentación y procedimientos, no tablas. Conservá la separación entre esquema de instalación nueva, migraciones incrementales, datos ficticios y scripts históricos.


## Organización de informes

Todos los informes técnicos y de etapas se encuentran centralizados en la carpeta `informes/`. Esta organización no modifica rutas de ejecución de PHP, JavaScript, CSS ni SQL.


## Referencia de esquema y volcado recibido (16/11/2026)

El archivo `mma_systems.sql` de esta carpeta es el esquema de instalación base de 24 tablas; la tabla `RECUPERACION_CONTRASENA` se contempla en una migración separada. El volcado externo aportado para revisión contiene 25 tablas y datos personales. La comparación de estructura está documentada en `../docs/ESQUEMA_REAL_MMA_SYSTEMS_2026-11-15.md`. No se incluyó ese volcado con datos reales en el ZIP corregido. No ejecutar el esquema base ni migraciones sobre la base activa: primero comprobar qué existe y probar en una copia.

**Discrepancia pendiente para instalaciones nuevas:** el volcado de referencia contiene `PROMOCION.Clave_promocion` y `Descuento DECIMAL(10,2)`, mientras el SQL base del ZIP omite esa columna y define `Descuento DECIMAL(5,2)`. Esta última precisión no admite importes superiores a 999,99. No se corrigió ni migró la base activa en esta entrega. Resolver y aprobar el esquema de instalación nueva antes de utilizar ese SQL para crear una base desde cero.
