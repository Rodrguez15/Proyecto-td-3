# Datos de demostración V20

El archivo `datos_demo/datos_demo_v20.sql` agrega registros ficticios para probar Academia VILAMIR sin borrar los datos existentes.

## Contenido

- 10 cuentas y fichas de alumnos de demostración.
- 2 cuentas y fichas de profesores de demostración.
- 4 disciplinas: MMA, Kickboxing, Muay Thai y Jiu-jitsu brasileño (BJJ).
- Grupos y horarios de ejemplo para las cuatro disciplinas.
- Asignaciones de profesores a disciplinas y grupos.
- Inscripciones de algunos alumnos para que se pueda probar la vista de clases.
- 4 seminarios/eventos con fechas futuras.

## Cómo importarlo

1. Hacé una copia de seguridad de tu base de datos.
2. Abrí phpMyAdmin y seleccioná la base `mma_systems`.
3. Entrá en la pestaña **Importar**.
4. Seleccioná `datos_demo/datos_demo_v20.sql` y ejecutá la importación.
5. Revisá las tablas `USUARIO`, `ALUMNO`, `PROFESOR`, `DISCIPLINA`, `GRUPO`, `HORARIO` y `SEMINARIO`.

También podés abrir el archivo en la pestaña **SQL** de phpMyAdmin y ejecutar su contenido después de seleccionar `mma_systems`.

## Accesos de demostración

Todas las cuentas de ejemplo usan la contraseña `Vilamir2026!`.

Alumnos: `ana.silva.demo@example.com`, `bruno.pereira.demo@example.com`, `camila.rodriguez.demo@example.com`, `diego.mendez.demo@example.com`, `emilia.torres.demo@example.com`, `facundo.costa.demo@example.com`, `guadalupe.sosa.demo@example.com`, `ignacio.martinez.demo@example.com`, `julieta.fernandez.demo@example.com` y `lautaro.gomez.demo@example.com`.

Profesores: `martin.acosta.prof.demo@example.com` y `valentina.suarez.prof.demo@example.com`.

**Seguridad:** son credenciales públicas de prueba. No las uses en un sitio publicado. Cambiá las contraseñas o eliminá las cuentas demo antes de abrir el sistema al público.

## Notas

- Los emails usan el dominio reservado `example.com`.
- Las cédulas son identificadores ficticios con prefijo `DEMO`; no son documentos reales.
- Los importes y horarios son de muestra y podés cambiarlos desde el sistema.
- El script no crea módulos de exámenes y no elimina tablas ni registros.
- El script puede volver a ejecutarse: evita duplicar los registros demo según email o nombre, aunque los registros preexistentes con esos identificadores conservan sus contraseñas y fichas.
