<?php
/* Recuperación segura de contraseña para alumnos y profesores de Academia VILAMIR. */
require_once __DIR__ . '/config/sesion.php';
require_once __DIR__ . '/config/conexion.php';
require_once __DIR__ . '/config/smtp.php';
require_once __DIR__ . '/config/alumnos_estado.php';

$mensaje = '';
$tipoMensaje = '';
$token = isset($_GET['token']) ? trim((string)$_GET['token']) : '';
$modoRestablecer = $token !== '';
$tokenValido = false;

// Determina la URL base para el enlace de recuperación
function vilamirBaseUrlRecuperacion(): ?string {
    $configurada = trim((string)(getenv('VILAMIR_BASE_URL') ?: (defined('VILAMIR_BASE_URL') ? VILAMIR_BASE_URL : '')));
    if ($configurada !== '') {
        $partes = parse_url($configurada);
        if (!is_array($partes) || !in_array(strtolower((string)($partes['scheme'] ?? '')), ['http', 'https'], true)
            || empty($partes['host']) || isset($partes['user']) || isset($partes['pass'])
            || isset($partes['query']) || isset($partes['fragment'])) {
            error_log('VILAMIR_BASE_URL inválida: debe ser una URL base HTTP(S) sin credenciales, consulta ni fragmento.');
            return null;
        }
        return rtrim($configurada, '/');
    }

    $entorno = strtolower(trim((string)(getenv('APP_ENV') ?: (defined('VILAMIR_ENV') ? VILAMIR_ENV : (getenv('VILAMIR_ENV') ?: 'development')))));
    if (in_array($entorno, ['production', 'prod', 'produccion', 'producción'], true)) return null;

    $host = strtolower(trim((string)($_SERVER['HTTP_HOST'] ?? '')));
    if (!preg_match('/^(localhost|127\.0\.0\.1|\[::1\])(?::[0-9]{1,5})?$/', $host)) return null;

    $https = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    $protocolo = $https ? 'https' : 'http';
    $ruta = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
    return $protocolo . '://' . $host . ($ruta ? $ruta : '');
}

if ($modoRestablecer) {
    try {
        $hashToken = hash('sha256', $token);
        $stmt = $conexion->prepare('SELECT id_recuperacion FROM RECUPERACION_CONTRASENA WHERE token_hash = :token_hash AND usado = 0 AND vence_en > NOW() LIMIT 1');
        $stmt->execute([':token_hash' => $hashToken]);
        $tokenValido = (bool)$stmt->fetchColumn();
        if (!$tokenValido) {
            $mensaje = 'El enlace no es válido o ha vencido. Solicita uno nuevo.';
            $tipoMensaje = 'error';
        }
    } catch (PDOException $e) {
        error_log('Error verificando token de recuperación: ' . $e->getMessage());
        $mensaje = 'No se pudo verificar el enlace. Inténtalo más tarde.';
        $tipoMensaje = 'error';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accion = (string)($_POST['accion'] ?? 'solicitar');
    if ($accion === 'solicitar') {
        $email = strtolower(trim((string)($_POST['email'] ?? '')));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $mensaje = 'Ingresa un correo electrónico válido.';
            $tipoMensaje = 'error';
        } else {
            $mensaje = 'Si el correo pertenece a una cuenta registrada y el servicio SMTP está configurado, recibirás instrucciones. La entrega debe comprobarse con una prueba real.';
            $tipoMensaje = 'success';
            try {
                $stmt = $conexion->prepare("SELECT ID_Usuario, Email, Rol FROM USUARIO WHERE LOWER(Email) = LOWER(:email) AND Rol IN ('Alumno','Profesor') LIMIT 1");
                $stmt->execute([':email' => $email]);
                $usuario = $stmt->fetch();
                if ($usuario) {
                    if (strcasecmp((string)$usuario['Rol'], 'Alumno') === 0
                        && vilamir_estado_baja_usuario($conexion, (int)$usuario['ID_Usuario']) === 'BAJA_DEFINITIVA') {
                        // No se emiten enlaces que puedan reactivar una cuenta dada de baja.
                        $usuario = false;
                    }
                }
                if ($usuario) {
                    $baseUrl = vilamirBaseUrlRecuperacion();
                    if ($baseUrl === null) {
                        error_log('VILAMIR recuperación: falta VILAMIR_BASE_URL válida; no se generó un enlace.');
                    } elseif (!vilamirSmtpConfigurado()) {
                        error_log('VILAMIR recuperación: SMTP no configurado; no se generó un token que no pueda entregarse.');
                    } else {
                        $conexion->beginTransaction();
                        $borrar = $conexion->prepare('DELETE FROM RECUPERACION_CONTRASENA WHERE id_usuario = :id_usuario');
                        $borrar->execute([':id_usuario' => $usuario['ID_Usuario']]);
                        $tokenPlano = bin2hex(random_bytes(32));
                        $tokenHash = hash('sha256', $tokenPlano);
                        $guardar = $conexion->prepare('INSERT INTO RECUPERACION_CONTRASENA (id_usuario, token_hash, vence_en, usado) VALUES (:id_usuario, :token_hash, DATE_ADD(NOW(), INTERVAL 60 MINUTE), 0)');
                        $guardar->execute([':id_usuario' => $usuario['ID_Usuario'], ':token_hash' => $tokenHash]);
                        $conexion->commit();

                        $url = $baseUrl . '/recuperar_contrasena.php?token=' . urlencode($tokenPlano);
                        $asunto = 'Recuperación de contraseña - Academia VILAMIR';
                        $cuerpo = "Hola,\n\nRecibimos una solicitud para restablecer la contraseña de tu cuenta en Academia VILAMIR.\n\nAccede al siguiente enlace para generar tu nueva contraseña (válido por 60 minutos):\n$url\n\nSi no realizaste esta solicitud, puedes ignorar este mensaje.\n\nAcademia VILAMIR";

                        if (!vilamirEnviarCorreo($usuario['Email'], $asunto, $cuerpo)) {
                            $invalidar = $conexion->prepare('DELETE FROM RECUPERACION_CONTRASENA WHERE token_hash = :token_hash');
                            $invalidar->execute([':token_hash' => $tokenHash]);
                            error_log('VILAMIR recuperación: no se confirmó el envío SMTP; token invalidado.');
                        }
                    }
                }
            } catch (Throwable $e) {
                if ($conexion->inTransaction()) $conexion->rollBack();
                error_log('Error solicitando recuperación: ' . $e->getMessage());
            }
        }
    } elseif ($accion === 'restablecer') {
        $token = trim((string)($_POST['token'] ?? ''));
        $nueva = (string)($_POST['nueva_contrasena'] ?? '');
        $confirmar = (string)($_POST['confirmar_contrasena'] ?? '');
        if ($token === '') {
            $mensaje = 'Falta el enlace de recuperación. Solicita uno nuevo.';
            $tipoMensaje = 'error';
            $modoRestablecer = false;
        } elseif (strlen($nueva) < 8) {
            $mensaje = 'La contraseña debe tener al menos 8 caracteres.';
            $tipoMensaje = 'error';
            $modoRestablecer = true;
            $tokenValido = true;
        } elseif ($nueva !== $confirmar) {
            $mensaje = 'Las contraseñas no coinciden.';
            $tipoMensaje = 'error';
            $modoRestablecer = true;
            $tokenValido = true;
        } else {
            try {
                $hashToken = hash('sha256', $token);
                $conexion->beginTransaction();
                $stmt = $conexion->prepare('SELECT id_recuperacion, id_usuario FROM RECUPERACION_CONTRASENA WHERE token_hash = :token_hash AND usado = 0 AND vence_en > NOW() LIMIT 1 FOR UPDATE');
                $stmt->execute([':token_hash' => $hashToken]);
                $recuperacion = $stmt->fetch();
                if (!$recuperacion) {
                    $conexion->rollBack();
                    $mensaje = 'El enlace no es válido o ha vencido. Solicita uno nuevo.';
                    $tipoMensaje = 'error';
                    $modoRestablecer = false;
                } else {
                    $estadoDestino = $conexion->prepare("SELECT u.Rol, a.ID_Alumno FROM USUARIO u LEFT JOIN ALUMNO a ON a.ID_Usuario=u.ID_Usuario WHERE u.ID_Usuario=? LIMIT 1");
                    $estadoDestino->execute([(int)$recuperacion['id_usuario']]);
                    $destinoCuenta = $estadoDestino->fetch(PDO::FETCH_ASSOC);
                    if ($destinoCuenta && strcasecmp((string)$destinoCuenta['Rol'], 'Alumno') === 0
                        && (int)$destinoCuenta['ID_Alumno'] > 0
                        && vilamir_estado_baja_alumno($conexion, (int)$destinoCuenta['ID_Alumno']) === 'BAJA_DEFINITIVA') {
                        $conexion->rollBack();
                        $mensaje = 'La cuenta tiene baja definitiva. Comunicate con la administración.';
                        $tipoMensaje = 'error';
                        $modoRestablecer = false;
                    } else {
                    $hashContrasena = password_hash($nueva, PASSWORD_DEFAULT);
                    $actualizar = $conexion->prepare('UPDATE USUARIO SET Contraseña = :contrasena WHERE ID_Usuario = :id_usuario');
                    $actualizar->execute([':contrasena' => $hashContrasena, ':id_usuario' => $recuperacion['id_usuario']]);
                    $marcar = $conexion->prepare('UPDATE RECUPERACION_CONTRASENA SET usado = 1 WHERE id_recuperacion = :id_recuperacion');
                    $marcar->execute([':id_recuperacion' => $recuperacion['id_recuperacion']]);
                    $conexion->commit();
                    $mensaje = '¡Tu contraseña ha sido restablecida con éxito! Ya puedes iniciar sesión.';
                    $tipoMensaje = 'success';
                    $modoRestablecer = false;
                    $tokenValido = false;
                    }
                }
            } catch (Throwable $e) {
                if ($conexion->inTransaction()) $conexion->rollBack();
                error_log('Error restableciendo contraseña: ' . $e->getMessage());
                $mensaje = 'No se pudo cambiar la contraseña. Inténtalo nuevamente.';
                $tipoMensaje = 'error';
                $modoRestablecer = false;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<?php vilamir_enviar_token_csrf(); ?>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Recuperar contraseña - Academia VILAMIR</title>
<link rel="stylesheet" href="css/style.css?v=20261026-etapa2-seminarios-galeria-v1">
<script src="js/csrf.js"></script>
</head>
<body class="login-page">
<header class="navbar">
  <div class="logo"><img src="images/logo-vilamir.jpg" alt="Escuela Vilamir" class="logo-img"></div>
  <nav><a href="index.php">Inicio</a><a href="login.html">Iniciar sesión</a></nav>
</header>
<main class="container">
<section class="login-card recovery-card">
  <h1><?= $modoRestablecer ? 'Crear nueva contraseña' : 'Recuperar contraseña' ?></h1>
  <p><?= $modoRestablecer ? 'Ingresa tu nueva contraseña para volver a acceder.' : 'Ingresa tu correo registrado para recibir el enlace de restablecimiento.' ?></p>
  <?php if ($mensaje !== ''): ?>
    <p class="<?= htmlspecialchars($tipoMensaje, ENT_QUOTES, 'UTF-8') ?> message-center" role="status"><?= htmlspecialchars($mensaje, ENT_QUOTES, 'UTF-8') ?></p>
  <?php endif; ?>
  <?php if ($modoRestablecer && $tokenValido): ?>
    <form method="post" action="recuperar_contrasena.php?token=<?= urlencode($token) ?>">
      <input type="hidden" name="accion" value="restablecer">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(vilamir_token_csrf(), ENT_QUOTES, 'UTF-8') ?>">
      <input type="hidden" name="token" value="<?= htmlspecialchars($token, ENT_QUOTES, 'UTF-8') ?>">
      <label for="nueva_contrasena">Nueva contraseña (mínimo 8 caracteres)</label>
      <input type="password" id="nueva_contrasena" name="nueva_contrasena" minlength="8" autocomplete="new-password" required>
      <label for="confirmar_contrasena">Confirmar nueva contraseña</label>
      <input type="password" id="confirmar_contrasena" name="confirmar_contrasena" minlength="8" autocomplete="new-password" required>
      <button type="submit">Guardar nueva contraseña</button>
    </form>
  <?php elseif (!$modoRestablecer): ?>
    <form method="post" action="recuperar_contrasena.php">
      <input type="hidden" name="accion" value="solicitar">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(vilamir_token_csrf(), ENT_QUOTES, 'UTF-8') ?>">
      <label for="email_recuperacion">Correo electrónico</label>
      <input type="email" id="email_recuperacion" name="email" placeholder="ejemplo@correo.com" autocomplete="email" maxlength="150" required>
      <button type="submit">Enviar enlace</button>
    </form>
  <?php endif; ?>
  <p class="register-link"><a href="login.html">Volver al inicio de sesión</a></p>
</section>
</main>
<footer>© 2026 Academia VILAMIR</footer>
<script src="js/mobile.js"></script>
</body>
</html>