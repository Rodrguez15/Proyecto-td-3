# Academia VILAMIR V21 — revisión y mantenimiento

Esta carpeta contiene la versión V21 del sistema, con sus módulos existentes y las mejoras de estadísticas, asistencia, notificaciones, pagos, alumnos, profesores y eventos. La academia no utiliza exámenes ni niveles de examen.

## Funciones presentes

- Administración de alumnos, responsables, profesores, disciplinas, grupos y horarios.
- Inscripciones, cupos y listas de espera para grupos y seminarios.
- Portal del alumno con ficha, horarios, inscripciones y código QR.
- Espacio del profesor con grupos asignados, horarios y listas de alumnos activos; acceso directo al registro de asistencia.
- Asistencia diferenciada por alumno, grupo, fecha y horario, para evitar mezclar clases del mismo día.
- Pagos, historial, comprobantes y verificación de comprobantes.
- Reportes de actividad y pagos; estadísticas de asistencia por período, disciplina, grupo y alumno.
- Calendario, galería, certificados, promociones y notificaciones.
- Exportación de datos y estilos centralizados en `css/style.css`.

## Instalación local en XAMPP

1. Hacé una copia de seguridad de la carpeta actual y exportá la base de datos desde phpMyAdmin.
2. Extraé esta carpeta en `C:\xampp\htdocs\vilamir_v3`.
3. Iniciá Apache y MySQL desde XAMPP.
4. Para una base nueva, importá `sql/mma_systems.sql` en phpMyAdmin.
5. Para una base existente, no importes el esquema inicial encima de tus datos. Revisá `sql/README.md` y aplicá solamente las migraciones que correspondan a la versión real de tu base, después de respaldarla. La migración `migraciones/migracion_asistencia_v21.sql` requiere que los cambios de asistencia V19 ya estén presentes.
6. Copiá `config/db_config.local.php.example` como `config/db_config.local.php` y completá los datos MySQL locales. También se admiten variables de entorno `DB_HOST`, `DB_NAME`, `DB_USER` y `DB_PASS`; `.env.example` es solo una plantilla y PHP no lo carga automáticamente. No se incluyen credenciales por defecto.
7. Probá el acceso de administrador, profesor y alumno, y luego verificá inscripciones, asistencia, pagos y comprobantes. En asistencia, probá especialmente un grupo que tenga más de un horario en el mismo día.

## Estadísticas y exportación

El panel de asistencia avanzada se encuentra en `estadisticas.php` y requiere sesión de administrador. Permite filtrar por fechas, disciplina, grupo y alumno, y exportar los resultados a CSV. Los filtros afectan las tablas de asistencia; los indicadores generales se muestran como resumen global.

## Notificaciones automáticas

`cron_notificaciones.php` genera avisos internos en la base (no correos). Se recomienda PHP CLI. Para revisar los avisos una vez al día en Windows, configurá el Programador de tareas para ejecutar, por ejemplo:

```text
C:\xampp\php\php.exe C:\xampp\htdocs\vilamir_v3\cron_notificaciones.php
```

Si no se programa esta tarea, los avisos no se generan por reloj automáticamente. El acceso web opcional exige CRON_KEY y POST; GET está deshabilitado. No se presume que InfinityFree ofrezca cron.

## Validación y límites

La comprobación de sintaxis no reemplaza una prueba funcional contra MySQL. Probá los cambios en una copia de tu instalación antes de usarlos en producción. No se deben borrar pagos ni inscripciones históricas para corregir datos: primero revisá su relación y estado.

## Seguridad y documentación complementaria (16/11/2026)

- No borrar físicamente alumnos ni cuentas vinculadas: las claves foráneas actuales pueden borrar pagos e historial.
- Las operaciones de escritura validan CSRF también en flujos públicos; login, registro y cierre de sesión tienen tratamiento explícito.
- SMTP y `VILAMIR_BASE_URL` deben configurarse y probarse antes de afirmar que recuperación por correo funciona.
- Consultar `docs/ESQUEMA_REAL_MMA_SYSTEMS_2026-11-15.md`, `docs/ANEXO_CONSULTAS_SQL.md`, `docs/MATRIZ_DE_PRUEBAS.md` y `docs/CHECKLIST_ENTREGABLES.md`.
- Ningún SQL o migración se ejecuta automáticamente ni debe importarse sobre la base activa.
