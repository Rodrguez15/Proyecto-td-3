# VILAMIR V6 — entrega con bajas de alumnos

## Configuración privada

Por seguridad, el ZIP no incluye `config/db_config.local.php` ni credenciales. Copiá `config/db_config.local.php.example` como `config/db_config.local.php` y completá los valores de XAMPP o InfinityFree. Para producción usá `VILAMIR_ENV = production`, el host/base de datos/usuario/contraseña del panel y `VILAMIR_BASE_URL = https://academiavilamir.rf.gd`. No compartas el archivo real.

## Gestión de bajas

En Administración → Alumnos aparecen las opciones Baja temporal y Baja definitiva. La baja temporal cancela inscripciones activas y mantiene acceso; el alumno puede volver a inscribirse. La baja definitiva cancela inscripciones activas y bloquea la cuenta en cada petición autenticada. Reactivar levanta el estado, pero no recupera inscripciones canceladas automáticamente: el alumno deberá volver a inscribirse.

Las bajas se registran como eventos en la tabla ya existente `ACTIVIDAD_SISTEMA`; se actualiza el campo `Estado` de las inscripciones activas existentes. No se borran alumnos, pagos, asistencias ni filas históricas. No se agregan ni modifican tablas o columnas.

## Despliegue

1. Respaldá archivos y base de datos.
2. Probá esta copia en XAMPP con una copia de la base.
3. Configurá `config/db_config.local.php` fuera del ZIP.
4. Verificá que existan `ACTIVIDAD_SISTEMA`, `INSCRIPCION_DISCIPLINA` e `INSCRIPCION_GRUPO_ALUMNO` con las columnas esperadas. La API verifica las tablas necesarias antes de iniciar la baja.
5. No importes ni ejecutes archivos SQL incluidos en el proyecto en la base activa.
6. Después de las pruebas manuales, desplegá únicamente los archivos del proyecto y el archivo de configuración privado creado por vos.

## Pruebas requeridas

En XAMPP y luego en InfinityFree con cuentas de prueba: baja temporal; confirmar que se cancelan inscripciones activas y se conservan pagos/asistencias; verificar que el alumno conserva acceso y puede inscribirse otra vez; baja definitiva; verificar que se cierra la sesión en la siguiente petición y que no puede iniciar sesión ni inscribirse; reactivación; verificar que puede ingresar y volver a inscribirse. Confirmar en el módulo del profesor que los alumnos con inscripción cancelada dejan de aparecer para nuevas asistencias y que las asistencias históricas siguen consultables.

No se ejecutaron pruebas contra MySQL, SMTP, cron ni dispositivos móviles en este entorno.
