<?php
/**
 * Cierra la sesión autenticada de Academia VILAMIR.
 * Usa la configuración compartida para cerrar VILAMIRSESSID, no una sesión PHP distinta.
 */
require_once __DIR__ . '/config/sesion.php';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    exit('Método no permitido. Use el botón Cerrar sesión de la aplicación.');
}

// Eliminar los datos de autenticación y cualquier otro dato de la sesión.
$_SESSION = [];

// Invalidar la cookie usando los mismos parámetros con los que se creó.
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    $cookieOptions = [
        'expires' => time() - 42000,
        'path' => $params['path'] !== '' ? $params['path'] : '/',
        'secure' => (bool)($params['secure'] ?? false),
        'httponly' => (bool)($params['httponly'] ?? true),
        'samesite' => $params['samesite'] ?? 'Lax',
    ];

    if (!empty($params['domain'])) {
        $cookieOptions['domain'] = $params['domain'];
    }

    setcookie(session_name(), '', $cookieOptions);
}

if (session_status() === PHP_SESSION_ACTIVE) {
    session_destroy();
}

// login.html sí existe en la raíz del proyecto y contiene el formulario de acceso.
header('Location: login.html', true, 302);
exit;
