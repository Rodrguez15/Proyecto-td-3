<?php
/*
 * ARCHIVO: api/tutor.php
 * PROPÓSITO: API segura de consulta para padres y tutores de alumnos menores.
 */
require_once dirname(__DIR__) . '/config/conexion.php';
require_once dirname(__DIR__) . '/config/sesion.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

function responderTutor(array $data, int $code = 200): void {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

$consulta = trim((string)($_GET['ci'] ?? $_POST['ci'] ?? ''));
if ($consulta === '') {
    responderTutor(['status' => 'error', 'message' => 'Ingresá la cédula o número registrado.'], 400);
}

// Normalizar quitando puntos, guiones y espacios
$ciLimpia = preg_replace('/[^0-9a-zA-Z]/', '', $consulta);
if (strlen($ciLimpia) < 4) {
    responderTutor(['status' => 'error', 'message' => 'El número ingresado es demasiado corto.'], 400);
}

try {
    // 1. Buscar al tutor por Cédula (en RESPONSABLE o cédula del ALUMNO)
    $sqlTutor = "
        SELECT r.ID_Responsable, r.ID_Alumno, r.Nombre AS TutorNombre, r.Apellido AS TutorApellido,
               r.Parentesco, r.Cedula AS TutorCedula, r.Telefono AS TutorTelefono,
               a.Nombre AS AlumnoNombre, a.Apellido AS AlumnoApellido, a.Fecha_nacimiento,
               a.Cobertura_medica, a.Telefono AS AlumnoTelefono
        FROM RESPONSABLE r
        JOIN ALUMNO a ON a.ID_Alumno = r.ID_Alumno
        WHERE REPLACE(REPLACE(REPLACE(r.Cedula, '.', ''), '-', ''), ' ', '') = ?
           OR REPLACE(REPLACE(REPLACE(COALESCE(a.Cedula, ''), '.', ''), '-', ''), ' ', '') = ?
           OR REPLACE(REPLACE(REPLACE(r.Telefono, ' ', ''), '-', ''), '+', '') = ?
        LIMIT 5
    ";
    $stmtTutor = $conexion->prepare($sqlTutor);
    $stmtTutor->execute([$ciLimpia, $ciLimpia, $ciLimpia]);
    $tutores = $stmtTutor->fetchAll(PDO::FETCH_ASSOC);

    if (empty($tutores)) {
        responderTutor([
            'status' => 'error',
            'message' => 'No se encontró ningún registro con esa cédula. Verificá los datos o contactá a la administración de la academia.'
        ], 404);
    }

    $resultado = [];

    foreach ($tutores as $t) {
        $idAlumno = (int)$t['ID_Alumno'];

        // 2. Disciplinas, grupos y horarios del hijo
        $sqlGrupos = "
            SELECT g.ID_Grupo, g.Nombre AS Grupo, d.Nombre AS Disciplina,
                   h.Dia, h.Hora_inicio, h.Hora_fin
            FROM INSCRIPCION_GRUPO_ALUMNO iga
            JOIN GRUPO g ON g.ID_Grupo = iga.ID_Grupo
            LEFT JOIN DISCIPLINA d ON d.ID_Disciplina = g.ID_Disciplina
            LEFT JOIN HORARIO h ON h.ID_Grupo = g.ID_Grupo
            WHERE iga.ID_Alumno = ? AND iga.Estado = 'Activa'
            ORDER BY d.Nombre, g.Nombre, 
                     FIELD(h.Dia, 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'),
                     h.Hora_inicio
        ";
        $stmtG = $conexion->prepare($sqlGrupos);
        $stmtG->execute([$idAlumno]);
        $filasG = $stmtG->fetchAll(PDO::FETCH_ASSOC);

        // Agrupar horarios por grupo
        $gruposMap = [];
        foreach ($filasG as $fg) {
            $gid = $fg['ID_Grupo'];
            if (!isset($gruposMap[$gid])) {
                $gruposMap[$gid] = [
                    'Grupo' => $fg['Grupo'],
                    'Disciplina' => $fg['Disciplina'] ?: 'General',
                    'Horarios' => []
                ];
            }
            if (!empty($fg['Dia'])) {
                $gruposMap[$gid]['Horarios'][] = $fg['Dia'] . ' ' . substr($fg['Hora_inicio'], 0, 5) . '-' . substr($fg['Hora_fin'], 0, 5);
            }
        }

        // 3. Cuotas y pagos (con cálculo de vencidos)
        $sqlPagos = "
            SELECT ID_Pago, Tipo, Fecha, Fecha_vencimiento, Importe, Estado, Metodo_pago, Numero_comprobante
            FROM PAGO
            WHERE ID_Alumno = ? AND Estado <> 'Anulado'
            ORDER BY Fecha DESC, ID_Pago DESC
            LIMIT 15
        ";
        $stmtP = $conexion->prepare($sqlPagos);
        $stmtP->execute([$idAlumno]);
        $pagos = $stmtP->fetchAll(PDO::FETCH_ASSOC);

        $totalPendiente = 0.0;
        $cuotasPendientes = 0;
        $proximoVencimiento = null;

        foreach ($pagos as &$p) {
            $estado = (string)$p['Estado'];
            $venc = $p['Fecha_vencimiento'];
            $esVencido = ($estado === 'Pendiente' && !empty($venc) && $venc < date('Y-m-d'));

            if ($esVencido) {
                $p['EstadoCalculado'] = 'Vencido';
            } else {
                $p['EstadoCalculado'] = $estado;
            }

            if ($estado === 'Pendiente') {
                $totalPendiente += (float)$p['Importe'];
                $cuotasPendientes++;
                if (!empty($venc) && ($proximoVencimiento === null || $venc < $proximoVencimiento)) {
                    $proximoVencimiento = $venc;
                }
            }
        }
        unset($p);

        // 4. Asistencias de los últimos 60 días
        $sqlAsist = "
            SELECT a.Fecha, a.Estado, COALESCE(a.Observacion, '') AS Observacion,
                   g.Nombre AS Grupo, d.Nombre AS Disciplina
            FROM ASISTENCIA a
            LEFT JOIN GRUPO g ON g.ID_Grupo = a.ID_Grupo
            LEFT JOIN DISCIPLINA d ON d.ID_Disciplina = g.ID_Disciplina
            WHERE a.ID_Alumno = ?
              AND a.Fecha >= DATE_SUB(CURDATE(), INTERVAL 60 DAY)
            ORDER BY a.Fecha DESC, a.ID_Asistencia DESC
        ";
        $stmtA = $conexion->prepare($sqlAsist);
        $stmtA->execute([$idAlumno]);
        $asistencias = $stmtA->fetchAll(PDO::FETCH_ASSOC);

        $totalClases = count($asistencias);
        $presentes = 0;
        $ausentes = 0;
        $justificados = 0;

        foreach ($asistencias as $as) {
            if ($as['Estado'] === 'Presente') $presentes++;
            elseif ($as['Estado'] === 'Ausente') $ausentes++;
            elseif ($as['Estado'] === 'Justificado') $justificados++;
        }
        $porcentajeAsistencia = $totalClases > 0 ? round(($presentes / $totalClases) * 100) : 0;

        $resultado[] = [
            'tutor' => [
                'Nombre' => $t['TutorNombre'] . ' ' . $t['TutorApellido'],
                'Parentesco' => $t['Parentesco'],
                'Telefono' => $t['TutorTelefono']
            ],
            'alumno' => [
                'ID_Alumno' => $idAlumno,
                'Nombre' => $t['AlumnoNombre'] . ' ' . $t['AlumnoApellido'],
                'Fecha_nacimiento' => $t['Fecha_nacimiento'],
                'Cobertura_medica' => $t['Cobertura_medica'] ?: 'No informada'
            ],
            'grupos' => array_values($gruposMap),
            'finanzas' => [
                'total_pendiente' => $totalPendiente,
                'cuotas_pendientes' => $cuotasPendientes,
                'proximo_vencimiento' => $proximoVencimiento ? date('d/m/Y', strtotime($proximoVencimiento)) : null,
                'pagos' => $pagos
            ],
            'asistencia' => [
                'total_clases' => $totalClases,
                'presentes' => $presentes,
                'ausentes' => $ausentes,
                'justificados' => $justificados,
                'porcentaje' => $porcentajeAsistencia,
                'historial' => $asistencias
            ]
        ];
    }

    responderTutor(['status' => 'success', 'datos' => $resultado]);

} catch (Throwable $e) {
    error_log("Error en api/tutor.php: " . $e->getMessage());
    responderTutor(['status' => 'error', 'message' => 'No se pudo procesar la consulta en este momento.'], 500);
}