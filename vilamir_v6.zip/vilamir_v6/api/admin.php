<?php
/*
 * ARCHIVO: api/admin.php
 * PROPÓSITO: API administrativa integral de Academia VILAMIR con soporte seguro de cuotas, finanzas, notificaciones y seminarios.
 */
require_once dirname(__DIR__) . '/config/conexion.php';
require_once dirname(__DIR__) . '/config/sesion.php';
require_once dirname(__DIR__) . '/config/notificaciones.php';
require_once dirname(__DIR__) . '/config/cupos.php';
require_once dirname(__DIR__) . '/config/qr.php';

if (session_status() === PHP_SESSION_NONE) session_start();

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['usuario_id']) || strcasecmp(trim((string)($_SESSION['usuario_rol'] ?? '')), 'Administrador') !== 0) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Acceso exclusivo para administradores.']);
    exit;
}

function out($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function post($k, $default = '') {
    return trim((string)($_POST[$k] ?? $default));
}

function passwordInput(): string {
    return (string)($_POST['password'] ?? '');
}

function validInitialPassword(string $password): bool {
    $length = function_exists('mb_strlen') ? mb_strlen($password, 'UTF-8') : strlen($password);
    return trim($password) !== '' && $length >= 8 && $length <= 4096;
}

function validDate($v) {
    if (!is_string($v) || $v === '') return false;
    $d = DateTime::createFromFormat('!Y-m-d', $v);
    $errors = DateTime::getLastErrors();
    return $d && ($errors === false || ($errors['warning_count'] === 0 && $errors['error_count'] === 0)) && $d->format('Y-m-d') === $v;
}

function id($k) {
    return max(0, (int)($_POST[$k] ?? 0));
}

$entity = $_GET['entity'] ?? $_POST['entity'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];

try {
    // ============================================================
    // CONSULTAS GET (LECTURA COMPLETA)
    // ============================================================
    if ($method === 'GET') {
        switch ($entity) {
            case 'dashboard':
                $tables = [
                    'ALUMNO' => 'alumnos', 'PROFESOR' => 'profesores', 'RESPONSABLE' => 'responsables',
                    'DISCIPLINA' => 'disciplinas', 'GRUPO' => 'grupos', 'HORARIO' => 'horarios',
                    'PAGO' => 'pagos', 'NOTIFICACION' => 'notificaciones', 'SEMINARIO' => 'seminarios',
                    'PROMOCION' => 'promociones', 'USUARIO' => 'usuarios'
                ];
                $counts = [];
                foreach ($tables as $t => $key) {
                    try {
                        $counts[$key] = (int)$conexion->query("SELECT COUNT(*) FROM `$t`")->fetchColumn();
                    } catch (Throwable $e) {
                        $counts[$key] = 0;
                    }
                }

                // Cálculo seguro del resumen financiero blindado
                $financial = [
                    'pendientes' => 0, 
                    'vencidos' => 0, 
                    'importe_pendiente' => 0.0, 
                    'importe_vencido' => 0.0, 
                    'cobrado_mes' => 0.0
                ];

                try {
                    // 1. Pendientes
                    $qPend = $conexion->query("SELECT COUNT(*), COALESCE(SUM(Importe), 0) FROM PAGO WHERE Estado = 'Pendiente'");
                    if ($qPend) {
                        $rowP = $qPend->fetch(PDO::FETCH_NUM);
                        $financial['pendientes'] = (int)($rowP[0] ?? 0);
                        $financial['importe_pendiente'] = (float)($rowP[1] ?? 0);
                    }

                    // 2. Cobrado en el mes
                    $qCob = $conexion->query("SELECT COALESCE(SUM(Importe), 0) FROM PAGO WHERE Estado = 'Pagado' AND MONTH(Fecha) = MONTH(CURDATE()) AND YEAR(Fecha) = YEAR(CURDATE())");
                    if ($qCob) {
                        $financial['cobrado_mes'] = (float)$qCob->fetchColumn();
                    }

                    // 3. Vencidos
                    $checkCol = $conexion->query("SHOW COLUMNS FROM `PAGO` LIKE 'Fecha_vencimiento'");
                    if ($checkCol && $checkCol->fetchColumn()) {
                        $qVenc = $conexion->query("SELECT COUNT(*), COALESCE(SUM(Importe), 0) FROM PAGO WHERE Estado = 'Pendiente' AND Fecha_vencimiento IS NOT NULL AND Fecha_vencimiento < CURDATE()");
                        if ($qVenc) {
                            $rowV = $qVenc->fetch(PDO::FETCH_NUM);
                            $financial['vencidos'] = (int)($rowV[0] ?? 0);
                            $financial['importe_vencido'] = (float)($rowV[1] ?? 0);
                        }
                    }
                } catch (Throwable $eFin) {
                    error_log('Aviso en resumen financiero: ' . $eFin->getMessage());
                }

                $upcoming = [];
                try {
                    $upcoming = $conexion->query("SELECT ID_Seminario, COALESCE(NULLIF(Nombre,''), Titulo) AS Nombre, Fecha, Hora, Lugar FROM SEMINARIO WHERE Fecha>=CURDATE() ORDER BY Fecha ASC, Hora ASC LIMIT 5")->fetchAll();
                } catch (Throwable $e) {}

                $activity = [];
                try {
                    $activity = $conexion->query("SELECT * FROM ACTIVIDAD_SISTEMA ORDER BY ID_Actividad DESC LIMIT 6")->fetchAll();
                } catch (Throwable $e) {}

                out(['status' => 'success', 'counts' => $counts, 'financial' => $financial, 'upcoming' => $upcoming, 'activity' => $activity]);

            case 'alumnos':
                $tieneActividad = (bool)$conexion->query("SHOW TABLES LIKE 'ACTIVIDAD_SISTEMA'")->fetchColumn();
                if ($tieneActividad) {
                    $sqlAlumnos = "SELECT a.*, u.Email,
                        COALESCE((SELECT CASE ac.Accion
                            WHEN 'ALUMNO_BAJA_TEMPORAL' THEN 'BAJA_TEMPORAL'
                            WHEN 'ALUMNO_BAJA_DEFINITIVA' THEN 'BAJA_DEFINITIVA'
                            WHEN 'ALUMNO_REACTIVADO' THEN 'ACTIVO'
                            ELSE 'NO_DISPONIBLE' END
                            FROM ACTIVIDAD_SISTEMA ac
                            WHERE ac.Accion IN ('ALUMNO_BAJA_TEMPORAL','ALUMNO_BAJA_DEFINITIVA','ALUMNO_REACTIVADO')
                              AND ac.Detalle LIKE CONCAT('ALUMNO_ID=', a.ID_Alumno, ';%')
                            ORDER BY ac.ID_Actividad DESC LIMIT 1), 'ACTIVO') AS Estado_baja
                        FROM ALUMNO a JOIN USUARIO u ON u.ID_Usuario=a.ID_Usuario
                        ORDER BY a.Apellido, a.Nombre";
                } else {
                    $sqlAlumnos = "SELECT a.*, u.Email, 'NO_DISPONIBLE' AS Estado_baja
                        FROM ALUMNO a JOIN USUARIO u ON u.ID_Usuario=a.ID_Usuario
                        ORDER BY a.Apellido, a.Nombre";
                }
                $s = $conexion->query($sqlAlumnos);
                out(['status' => 'success', 'rows' => $s->fetchAll()]);

            case 'profesores':
                $s = $conexion->query("SELECT p.*, u.Email AS UsuarioEmail FROM PROFESOR p LEFT JOIN USUARIO u ON u.ID_Usuario=p.ID_Usuario ORDER BY p.Apellido, p.Nombre");
                out(['status' => 'success', 'rows' => $s->fetchAll()]);

            case 'profesores_asignaciones':
                $grupos = $conexion->query("SELECT p.ID_Profesor, p.Nombre AS ProfesorNombre, p.Apellido AS ProfesorApellido,
                        igp.Estado AS Estado_asignacion, g.ID_Grupo, g.Nombre AS Grupo,
                        d.Nombre AS Disciplina, h.Dia, h.Hora_inicio, h.Hora_fin
                    FROM PROFESOR p
                    LEFT JOIN INSCRIPCION_GRUPO_PROFESOR igp ON igp.ID_Profesor=p.ID_Profesor
                    LEFT JOIN GRUPO g ON g.ID_Grupo=igp.ID_Grupo
                    LEFT JOIN DISCIPLINA d ON d.ID_Disciplina=g.ID_Disciplina
                    LEFT JOIN HORARIO h ON h.ID_Grupo=g.ID_Grupo
                    ORDER BY p.Apellido, p.Nombre, g.Nombre, FIELD(h.Dia,'Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo'), h.Hora_inicio")->fetchAll();

                $disciplinas = $conexion->query("SELECT p.ID_Profesor, pd.ID_Disciplina, d.Nombre AS Disciplina
                    FROM PROFESOR p
                    LEFT JOIN PROFESOR_DISCIPLINA pd ON pd.ID_Profesor=p.ID_Profesor
                    LEFT JOIN DISCIPLINA d ON d.ID_Disciplina=pd.ID_Disciplina
                    ORDER BY p.Apellido, p.Nombre, d.Nombre")->fetchAll();

                out(['status' => 'success', 'grupos' => $grupos, 'disciplinas' => $disciplinas]);

            case 'responsables':
                $s = $conexion->query("SELECT r.*, CONCAT(a.Nombre,' ',a.Apellido) Alumno FROM RESPONSABLE r JOIN ALUMNO a ON a.ID_Alumno=r.ID_Alumno ORDER BY a.Apellido, a.Nombre, r.Apellido, r.Nombre");
                out(['status' => 'success', 'rows' => $s->fetchAll()]);

            case 'disciplinas':
                $s = $conexion->query("SELECT * FROM DISCIPLINA ORDER BY Nombre");
                out(['status' => 'success', 'rows' => $s->fetchAll()]);

            case 'grupos':
                $s = $conexion->query("SELECT g.*, d.Nombre AS Disciplina FROM GRUPO g LEFT JOIN DISCIPLINA d ON d.ID_Disciplina=g.ID_Disciplina ORDER BY g.Nombre");
                out(['status' => 'success', 'rows' => $s->fetchAll()]);

            case 'horarios':
                $s = $conexion->query("SELECT h.ID_Horario, h.ID_Grupo, h.Dia, h.Hora_inicio, h.Hora_fin, g.Nombre AS Grupo, d.Nombre AS Disciplina FROM HORARIO h LEFT JOIN GRUPO g ON g.ID_Grupo=h.ID_Grupo LEFT JOIN DISCIPLINA d ON d.ID_Disciplina=g.ID_Disciplina ORDER BY FIELD(h.Dia,'Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo'), h.Hora_inicio");
                out(['status' => 'success', 'rows' => $s->fetchAll()]);

            case 'pagos':
                $s = $conexion->query("SELECT p.*, CONCAT(a.Nombre,' ',a.Apellido) Alumno FROM PAGO p JOIN ALUMNO a ON a.ID_Alumno=p.ID_Alumno ORDER BY p.Fecha DESC, p.ID_Pago DESC");
                out(['status' => 'success', 'rows' => $s->fetchAll()]);

            // CASO AGREGADO: Pestaña de Notificaciones en admin.php
            case 'pagos_resumen':
                $year = max(2000, (int)($_GET['year'] ?? date('Y')));
                $month = max(1, min(12, (int)($_GET['month'] ?? date('n'))));
                $summary = ['periodo' => sprintf('%04d-%02d', $year, $month), 'total' => 0, 'pagados' => 0, 'pendientes' => 0, 'vencidos' => 0, 'anulados' => 0, 'importe_cobrado' => 0, 'importe_pendiente' => 0, 'importe_vencido' => 0, 'importe_anulado' => 0];

                $q = $conexion->prepare("SELECT Estado, Fecha_vencimiento, COALESCE(Importe,0) Importe FROM PAGO WHERE YEAR(Fecha)=? AND MONTH(Fecha)=?");
                $q->execute([$year, $month]);

                foreach ($q->fetchAll() as $r) {
                    $e = strtolower(trim((string)$r['Estado']));
                    $imp = (float)$r['Importe'];
                    $summary['total']++;

                    if (strpos($e, 'anul') !== false) {
                        $summary['anulados']++;
                        $summary['importe_anulado'] += $imp;
                        continue;
                    }
                    if (strpos($e, 'pag') !== false) {
                        $summary['pagados']++;
                        $summary['importe_cobrado'] += $imp;
                        continue;
                    }
                    if (!empty($r['Fecha_vencimiento']) && $r['Fecha_vencimiento'] < date('Y-m-d')) {
                        $summary['vencidos']++;
                        $summary['importe_vencido'] += $imp;
                    } else {
                        $summary['pendientes']++;
                        $summary['importe_pendiente'] += $imp;
                    }
                }
                out(['status' => 'success', 'summary' => $summary]);

            case 'notificaciones':
                $s = $conexion->query("SELECT n.*, CONCAT(a.Nombre,' ',a.Apellido) Alumno FROM NOTIFICACION n JOIN ALUMNO a ON a.ID_Alumno=n.ID_Alumno ORDER BY n.Fecha DESC, n.ID_Notificacion DESC");
                out(['status' => 'success', 'rows' => $s->fetchAll()]);

            case 'seminarios':
                $s = $conexion->query("SELECT ID_Seminario, COALESCE(NULLIF(Nombre,''), Titulo) AS Nombre, Descripcion, Costo, Fecha, Hora, Lugar, Cupo, Ponente FROM SEMINARIO ORDER BY Fecha DESC");
                out(['status' => 'success', 'rows' => $s->fetchAll()]);

            case 'promociones':
                $s = $conexion->query("SELECT * FROM PROMOCION ORDER BY ID_Promocion ASC");
                out(['status' => 'success', 'rows' => $s->fetchAll()]);

            case 'usuarios':
                $s = $conexion->query("SELECT ID_Usuario, Email, Rol, Creado_en FROM USUARIO ORDER BY Email");
                out(['status' => 'success', 'rows' => $s->fetchAll()]);

            case 'inscripciones_disciplina':
                $s = $conexion->query("SELECT i.*, CONCAT(a.Nombre,' ',a.Apellido) Alumno, d.Nombre Disciplina FROM INSCRIPCION_DISCIPLINA i JOIN ALUMNO a ON a.ID_Alumno=i.ID_Alumno JOIN DISCIPLINA d ON d.ID_Disciplina=i.ID_Disciplina ORDER BY i.Fecha_ins DESC");
                out(['status' => 'success', 'rows' => $s->fetchAll()]);

            // CASO AGREGADO: Pestaña de Inscripciones a Seminarios en admin.php
            case 'inscripciones_seminario':
                $s = $conexion->query("
                    SELECT i.*, CONCAT(a.Nombre,' ',a.Apellido) AS Alumno, 
                           COALESCE(NULLIF(s.Nombre,''), s.Titulo) AS Seminario,
                           s.Fecha AS Fecha_seminario, s.Costo
                    FROM INSCRIPCION_SEMINARIO i 
                    JOIN ALUMNO a ON a.ID_Alumno = i.ID_Alumno 
                    JOIN SEMINARIO s ON s.ID_Seminario = i.ID_Seminario 
                    ORDER BY i.Fecha_ins DESC, i.ID_Ins_seminario DESC
                ");
                out(['status' => 'success', 'rows' => $s ? $s->fetchAll() : []]);

            default:
                out(['status' => 'error', 'message' => 'Módulo no válido: ' . htmlspecialchars($entity)], 400);
        }
    }

    if ($method !== 'POST') out(['status' => 'error', 'message' => 'Método no permitido.'], 405);

    $action = post('accion', 'crear');
    $itemId = id('id');

    // ============================================================
    // 1. MÓDULO DE ALUMNOS
    // ============================================================
    if ($entity === 'alumnos') {
        // Bloqueo explícito en servidor: nunca borrar físicamente alumnos.
        // Se conservan pagos, asistencias e historial sin modificar el esquema.
        if ($action === 'eliminar') {
            out([
                'status' => 'error',
                'message' => 'La eliminación física de alumnos está deshabilitada para proteger pagos e historial académico. La ficha debe conservarse.'
            ], 409);
        }

        if (in_array($action, ['baja_temporal', 'baja_definitiva', 'reactivar'], true)) {
            if ($itemId <= 0) out(['status' => 'error', 'message' => 'ID de alumno no válido.'], 400);

            $tablasNecesarias = ['ACTIVIDAD_SISTEMA'];
            if ($action !== 'reactivar') $tablasNecesarias = array_merge($tablasNecesarias, ['INSCRIPCION_DISCIPLINA', 'INSCRIPCION_GRUPO_ALUMNO']);
            foreach ($tablasNecesarias as $tablaNecesaria) {
                $checkTabla = $conexion->query("SHOW TABLES LIKE '{$tablaNecesaria}'");
                if (!$checkTabla->fetchColumn()) {
                    out(['status' => 'error', 'message' => "No se puede gestionar la baja: falta la tabla existente {$tablaNecesaria}. No se modificó ningún dato."], 503);
                }
            }

            $buscarAlumno = $conexion->prepare("SELECT a.ID_Alumno, a.ID_Usuario, a.Nombre, a.Apellido
                FROM ALUMNO a WHERE a.ID_Alumno = ? LIMIT 1");
            $buscarAlumno->execute([$itemId]);
            $alumnoBaja = $buscarAlumno->fetch(PDO::FETCH_ASSOC);
            if (!$alumnoBaja) out(['status' => 'error', 'message' => 'Alumno no encontrado.'], 404);

            require_once dirname(__DIR__) . '/config/alumnos_estado.php';
            $estadoActual = vilamir_estado_baja_alumno($conexion, $itemId);
            if ($estadoActual === 'NO_DISPONIBLE') {
                out(['status' => 'error', 'message' => 'No se pudo verificar el estado administrativo. No se realizó ningún cambio.'], 503);
            }

            if ($action === 'baja_temporal' && $estadoActual === 'BAJA_DEFINITIVA') {
                out(['status' => 'error', 'message' => 'El alumno tiene baja definitiva. Usá Reactivar para habilitar su cuenta.'], 409);
            }
            if ($action === 'baja_temporal' && $estadoActual === 'BAJA_TEMPORAL') {
                out(['status' => 'success', 'message' => 'El alumno ya tiene una baja temporal. No se realizaron cambios.']);
            }
            if ($action === 'baja_definitiva' && $estadoActual === 'BAJA_DEFINITIVA') {
                out(['status' => 'success', 'message' => 'El alumno ya tiene una baja definitiva. No se realizaron cambios.']);
            }
            if ($action === 'reactivar' && $estadoActual === 'ACTIVO') {
                out(['status' => 'error', 'message' => 'El alumno ya figura activo.'], 409);
            }

            $accionLog = $action === 'baja_temporal' ? 'ALUMNO_BAJA_TEMPORAL' : ($action === 'baja_definitiva' ? 'ALUMNO_BAJA_DEFINITIVA' : 'ALUMNO_REACTIVADO');
            $nombreLog = trim($alumnoBaja['Nombre'] . ' ' . $alumnoBaja['Apellido']);
            $detalleLog = 'ALUMNO_ID=' . $itemId . ';USUARIO_ID=' . (int)$alumnoBaja['ID_Usuario'] . ';NOMBRE=' . substr($nombreLog, 0, 150);

            $conexion->beginTransaction();
            try {
                if ($action === 'baja_temporal' || $action === 'baja_definitiva') {
                    // Solo se cancelan inscripciones activas. No se borran pagos,
                    // asistencias ni filas históricas de inscripciones.
                    $cancelarDisciplina = $conexion->prepare("UPDATE INSCRIPCION_DISCIPLINA SET Estado='Cancelada' WHERE ID_Alumno=? AND Estado='Activa'");
                    $cancelarDisciplina->execute([$itemId]);
                    $cancelarGrupo = $conexion->prepare("UPDATE INSCRIPCION_GRUPO_ALUMNO SET Estado='Cancelada' WHERE ID_Alumno=? AND Estado='Activa'");
                    $cancelarGrupo->execute([$itemId]);
                }

                $log = $conexion->prepare('INSERT INTO ACTIVIDAD_SISTEMA (ID_Usuario, Accion, Detalle) VALUES (?, ?, ?)');
                $log->execute([(int)$_SESSION['usuario_id'], $accionLog, $detalleLog]);
                $conexion->commit();
            } catch (Throwable $eBaja) {
                if ($conexion->inTransaction()) $conexion->rollBack();
                throw $eBaja;
            }

            if ($action === 'baja_temporal') {
                out(['status' => 'success', 'message' => 'Baja temporal aplicada. Se cancelaron las inscripciones activas y se conservaron pagos y asistencias. El alumno mantiene acceso y podrá volver a inscribirse.']);
            }
            if ($action === 'baja_definitiva') {
                out(['status' => 'success', 'message' => 'Baja definitiva aplicada. Se cancelaron las inscripciones y se bloqueó el acceso del alumno. Los pagos y las asistencias históricas se conservaron.']);
            }
            out(['status' => 'success', 'message' => $estadoActual === 'BAJA_DEFINITIVA'
                ? 'Alumno reactivado. La cuenta vuelve a estar habilitada; podrá iniciar sesión y volver a inscribirse. No se restauraron inscripciones antiguas automáticamente.'
                : 'Baja temporal levantada. El alumno puede volver a inscribirse; no se restauraron inscripciones antiguas automáticamente.']);
        }

        $nombre = post('nombre');
        $apellido = post('apellido');
        $email = strtolower(post('email'));
        $cedula = post('cedula');
        $telefono = post('telefono');
        $fnac = post('fecha_nacimiento');
        $direccion = post('direccion');
        $cobertura = post('cobertura_medica');
        $peso = (float)($_POST['peso'] ?? 0);
        $categoria = post('categoria');

        if ($action === 'editar') {
            if ($itemId <= 0) out(['status' => 'error', 'message' => 'ID de alumno no válido.'], 400);

            $stmtA = $conexion->prepare("SELECT ID_Usuario FROM ALUMNO WHERE ID_Alumno = ? LIMIT 1");
            $stmtA->execute([$itemId]);
            $uid = (int)$stmtA->fetchColumn();
            if (!$uid) out(['status' => 'error', 'message' => 'Alumno no encontrado.'], 404);

            if ($email !== '') {
                $chk = $conexion->prepare("SELECT ID_Usuario FROM USUARIO WHERE LOWER(Email) = LOWER(?) AND ID_Usuario <> ? LIMIT 1");
                $chk->execute([$email, $uid]);
                if ($chk->fetchColumn()) out(['status' => 'error', 'message' => 'Ese correo ya está en uso por otro usuario.'], 400);
            }

            $conexion->beginTransaction();
            $updA = $conexion->prepare("
                UPDATE ALUMNO SET 
                    Nombre = ?, Apellido = ?, Cedula = NULLIF(?,''), Telefono = NULLIF(?,''),
                    Fecha_nacimiento = NULLIF(?,''), Direccion = NULLIF(?,''), Cobertura_medica = NULLIF(?,''),
                    Peso = ?, Categoria = NULLIF(?,'')
                WHERE ID_Alumno = ?
            ");
            $updA->execute([$nombre, $apellido, $cedula, $telefono, $fnac, $direccion, $cobertura, $peso > 0 ? $peso : null, $categoria, $itemId]);

            if ($email !== '') {
                $conexion->prepare("UPDATE USUARIO SET Email = ? WHERE ID_Usuario = ?")->execute([$email, $uid]);
            }
            $conexion->commit();

            out(['status' => 'success', 'message' => "Ficha del alumno '{$nombre} {$apellido}' actualizada con éxito."]);
        }

        if ($action === 'crear') {
            if (!$nombre || !$apellido || !$email) out(['status' => 'error', 'message' => 'Nombre, apellido y correo son obligatorios.'], 400);
            
            $chk = $conexion->prepare("SELECT ID_Usuario FROM USUARIO WHERE LOWER(Email) = LOWER(?) LIMIT 1");
            $chk->execute([$email]);
            if ($chk->fetchColumn()) out(['status' => 'error', 'message' => 'El correo ya está registrado.'], 400);

            $password = passwordInput();
            if (!validInitialPassword($password)) {
                out(['status' => 'error', 'message' => 'Ingresá una contraseña inicial de al menos 8 caracteres.'], 400);
            }

            $conexion->beginTransaction();
            $insU = $conexion->prepare("INSERT INTO USUARIO (Email, Contraseña, Rol) VALUES (?, ?, 'Alumno')");
            $insU->execute([$email, password_hash($password, PASSWORD_DEFAULT)]);
            $newUid = (int)$conexion->lastInsertId();

            $codigoQr = vilamir_nuevo_codigo_qr($conexion);

            $insA = $conexion->prepare("
                INSERT INTO ALUMNO (ID_Usuario, Nombre, Apellido, Cedula, Telefono, Fecha_nacimiento, Direccion, Cobertura_medica, Peso, Categoria, Codigo_qr)
                VALUES (?, ?, ?, NULLIF(?,''), NULLIF(?,''), NULLIF(?,''), NULLIF(?,''), NULLIF(?,''), ?, NULLIF(?,''), ?)
            ");
            $insA->execute([$newUid, $nombre, $apellido, $cedula, $telefono, $fnac, $direccion, $cobertura, $peso > 0 ? $peso : null, $categoria, $codigoQr]);
            $conexion->commit();

            out(['status' => 'success', 'message' => "Alumno registrado correctamente con QR {$codigoQr}."]);
        }
    }

    // ============================================================
    // 2. MÓDULO DE NOTIFICACIONES (CREAR / ELIMINAR DESDE ADMIN)
    // ============================================================
    if ($entity === 'notificaciones') {
        $idAlumno = id('id_alumno');
        $mensaje = post('mensaje');
        $estado = post('estado', 'Pendiente');
        $fecha = post('fecha', date('Y-m-d'));

        if ($action === 'eliminar') {
            if ($itemId <= 0) out(['status' => 'error', 'message' => 'ID no válido.'], 400);
            $conexion->prepare("DELETE FROM NOTIFICACION WHERE ID_Notificacion = ?")->execute([$itemId]);
            out(['status' => 'success', 'message' => 'Notificación eliminada correctamente.']);
        }

        if ($action === 'crear') {
            if ($idAlumno <= 0 || !$mensaje) out(['status' => 'error', 'message' => 'Selecciona un alumno e ingresa un mensaje.'], 400);
            if (!vilamirAlumnoPuedeRecibirNotificaciones($conexion, $idAlumno)) {
                out(['status' => 'error', 'message' => 'No se puede enviar la notificación: el alumno está dado de baja o no se pudo verificar su estado.'], 409);
            }
            $stmt = $conexion->prepare("INSERT INTO NOTIFICACION (ID_Alumno, Mensaje, Estado, Fecha) VALUES (?, ?, ?, ?)");
            $stmt->execute([$idAlumno, $mensaje, $estado, $fecha]);
            out(['status' => 'success', 'message' => 'Notificación enviada al alumno.']);
        }
    }

    // ============================================================
    // 3. MÓDULO DE INSCRIPCIONES A SEMINARIOS (ADMIN)
    // ============================================================
    if ($entity === 'inscripciones_seminario') {
        $idAlumno = id('id_alumno');
        $idSeminario = id('id_seminario');
        $estado = post('estado', 'Activa');
        $fecha = post('fecha', date('Y-m-d'));

        if ($action === 'eliminar') {
            if ($itemId <= 0) out(['status' => 'error', 'message' => 'ID no válido.'], 400);
            $conexion->prepare("DELETE FROM INSCRIPCION_SEMINARIO WHERE ID_Ins_seminario = ?")->execute([$itemId]);
            out(['status' => 'success', 'message' => 'Inscripción eliminada.']);
        }

        if ($action === 'crear') {
            if ($idAlumno <= 0 || $idSeminario <= 0) out(['status' => 'error', 'message' => 'Selecciona un alumno y un seminario.'], 400);

            $stmt = $conexion->prepare("INSERT INTO INSCRIPCION_SEMINARIO (ID_Alumno, ID_Seminario, Fecha_ins, Estado) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE Estado = VALUES(Estado)");
            $stmt->execute([$idAlumno, $idSeminario, $fecha, $estado]);
            out(['status' => 'success', 'message' => 'Inscripción a seminario registrada con éxito.']);
        }
    }

    // ============================================================
    // 4. MÓDULO DE PAGOS Y CUOTAS MASIVAS
    // ============================================================
    if ($entity === 'pagos') {
        if ($action === 'confirmar') {
            if ($itemId <= 0) out(['status' => 'error', 'message' => 'Pago no válido.'], 400);

            $s = $conexion->prepare("SELECT ID_Pago, ID_Alumno, Tipo, Importe, Estado, Numero_comprobante FROM PAGO WHERE ID_Pago=? LIMIT 1");
            $s->execute([$itemId]);
            $pago = $s->fetch();

            if (!$pago) out(['status' => 'error', 'message' => 'Pago no encontrado.'], 404);
            if (strcasecmp((string)$pago['Estado'], 'Anulado') === 0) {
                out(['status' => 'error', 'message' => 'Un pago anulado no se puede confirmar.'], 400);
            }

            $metodo = trim(post('metodo_pago', 'Efectivo'));
            $fechaCobro = post('fecha', date('Y-m-d'));
            if (!validDate($fechaCobro)) $fechaCobro = date('Y-m-d');

            $upd = $conexion->prepare("UPDATE PAGO SET Estado='Pagado', Metodo_pago=?, Fecha=? WHERE ID_Pago=?");
            $upd->execute([$metodo, $fechaCobro, $itemId]);

            $comprobante = $pago['Numero_comprobante'] ?: ('#' . $itemId);

            vilamirNotificarAlumno(
                $conexion, 
                (int)$pago['ID_Alumno'], 
                "Tu pago de " . ($pago['Tipo'] ?: 'cuota') . " por $" . number_format((float)$pago['Importe'], 2, ',', '.') . " fue confirmado como PAGADO ({$metodo}). Comprobante: {$comprobante}"
            );

            out([
                'status' => 'success',
                'message' => 'Pago confirmado con éxito como Pagado (' . $metodo . ').',
                'id' => $itemId,
                'estado' => 'Pagado',
                'metodo_pago' => $metodo,
                'fecha' => $fechaCobro
            ]);
        }

        if ($action === 'generar_cuotas_mes') {
            $mes = max(1, min(12, (int)($_POST['mes'] ?? date('n'))));
            $anio = max(2020, min(2100, (int)($_POST['anio'] ?? date('Y'))));
            $diaVenc = max(1, min(28, (int)($_POST['dia_vencimiento'] ?? 10)));

            $mesesNombres = [
                1 => 'Enero', 2 => 'Febrero', 3 => 'Marzo', 4 => 'Abril',
                5 => 'Mayo', 6 => 'Junio', 7 => 'Julio', 8 => 'Agosto',
                9 => 'Septiembre', 10 => 'Octubre', 11 => 'Noviembre', 12 => 'Diciembre'
            ];
            $nombreMes = $mesesNombres[$mes] ?? 'Mes ' . $mes;
            $fechaEmision = date('Y-m-d');
            $fechaVencimiento = sprintf('%04d-%02d-%02d', $anio, $mes, $diaVenc);

            $tarifasQ = $conexion->query("SELECT Nombre, Descuento FROM PROMOCION WHERE Activa = 1");
            $tarifasLista = $tarifasQ ? $tarifasQ->fetchAll(PDO::FETCH_ASSOC) : [];
            
            $tarifa1 = 1500.00;
            $tarifa2 = 1900.00;
            $tarifa3 = 2100.00;
            $tarifaLibre = 2500.00;

            foreach ($tarifasLista as $tRow) {
                $n = strtolower($tRow['Nombre']);
                $val = (float)$tRow['Descuento'];
                if (strpos($n, '1') !== false || strpos($n, 'individual') !== false || strpos($n, 'básico') !== false) $tarifa1 = $val;
                if (strpos($n, '2') !== false || strpos($n, 'doble') !== false) $tarifa2 = $val;
                if (strpos($n, '3') !== false || strpos($n, 'triple') !== false) $tarifa3 = $val;
                if (strpos($n, 'libre') !== false || strpos($n, 'todas') !== false) $tarifaLibre = $val;
            }

            $qInscripciones = $conexion->query(
                "SELECT i.ID_Alumno, CONCAT(a.Nombre, ' ', a.Apellido) AS Alumno,
                        GROUP_CONCAT(d.Nombre SEPARATOR ' + ') AS DisciplinasNombres,
                        COUNT(i.ID_Disciplina) AS CantidadDisciplinas
                 FROM INSCRIPCION_DISCIPLINA i
                 JOIN DISCIPLINA d ON d.ID_Disciplina = i.ID_Disciplina
                 JOIN ALUMNO a ON a.ID_Alumno = i.ID_Alumno
                 WHERE i.Estado = 'Activa' AND d.Costo > 0
                 GROUP BY i.ID_Alumno, a.Nombre, a.Apellido"
            );
            $alumnosConCursos = $qInscripciones ? $qInscripciones->fetchAll(PDO::FETCH_ASSOC) : [];

            if (empty($alumnosConCursos)) {
                out(['status' => 'success', 'message' => 'No hay alumnos con inscripciones activas.', 'generadas' => 0]);
            }

            $generadas = 0;
            $totalImporte = 0.0;

            $checkExistente = $conexion->prepare(
                "SELECT ID_Pago FROM PAGO WHERE ID_Alumno = ? AND Tipo LIKE ? AND Estado <> 'Anulado' LIMIT 1"
            );
            $insertPago = $conexion->prepare(
                "INSERT INTO PAGO (ID_Alumno, Tipo, Fecha, Fecha_vencimiento, Importe, Estado, Metodo_pago) VALUES (?, ?, ?, ?, ?, 'Pendiente', 'A confirmar')"
            );
            $updateComprobante = $conexion->prepare(
                "UPDATE PAGO SET Numero_comprobante = ? WHERE ID_Pago = ?"
            );

            foreach ($alumnosConCursos as $item) {
                $idAlumno = (int)$item['ID_Alumno'];
                $cant = (int)$item['CantidadDisciplinas'];
                $disciplinasTxt = $item['DisciplinasNombres'];

                if ($cant === 1) {
                    $importeCuota = $tarifa1;
                    $tipoPromo = "Cuota {$nombreMes} {$anio} - {$disciplinasTxt}";
                } elseif ($cant === 2) {
                    $importeCuota = $tarifa2;
                    $tipoPromo = "Cuota Promocional 2 Disciplinas {$nombreMes} {$anio} ({$disciplinasTxt})";
                } elseif ($cant === 3) {
                    $importeCuota = $tarifa3;
                    $tipoPromo = "Cuota Promocional 3 Disciplinas {$nombreMes} {$anio} ({$disciplinasTxt})";
                } else {
                    $importeCuota = $tarifaLibre;
                    $tipoPromo = "Pase Libre Total {$nombreMes} {$anio} ({$disciplinasTxt})";
                }

                $patronMes = "%{$nombreMes} {$anio}%";
                $checkExistente->execute([$idAlumno, $patronMes]);
                if ($checkExistente->fetchColumn()) continue;

                $conexion->beginTransaction();
                try {
                    $insertPago->execute([$idAlumno, $tipoPromo, $fechaEmision, $fechaVencimiento, $importeCuota]);
                    $nuevoId = (int)$conexion->lastInsertId();
                    $codigo = 'VIL-' . $fechaEmision . '-' . str_pad((string)$nuevoId, 6, '0', STR_PAD_LEFT);
                    $updateComprobante->execute([$codigo, $nuevoId]);
                    $conexion->commit();

                    $generadas++;
                    $totalImporte += $importeCuota;

                    vilamirNotificarAlumno(
                        $conexion,
                        $idAlumno,
                        "Se generó tu {$tipoPromo}: $" . number_format($importeCuota, 2, ',', '.') . " con vencimiento el " . date('d/m/Y', strtotime($fechaVencimiento)) . ". Comprobante: {$codigo}"
                    );
                } catch (Throwable $e) {
                    if ($conexion->inTransaction()) $conexion->rollBack();
                }
            }

            out([
                'status' => 'success',
                'message' => "¡Listo! Se generaron {$generadas} cuotas aplicando las tarifas configuradas por un total de $" . number_format($totalImporte, 2, ',', '.') . " UYU.",
                'generadas' => $generadas
            ]);
        }

        $alumno = id('id_alumno');
        $tipo = post('tipo');
        $fecha = post('fecha');
        $vencimiento = post('fecha_vencimiento');
        $importe = (float)($_POST['importe'] ?? 0);
        $estado = post('estado', 'Pendiente');
        $metodo = post('metodo_pago');

        if ($action === 'eliminar') {
            $motivo = trim(post('motivo_anulacion', 'Anulación administrativa'));
            $s = $conexion->prepare("UPDATE PAGO SET Estado='Anulado', Anulado_en=NOW(), Anulado_por=?, Motivo_anulacion=? WHERE ID_Pago=?");
            $s->execute([(int)$_SESSION['usuario_id'], $motivo, $itemId]);
            out(['status' => 'success', 'message' => 'Pago anulado correctamente. El historial se conserva.']);
        }

        if ($action === 'editar') {
            $conexion->prepare("UPDATE PAGO SET ID_Alumno=?, Tipo=?, Fecha=?, Fecha_vencimiento=?, Importe=?, Estado=?, Metodo_pago=? WHERE ID_Pago=?")
                ->execute([$alumno, $tipo, $fecha, $vencimiento !== '' ? $vencimiento : null, $importe, $estado, $metodo, $itemId]);
            out(['status' => 'success', 'message' => 'Pago actualizado.']);
        }

        $conexion->beginTransaction();
        try {
            $conexion->prepare("INSERT INTO PAGO(ID_Alumno, Tipo, Fecha, Fecha_vencimiento, Importe, Estado, Metodo_pago) VALUES(?, ?, ?, ?, ?, ?, ?)")
                ->execute([$alumno, $tipo, $fecha, $vencimiento !== '' ? $vencimiento : null, $importe, $estado, $metodo]);
            $nuevoId = (int)$conexion->lastInsertId();
            $codigo = 'VIL-' . $fecha . '-' . str_pad((string)$nuevoId, 6, '0', STR_PAD_LEFT);
            $conexion->prepare('UPDATE PAGO SET Numero_comprobante=? WHERE ID_Pago=?')->execute([$codigo, $nuevoId]);
            $conexion->commit();
            out(['status' => 'success', 'message' => 'Pago registrado. Comprobante: ' . $codigo, 'id' => $nuevoId, 'comprobante' => $codigo]);
        } catch (Throwable $e) {
            if ($conexion->inTransaction()) $conexion->rollBack();
            throw $e;
        }
    }

    // DISCIPLINAS
    if ($entity === 'disciplinas') {
        $nombre = post('nombre');
        $desc = post('descripcion');
        $costo = (float)($_POST['costo'] ?? 0);

        if ($action === 'eliminar') {
            $conexion->prepare("DELETE FROM DISCIPLINA WHERE ID_Disciplina=?")->execute([$itemId]);
            out(['status' => 'success', 'message' => 'Disciplina eliminada.']);
        }
        if ($action === 'editar') {
            $conexion->prepare("UPDATE DISCIPLINA SET Nombre=?, Descripcion=?, Costo=? WHERE ID_Disciplina=?")->execute([$nombre, $desc, $costo, $itemId]);
            out(['status' => 'success', 'message' => 'Disciplina actualizada.']);
        }
        $conexion->prepare("INSERT INTO DISCIPLINA(Nombre, Descripcion, Costo) VALUES(?, ?, ?)")->execute([$nombre, $desc, $costo]);
        out(['status' => 'success', 'message' => 'Disciplina creada.']);
    }

    // GRUPOS
    if ($entity === 'grupos') {
        $nombre = post('nombre');
        $cupo = max(1, (int)($_POST['cupo_maximo'] ?? 20));
        $disciplina = id('id_disciplina');
        $nivel = post('nivel', 'Principiante');
        $descripcion = post('descripcion');

        if ($action === 'eliminar') {
            $conexion->prepare("DELETE FROM GRUPO WHERE ID_Grupo=?")->execute([$itemId]);
            out(['status' => 'success', 'message' => 'Grupo eliminado.']);
        }
        if ($action === 'editar') {
            $conexion->prepare("UPDATE GRUPO SET Nombre=?, ID_Disciplina=?, Cupo_maximo=?, Nivel=?, Descripcion=? WHERE ID_Grupo=?")
                ->execute([$nombre, $disciplina, $cupo, $nivel, $descripcion, $itemId]);
            vilamirPromoverListaGrupo($conexion, $itemId);
            out(['status' => 'success', 'message' => 'Grupo actualizado.']);
        }
        $conexion->prepare("INSERT INTO GRUPO(Nombre, ID_Disciplina, Cupo_maximo, Nivel, Descripcion) VALUES(?, ?, ?, ?, ?)")
            ->execute([$nombre, $disciplina, $cupo, $nivel, $descripcion]);
        out(['status' => 'success', 'message' => 'Grupo creado correctamente.']);
    }

    // HORARIOS
    if ($entity === 'horarios') {
        $grupo = id('id_grupo');
        $dia = post('dia');
        $ini = post('hora_inicio');
        $fin = post('hora_fin');

        if ($action === 'eliminar') {
            $conexion->prepare("DELETE FROM HORARIO WHERE ID_Horario=?")->execute([$itemId]);
            out(['status' => 'success', 'message' => 'Horario eliminado.']);
        }
        if ($action === 'editar') {
            $conexion->prepare("UPDATE HORARIO SET ID_Grupo=?, Dia=?, Hora_inicio=?, Hora_fin=? WHERE ID_Horario=?")->execute([$grupo, $dia, $ini, $fin, $itemId]);
            out(['status' => 'success', 'message' => 'Horario actualizado.']);
        }
        $conexion->prepare("INSERT INTO HORARIO(ID_Grupo, Dia, Hora_inicio, Hora_fin) VALUES(?, ?, ?, ?)")->execute([$grupo, $dia, $ini, $fin]);
        out(['status' => 'success', 'message' => 'Horario creado.']);
    }

    // PROFESORES: ficha docente + cuenta de acceso vinculada.
    if ($entity === 'profesores') {
        $nombre = post('nombre');
        $apellido = post('apellido');
        $especialidad = post('especialidad');
        $email = strtolower(post('email'));
        $telefono = post('telefono');
        $cedula = post('cedula');
        $direccion = post('direccion');
        $password = passwordInput();

        if ($action === 'eliminar') {
            if ($itemId <= 0) out(['status' => 'error', 'message' => 'Profesor no válido.'], 400);
            $qUser = $conexion->prepare('SELECT ID_Usuario FROM PROFESOR WHERE ID_Profesor = ? LIMIT 1');
            $qUser->execute([$itemId]);
            $uidEliminar = (int)$qUser->fetchColumn();
            $conexion->beginTransaction();
            try {
                $conexion->prepare('DELETE FROM PROFESOR WHERE ID_Profesor = ?')->execute([$itemId]);
                if ($uidEliminar > 0) {
                    $qRefs = $conexion->prepare('SELECT (SELECT COUNT(*) FROM PROFESOR WHERE ID_Usuario = ?) + (SELECT COUNT(*) FROM ALUMNO WHERE ID_Usuario = ?)');
                    $qRefs->execute([$uidEliminar, $uidEliminar]);
                    if ((int)$qRefs->fetchColumn() === 0) {
                        $conexion->prepare("DELETE FROM USUARIO WHERE ID_Usuario = ? AND Rol = 'Profesor'")->execute([$uidEliminar]);
                    }
                }
                $conexion->commit();
            } catch (Throwable $e) {
                if ($conexion->inTransaction()) $conexion->rollBack();
                throw $e;
            }
            out(['status' => 'success', 'message' => 'Profesor eliminado correctamente.']);
        }

        if (!$nombre || !$apellido || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            out(['status' => 'error', 'message' => 'Nombre, apellido y correo válido son obligatorios.'], 400);
        }

        if ($action === 'editar') {
            if ($itemId <= 0) out(['status' => 'error', 'message' => 'ID de profesor no válido.'], 400);
            $qActual = $conexion->prepare('SELECT ID_Usuario FROM PROFESOR WHERE ID_Profesor = ? LIMIT 1');
            $qActual->execute([$itemId]);
            $uidActual = (int)$qActual->fetchColumn();
            if (!$qActual->rowCount() && $uidActual === 0) {
                $qExiste = $conexion->prepare('SELECT 1 FROM PROFESOR WHERE ID_Profesor = ?');
                $qExiste->execute([$itemId]);
                if (!$qExiste->fetchColumn()) out(['status' => 'error', 'message' => 'Profesor no encontrado.'], 404);
            }
            $qDup = $conexion->prepare('SELECT ID_Profesor FROM PROFESOR WHERE LOWER(Email) = LOWER(?) AND ID_Profesor <> ? LIMIT 1');
            $qDup->execute([$email, $itemId]);
            if ($qDup->fetchColumn()) out(['status' => 'error', 'message' => 'Ese correo ya está utilizado por otro profesor.'], 400);
            if ($uidActual > 0) {
                $qDupUser = $conexion->prepare('SELECT ID_Usuario FROM USUARIO WHERE LOWER(Email) = LOWER(?) AND ID_Usuario <> ? LIMIT 1');
                $qDupUser->execute([$email, $uidActual]);
                if ($qDupUser->fetchColumn()) out(['status' => 'error', 'message' => 'Ese correo ya está utilizado por otro usuario.'], 400);
            } else {
                $qDupUser = $conexion->prepare('SELECT ID_Usuario FROM USUARIO WHERE LOWER(Email) = LOWER(?) LIMIT 1');
                $qDupUser->execute([$email]);
                if ($qDupUser->fetchColumn()) out(['status' => 'error', 'message' => 'Ese correo ya está utilizado por otro usuario.'], 400);
            }
            if ($password !== '' && !validInitialPassword($password)) {
                out(['status' => 'error', 'message' => 'La contraseña debe tener al menos 8 caracteres.'], 400);
            }
            $conexion->beginTransaction();
            try {
                if ($uidActual > 0) {
                    $conexion->prepare('UPDATE USUARIO SET Email = ?' . ($password !== '' ? ', Contraseña = ?' : '') . ' WHERE ID_Usuario = ?')
                        ->execute($password !== '' ? [$email, password_hash($password, PASSWORD_DEFAULT), $uidActual] : [$email, $uidActual]);
                } elseif ($password !== '') {
                    $conexion->prepare("INSERT INTO USUARIO (Email, Contraseña, Rol) VALUES (?, ?, 'Profesor')")
                        ->execute([$email, password_hash($password, PASSWORD_DEFAULT)]);
                    $uidActual = (int)$conexion->lastInsertId();
                }
                $conexion->prepare("UPDATE PROFESOR SET Nombre=?, Apellido=?, Cedula=NULLIF(?,''), Direccion=NULLIF(?,''), Especialidad=NULLIF(?,''), Email=?, Telefono=NULLIF(?,''), ID_Usuario=NULLIF(?,0) WHERE ID_Profesor=?")
                    ->execute([$nombre, $apellido, $cedula, $direccion, $especialidad, $email, $telefono, $uidActual, $itemId]);
                $conexion->commit();
            } catch (Throwable $e) {
                if ($conexion->inTransaction()) $conexion->rollBack();
                throw $e;
            }
            out(['status' => 'success', 'message' => 'Datos del profesor y su cuenta actualizados correctamente.']);
        }

        if ($action === 'crear') {
            if (!validInitialPassword($password)) {
                out(['status' => 'error', 'message' => 'Ingresá una contraseña inicial de al menos 8 caracteres.'], 400);
            }
            $qDup = $conexion->prepare('SELECT ID_Usuario FROM USUARIO WHERE LOWER(Email) = LOWER(?) LIMIT 1');
            $qDup->execute([$email]);
            if ($qDup->fetchColumn()) out(['status' => 'error', 'message' => 'Ese correo ya está registrado.'], 400);
            $qDupP = $conexion->prepare('SELECT ID_Profesor FROM PROFESOR WHERE LOWER(Email) = LOWER(?) LIMIT 1');
            $qDupP->execute([$email]);
            if ($qDupP->fetchColumn()) out(['status' => 'error', 'message' => 'Ese correo ya está registrado como profesor.'], 400);
            $conexion->beginTransaction();
            try {
                $conexion->prepare("INSERT INTO USUARIO (Email, Contraseña, Rol) VALUES (?, ?, 'Profesor')")
                    ->execute([$email, password_hash($password, PASSWORD_DEFAULT)]);
                $uidNuevo = (int)$conexion->lastInsertId();
                $conexion->prepare("INSERT INTO PROFESOR (ID_Usuario, Nombre, Apellido, Telefono, Cedula, Direccion, Especialidad, Email) VALUES (?, ?, ?, NULLIF(?,''), NULLIF(?,''), NULLIF(?,''), NULLIF(?,''), ?)")
                    ->execute([$uidNuevo, $nombre, $apellido, $telefono, $cedula, $direccion, $especialidad, $email]);
                $conexion->commit();
            } catch (Throwable $e) {
                if ($conexion->inTransaction()) $conexion->rollBack();
                throw $e;
            }
            out(['status' => 'success', 'message' => 'Profesor y cuenta de acceso creados correctamente.']);
        }
    }

    // RESPONSABLES
    if ($entity === 'responsables') {
        $idAlumno = id('id_alumno');
        $nombre = post('nombre');
        $apellido = post('apellido');
        $parentesco = post('parentesco');
        $cedula = post('cedula');
        $telefono = post('telefono');
        $direccion = post('direccion');

        if ($action === 'eliminar') {
            if ($itemId <= 0) out(['status' => 'error', 'message' => 'ID no válido.'], 400);
            $conexion->prepare("DELETE FROM RESPONSABLE WHERE ID_Responsable = ?")->execute([$itemId]);
            out(['status' => 'success', 'message' => 'Responsable eliminado.']);
        }

        if ($action === 'editar') {
            if ($itemId <= 0) out(['status' => 'error', 'message' => 'ID no válido.'], 400);
            $stmtR = $conexion->prepare("
                UPDATE RESPONSABLE SET 
                    ID_Alumno = ?, Nombre = ?, Apellido = ?, Parentesco = ?, Cedula = ?, Telefono = ?, Direccion = ?
                WHERE ID_Responsable = ?
            ");
            $stmtR->execute([$idAlumno, $nombre, $apellido, $parentesco, $cedula, $telefono, $direccion, $itemId]);
            out(['status' => 'success', 'message' => 'Datos del tutor/responsable actualizados.']);
        }

        if ($action === 'crear') {
            if ($idAlumno <= 0 || !$nombre || !$apellido) out(['status' => 'error', 'message' => 'Selecciona un alumno e ingresa nombre y apellido.'], 400);
            $stmtR = $conexion->prepare("
                INSERT INTO RESPONSABLE (ID_Alumno, Nombre, Apellido, Parentesco, Cedula, Telefono, Direccion)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            $stmtR->execute([$idAlumno, $nombre, $apellido, $parentesco, $cedula, $telefono, $direccion]);
            out(['status' => 'success', 'message' => 'Tutor registrado con éxito.']);
        }
    }

    // SEMINARIOS
    if ($entity === 'seminarios') {
        $nombre = post('nombre');
        $desc = post('descripcion');
        $costo = (float)($_POST['costo'] ?? 0);
        $fecha = post('fecha');
        $hora = post('hora');
        $lugar = post('lugar');
        $ponente = post('ponente', 'Profesor VILAMIR');
        $cupo = (int)($_POST['cupo'] ?? 0);

        if ($action === 'eliminar') {
            $conexion->prepare("DELETE FROM SEMINARIO WHERE ID_Seminario=?")->execute([$itemId]);
            out(['status' => 'success', 'message' => 'Seminario eliminado.']);
        }
        if ($action === 'editar') {
            $conexion->prepare("
                UPDATE SEMINARIO SET 
                    Nombre=?, Descripcion=?, Costo=?, Fecha=?, Titulo=?, Hora=?, Lugar=?, Ponente=?, Cupo=?
                WHERE ID_Seminario=?
            ")->execute([$nombre, $desc, $costo, $fecha, $nombre, $hora ?: null, $lugar ?: null, $ponente, $cupo > 0 ? $cupo : null, $itemId]);
            vilamirPromoverListaSeminario($conexion, $itemId);
            out(['status' => 'success', 'message' => 'Seminario actualizado con éxito.']);
        }
        $conexion->prepare("
            INSERT INTO SEMINARIO (Nombre, Descripcion, Costo, Fecha, Titulo, Ponente, Hora, Lugar, Cupo)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ")->execute([$nombre, $desc, $costo, $fecha, $nombre, $ponente, $hora ?: null, $lugar ?: null, $cupo > 0 ? $cupo : null]);
        out(['status' => 'success', 'message' => 'Seminario creado y publicado correctamente.']);
    }

    // PROMOCIONES
    if ($entity === 'promociones') {
        $nombre = post('nombre');
        $desc = post('descripcion');
        $descuento = (float)($_POST['descuento'] ?? 0);
        $inicio = post('fecha_inicio');
        $fin = post('fecha_fin');
        $activa = isset($_POST['activa']) ? (int)$_POST['activa'] : 1;

        if ($action === 'eliminar') {
            if ($itemId <= 0) out(['status' => 'error', 'message' => 'Promoción no válida.'], 400);
            $conexion->prepare('UPDATE PROMOCION SET Activa=0 WHERE ID_Promocion=?')->execute([$itemId]);
            out(['status' => 'success', 'message' => 'Promoción desactivada correctamente.']);
        }

        if (!$nombre) out(['status' => 'error', 'message' => 'El nombre de la promoción es obligatorio.'], 400);
        if (!is_finite($descuento) || $descuento <= 0) {
            out(['status' => 'error', 'message' => 'El precio mensual debe ser mayor que cero.'], 400);
        }
        if (!in_array($activa, [0, 1], true)) $activa = 1;
        if ($inicio !== '' && !validDate($inicio)) {
            out(['status' => 'error', 'message' => 'La fecha de inicio no es válida.'], 400);
        }
        if ($fin !== '' && !validDate($fin)) {
            out(['status' => 'error', 'message' => 'La fecha de vencimiento no es válida.'], 400);
        }
        if ($inicio !== '' && $fin !== '' && $fin < $inicio) {
            out(['status' => 'error', 'message' => 'La fecha de vencimiento no puede ser anterior al inicio.'], 400);
        }

        if ($action === 'editar') {
            if ($itemId <= 0) out(['status' => 'error', 'message' => 'ID no válido.'], 400);

            $stmtUpd = $conexion->prepare("
                UPDATE PROMOCION 
                SET Nombre = ?, Descripcion = ?, Descuento = ?, Fecha_inicio = NULLIF(?,''), Fecha_fin = NULLIF(?,''), Activa = ?
                WHERE ID_Promocion = ?
            ");
            $stmtUpd->execute([$nombre, $desc, $descuento, $inicio, $fin, $activa, $itemId]);

            vilamirNotificarTodosAlumnos($conexion, "📢 Actualización de Tarifa/Promoción: '{$nombre}' ahora cuesta $" . number_format($descuento, 2, ',', '.') . " UYU.");
            out(['status' => 'success', 'message' => "Promoción '{$nombre}' actualizada a $" . number_format($descuento, 2, ',', '.') . " UYU con éxito."]);
        }

        $stmtIns = $conexion->prepare("
            INSERT INTO PROMOCION (Nombre, Descripcion, Descuento, Fecha_inicio, Fecha_fin, Activa)
            VALUES (?, ?, ?, NULLIF(?,''), NULLIF(?,''), ?)
        ");
        $stmtIns->execute([$nombre, $desc, $descuento, $inicio, $fin, $activa]);
        vilamirNotificarTodosAlumnos($conexion, "🎁 ¡Nueva Promoción en Vilamir!: '{$nombre}'. Tarifa: $" . number_format($descuento, 2, ',', '.') . " UYU.");
        out(['status' => 'success', 'message' => 'Nueva promoción creada y publicada correctamente.']);
    }

    // USUARIOS
    if ($entity === 'usuarios') {
        $email = strtolower(post('email'));
        $rol = post('rol', 'Alumno');
        $password = passwordInput();

        if ($action === 'eliminar') {
            if ($itemId <= 0) out(['status' => 'error', 'message' => 'Usuario no válido.'], 400);
            if ($itemId === (int)$_SESSION['usuario_id']) out(['status' => 'error', 'message' => 'No puedes eliminar tu propia cuenta.'], 400);

            // La FK ALUMNO.ID_Usuario -> USUARIO.ID_Usuario usa ON DELETE CASCADE.
            // Además, ALUMNO tiene relaciones históricas (incluido PAGO) con borrado en cascada.
            // Bloquear la eliminación de cualquier cuenta vinculada a un alumno.
            $qAlumno = $conexion->prepare('SELECT ID_Alumno FROM ALUMNO WHERE ID_Usuario = ? LIMIT 1');
            $qAlumno->execute([$itemId]);
            if ($qAlumno->fetchColumn()) {
                out([
                    'status' => 'error',
                    'message' => 'No se puede eliminar esta cuenta: está vinculada a un alumno y podría borrar pagos, asistencias e historial académico. Conserva el registro y solicita una baja administrativa sin borrado físico.'
                ], 409);
            }

            $conexion->prepare("DELETE FROM USUARIO WHERE ID_Usuario=?")->execute([$itemId]);
            out(['status' => 'success', 'message' => 'Usuario eliminado.']);
        }
        if ($action === 'editar') {
            $q = "UPDATE USUARIO SET Email=?, Rol=?";
            $args = [$email, $rol];
            if ($password !== '') {
                $q .= ', Contraseña=?';
                $args[] = password_hash($password, PASSWORD_DEFAULT);
            }
            $q .= ' WHERE ID_Usuario=?';
            $args[] = $itemId;
            $conexion->prepare($q)->execute($args);
            out(['status' => 'success', 'message' => 'Usuario actualizado.']);
        }
        if (!validInitialPassword($password)) out(['status' => 'error', 'message' => 'Contraseña de al menos 8 caracteres requerida.'], 400);
        $conexion->prepare("INSERT INTO USUARIO(Email, Contraseña, Rol) VALUES(?, ?, ?)")->execute([$email, password_hash($password, PASSWORD_DEFAULT), $rol]);
        out(['status' => 'success', 'message' => 'Usuario creado correctamente.']);
    }

    out(['status' => 'error', 'message' => 'Módulo no válido.'], 400);

} catch (Throwable $e) {
    error_log('API admin error: ' . $e->getMessage());
    out(['status' => 'error', 'message' => 'No se pudo completar la operación.'], 500);
}