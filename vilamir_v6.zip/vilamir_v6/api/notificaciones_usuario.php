<?php

/*
 * DESCRIPCIÓN DEL ARCHIVO
 * API de notificaciones del usuario autenticado.
 */
require_once dirname(__DIR__).'/config/conexion.php';

require_once dirname(__DIR__).'/config/sesion.php';

header('Content-Type: application/json; charset=utf-8');

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

function respuestaNotifUsuario(array $d,int $c=200):void {
    http_response_code($c);
    echo json_encode($d,JSON_UNESCAPED_UNICODE);
    exit;
    }

if(!isset($_SESSION['usuario_id'])) respuestaNotifUsuario(['status'=>'error','message'=>'Sesión requerida.'],401);

// La API está disponible para Profesores y Administradores.
$rolNotif=strcasecmp(trim((string)($_SESSION['usuario_rol']??'')),'Profesor')===0
    || strcasecmp(trim((string)($_SESSION['usuario_rol']??'')),'Administrador')===0;

if(!$rolNotif) respuestaNotifUsuario(['status'=>'error','message'=>'Acceso exclusivo para profesores y administradores.'],403);

try {

    $uid=(int)$_SESSION['usuario_id'];

    $exists=$conexion->query("SHOW TABLES LIKE 'NOTIFICACION_USUARIO'")->fetchColumn();

    if(!$exists) respuestaNotifUsuario(['status'=>'error','message'=>'Falta la migración de notificaciones V11. Ejecutá sql/migracion_notificaciones_v11.sql.'],503);

    if($_SERVER['REQUEST_METHOD']==='POST') {

        $accion=(string)($_POST['accion']??'');

        if($accion==='leer_todas') {
            $q=$conexion->prepare('UPDATE NOTIFICACION_USUARIO SET Leida=1 WHERE ID_Usuario=?');
            $q->execute([$uid]);
            respuestaNotifUsuario(['status'=>'success','message'=>'Todas las notificaciones fueron marcadas como leídas.']);
            }

        if($accion==='leer') {
            $id=(int)($_POST['id']??0);
            if($id<=0)respuestaNotifUsuario(['status'=>'error','message'=>'Notificación no válida.'],400);
            $q=$conexion->prepare('UPDATE NOTIFICACION_USUARIO SET Leida=1 WHERE ID_Notificacion_Usuario=? AND ID_Usuario=?');
            $q->execute([$id,$uid]);
            respuestaNotifUsuario(['status'=>'success','message'=>'Notificación marcada como leída.']);
            }

        respuestaNotifUsuario(['status'=>'error','message'=>'Acción no válida.'],400);
        }

    $q=$conexion->prepare('SELECT ID_Notificacion_Usuario,Titulo,Mensaje,Fecha,Leida FROM NOTIFICACION_USUARIO WHERE ID_Usuario=? ORDER BY Fecha DESC,ID_Notificacion_Usuario DESC LIMIT 30');
    $q->execute([$uid]);
    $rows=$q->fetchAll();

    respuestaNotifUsuario(['status'=>'success','rows'=>$rows,'no_leidas'=>count(array_filter($rows,fn($r)=>(int)$r['Leida']===0))]);
    }
catch(Throwable $e) {
    error_log('api/notificaciones_usuario: '.$e->getMessage());
    respuestaNotifUsuario(['status'=>'error','message'=>'No se pudieron cargar las notificaciones.'],500);
    }

