<?php

/*
 * ARCHIVO: calendario.php
 * PROPÓSITO: Endpoints de API relacionados con calendario; validan solicitudes y comunican datos entre la interfaz y el servidor.
 */
require_once dirname(__DIR__).'/config/conexion.php';

require_once dirname(__DIR__).'/config/sesion.php';

header('Content-Type: application/json; charset=utf-8');

function calout($d,$c = 200) {
    http_response_code($c);

    echo json_encode($d,JSON_UNESCAPED_UNICODE);

    exit;
    }

if
(!isset($_SESSION['usuario_id']))
calout
(['status'=>'error','message'=>'Sesión requerida.'],401);

try {

    $rol = $_SESSION['usuario_rol'] ?? '';

    $uid = (int)$_SESSION['usuario_id'];

    $tipo = strtolower(trim((string)($_GET['tipo'] ?? 'todos')));

    $disciplina = (int)($_GET['disciplina'] ?? 0);

    $grupo = (int)($_GET['grupo'] ?? 0);

    // El calendario respeta el rol: administrador ve todo; profesor ve sus grupos;
    // alumno ve solamente sus clases. Los seminarios/eventos próximos son visibles.
    $where = [];

    $params = [];

    $join = '';

    if (strcasecmp($rol, 'Profesor') === 0) {

        $join .= " INNER JOIN PROFESOR p ON p.ID_Usuario=?\n                    INNER JOIN INSCRIPCION_GRUPO_PROFESOR igp ON igp.ID_Grupo=g.ID_Grupo AND igp.ID_Profesor=p.ID_Profesor AND igp.Estado='Activa' ";

        $params[] = $uid;
        }
    elseif (strcasecmp($rol, 'Alumno') === 0) {

        $join .= " INNER JOIN ALUMNO a ON a.ID_Usuario=?\n                    INNER JOIN INSCRIPCION_GRUPO_ALUMNO iga ON iga.ID_Grupo=g.ID_Grupo AND iga.ID_Alumno=a.ID_Alumno AND iga.Estado='Activa' ";

        $params[] = $uid;
        }

    if ($disciplina > 0) {
        $where[] = 'g.ID_Disciplina=?';
        $params[] = $disciplina;
        }

    if ($grupo > 0) {
        $where[] = 'g.ID_Grupo=?';
        $params[] = $grupo;
        }

    $whereSql = $where ? ' WHERE '.implode(' AND ', $where) : '';

    $sql = "SELECT DISTINCT h.ID_Horario,h.Dia,h.Hora_inicio,h.Hora_fin,
                    g.ID_Grupo,g.Nombre AS Grupo,
                    d.ID_Disciplina,d.Nombre AS Disciplina
             FROM HORARIO h
             JOIN GRUPO g ON g.ID_Grupo=h.ID_Grupo
             LEFT JOIN DISCIPLINA d ON d.ID_Disciplina=g.ID_Disciplina
             $join $whereSql
             ORDER BY FIELD(h.Dia,'Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo'),h.Hora_inicio,g.Nombre";

    $q = $conexion->prepare($sql);

    $q->execute($params);

    $horarios = $q->fetchAll(PDO::FETCH_ASSOC);

    $seminarios = $conexion->query("SELECT ID_Seminario,
        COALESCE(NULLIF(Nombre,''),Titulo) AS Nombre,Descripcion,Fecha,Hora,Lugar,Costo
        FROM SEMINARIO WHERE Fecha>=CURDATE() ORDER BY Fecha,Hora LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);

    $disciplinas = $conexion->query("SELECT DISTINCT d.ID_Disciplina,d.Nombre
        FROM DISCIPLINA d JOIN GRUPO g ON g.ID_Disciplina=d.ID_Disciplina
        JOIN HORARIO h ON h.ID_Grupo=g.ID_Grupo ORDER BY d.Nombre")->fetchAll(PDO::FETCH_ASSOC);

    // Los grupos disponibles para el filtro se calculan con el mismo alcance del calendario.
    $grupos = [];

    foreach ($horarios as $h) {

        $gid=(int)$h['ID_Grupo'];

        if (!isset($grupos[$gid])) $grupos[$gid]=['ID_Grupo'=>$gid,'Nombre'=>$h['Grupo'],'ID_Disciplina'=>(int)$h['ID_Disciplina'],'Disciplina'=>$h['Disciplina']];
        }

    $grupos=array_values($grupos);

    calout(['status'=>'success','rol'=>$rol,'tipo'=>$tipo,'horarios'=>$horarios,'seminarios'=>$seminarios,'disciplinas'=>$disciplinas,'grupos'=>$grupos]);
    }

catch(Throwable $e) {
    error_log('calendario.php: '.$e -> getMessage());

    calout(['status' => 'error','message' => 'No se pudo cargar el calendario.'],500);
    }

