<?php

/*
 * DESCRIPCIÓN DEL ARCHIVO
 * API de datos para el espacio del profesor y sus grupos.
 */
// ============================================================
// PORTAL DEL PROFESOR - VILAMIR
// Perfil, disciplinas, grupos, horarios y acceso docente.
// ============================================================
require_once dirname(__DIR__) . '/config/conexion.php';

require_once dirname(__DIR__) . '/config/sesion.php';

header('Content-Type: application/json; charset=utf-8');

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

header('Pragma: no-cache');

function responderProfesor(array $data, int $code = 200): void {

    http_response_code($code);

    echo json_encode($data, JSON_UNESCAPED_UNICODE);

    exit;
    }

if (!isset($_SESSION['usuario_id']) || strcasecmp(trim((string)($_SESSION['usuario_rol'] ?? '')), 'Profesor') !== 0) {

    responderProfesor(['status'=>'error','message'=>'Acceso exclusivo para profesores.'], 403);
    }

try {

    $idUsuario = (int)$_SESSION['usuario_id'];

    // Primero buscamos el perfil vinculado a la cuenta.
    $stmt = $conexion->prepare(
    'SELECT ID_Profesor, ID_Usuario, Nombre, Apellido, Especialidad, Email
         FROM PROFESOR WHERE ID_Usuario=? LIMIT 1'
    );

    $stmt->execute([$idUsuario]);

    $profesor = $stmt->fetch();

    // Compatibilidad con profesores creados antes de que el vínculo ID_Usuario
    // fuera obligatorio: si el correo coincide, reparamos automáticamente el vínculo.
    if (!$profesor) {

        $stmt = $conexion->prepare(
        'SELECT ID_Profesor, ID_Usuario, Nombre, Apellido, Especialidad, Email
             FROM PROFESOR
             WHERE LOWER(Email)=LOWER(?) AND (ID_Usuario IS NULL OR ID_Usuario=0)
             LIMIT 1'
        );

        $stmt->execute([$_SESSION['usuario_email'] ?? '']);

        $profesor = $stmt->fetch();

        if ($profesor) {

            $conexion->prepare('UPDATE PROFESOR SET ID_Usuario=? WHERE ID_Profesor=?')
            ->execute([$idUsuario, $profesor['ID_Profesor']]);

            $profesor['ID_Usuario'] = $idUsuario;
            }
        }

    if (!$profesor) {

        responderProfesor([
        'status'=>'error',
        'message'=>'Tu cuenta tiene rol Profesor, pero no está vinculada a un perfil docente. Editá el profesor desde Administración para sincronizar su cuenta.'
        ], 404);
        }

    $idProfesor = (int)$profesor['ID_Profesor'];

    $accion = $_GET['accion'] ?? 'datos';

    if ($accion === 'avisos') {

        try {

            $q=$conexion->prepare('SELECT ID_Notificacion_Profesor,Categoria,Mensaje,Fecha,Leida FROM NOTIFICACION_PROFESOR WHERE ID_Profesor=? ORDER BY Fecha DESC,ID_Notificacion_Profesor DESC LIMIT 50');

            $q->execute([$idProfesor]);

            responderProfesor(['status'=>'success','avisos'=>$q->fetchAll()]);
            }
        catch(Throwable $e) {

            responderProfesor(['status'=>'success','avisos'=>[],'aviso_migracion'=>'Ejecutá sql/migracion_v11_notificaciones.sql para habilitar avisos docentes.']);
            }
        }

    if ($accion === 'marcar_aviso' && $_SERVER['REQUEST_METHOD'] === 'POST') {

        $idAviso=(int)($_POST['id']??0);

        if($idAviso<=0) responderProfesor(['status'=>'error','message'=>'Aviso no válido.'],400);

        try {

            $q=$conexion->prepare('UPDATE NOTIFICACION_PROFESOR SET Leida=1 WHERE ID_Notificacion_Profesor=? AND ID_Profesor=?');

            $q->execute([$idAviso,$idProfesor]);

            responderProfesor(['status'=>'success','message'=>'Aviso marcado como leído.']);
            }
        catch(Throwable $e) {
            responderProfesor(['status'=>'error','message'=>'Ejecutá la migración V11 para habilitar los avisos.'],500);
            }
        }

    if ($accion === 'dashboard') {

        $hasAsistencia = (bool)$conexion->query("SHOW TABLES LIKE 'ASISTENCIA'")->fetchColumn();

        $stats = ['alumnos'=>0,'presentes_mes'=>0,'registros_mes'=>0,'asistencia_mes'=>0];

        if ($hasAsistencia) {

            $q=$conexion->prepare("SELECT COUNT(DISTINCT iga.ID_Alumno) FROM INSCRIPCION_GRUPO_ALUMNO iga JOIN INSCRIPCION_GRUPO_PROFESOR igp ON igp.ID_Grupo=iga.ID_Grupo AND igp.ID_Profesor=? AND igp.Estado='Activa' WHERE iga.Estado='Activa'");

            $q->execute([$idProfesor]);
            $stats['alumnos']=(int)$q->fetchColumn();

            $q=$conexion->prepare("SELECT COUNT(*), COALESCE(SUM(CASE WHEN a.Estado='Presente' THEN 1 ELSE 0 END),0) FROM ASISTENCIA a JOIN INSCRIPCION_GRUPO_PROFESOR igp ON igp.ID_Grupo=a.ID_Grupo AND igp.ID_Profesor=? AND igp.Estado='Activa' WHERE YEAR(a.Fecha)=YEAR(CURDATE()) AND MONTH(a.Fecha)=MONTH(CURDATE())");

            $q->execute([$idProfesor]);
            $row=$q->fetch();
            $stats['registros_mes']=(int)($row[0]??0);
            $stats['presentes_mes']=(int)($row[1]??0);

            $stats['asistencia_mes']=$stats['registros_mes']>0?round(($stats['presentes_mes']/$stats['registros_mes'])*100):0;
            }
        else {

            $q=$conexion->prepare("SELECT COUNT(DISTINCT iga.ID_Alumno) FROM INSCRIPCION_GRUPO_ALUMNO iga JOIN INSCRIPCION_GRUPO_PROFESOR igp ON igp.ID_Grupo=iga.ID_Grupo AND igp.ID_Profesor=? AND igp.Estado='Activa' WHERE iga.Estado='Activa'");

            $q->execute([$idProfesor]);
            $stats['alumnos']=(int)$q->fetchColumn();
            }

        $q=$conexion->prepare("SELECT g.ID_Grupo,g.Nombre,g.Nivel,d.Nombre AS Disciplina,g.Cupo_maximo,COUNT(DISTINCT iga.ID_Alumno) AS Alumnos
             FROM GRUPO g JOIN DISCIPLINA d ON d.ID_Disciplina=g.ID_Disciplina
             JOIN INSCRIPCION_GRUPO_PROFESOR igp ON igp.ID_Grupo=g.ID_Grupo AND igp.ID_Profesor=? AND igp.Estado='Activa'
             LEFT JOIN INSCRIPCION_GRUPO_ALUMNO iga ON iga.ID_Grupo=g.ID_Grupo AND iga.Estado='Activa'
             GROUP BY g.ID_Grupo,g.Nombre,g.Nivel,d.Nombre,g.Cupo_maximo ORDER BY d.Nombre,g.Nombre");

        $q->execute([$idProfesor]);
        $gruposDashboard=$q->fetchAll();

        responderProfesor(['status'=>'success','stats'=>$stats,'grupos'=>$gruposDashboard]);
        }

    if ($accion === 'datos') {

        // Disciplinas del profesor. Si la tabla todavía no fue creada, devolvemos
        // un error claro en lugar de dejar el panel completamente en blanco.
        $stmt = $conexion->query("SHOW TABLES LIKE 'PROFESOR_DISCIPLINA'");

        if (!$stmt->fetchColumn()) {

            responderProfesor(['status'=>'error','message'=>'Falta la tabla PROFESOR_DISCIPLINA. Ejecutá sql/migracion_profesores_responsables.sql en la base de datos.'],500);
            }

        $stmt = $conexion->prepare(
        'SELECT d.ID_Disciplina,d.Nombre,d.Descripcion,d.Costo,
                    CASE WHEN pd.ID_Profesor IS NULL THEN 0 ELSE 1 END AS Seleccionada
             FROM DISCIPLINA d
             LEFT JOIN PROFESOR_DISCIPLINA pd
               ON pd.ID_Disciplina=d.ID_Disciplina AND pd.ID_Profesor=?
             ORDER BY d.Nombre'
        );

        $stmt->execute([$idProfesor]);

        $disciplinas = $stmt->fetchAll();

        // Los grupos propios son los asignados directamente al profesor.
        // También mostramos los grupos de sus disciplinas para que pueda elegir
        // inscribirse/asignarse desde la página de Grupos.
        $stmt = $conexion->query("SHOW TABLES LIKE 'INSCRIPCION_GRUPO_PROFESOR'");

        if (!$stmt->fetchColumn()) {

            responderProfesor(['status'=>'error','message'=>'Falta la tabla INSCRIPCION_GRUPO_PROFESOR. Ejecutá sql/migracion_inscripciones_grupos.sql en la base de datos.'],500);
            }

        $stmt = $conexion->prepare(
        "SELECT g.ID_Grupo,g.Nombre,g.Nivel,g.Descripcion,g.Cupo_maximo,
                    d.Nombre AS Disciplina,
                    CASE WHEN igp.ID_Profesor IS NULL THEN 0 ELSE 1 END AS Asignado
             FROM GRUPO g
             LEFT JOIN DISCIPLINA d ON d.ID_Disciplina=g.ID_Disciplina
             LEFT JOIN INSCRIPCION_GRUPO_PROFESOR igp
               ON igp.ID_Grupo=g.ID_Grupo AND igp.ID_Profesor=? AND igp.Estado='Activa'
             WHERE EXISTS (
                 SELECT 1 FROM PROFESOR_DISCIPLINA pd
                 WHERE pd.ID_Profesor=? AND pd.ID_Disciplina=g.ID_Disciplina
             ) OR igp.ID_Profesor IS NOT NULL
             ORDER BY d.Nombre,g.Nombre"
        );

        $stmt->execute([$idProfesor,$idProfesor]);

        $grupos = $stmt->fetchAll();

        $stmt = $conexion->prepare(
        "SELECT h.ID_Horario,h.Dia,h.Hora_inicio,h.Hora_fin,
                    g.ID_Grupo,g.Nombre AS Grupo,d.Nombre AS Disciplina
             FROM HORARIO h
             JOIN GRUPO g ON g.ID_Grupo=h.ID_Grupo
             LEFT JOIN DISCIPLINA d ON d.ID_Disciplina=g.ID_Disciplina
             JOIN INSCRIPCION_GRUPO_PROFESOR igp
               ON igp.ID_Grupo=g.ID_Grupo AND igp.ID_Profesor=? AND igp.Estado='Activa'
             ORDER BY FIELD(h.Dia,'Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo'),h.Hora_inicio,g.Nombre"
        );

        $stmt->execute([$idProfesor]);

        $horarios = $stmt->fetchAll();

        // Mostrar únicamente las listas de alumnos de los grupos asignados al docente.
        $stmt = $conexion->prepare("SELECT iga.ID_Grupo, a.ID_Alumno, a.Nombre, a.Apellido
            FROM INSCRIPCION_GRUPO_ALUMNO iga
            JOIN ALUMNO a ON a.ID_Alumno = iga.ID_Alumno
            JOIN INSCRIPCION_GRUPO_PROFESOR igp
              ON igp.ID_Grupo = iga.ID_Grupo AND igp.ID_Profesor = ? AND igp.Estado = 'Activa'
            WHERE iga.Estado = 'Activa'
            ORDER BY iga.ID_Grupo, a.Apellido, a.Nombre");
        $stmt->execute([$idProfesor]);
        $alumnosGrupos = $stmt->fetchAll();

        responderProfesor([
        'status'=>'success',
        'profesor'=>$profesor,
        'disciplinas'=>$disciplinas,
        'grupos'=>$grupos,
        'horarios'=>$horarios,
        'alumnos_grupos'=>$alumnosGrupos
        ]);
        }

    if ($accion === 'guardar_disciplinas' && $_SERVER['REQUEST_METHOD'] === 'POST') {

        $ids = $_POST['disciplinas'] ?? [];
        if (!is_array($ids)) {
            responderProfesor(['status'=>'error','message'=>'La selección de disciplinas no es válida.'], 400);
        }
        $ids = array_values(array_unique(array_filter(array_map('intval', $ids), static fn($id) => $id > 0)));

        $conexion->beginTransaction();
        try {
            // Validar toda la selección antes de tocar las asignaciones existentes.
            if ($ids) {
                $placeholders = implode(',', array_fill(0, count($ids), '?'));
                $validar = $conexion->prepare("SELECT ID_Disciplina FROM DISCIPLINA WHERE ID_Disciplina IN ($placeholders)");
                $validar->execute($ids);
                $validos = array_map('intval', $validar->fetchAll(PDO::FETCH_COLUMN));
                sort($validos);
                $esperados = $ids;
                sort($esperados);
                if ($validos !== $esperados) {
                    $conexion->rollBack();
                    responderProfesor(['status'=>'error','message'=>'Una o más disciplinas ya no existen. No se modificaron tus asignaciones.'], 409);
                }
            }

            // Sincronizar diferencias: no borrar todo para luego reconstruirlo.
            $actualQ = $conexion->prepare('SELECT ID_Disciplina FROM PROFESOR_DISCIPLINA WHERE ID_Profesor=?');
            $actualQ->execute([$idProfesor]);
            $actuales = array_map('intval', $actualQ->fetchAll(PDO::FETCH_COLUMN));
            $quitar = array_values(array_diff($actuales, $ids));
            $agregar = array_values(array_diff($ids, $actuales));

            if ($quitar) {
                $ph = implode(',', array_fill(0, count($quitar), '?'));
                $del = $conexion->prepare("DELETE FROM PROFESOR_DISCIPLINA WHERE ID_Profesor=? AND ID_Disciplina IN ($ph)");
                $del->execute(array_merge([$idProfesor], $quitar));
            }
            if ($agregar) {
                $ins = $conexion->prepare('INSERT INTO PROFESOR_DISCIPLINA(ID_Profesor,ID_Disciplina) VALUES(?,?)');
                foreach ($agregar as $idDisciplina) $ins->execute([$idProfesor, $idDisciplina]);
            }

            $conexion->commit();
            responderProfesor(['status'=>'success','message'=>'Disciplinas de enseñanza actualizadas.','disciplinas'=>$ids]);
        } catch(Throwable $e) {
            if ($conexion->inTransaction()) $conexion->rollBack();
            throw $e;
        }
        }

    responderProfesor(['status'=>'error','message'=>'Acción no válida.'],400);
    }
catch(Throwable $e) {

    error_log('Error en api/profesor_portal.php: '.$e->getMessage());

    responderProfesor(['status'=>'error','message'=>'No se pudo cargar el espacio docente. Verificá las migraciones de profesores y grupos.'],500);
    }

