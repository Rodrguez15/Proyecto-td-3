<?php

/*
 * ARCHIVO: grupos.php
 * PROPÓSITO: Endpoints de API relacionados con grupos; validan solicitudes y comunican datos entre la interfaz y el servidor.
 */
// ============================================================
// API GRUPOS
// GET  -> lista grupos y estado de inscripción del usuario.
// POST -> crear, editar, eliminar, inscribirse o darse de baja.
// ============================================================
require_once dirname(__DIR__) . '/config/conexion.php';

require_once dirname(__DIR__).'/config/sesion.php';

require_once dirname(__DIR__).'/config/cupos.php';

if (session_status() === PHP_SESSION_NONE) session_start();

header('Content-Type: application/json; charset=utf-8');

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

header('Pragma: no-cache');

if (!isset($_SESSION['usuario_id'])) {

    http_response_code(401);

    echo json_encode(['status'=>'error','message'=>'No autorizado.']);

    exit;
    }

$rol = $_SESSION['usuario_rol'] ?? '';

$nivelesPermitidos = ['Principiante','Intermedio','Avanzado','Competencia'];

function responder($datos, $codigo=200) {

    http_response_code($codigo);

    echo json_encode($datos, JSON_UNESCAPED_UNICODE);

    exit;
    }

try {

    // --------------------------------------------------------
    // GET: grupos disponibles
    // --------------------------------------------------------
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {

        $uid = (int)$_SESSION['usuario_id'];

        $idAlumno = 0;

        $idProfesor = 0;

        if ($rol === 'Alumno') {

            $q = $conexion->prepare('SELECT ID_Alumno FROM ALUMNO WHERE ID_Usuario=? LIMIT 1');

            $q->execute([$uid]);

            $idAlumno = (int)($q->fetchColumn() ?: 0);
            }
        elseif ($rol === 'Profesor') {

            $q = $conexion->prepare('SELECT ID_Profesor FROM PROFESOR WHERE ID_Usuario=? LIMIT 1');

            $q->execute([$uid]);

            $idProfesor = (int)($q->fetchColumn() ?: 0);
            }

        $sql = "
            SELECT
                g.ID_Grupo,
                g.Nombre,
                g.ID_Disciplina,
                d.Nombre AS Disciplina,
                g.Nivel,
                g.Descripcion,
                g.Cupo_maximo,
                (
                    SELECT COUNT(*)
                    FROM INSCRIPCION_GRUPO_ALUMNO iga
                    WHERE iga.ID_Grupo=g.ID_Grupo AND iga.Estado='Activa'
                ) AS Alumnos_inscritos,
                CASE
                    WHEN ? > 0 AND EXISTS (
                        SELECT 1 FROM INSCRIPCION_GRUPO_ALUMNO x
                        WHERE x.ID_Grupo=g.ID_Grupo AND x.ID_Alumno=? AND x.Estado='Activa'
                    ) THEN 1 ELSE 0
                END AS Alumno_inscrito,
                CASE
                    WHEN ? > 0 AND EXISTS (
                        SELECT 1 FROM INSCRIPCION_GRUPO_PROFESOR x
                        WHERE x.ID_Grupo=g.ID_Grupo AND x.ID_Profesor=? AND x.Estado='Activa'
                    ) THEN 1 ELSE 0
                END AS Profesor_inscrito,
                (SELECT COUNT(*) FROM LISTA_ESPERA le WHERE le.ID_Grupo=g.ID_Grupo AND le.Estado='En espera') AS Espera_total,
                CASE WHEN ? > 0 AND EXISTS (SELECT 1 FROM LISTA_ESPERA le WHERE le.ID_Grupo=g.ID_Grupo AND le.ID_Alumno=? AND le.Estado='En espera') THEN 1 ELSE 0 END AS Alumno_en_espera
            FROM GRUPO g
            LEFT JOIN DISCIPLINA d ON d.ID_Disciplina=g.ID_Disciplina
            ORDER BY d.Nombre ASC, g.Nombre ASC
        ";

        $q = $conexion->prepare($sql);

        $q->execute([$idAlumno,$idAlumno,$idProfesor,$idProfesor,$idAlumno,$idAlumno]);

        responder([
        'status'=>'success',
        'grupos'=>$q->fetchAll(),
        'rol'=>$rol
        ]);
        }

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

        responder(['status'=>'error','message'=>'Método no permitido.'],405);
        }

    $accion = $_POST['accion'] ?? 'crear';

    // --------------------------------------------------------
    // Inscripción de alumno o profesor.
    // --------------------------------------------------------
    if ($accion === 'entrar_espera') {

        if ($rol !== 'Alumno') responder(['status'=>'error','message'=>'Solo los alumnos pueden entrar en lista de espera.'],403);

        $idGrupo=(int)($_POST['id_grupo']??0);
        $uid=(int)$_SESSION['usuario_id'];

        $q=$conexion->prepare('SELECT ID_Alumno FROM ALUMNO WHERE ID_Usuario=? LIMIT 1');
        $q->execute([$uid]);
        $idAlumno=(int)($q->fetchColumn()?:0);

        if(!$idAlumno||!$idGrupo) responder(['status'=>'error','message'=>'Datos inválidos.'],400);

        $q=$conexion->prepare("SELECT Cupo_maximo,(SELECT COUNT(*) FROM INSCRIPCION_GRUPO_ALUMNO iga WHERE iga.ID_Grupo=GRUPO.ID_Grupo AND iga.Estado='Activa') AS Inscritos FROM GRUPO WHERE ID_Grupo=? LIMIT 1");
        $q->execute([$idGrupo]);
        $cap=$q->fetch();

        if(!$cap) responder(['status'=>'error','message'=>'El grupo no existe.'],404);

        $q=$conexion->prepare("SELECT 1 FROM INSCRIPCION_GRUPO_ALUMNO WHERE ID_Alumno=? AND ID_Grupo=? AND Estado='Activa' LIMIT 1");
        $q->execute([$idAlumno,$idGrupo]);
        if($q->fetchColumn()) responder(['status'=>'error','message'=>'Ya estás inscripto en este grupo.'],409);

        if((int)$cap['Cupo_maximo']<=0 || (int)$cap['Inscritos']<(int)$cap['Cupo_maximo']) responder(['status'=>'error','message'=>'El grupo todavía tiene lugares disponibles. Podés inscribirte directamente.'],409);

        $q=$conexion->prepare("INSERT INTO LISTA_ESPERA(ID_Alumno,ID_Grupo) VALUES(?,?) ON DUPLICATE KEY UPDATE Estado='En espera',Fecha_solicitud=CURRENT_TIMESTAMP");
        $q->execute([$idAlumno,$idGrupo]);

        responder(['status'=>'success','message'=>'Te agregamos a la lista de espera.']);
        }

    if ($accion === 'salir_espera') {

        if ($rol !== 'Alumno') responder(['status'=>'error','message'=>'Solo los alumnos pueden salir de la lista de espera.'],403);

        $idGrupo=(int)($_POST['id_grupo']??0);

        $uid=(int)$_SESSION['usuario_id'];

        $q=$conexion->prepare('SELECT ID_Alumno FROM ALUMNO WHERE ID_Usuario=? LIMIT 1');
        $q->execute([$uid]);
        $idAlumno=(int)($q->fetchColumn()?:0);

        if(!$idAlumno||$idGrupo<=0)responder(['status'=>'error','message'=>'Datos inválidos.'],400);

        $q=$conexion->prepare("UPDATE LISTA_ESPERA SET Estado='Cancelado' WHERE ID_Alumno=? AND ID_Grupo=? AND Estado='En espera'");
        $q->execute([$idAlumno,$idGrupo]);

        responder(['status'=>'success','message'=>$q->rowCount()?'Saliste de la lista de espera.':'No estabas en la lista de espera.']);
        }

    if ($accion === 'inscribir') {

        $idGrupo = (int)($_POST['id_grupo'] ?? 0);

        if ($idGrupo <= 0) responder(['status'=>'error','message'=>'Grupo no válido.']);

        $q = $conexion->prepare('SELECT ID_Grupo, ID_Disciplina, Cupo_maximo FROM GRUPO WHERE ID_Grupo=? LIMIT 1');

        $q->execute([$idGrupo]);

        $grupo = $q->fetch();

        if (!$grupo) responder(['status'=>'error','message'=>'El grupo no existe.']);

        $uid = (int)$_SESSION['usuario_id'];

        if ($rol === 'Alumno') {

            $q = $conexion->prepare('SELECT ID_Alumno FROM ALUMNO WHERE ID_Usuario=? LIMIT 1');

            $q->execute([$uid]);

            $idAlumno = (int)($q->fetchColumn() ?: 0);

            if (!$idAlumno) responder(['status'=>'error','message'=>'No se encontró el alumno asociado.'],403);

            $conexion->beginTransaction();

            $lock = $conexion->prepare('SELECT ID_Grupo,ID_Disciplina,Cupo_maximo FROM GRUPO WHERE ID_Grupo=? FOR UPDATE');

            $lock->execute([$idGrupo]);

            $grupoBloqueado=$lock->fetch();

            if(!$grupoBloqueado) {
                $conexion->rollBack();
                responder(['status'=>'error','message'=>'El grupo no existe.'],404);
                }

            $q = $conexion->prepare('SELECT ID_Inscripcion,Estado FROM INSCRIPCION_GRUPO_ALUMNO WHERE ID_Alumno=? AND ID_Grupo=? LIMIT 1');

            $q->execute([$idAlumno,$idGrupo]);

            $exist=$q->fetch();

            if($exist && strcasecmp((string)$exist['Estado'],'Activa')===0) {
                $conexion->rollBack();
                responder(['status'=>'error','message'=>'Ya estás inscrito en este grupo.'],409);
                }

            $q = $conexion->prepare("SELECT COUNT(*) FROM INSCRIPCION_GRUPO_ALUMNO WHERE ID_Grupo=? AND Estado='Activa'");

            $q->execute([$idGrupo]);

            $cantidad=(int)$q->fetchColumn();

            if((int)$grupoBloqueado['Cupo_maximo']<=0 || $cantidad >= (int)$grupoBloqueado['Cupo_maximo']) {

                $conexion->rollBack();

                responder(['status'=>'error','message'=>'Este grupo ya alcanzó su cupo máximo. Entrá a la lista de espera.'],409);
                }

            if($exist) {

                $q=$conexion->prepare("UPDATE INSCRIPCION_GRUPO_ALUMNO SET Estado='Activa',Fecha_inscripcion=CURRENT_TIMESTAMP WHERE ID_Inscripcion=?");

                $q->execute([(int)$exist['ID_Inscripcion']]);
                }
            else {

                $q=$conexion->prepare("INSERT INTO INSCRIPCION_GRUPO_ALUMNO(ID_Alumno,ID_Grupo,Estado) VALUES(?,?,'Activa')");

                $q->execute([$idAlumno,$idGrupo]);
                }

            $conexion->prepare("UPDATE LISTA_ESPERA SET Estado='Admitido' WHERE ID_Alumno=? AND ID_Grupo=? AND Estado='En espera'")->execute([$idAlumno,$idGrupo]);

            if (!empty($grupo['ID_Disciplina'])) {
                // La inscripción a la disciplina se sincroniza sin borrar el historial.
                $q = $conexion->prepare('SELECT ID_Ins_disciplina,Estado FROM INSCRIPCION_DISCIPLINA WHERE ID_Alumno=? AND ID_Disciplina=? LIMIT 1 FOR UPDATE');
                $q->execute([$idAlumno,(int)$grupo['ID_Disciplina']]);
                $insDisciplina=$q->fetch();

                if ($insDisciplina && strcasecmp((string)$insDisciplina['Estado'],'Activa')!==0) {
                    $q=$conexion->prepare("UPDATE INSCRIPCION_DISCIPLINA SET Estado='Activa',Fecha_ins=CURDATE() WHERE ID_Ins_disciplina=?");
                    $q->execute([(int)$insDisciplina['ID_Ins_disciplina']]);
                } elseif (!$insDisciplina) {
                    $q=$conexion->prepare("INSERT INTO INSCRIPCION_DISCIPLINA(ID_Alumno,ID_Disciplina,Fecha_ins,Estado) VALUES(?,?,CURDATE(),'Activa')");
                    $q->execute([$idAlumno,(int)$grupo['ID_Disciplina']]);
                }
            }

            $conexion->commit();

            responder(['status'=>'success','message'=>'Te inscribiste al grupo correctamente.']);
            }

        if ($rol === 'Profesor') {

            $q = $conexion->prepare('SELECT ID_Profesor FROM PROFESOR WHERE ID_Usuario=? LIMIT 1');

            $q->execute([$uid]);

            $idProfesor = (int)($q->fetchColumn() ?: 0);

            if (!$idProfesor) responder(['status'=>'error','message'=>'No se encontró el profesor asociado.'],403);

            // El profesor solamente puede inscribirse en grupos de disciplinas que enseña.
            if (empty($grupo['ID_Disciplina'])) {

                responder(['status'=>'error','message'=>'Este grupo todavía no tiene una disciplina asignada.']);
                }

            $q = $conexion->prepare('SELECT 1 FROM PROFESOR_DISCIPLINA WHERE ID_Profesor=? AND ID_Disciplina=?');

            $q->execute([$idProfesor,(int)$grupo['ID_Disciplina']]);

            if (!$q->fetch()) {

                responder(['status'=>'error','message'=>'Primero debes seleccionar esta disciplina como una de las que enseñas.']);
                }

            $q = $conexion->prepare('SELECT ID_Inscripcion,Estado FROM INSCRIPCION_GRUPO_PROFESOR WHERE ID_Profesor=? AND ID_Grupo=? LIMIT 1');

            $q->execute([$idProfesor,$idGrupo]);
            $asignacionExistente = $q->fetch();

            if ($asignacionExistente && strcasecmp((string)$asignacionExistente['Estado'],'Activa') === 0) {
                responder(['status'=>'error','message'=>'Ya estás asignado a este grupo.'],409);
            }

            if ($asignacionExistente) {
                // Reactiva la asignación histórica en vez de intentar crear una fila duplicada.
                $q = $conexion->prepare("UPDATE INSCRIPCION_GRUPO_PROFESOR SET Estado='Activa' WHERE ID_Inscripcion=?");
                $q->execute([(int)$asignacionExistente['ID_Inscripcion']]);
            } else {
                $q = $conexion->prepare("INSERT INTO INSCRIPCION_GRUPO_PROFESOR(ID_Profesor,ID_Grupo,Estado) VALUES(?,?, 'Activa')");
                $q->execute([$idProfesor,$idGrupo]);
            }

            responder(['status'=>'success','message'=>'Asignación al grupo actualizada correctamente.']);
            }

        responder(['status'=>'error','message'=>'Tu rol no permite inscribirse en grupos.'],403);
        }

    if ($accion === 'cancelar_inscripcion') {

        $idGrupo = (int)($_POST['id_grupo'] ?? 0);

        $uid = (int)$_SESSION['usuario_id'];

        if ($rol === 'Alumno') {

            $q = $conexion->prepare('SELECT ID_Alumno FROM ALUMNO WHERE ID_Usuario=? LIMIT 1');

            $q->execute([$uid]);

            $idAlumno = (int)($q->fetchColumn() ?: 0);

            $q = $conexion->prepare("UPDATE INSCRIPCION_GRUPO_ALUMNO SET Estado='Cancelada' WHERE ID_Alumno=? AND ID_Grupo=? AND Estado='Activa'");

            $q->execute([$idAlumno,$idGrupo]);

            $liberado=$q->rowCount()>0;
            }
        elseif ($rol === 'Profesor') {

            $q = $conexion->prepare('SELECT ID_Profesor FROM PROFESOR WHERE ID_Usuario=? LIMIT 1');

            $q->execute([$uid]);

            $idProfesor = (int)($q->fetchColumn() ?: 0);

            $q = $conexion->prepare('DELETE FROM INSCRIPCION_GRUPO_PROFESOR WHERE ID_Profesor=? AND ID_Grupo=?');

            $q->execute([$idProfesor,$idGrupo]);
            }
        else {

            responder(['status'=>'error','message'=>'No autorizado.'],403);
            }

        if ($rol === 'Alumno' && !empty($liberado)) {

            $promovidos=vilamirPromoverListaGrupo($conexion,$idGrupo);

            responder(['status'=>'success','message'=>$promovidos>0?'Inscripción cancelada. Se promovió automáticamente a la siguiente persona de la lista de espera.':'Inscripción cancelada correctamente.']);
            }

        responder(['status'=>'success','message'=>'Inscripción cancelada.']);
        }

    // --------------------------------------------------------
    // Administración de grupos.
    // --------------------------------------------------------
    if ($rol !== 'Administrador') {

        responder(['status'=>'error','message'=>'Solo el administrador puede realizar esta acción.'],403);
        }

    $id = (int)($_POST['id'] ?? 0);

    if ($accion === 'eliminar') {

        if ($id <= 0) responder(['status'=>'error','message'=>'ID no válido.']);

        $check=$conexion->prepare('SELECT ID_Grupo,Nombre FROM GRUPO WHERE ID_Grupo=? LIMIT 1');

        $check->execute([$id]);

        $grupoEliminar=$check->fetch();

        if(!$grupoEliminar) responder(['status'=>'error','message'=>'El grupo no existe.'],404);

        $dependencias=[];

        foreach([
        ['INSCRIPCION_GRUPO_ALUMNO','inscripciones de alumnos'],
        ['INSCRIPCION_GRUPO_PROFESOR','asignaciones de profesores'],
        ['HORARIO','horarios'],
        ['LISTA_ESPERA','personas en lista de espera'],
        ['ASISTENCIA','registros de asistencia']
        ] as [$tabla,$label]) {

            try {
                $c=$conexion->prepare("SELECT COUNT(*) FROM `$tabla` WHERE ID_Grupo=?");
                $c->execute([$id]);
                $n=(int)$c->fetchColumn();
                if($n>0)$dependencias[]=$n.' '.$label;
                }
            catch(Throwable $ignored) {
                }
            }

        $conexion->prepare('DELETE FROM GRUPO WHERE ID_Grupo=?')->execute([$id]);

        responder(['status'=>'success','message'=>'Grupo eliminado correctamente.'.($dependencias?' Se eliminaron también: '.implode(', ',$dependencias).'.':'')]);
        }

    $nombre = trim($_POST['nombre'] ?? '');

    $nivel = trim($_POST['nivel'] ?? '');

    $descripcion = trim($_POST['descripcion'] ?? '');

    $cupo = max(1, (int)($_POST['cupo_maximo'] ?? 20));

    $idDisciplina = (int)($_POST['id_disciplina'] ?? 0);

    if ($nombre === '' || $descripcion === '' || !in_array($nivel,$nivelesPermitidos,true)) {

        responder(['status'=>'error','message'=>'Complete correctamente los datos del grupo.']);
        }

    if ($idDisciplina <= 0) responder(['status'=>'error','message'=>'Seleccione una disciplina para el grupo.']);

    $q = $conexion->prepare('SELECT ID_Disciplina FROM DISCIPLINA WHERE ID_Disciplina=?');

    $q->execute([$idDisciplina]);

    if (!$q->fetch()) responder(['status'=>'error','message'=>'La disciplina seleccionada no existe.']);

    if ($accion === 'editar') {

        if ($id <= 0) responder(['status'=>'error','message'=>'ID no válido.']);

        $q = $conexion->prepare('UPDATE GRUPO SET Nombre=?, ID_Disciplina=?, Cupo_maximo=?, Nivel=?, Descripcion=? WHERE ID_Grupo=?');

        $q->execute([$nombre,$idDisciplina,$cupo,$nivel,$descripcion,$id]);

        $promovidos=vilamirPromoverListaGrupo($conexion,$id);

        responder(['status'=>'success','message'=>$promovidos>0?'Grupo actualizado. Se promovió automáticamente a '.$promovidos.' persona(s) de la lista de espera.':'Grupo actualizado correctamente.']);
        }

    $q = $conexion->prepare('INSERT INTO GRUPO(Nombre,ID_Disciplina,Cupo_maximo,Nivel,Descripcion) VALUES(?,?,?,?,?)');

    $q->execute([$nombre,$idDisciplina,$cupo,$nivel,$descripcion]);

    responder(['status'=>'success','message'=>'Grupo creado correctamente.']);
    }
catch (Throwable $e) {

    error_log('Error en api/grupos.php: '.$e->getMessage());

    responder(['status'=>'error','message'=>'Hubo un problema en el servidor.'],500);
    }

