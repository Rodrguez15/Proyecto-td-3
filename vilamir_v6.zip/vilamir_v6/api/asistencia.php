<?php
/*
 * ACADEMIA VILAMIR V21
 * API de asistencia docente.
 * La asistencia se identifica por alumno + grupo + fecha + horario.
 */
require_once dirname(__DIR__) . '/config/conexion.php';
require_once dirname(__DIR__) . '/config/sesion.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

function asistenciaResponder(array $datos, int $codigo = 200): void
{
    http_response_code($codigo);
    echo json_encode($datos, JSON_UNESCAPED_UNICODE);
    exit;
}

function asistenciaDiaSemana(string $fecha): ?string
{
    $dias = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
    $fechaObjeto = DateTimeImmutable::createFromFormat('!Y-m-d', $fecha);
    $errores = DateTimeImmutable::getLastErrors();
    if (!$fechaObjeto || ($errores !== false && ($errores['warning_count'] > 0 || $errores['error_count'] > 0)) || $fechaObjeto->format('Y-m-d') !== $fecha) {
        return null;
    }
    return $dias[(int) $fechaObjeto->format('w')];
}

if (!isset($_SESSION['usuario_id']) || strcasecmp(trim((string) ($_SESSION['usuario_rol'] ?? '')), 'Profesor') !== 0) {
    asistenciaResponder(['status' => 'error', 'message' => 'Acceso exclusivo para profesores.'], 403);
}

$metodo = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
if (!in_array($metodo, ['GET', 'POST'], true)) {
    header('Allow: GET, POST');
    asistenciaResponder(['status' => 'error', 'message' => 'Método no permitido.'], 405);
}

try {
    $idUsuario = (int) $_SESSION['usuario_id'];
    $buscarProfesor = $conexion->prepare('SELECT ID_Profesor FROM PROFESOR WHERE ID_Usuario = ? LIMIT 1');
    $buscarProfesor->execute([$idUsuario]);
    $idProfesor = (int) $buscarProfesor->fetchColumn();

    // Compatibilidad con perfiles docentes antiguos todavía vinculados por correo.
    if (!$idProfesor) {
        $buscarProfesor = $conexion->prepare('SELECT ID_Profesor FROM PROFESOR WHERE LOWER(Email) = LOWER(?) AND (ID_Usuario IS NULL OR ID_Usuario = 0) LIMIT 1');
        $buscarProfesor->execute([$_SESSION['usuario_email'] ?? '']);
        $idProfesor = (int) $buscarProfesor->fetchColumn();
        if ($idProfesor) {
            $conexion->prepare('UPDATE PROFESOR SET ID_Usuario = ? WHERE ID_Profesor = ?')->execute([$idUsuario, $idProfesor]);
        }
    }

    if (!$idProfesor) {
        asistenciaResponder(['status' => 'error', 'message' => 'Tu cuenta no está vinculada a un perfil de profesor. Pedí a Administración que sincronice tu perfil docente.'], 404);
    }

    $grupo = (int) ($_POST['grupo'] ?? $_GET['grupo'] ?? 0);
    $fecha = (string) ($_POST['fecha'] ?? $_GET['fecha'] ?? date('Y-m-d'));
    $dia = asistenciaDiaSemana($fecha);
    if ($dia === null) {
        asistenciaResponder(['status' => 'error', 'message' => 'La fecha de asistencia no es válida.'], 400);
    }

    if (!$grupo) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            asistenciaResponder(['status' => 'error', 'message' => 'Seleccioná un grupo.'], 400);
        }
        $grupos = $conexion->prepare("SELECT g.ID_Grupo, g.Nombre, d.Nombre AS Disciplina
            FROM GRUPO g
            JOIN DISCIPLINA d ON d.ID_Disciplina = g.ID_Disciplina
            JOIN INSCRIPCION_GRUPO_PROFESOR igp ON igp.ID_Grupo = g.ID_Grupo
            WHERE igp.ID_Profesor = ? AND igp.Estado = 'Activa'
            ORDER BY d.Nombre, g.Nombre");
        $grupos->execute([$idProfesor]);
        asistenciaResponder(['status' => 'success', 'grupos' => $grupos->fetchAll()]);
    }

    $validarGrupo = $conexion->prepare("SELECT 1 FROM INSCRIPCION_GRUPO_PROFESOR WHERE ID_Profesor = ? AND ID_Grupo = ? AND Estado = 'Activa' LIMIT 1");
    $validarGrupo->execute([$idProfesor, $grupo]);
    if (!$validarGrupo->fetchColumn()) {
        asistenciaResponder(['status' => 'error', 'message' => 'No estás asignado a este grupo.'], 403);
    }

    $consultaHorarios = $conexion->prepare('SELECT ID_Horario, Dia, Hora_inicio, Hora_fin FROM HORARIO WHERE ID_Grupo = ? AND Dia = ? ORDER BY Hora_inicio');
    $consultaHorarios->execute([$grupo, $dia]);
    $horarios = $consultaHorarios->fetchAll();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!isset($_POST['asistencias']) || !is_string($_POST['asistencias'])) {
            asistenciaResponder(['status' => 'error', 'message' => 'Falta la lista de asistencias o tiene un formato inválido. No se guardó ningún cambio.'], 400);
        }

        $horario = (int) ($_POST['horario'] ?? 0);
        if (!$horario) {
            asistenciaResponder(['status' => 'error', 'message' => 'Seleccioná el horario de la clase antes de guardar.'], 400);
        }

        $validarHorario = $conexion->prepare('SELECT 1 FROM HORARIO WHERE ID_Horario = ? AND ID_Grupo = ? AND Dia = ? LIMIT 1');
        $validarHorario->execute([$horario, $grupo, $dia]);
        if (!$validarHorario->fetchColumn()) {
            asistenciaResponder(['status' => 'error', 'message' => 'El horario seleccionado no corresponde al grupo ni al día de la asistencia.'], 400);
        }

        $items = json_decode((string) $_POST['asistencias'], true);
        if (!is_array($items)) {
            asistenciaResponder(['status' => 'error', 'message' => 'Los datos de asistencia no tienen un formato válido.'], 400);
        }

        // Validar todo el lote antes de escribir: no informar éxito si se omitió
        // silenciosamente un alumno o un estado inválido enviado por el cliente.
        $alumnosEnviados = [];
        $itemsValidados = [];
        $validarAlumno = $conexion->prepare("SELECT 1 FROM INSCRIPCION_GRUPO_ALUMNO WHERE ID_Alumno = ? AND ID_Grupo = ? AND Estado = 'Activa' LIMIT 1");

        foreach ($items as $item) {
            if (!is_array($item)) {
                asistenciaResponder(['status' => 'error', 'message' => 'La lista contiene un registro de asistencia inválido. No se guardó ningún cambio.'], 400);
            }
            $alumno = (int) ($item['alumno'] ?? 0);
            $estado = (string) ($item['estado'] ?? '');
            $observacion = trim((string) ($item['observacion'] ?? ''));
            if ($alumno <= 0 || !in_array($estado, ['Presente', 'Ausente', 'Justificado'], true)) {
                asistenciaResponder(['status' => 'error', 'message' => 'Hay un alumno o estado de asistencia inválido. No se guardó ningún cambio.'], 400);
            }
            if (isset($alumnosEnviados[$alumno])) {
                asistenciaResponder(['status' => 'error', 'message' => 'La lista contiene alumnos duplicados. Recargá la asistencia e intentá nuevamente.'], 400);
            }
            $alumnosEnviados[$alumno] = true;
            $validarAlumno->execute([$alumno, $grupo]);
            if (!$validarAlumno->fetchColumn()) {
                asistenciaResponder(['status' => 'error', 'message' => 'Uno de los alumnos ya no está inscripto activamente en este grupo. Recargá la lista; no se guardó ningún cambio.'], 409);
            }
            $observacionCorta = $observacion !== ''
                ? (function_exists('mb_substr') ? mb_substr($observacion, 0, 255, 'UTF-8') : substr($observacion, 0, 255))
                : null;
            $itemsValidados[] = [$alumno, $estado, $observacionCorta];
        }

        // Comprobar que el navegador envió la lista completa de alumnos activos.
        $consultaActivos = $conexion->prepare("SELECT ID_Alumno FROM INSCRIPCION_GRUPO_ALUMNO WHERE ID_Grupo = ? AND Estado = 'Activa'");
        $consultaActivos->execute([$grupo]);
        $alumnosActivos = array_map('intval', $consultaActivos->fetchAll(PDO::FETCH_COLUMN));
        sort($alumnosActivos);
        $idsEnviados = array_map('intval', array_keys($alumnosEnviados));
        sort($idsEnviados);
        if ($alumnosActivos !== $idsEnviados) {
            asistenciaResponder(['status' => 'error', 'message' => 'La lista de alumnos cambió o está incompleta. Recargá la asistencia antes de guardar. No se guardó ningún cambio.'], 409);
        }

        $conexion->beginTransaction();
        $guardar = $conexion->prepare("INSERT INTO ASISTENCIA (ID_Alumno, ID_Grupo, ID_Horario, ID_Profesor, Fecha, Estado, Observacion)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE ID_Profesor = VALUES(ID_Profesor), Estado = VALUES(Estado), Observacion = VALUES(Observacion)");

        foreach ($itemsValidados as [$alumno, $estado, $observacionCorta]) {
            $guardar->execute([$alumno, $grupo, $horario, $idProfesor, $fecha, $estado, $observacionCorta]);
        }

        $conexion->commit();
        asistenciaResponder(['status' => 'success', 'message' => 'Asistencia guardada correctamente.', 'registros' => count($itemsValidados)]);
    }

    // El horario forma parte de la identidad de la asistencia. Nunca mezclar dos
    // clases del mismo grupo y fecha en una misma lista.
    $horario = (int) ($_GET['horario'] ?? 0);
    if ($horario === 0 && count($horarios) === 1) {
        $horario = (int) $horarios[0]['ID_Horario'];
    }

    if (!$horarios) {
        asistenciaResponder(['status' => 'success', 'dia' => $dia, 'horarios' => [], 'alumnos' => [], 'requiere_horario' => false, 'message' => 'Este grupo no tiene un horario configurado para el día seleccionado.']);
    }

    if ($horario > 0) {
        $validarHorario = $conexion->prepare('SELECT 1 FROM HORARIO WHERE ID_Horario = ? AND ID_Grupo = ? AND Dia = ? LIMIT 1');
        $validarHorario->execute([$horario, $grupo, $dia]);
        if (!$validarHorario->fetchColumn()) {
            asistenciaResponder(['status' => 'error', 'message' => 'El horario seleccionado no corresponde al grupo ni al día de la asistencia.'], 400);
        }
    } elseif (count($horarios) > 1) {
        asistenciaResponder(['status' => 'success', 'dia' => $dia, 'horarios' => $horarios, 'alumnos' => [], 'requiere_horario' => true, 'message' => 'Este grupo tiene más de una clase ese día. Seleccioná el horario y volvé a cargar los alumnos.']);
    }

    $alumnos = $conexion->prepare("SELECT a.ID_Alumno, a.Nombre, a.Apellido,
            COALESCE(asist.Estado, 'Sin marcar') AS Estado,
            COALESCE(asist.Observacion, '') AS Observacion,
            asist.ID_Horario,
            COALESCE(est.Porcentaje30, 0) AS Porcentaje30
        FROM INSCRIPCION_GRUPO_ALUMNO iga
        JOIN ALUMNO a ON a.ID_Alumno = iga.ID_Alumno
        LEFT JOIN ASISTENCIA asist
            ON asist.ID_Alumno = a.ID_Alumno
            AND asist.ID_Grupo = iga.ID_Grupo
            AND asist.Fecha = ?
            AND asist.ID_Horario = ?
        LEFT JOIN (
            SELECT ID_Alumno, ID_Grupo,
                ROUND(100 * SUM(CASE WHEN Estado = 'Presente' THEN 1 ELSE 0 END) / COUNT(*), 0) AS Porcentaje30
            FROM ASISTENCIA
            WHERE Fecha >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) AND Fecha <= CURDATE()
            GROUP BY ID_Alumno, ID_Grupo
        ) est ON est.ID_Alumno = a.ID_Alumno AND est.ID_Grupo = iga.ID_Grupo
        WHERE iga.ID_Grupo = ? AND iga.Estado = 'Activa'
        ORDER BY a.Apellido, a.Nombre");
    $alumnos->execute([$fecha, $horario, $grupo]);

    asistenciaResponder([
        'status' => 'success',
        'dia' => $dia,
        'horarios' => $horarios,
        'horario_seleccionado' => $horario,
        'alumnos' => $alumnos->fetchAll(),
        'requiere_horario' => false
    ]);
} catch (Throwable $e) {
    if (isset($conexion) && $conexion->inTransaction()) {
        $conexion->rollBack();
    }
    error_log('api/asistencia.php: ' . $e->getMessage());
    asistenciaResponder(['status' => 'error', 'message' => 'No se pudo procesar la asistencia. Verificá que la migración de asistencia V19 esté aplicada en la base de datos.'], 500);
}
