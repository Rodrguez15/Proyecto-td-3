<?php
/*
 * ARCHIVO: api/avanzadas.php
 * PROPÓSITO: API de funciones complementarias (búsqueda, actividad, certificados, galería y lista de espera).
 */
ini_set('display_errors', '0');
error_reporting(E_ALL);

require_once dirname(__DIR__) . '/config/conexion.php';
require_once dirname(__DIR__) . '/config/sesion.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

function jout($d, $c = 200) {
    http_response_code($c);
    echo json_encode($d, JSON_UNESCAPED_UNICODE);
    exit;
}

function isAdmin() {
    return strcasecmp(trim((string)($_SESSION['usuario_rol'] ?? '')), 'Administrador') === 0;
}

function isStaff() {
    return in_array(strtolower(trim((string)($_SESSION['usuario_rol'] ?? ''))), ['administrador', 'profesor'], true);
}

// Función auxiliar para redimensionar y optimizar imágenes
function procesarImagenGaleria(array $f, string $dir): ?string {
    $tmp = $f['tmp_name'] ?? '';
    if (empty($tmp) || !is_uploaded_file($tmp)) return null;

    // Validar el contenido real del archivo, no su nombre ni su extensión.
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($tmp);
    $permitidos = [
        'image/jpeg' => ['ext' => 'jpg', 'tipo' => IMAGETYPE_JPEG],
        'image/png'  => ['ext' => 'png', 'tipo' => IMAGETYPE_PNG],
        'image/webp' => ['ext' => 'webp', 'tipo' => IMAGETYPE_WEBP],
    ];

    if (!isset($permitidos[$mime])) return null;

    $info = @getimagesize($tmp);
    if ($info === false || ($info['mime'] ?? '') !== $mime ||
        ($info[2] ?? 0) !== $permitidos[$mime]['tipo']) {
        return null;
    }

    if (!is_dir($dir) && !mkdir($dir, 0755, true)) {
        return null;
    }

    $nombreBase = bin2hex(random_bytes(12));

    if (extension_loaded('gd') && function_exists('imagecreatefromstring')) {
        $contenido = file_get_contents($tmp);
        $origen = ($contenido !== false) ? @imagecreatefromstring($contenido) : false;

        // Si GD no puede decodificarla, se rechaza; nunca se guarda el original.
        if ($origen === false) return null;

        // Corregir orientación si fue tomada con celular.
        if (function_exists('exif_read_data')) {
            $exif = @exif_read_data($tmp);
            if (!empty($exif['Orientation'])) {
                switch ($exif['Orientation']) {
                    case 3: $origen = imagerotate($origen, 180, 0); break;
                    case 6: $origen = imagerotate($origen, -90, 0); break;
                    case 8: $origen = imagerotate($origen, 90, 0); break;
                }
            }
        }

        $w = imagesx($origen);
        $h = imagesy($origen);
        $max = 1200;
        $ratio = min(1, $max / max($w, $h));
        $nw = max(1, (int)round($w * $ratio));
        $nh = max(1, (int)round($h * $ratio));

        $lienzo = imagecreatetruecolor($nw, $nh);
        if (!$lienzo) {
            imagedestroy($origen);
            return null;
        }

        if ($mime === 'image/png' || $mime === 'image/webp') {
            imagealphablending($lienzo, false);
            imagesavealpha($lienzo, true);
            $transparente = imagecolorallocatealpha($lienzo, 0, 0, 0, 127);
            imagefill($lienzo, 0, 0, $transparente);
        }

        imagecopyresampled($lienzo, $origen, 0, 0, 0, 0, $nw, $nh, $w, $h);

        if (function_exists('imagewebp')) {
            $nombreArchivo = $nombreBase . '.webp';
            $guardado = imagewebp($lienzo, $dir . '/' . $nombreArchivo, 82);
        } else {
            $nombreArchivo = $nombreBase . '.jpg';
            $guardado = imagejpeg($lienzo, $dir . '/' . $nombreArchivo, 82);
        }

        imagedestroy($origen);
        imagedestroy($lienzo);

        if (!$guardado) {
            @unlink($dir . '/' . $nombreArchivo);
            return null;
        }
        return $nombreArchivo;
    }

    // Sin GD, solo se conserva el archivo original si ya pasó las validaciones
    // de MIME y estructura de imagen anteriores.
    $nombreArchivo = $nombreBase . '.' . $permitidos[$mime]['ext'];
    return move_uploaded_file($tmp, $dir . '/' . $nombreArchivo) ? $nombreArchivo : null;
}
try {
    $entity = $_GET['entity'] ?? $_POST['entity'] ?? '';
    $method = $_SERVER['REQUEST_METHOD'];

    // BUSCADOR GLOBAL
    if ($entity === 'buscar') {
        if (!isAdmin()) jout(['status' => 'error', 'message' => 'Solo administradores.'], 403);

        $q = trim((string)($_GET['q'] ?? ''));
        $tipo = $_GET['tipo'] ?? 'todos';
        $like = '%' . $q . '%';
        $out = [];

        if ($tipo === 'todos' || $tipo === 'alumnos') {
            $s = $conexion->prepare("SELECT ID_Alumno AS id, CONCAT(Nombre,' ',Apellido) AS nombre, 'Alumno' AS tipo, ID_Alumno AS ref FROM ALUMNO WHERE CONCAT(Nombre,' ',Apellido) LIKE ? ORDER BY Apellido,Nombre LIMIT 50");
            $s->execute([$like]);
            $out = array_merge($out, $s->fetchAll());
        }

        if ($tipo === 'todos' || $tipo === 'profesores') {
            $s = $conexion->prepare("SELECT ID_Profesor AS id, CONCAT(Nombre,' ',Apellido) AS nombre, 'Profesor' AS tipo, ID_Profesor AS ref FROM PROFESOR WHERE CONCAT(Nombre,' ',Apellido) LIKE ? ORDER BY Apellido,Nombre LIMIT 50");
            $s->execute([$like]);
            $out = array_merge($out, $s->fetchAll());
        }

        if ($tipo === 'todos' || $tipo === 'seminarios') {
            $s = $conexion->prepare("SELECT ID_Seminario AS id, COALESCE(NULLIF(Nombre,''),Titulo) AS nombre, 'Seminario/evento' AS tipo, ID_Seminario AS ref FROM SEMINARIO WHERE COALESCE(NULLIF(Nombre,''),Titulo) LIKE ? ORDER BY Fecha DESC LIMIT 50");
            $s->execute([$like]);
            $out = array_merge($out, $s->fetchAll());
        }

        if ($tipo === 'todos' || $tipo === 'grupos') {
            $s = $conexion->prepare("SELECT ID_Grupo AS id, Nombre AS nombre, 'Grupo' AS tipo, ID_Grupo AS ref FROM GRUPO WHERE Nombre LIKE ? ORDER BY Nombre LIMIT 50");
            $s->execute([$like]);
            $out = array_merge($out, $s->fetchAll());
        }

        if ($tipo === 'todos' || $tipo === 'disciplinas') {
            $s = $conexion->prepare("SELECT ID_Disciplina AS id, Nombre AS nombre, 'Disciplina' AS tipo, ID_Disciplina AS ref FROM DISCIPLINA WHERE Nombre LIKE ? ORDER BY Nombre LIMIT 50");
            $s->execute([$like]);
            $out = array_merge($out, $s->fetchAll());
        }

        jout(['status' => 'success', 'rows' => $out]);
    }

    // ACTIVIDAD DEL SISTEMA
    if ($entity === 'actividad') {
        if (!isAdmin()) jout(['status' => 'error', 'message' => 'Solo administradores.'], 403);
        try {
            $s = $conexion->query("SELECT ac.ID_Actividad, ac.Accion, ac.Detalle, ac.Fecha, COALESCE(u.Email,'Sistema') AS Usuario FROM ACTIVIDAD_SISTEMA ac LEFT JOIN USUARIO u ON u.ID_Usuario=ac.ID_Usuario ORDER BY ac.Fecha DESC, ac.ID_Actividad DESC LIMIT 100");
            jout(['status' => 'success', 'rows' => $s->fetchAll()]);
        } catch (Throwable $ignored) {
            jout(['status' => 'success', 'rows' => []]);
        }
    }

    // GALERÍA DE EVENTOS
    if ($entity === 'galeria') {
        $dir = dirname(__DIR__) . '/uploads/gallery';

        // 1. OBTENER FOTOS (GET)
        if ($method === 'GET') {
            try {
                $conexion->exec("CREATE TABLE IF NOT EXISTS `GALERIA_EVENTO` (
                    `ID_Galeria` int(11) NOT NULL AUTO_INCREMENT,
                    `ID_Seminario` int(11) DEFAULT NULL,
                    `Titulo` varchar(150) NOT NULL,
                    `Imagen` varchar(255) NOT NULL,
                    `Descripcion` varchar(255) DEFAULT NULL,
                    PRIMARY KEY (`ID_Galeria`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

                // Se ordena por ID_Galeria DESC para evitar fallos si no existe columna 'Fecha'
                $sql = "SELECT g.ID_Galeria, g.ID_Seminario, g.Titulo, g.Imagen, g.Descripcion,
                               COALESCE(s.Nombre, s.Titulo) AS Evento
                        FROM GALERIA_EVENTO g
                        LEFT JOIN SEMINARIO s ON s.ID_Seminario = g.ID_Seminario
                        ORDER BY g.ID_Galeria DESC";
                $s = $conexion->query($sql);
                $rows = $s ? $s->fetchAll(PDO::FETCH_ASSOC) : [];
                jout(['status' => 'success', 'rows' => $rows]);
            } catch (Throwable $e) {
                error_log('Error cargando galería: ' . $e->getMessage());
                jout(['status' => 'success', 'rows' => []]);
            }
        }

        if (!isAdmin()) jout(['status' => 'error', 'message' => 'Solo administradores.'], 403);

        $accion = strtolower(trim((string)($_POST['accion'] ?? 'agregar')));
        $id = (int)($_POST['id_galeria'] ?? 0);

        // 2. BORRAR FOTO
        if ($accion === 'borrar') {
            if ($id < 1) jout(['status' => 'error', 'message' => 'Identificador no válido.'], 400);
            $q = $conexion->prepare('SELECT Imagen FROM GALERIA_EVENTO WHERE ID_Galeria=?');
            $q->execute([$id]);
            $actual = $q->fetch();
            if (!$actual) jout(['status' => 'error', 'message' => 'La fotografía ya no existe.'], 404);

            $conexion->prepare('DELETE FROM GALERIA_EVENTO WHERE ID_Galeria=?')->execute([$id]);
            $nombre = basename((string)$actual['Imagen']);
            if ($nombre !== '' && is_file($dir . '/' . $nombre)) {
                @unlink($dir . '/' . $nombre);
            }
            jout(['status' => 'success', 'message' => 'Fotografía eliminada de la galería.']);
        }

        $titulo = trim((string)($_POST['titulo'] ?? ''));
        $desc = trim((string)($_POST['descripcion'] ?? ''));
        $sid = (int)($_POST['seminario'] ?? 0);

        if ($titulo === '') jout(['status' => 'error', 'message' => 'El título es obligatorio.'], 400);

        // Procesar imagen si fue enviada
        $nombreImagen = null;
        if (isset($_FILES['imagen']) && (($_FILES['imagen']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE)) {
            $f = $_FILES['imagen'];
            if ($f['error'] !== UPLOAD_ERR_OK) jout(['status' => 'error', 'message' => 'Error al recibir la imagen.'], 400);
            if ((int)$f['size'] > 8 * 1024 * 1024) jout(['status' => 'error', 'message' => 'La imagen supera los 8 MB.'], 400);

            // Rechazar extensiones/contenidos que no sean imágenes antes de procesar.
            // La extensión del nombre no se considera confiable: se valida el MIME real.
            $mimeArchivo = '';
            if (class_exists('finfo')) {
                $detectorMime = new finfo(FILEINFO_MIME_TYPE);
                $mimeArchivo = (string)$detectorMime->file($f['tmp_name']);
            }

            $mimesGaleria = ['image/jpeg', 'image/png', 'image/webp'];
            if (!in_array($mimeArchivo, $mimesGaleria, true)) {
                jout([
                    'status' => 'error',
                    'message' => 'Archivo rechazado. Solo se permiten imágenes JPG, PNG o WEBP.'
                ], 400);
            }

            $nombreImagen = procesarImagenGaleria($f, $dir);
            if (!$nombreImagen) jout(['status' => 'error', 'message' => 'No se pudo procesar la imagen. Verificá que sea una imagen JPG, PNG o WEBP válida.'], 500);
        }

        // 3. EDITAR FOTO
        if ($accion === 'editar') {
            if ($id < 1) jout(['status' => 'error', 'message' => 'Identificador no válido.'], 400);
            $q = $conexion->prepare('SELECT Imagen FROM GALERIA_EVENTO WHERE ID_Galeria=?');
            $q->execute([$id]);
            $actual = $q->fetch();
            if (!$actual) jout(['status' => 'error', 'message' => 'La fotografía ya no existe.'], 404);

            if ($nombreImagen !== null) {
                $conexion->prepare('UPDATE GALERIA_EVENTO SET ID_Seminario=?, Titulo=?, Imagen=?, Descripcion=? WHERE ID_Galeria=?')
                         ->execute([$sid ?: null, $titulo, $nombreImagen, $desc ?: null, $id]);
                $vieja = basename((string)$actual['Imagen']);
                if ($vieja !== '' && is_file($dir . '/' . $vieja)) @unlink($dir . '/' . $vieja);
            } else {
                $conexion->prepare('UPDATE GALERIA_EVENTO SET ID_Seminario=?, Titulo=?, Descripcion=? WHERE ID_Galeria=?')
                         ->execute([$sid ?: null, $titulo, $desc ?: null, $id]);
            }
            jout(['status' => 'success', 'message' => 'Fotografía actualizada correctamente.']);
        }

        // 4. AGREGAR FOTO
        if ($nombreImagen === null) jout(['status' => 'error', 'message' => 'Debes seleccionar una imagen.'], 400);

        $conexion->prepare('INSERT INTO GALERIA_EVENTO (ID_Seminario, Titulo, Imagen, Descripcion) VALUES (?, ?, ?, ?)')
                 ->execute([$sid ?: null, $titulo, $nombreImagen, $desc ?: null]);

        jout(['status' => 'success', 'message' => 'Fotografía agregada a la galería con éxito.']);
    }

    // LISTA DE ESPERA
    if ($entity === 'espera') {
        if (!isset($_SESSION['usuario_id'])) jout(['status' => 'error', 'message' => 'No autorizado.'], 401);
        $uid = (int)$_SESSION['usuario_id'];
        $a = $conexion->prepare('SELECT ID_Alumno FROM ALUMNO WHERE ID_Usuario=?');
        $a->execute([$uid]);
        $al = (int)$a->fetchColumn();
        $grupo = (int)($_POST['grupo'] ?? $_GET['grupo'] ?? 0);
        if (!$al || !$grupo) jout(['status' => 'error', 'message' => 'Datos inválidos.'], 400);

        $accion = $_POST['accion'] ?? 'entrar';
        if ($accion === 'salir') {
            $conexion->prepare("UPDATE LISTA_ESPERA SET Estado='Cancelado' WHERE ID_Alumno=? AND ID_Grupo=?")->execute([$al, $grupo]);
            jout(['status' => 'success', 'message' => 'Saliste de la lista de espera.']);
        }

        $conexion->prepare("INSERT INTO LISTA_ESPERA (ID_Alumno, ID_Grupo) VALUES (?, ?) ON DUPLICATE KEY UPDATE Estado='En espera', Fecha_solicitud=CURRENT_TIMESTAMP")
                 ->execute([$al, $grupo]);
        jout(['status' => 'success', 'message' => 'Te agregamos a la lista de espera.']);
    }

    jout(['status' => 'error', 'message' => 'Módulo no válido.'], 400);

} catch (Throwable $e) {
    error_log('API avanzadas: ' . $e->getMessage());
    jout(['status' => 'error', 'message' => 'No se pudo completar la operación. Intente nuevamente.'], 500);
}