<?php

/*
 * ARCHIVO: mis_clases.php
 * PROPÓSITO: Endpoints de API relacionados con mis clases; validan solicitudes y comunican datos entre la interfaz y el servidor.
 */
// ============================================================
// VILAMIR - MIS CLASES DEL ALUMNO
// Devuelve disciplinas inscritas, grupos y horarios relacionados.
// ============================================================
require_once dirname(__DIR__) . '/config/conexion.php';

require_once dirname(__DIR__) . '/config/sesion.php';

header('Content-Type: application/json; charset=utf-8');

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

header('Pragma: no-cache');

function responderMisClases(array $data, int $codigo = 200): void {

    http_response_code($codigo);

    echo json_encode($data, JSON_UNESCAPED_UNICODE);

    exit;
    }

if (!isset($_SESSION['usuario_id']) || strcasecmp((string)($_SESSION['usuario_rol'] ?? ''), 'Alumno') !== 0) {

    responderMisClases(['status' => 'error', 'message' => 'Acceso permitido únicamente a alumnos.'], 403);
    }

try {

    $uid = (int)$_SESSION['usuario_id'];

    $q = $conexion->prepare('SELECT ID_Alumno FROM ALUMNO WHERE ID_Usuario = ? LIMIT 1');

    $q->execute([$uid]);

    $idAlumno = (int)($q->fetchColumn() ?: 0);

    if ($idAlumno <= 0) {

        responderMisClases(['status' => 'error', 'message' => 'No se encontró el alumno asociado a tu cuenta.'], 403);
        }

    // 1) Disciplinas en las que el alumno está inscripto.
    $q = $conexion->prepare(
    "SELECT i.ID_Ins_disciplina, i.ID_Disciplina, i.Fecha_ins, i.Estado,
                d.Nombre, d.Descripcion, d.Costo
         FROM INSCRIPCION_DISCIPLINA i
         INNER JOIN DISCIPLINA d ON d.ID_Disciplina = i.ID_Disciplina
         WHERE i.ID_Alumno = ?
           AND (i.Estado IS NULL OR i.Estado <> 'Cancelada')
         ORDER BY d.Nombre ASC"
    );

    $q->execute([$idAlumno]);

    $disciplinas = $q->fetchAll(PDO::FETCH_ASSOC);

    // 2) Grupos activos del alumno + sus horarios.
    $q = $conexion->prepare(
    "SELECT iga.ID_Inscripcion AS ID_Inscripcion_Grupo,
                iga.ID_Grupo, iga.Fecha_inscripcion, iga.Estado,
                g.Nombre AS Grupo, g.ID_Disciplina, g.Nivel,
                g.Descripcion AS Grupo_Descripcion, g.Cupo_maximo,
                d.Nombre AS Disciplina,
                h.ID_Horario, h.Dia, h.Hora_inicio, h.Hora_fin
         FROM INSCRIPCION_GRUPO_ALUMNO iga
         INNER JOIN GRUPO g ON g.ID_Grupo = iga.ID_Grupo
         LEFT JOIN DISCIPLINA d ON d.ID_Disciplina = g.ID_Disciplina
         LEFT JOIN HORARIO h ON h.ID_Grupo = g.ID_Grupo
         WHERE iga.ID_Alumno = ?
           AND iga.Estado = 'Activa'
         ORDER BY d.Nombre ASC, g.Nombre ASC,
                  FIELD(h.Dia,'Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo'),
                  h.Hora_inicio ASC"
    );

    $q->execute([$idAlumno]);

    $filasGrupos = $q->fetchAll(PDO::FETCH_ASSOC);

    // Agrupar horarios por grupo para que el frontend no tenga que deduplicar tarjetas.
    $gruposMapa = [];

    foreach ($filasGrupos as $fila) {

        $gid = (int)$fila['ID_Grupo'];

        if (!isset($gruposMapa[$gid])) {

            $gruposMapa[$gid] = [
            'ID_Grupo' => $gid,
            'Grupo' => $fila['Grupo'],
            'ID_Disciplina' => (int)$fila['ID_Disciplina'],
            'Disciplina' => $fila['Disciplina'] ?: 'Sin disciplina',
            'Nivel' => $fila['Nivel'],
            'Descripcion' => $fila['Grupo_Descripcion'],
            'Fecha_inscripcion' => $fila['Fecha_inscripcion'],
            'Estado' => $fila['Estado'],
            'Horarios' => []
            ];
            }

        if (!empty($fila['ID_Horario'])) {

            $gruposMapa[$gid]['Horarios'][] = [
            'ID_Horario' => (int)$fila['ID_Horario'],
            'Dia' => $fila['Dia'],
            'Hora_inicio' => $fila['Hora_inicio'],
            'Hora_fin' => $fila['Hora_fin']
            ];
            }
        }

    $grupos = array_values($gruposMapa);

    // Relacionar grupos con sus disciplinas.
    $gruposPorDisciplina = [];

    foreach ($grupos as $grupo) {

        $did = (int)$grupo['ID_Disciplina'];

        if ($did > 0) {

            $gruposPorDisciplina[$did][] = $grupo;
            }
        }

    foreach ($disciplinas as &$disciplina) {

        $did = (int)$disciplina['ID_Disciplina'];

        $disciplina['Grupos'] = $gruposPorDisciplina[$did] ?? [];
        }

    unset($disciplina);

    responderMisClases([
    'status' => 'success',
    'alumno_id' => $idAlumno,
    'clases' => $disciplinas,
    'disciplinas' => $disciplinas,
    'grupos' => $grupos,
    'total_disciplinas' => count($disciplinas),
    'total_grupos' => count($grupos)
    ]);
    }
catch (Throwable $e) {

    error_log('mis_clases: ' . $e->getMessage());

    responderMisClases([
    'status' => 'error',
    'message' => 'No se pudieron cargar tus clases. Intentá nuevamente.'
    ], 500);
    }

