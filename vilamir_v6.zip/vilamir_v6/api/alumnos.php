<?php
/*
 * ARCHIVO: api/alumnos.php
 * Endpoint flexible para listado, búsqueda y gestión de alumnos.
 */
require_once dirname(__DIR__) . '/config/conexion.php';
require_once dirname(__DIR__) . '/config/sesion.php';
require_once dirname(__DIR__) . '/config/qr.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json; charset=utf-8');

// Verificación de sesión de Administrador
if (!isset($_SESSION['usuario_id'])) {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'No autorizado.']);
    exit;
}

$rol = $_SESSION['usuario_rol'] ?? '';
if (strcasecmp($rol, 'Administrador') !== 0) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Solo el administrador puede acceder a este módulo.']);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];

try {
    // ============================================================
    // CONSULTA GET: LISTADO Y BÚSQUEDA (LEFT JOIN SEGURO)
    // ============================================================
    if ($method === 'GET') {
        $busqueda = trim((string)($_GET['q'] ?? ''));

        // Se usa SELECT a.* para evitar errores si falta alguna columna en la BD
        $tieneActividad = (bool)$conexion->query("SHOW TABLES LIKE 'ACTIVIDAD_SISTEMA'")->fetchColumn();
        $estadoSelect = $tieneActividad
            ? "COALESCE((SELECT CASE ac.Accion WHEN 'ALUMNO_BAJA_TEMPORAL' THEN 'BAJA_TEMPORAL' WHEN 'ALUMNO_BAJA_DEFINITIVA' THEN 'BAJA_DEFINITIVA' WHEN 'ALUMNO_REACTIVADO' THEN 'ACTIVO' ELSE 'NO_DISPONIBLE' END FROM ACTIVIDAD_SISTEMA ac WHERE ac.Accion IN ('ALUMNO_BAJA_TEMPORAL','ALUMNO_BAJA_DEFINITIVA','ALUMNO_REACTIVADO') AND ac.Detalle LIKE CONCAT('ALUMNO_ID=', a.ID_Alumno, ';%') ORDER BY ac.ID_Actividad DESC LIMIT 1), 'ACTIVO')"
            : "'NO_DISPONIBLE'";
        $sql = "SELECT a.*, COALESCE(u.Email, '') AS Email, {$estadoSelect} AS Estado_baja
                FROM ALUMNO a
                LEFT JOIN USUARIO u ON u.ID_Usuario = a.ID_Usuario";

        $params = [];
        if ($busqueda !== '') {
            $sql .= " WHERE a.Nombre LIKE :q1 
                         OR a.Apellido LIKE :q2 
                         OR COALESCE(u.Email, '') LIKE :q3";
            $like = '%' . $busqueda . '%';
            $params = [
                ':q1' => $like,
                ':q2' => $like,
                ':q3' => $like
            ];
        }

        $sql .= " ORDER BY a.Apellido ASC, a.Nombre ASC";
        $stmt = $conexion->prepare($sql);
        $stmt->execute($params);
        $filas = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Se devuelven ambas claves ('alumnos' y 'rows') para compatibilidad total con el JS
        echo json_encode([
            'status'  => 'success',
            'total'   => count($filas),
            'alumnos' => $filas,
            'rows'    => $filas
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ============================================================
    // MÉTODO POST: CREAR / EDITAR
    // ============================================================
    if ($method === 'POST') {
        $accion = $_POST['accion'] ?? 'crear';
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;

        if ($accion === 'eliminar') {
            http_response_code(409);
            echo json_encode([
                'status' => 'error',
                'message' => 'No se permite eliminar físicamente un alumno para proteger su historial contable y académico.'
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $nombre    = trim((string)($_POST['nombre'] ?? ''));
        $apellido  = trim((string)($_POST['apellido'] ?? ''));
        $email     = strtolower(trim((string)($_POST['email'] ?? '')));
        $cedula    = trim((string)($_POST['cedula'] ?? ''));
        $telefono  = trim((string)($_POST['telefono'] ?? ''));
        $fechaNac  = trim((string)($_POST['fecha_nacimiento'] ?? ''));
        $direccion = trim((string)($_POST['direccion'] ?? ''));
        $cobertura = trim((string)($_POST['cobertura_medica'] ?? ''));
        $pesoRaw   = trim((string)($_POST['peso'] ?? '0'));
        $peso      = is_numeric($pesoRaw) ? (float)$pesoRaw : null;
        $categoria = trim((string)($_POST['categoria'] ?? ''));

        if ($nombre === '' || $apellido === '' || mb_strlen($nombre) > 100 || mb_strlen($apellido) > 100 || mb_strlen($email) > 150 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Complete correctamente nombre, apellido y correo.'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        if ($accion === 'editar') {
            if ($id <= 0) {
                echo json_encode(['status' => 'error', 'message' => 'ID no válido.'], JSON_UNESCAPED_UNICODE);
                exit;
            }

            $stmt = $conexion->prepare("SELECT ID_Usuario FROM ALUMNO WHERE ID_Alumno = :id LIMIT 1");
            $stmt->execute([':id' => $id]);
            $row = $stmt->fetch();

            if (!$row) {
                echo json_encode(['status' => 'error', 'message' => 'Alumno no encontrado.'], JSON_UNESCAPED_UNICODE);
                exit;
            }

            $uid = (int)$row['ID_Usuario'];

            // Verificar correo duplicado
            if ($uid > 0) {
                $stmt = $conexion->prepare("SELECT ID_Usuario FROM USUARIO WHERE LOWER(Email) = LOWER(:email) AND ID_Usuario <> :uid LIMIT 1");
                $stmt->execute([':email' => $email, ':uid' => $uid]);
                if ($stmt->fetch()) {
                    echo json_encode(['status' => 'error', 'message' => 'Ese correo ya está utilizado por otro usuario.'], JSON_UNESCAPED_UNICODE);
                    exit;
                }
            }

            $conexion->beginTransaction();
            try {
                // Actualización dinámica: si la columna no existiera en una BD vieja, actualiza al menos nombre y apellido
                try {
                    $sqlUpd = "UPDATE ALUMNO SET 
                                Nombre = :nombre, Apellido = :apellido, 
                                Cedula = NULLIF(:cedula,''), Telefono = NULLIF(:telefono,''), 
                                Fecha_nacimiento = NULLIF(:fnac,''), Direccion = NULLIF(:dir,''), 
                                Cobertura_medica = NULLIF(:cob,''), Peso = :peso, Categoria = NULLIF(:cat,'') 
                               WHERE ID_Alumno = :id";
                    $stmtUpd = $conexion->prepare($sqlUpd);
                    $stmtUpd->execute([
                        ':nombre'   => $nombre,
                        ':apellido' => $apellido,
                        ':cedula'   => $cedula,
                        ':telefono' => $telefono,
                        ':fnac'     => $fechaNac ?: null,
                        ':dir'      => $direccion,
                        ':cob'      => $cobertura,
                        ':peso'     => ($peso && $peso > 0) ? $peso : null,
                        ':cat'      => $categoria,
                        ':id'       => $id
                    ]);
                } catch (Throwable $eSub) {
                    // Fallback para esquemas antiguos
                    $stmtUpd = $conexion->prepare("UPDATE ALUMNO SET Nombre = :nombre, Apellido = :apellido WHERE ID_Alumno = :id");
                    $stmtUpd->execute([':nombre' => $nombre, ':apellido' => $apellido, ':id' => $id]);
                }

                if ($uid > 0) {
                    $stmtU = $conexion->prepare("UPDATE USUARIO SET Email = :email WHERE ID_Usuario = :uid");
                    $stmtU->execute([':email' => $email, ':uid' => $uid]);
                }

                $conexion->commit();
            } catch (Throwable $e) {
                if ($conexion->inTransaction()) $conexion->rollBack();
                throw $e;
            }

            echo json_encode(['status' => 'success', 'message' => 'Alumno actualizado correctamente.'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        // Crear alumno nuevo
        $stmt = $conexion->prepare("SELECT ID_Usuario FROM USUARIO WHERE LOWER(Email) = LOWER(:email) LIMIT 1");
        $stmt->execute([':email' => $email]);
        if ($stmt->fetch()) {
            echo json_encode(['status' => 'error', 'message' => 'Este correo ya está registrado.'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $temporal = bin2hex(random_bytes(6));
        $hash = password_hash($temporal, PASSWORD_DEFAULT);
        $codigoQr = vilamir_nuevo_codigo_qr($conexion);

        $conexion->beginTransaction();
        try {
            $stmtU = $conexion->prepare("INSERT INTO USUARIO (Email, Contraseña, Rol) VALUES (:email, :hash, 'Alumno')");
            $stmtU->execute([':email' => $email, ':hash' => $hash]);
            $uid = (int)$conexion->lastInsertId();

            try {
                $sqlIns = "INSERT INTO ALUMNO 
                            (ID_Usuario, Nombre, Apellido, Cedula, Telefono, Fecha_nacimiento, Direccion, Cobertura_medica, Peso, Categoria, Codigo_qr) 
                           VALUES 
                            (:uid, :nombre, :apellido, NULLIF(:cedula,''), NULLIF(:telefono,''), NULLIF(:fnac,''), NULLIF(:dir,''), NULLIF(:cob,''), :peso, NULLIF(:cat,''), :qr)";
                $stmtA = $conexion->prepare($sqlIns);
                $stmtA->execute([
                    ':uid'      => $uid,
                    ':nombre'   => $nombre,
                    ':apellido' => $apellido,
                    ':cedula'   => $cedula,
                    ':telefono' => $telefono,
                    ':fnac'     => $fechaNac ?: null,
                    ':dir'      => $direccion,
                    ':cob'      => $cobertura,
                    ':peso'     => ($peso && $peso > 0) ? $peso : null,
                    ':cat'      => $categoria,
                    ':qr'       => $codigoQr
                ]);
            } catch (Throwable $eSub) {
                // Fallback si la tabla no tuviera las columnas extras
                $stmtA = $conexion->prepare("INSERT INTO ALUMNO (ID_Usuario, Nombre, Apellido) VALUES (:uid, :nombre, :apellido)");
                $stmtA->execute([':uid' => $uid, ':nombre' => $nombre, ':apellido' => $apellido]);
            }

            $conexion->commit();
        } catch (Throwable $e) {
            if ($conexion->inTransaction()) $conexion->rollBack();
            throw $e;
        }

        echo json_encode([
            'status'            => 'success',
            'message'           => 'Alumno registrado correctamente.',
            'password_temporal' => $temporal,
            'codigo_qr'         => $codigoQr
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

} catch (Throwable $e) {
    if (isset($conexion) && $conexion instanceof PDO && $conexion->inTransaction()) {
        $conexion->rollBack();
    }
    error_log("Error en api/alumnos.php: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'status' => 'error', 
        'message' => 'No se pudo completar la operación. Verificá los datos e intentá nuevamente.'
    ], JSON_UNESCAPED_UNICODE);
}