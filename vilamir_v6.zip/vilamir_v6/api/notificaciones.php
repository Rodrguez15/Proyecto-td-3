<?php

/*
 * DESCRIPCIÓN DEL ARCHIVO
 * API para consultar y generar notificaciones y avisos automáticos de vencimiento (RN-06 / RN-08).
 * Corrige errores de columnas y elimina código HTML huérfano.
 */
require_once dirname(__DIR__) . '/config/conexion.php';
require_once dirname(__DIR__) . '/config/sesion.php';
require_once dirname(__DIR__) . '/config/notificaciones.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

function notifOut(array $data, int $code = 200): void {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

if (!isset($_SESSION['usuario_id']) || strcasecmp(trim((string)($_SESSION['usuario_rol'] ?? '')), 'Administrador') !== 0) {
    notifOut(['status' => 'error', 'message' => 'Acceso exclusivo para administradores.'], 403);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    notifOut(['status' => 'error', 'message' => 'Método no permitido.'], 405);
}

$accion = trim((string)($_POST['accion'] ?? ''));

try {

    // ============================================================
    // ACCIÓN: GENERAR AVISOS AUTOMÁTICOS DE CUOTAS Y EVENTOS
    // ============================================================
    if ($accion === 'generar_automaticas') {
        $creadas = ['pagos_proximos' => 0, 'pagos_vencidos' => 0, 'eventos' => 0, 'promociones' => 0];
        $alumnos = $conexion->query('SELECT ID_Alumno FROM ALUMNO ORDER BY ID_Alumno')->fetchAll(PDO::FETCH_COLUMN);

        // Pagos y eventos usan exactamente las mismas reglas y textos que el cron.
        foreach ($alumnos as $idAlumno) {
            $generadas = vilamirGenerarAvisosAlumno($conexion, (int)$idAlumno);
            foreach ($generadas as $tipo => $cantidad) {
                if (isset($creadas[$tipo])) $creadas[$tipo] += (int)$cantidad;
            }
        }

        // Las promociones también respetan el estado administrativo del alumno.
        $promosActivas = $conexion->query("SELECT ID_Promocion, Nombre, Descuento
            FROM PROMOCION
            WHERE Activa = 1 AND (Fecha_fin IS NULL OR Fecha_fin >= CURDATE())")
            ->fetchAll(PDO::FETCH_ASSOC);
        foreach ($promosActivas as $promo) {
            $mensaje = "🎁 PROMOCIÓN DISPONIBLE: {$promo['Nombre']} con un {$promo['Descuento']}% de beneficio. Consultá en tu panel de Mi Cuenta. [Promo #" . (int)$promo['ID_Promocion'] . ']';
            foreach ($alumnos as $idAlumno) {
                if (vilamirNotificarAlumno($conexion, (int)$idAlumno, $mensaje)) $creadas['promociones']++;
            }
        }

        $totalAvisos = array_sum($creadas);
        try {
            $qAuditoria = $conexion->prepare("INSERT INTO ACTIVIDAD_SISTEMA (ID_Usuario, Accion, Detalle) VALUES (?, 'Avisos automáticos', ?)");
            $qAuditoria->execute([
                (int)$_SESSION['usuario_id'],
                "Generación de {$totalAvisos} notificaciones automáticas ({$creadas['pagos_vencidos']} vencidas, {$creadas['pagos_proximos']} próximas a vencer)."
            ]);
        } catch (Throwable $eIgnored) {}

        notifOut([
            'status' => 'success',
            'message' => "Se generaron {$totalAvisos} avisos automáticos nuevos. Los avisos ya existentes no se duplicaron y se omitieron alumnos dados de baja o con estado no verificable.",
            'creadas' => $creadas,
            'total' => $totalAvisos
        ]);
    }

    // ============================================================
    // ACCIÓN: DIFUNDIR MENSAJES MANUALES A ALUMNOS O PROFESORES
    // ============================================================
    if ($accion === 'difundir_alumnos' || $accion === 'difundir_profesores') {
        $mensaje = trim((string)($_POST['mensaje'] ?? ''));

        if ($mensaje === '') {
            notifOut(['status' => 'error', 'message' => 'Escribí el mensaje antes de enviarlo.'], 400);
        }

        if (mb_strlen($mensaje) > 2000) {
            notifOut(['status' => 'error', 'message' => 'El mensaje supera los 2000 caracteres permitidos.'], 400);
        }

        if ($accion === 'difundir_alumnos') {
            $ids = $conexion->query('SELECT ID_Alumno FROM ALUMNO ORDER BY ID_Alumno')->fetchAll(PDO::FETCH_COLUMN);
            $cantidad = 0;
            foreach ($ids as $idAlumno) {
                if (vilamirNotificarAlumno($conexion, (int)$idAlumno, $mensaje)) $cantidad++;
            }
            $destino = 'alumnos';
        } else {
            $stmt = $conexion->prepare("INSERT INTO NOTIFICACION_PROFESOR (ID_Profesor, Categoria, Mensaje, Fecha, Leida) SELECT ID_Profesor, 'General', ?, NOW(), 0 FROM PROFESOR");
            $stmt->execute([$mensaje]);
            $cantidad = $stmt->rowCount();
            $destino = 'profesores';
        }

        notifOut([
            'status' => 'success',
            'message' => "Aviso difundido correctamente a {$cantidad} {$destino}.",
            'destino' => $destino,
            'cantidad' => $cantidad
        ]);
    }

    notifOut(['status' => 'error', 'message' => 'Acción no válida.'], 400);

} catch (Throwable $e) {
    error_log('Error en api/notificaciones.php: ' . $e->getMessage());
    notifOut(['status' => 'error', 'message' => 'No se pudieron generar los avisos automáticos. Verifique los registros del sistema.'], 500);
}