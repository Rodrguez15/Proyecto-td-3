<?php

/*
 * DESCRIPCIÓN DEL ARCHIVO
 * API para consultar, crear y gestionar seminarios e inscripciones.
 */
// Descripción: endpoint/configuración de seminarios. Gestiona la comunicación entre la interfaz y la base de datos.
require_once dirname(__DIR__).'/config/conexion.php';

require_once dirname(__DIR__).'/config/sesion.php';

require_once dirname(__DIR__).'/config/cupos.php';

header('Content-Type: application/json; charset=utf-8');

if(!isset($_SESSION['usuario_id'])) {

    http_response_code(401);

    echo json_encode(['status'=>'error','message'=>'No autorizado.']);

    exit;
    }

$admin=($_SESSION['usuario_rol']??'')==='Administrador';

try {

    if($_SERVER['REQUEST_METHOD']==='GET') {

        // Para los alumnos devolvemos además si ya están inscriptos.
        $uid=(int)($_SESSION['usuario_id']??0);

        $alumnoStmt=$conexion->prepare('SELECT ID_Alumno FROM ALUMNO WHERE ID_Usuario=?');

        $alumnoStmt->execute([$uid]);

        $alumno=$alumnoStmt->fetchColumn();

        if($alumno) {

            $s=$conexion->prepare("SELECT s.ID_Seminario,COALESCE(NULLIF(s.Nombre,''),s.Titulo) Nombre,s.Descripcion,s.Costo,s.Fecha,s.Hora,s.Lugar,s.Cupo,IF(i.ID_Ins_seminario IS NULL,0,1) Inscrito,i.ID_Ins_seminario,(SELECT COUNT(*) FROM INSCRIPCION_SEMINARIO ix WHERE ix.ID_Seminario=s.ID_Seminario AND ix.Estado='Activa') Inscritos,(SELECT COUNT(*) FROM LISTA_ESPERA_SEMINARIO le WHERE le.ID_Seminario=s.ID_Seminario AND le.Estado='En espera') Espera_total,IF(EXISTS(SELECT 1 FROM LISTA_ESPERA_SEMINARIO le WHERE le.ID_Seminario=s.ID_Seminario AND le.ID_Alumno=? AND le.Estado='En espera'),1,0) En_espera FROM SEMINARIO s LEFT JOIN INSCRIPCION_SEMINARIO i ON i.ID_Seminario=s.ID_Seminario AND i.ID_Alumno=? AND i.Estado='Activa' ORDER BY s.Fecha ASC");

            $s->execute([(int)$alumno,(int)$alumno]);
            }
        else {

            $s=$conexion->query("SELECT s.ID_Seminario,COALESCE(NULLIF(s.Nombre,''),s.Titulo) Nombre,s.Descripcion,s.Costo,s.Fecha,s.Hora,s.Lugar,s.Cupo,0 Inscrito,NULL ID_Ins_seminario,(SELECT COUNT(*) FROM INSCRIPCION_SEMINARIO ix WHERE ix.ID_Seminario=s.ID_Seminario AND ix.Estado='Activa') Inscritos,(SELECT COUNT(*) FROM LISTA_ESPERA_SEMINARIO le WHERE le.ID_Seminario=s.ID_Seminario AND le.Estado='En espera') Espera_total,0 En_espera FROM SEMINARIO s ORDER BY s.Fecha ASC");
            }

        echo json_encode(['status'=>'success','seminarios'=>$s->fetchAll()]);

        exit;
        }

    if(!$admin) {

        http_response_code(403);

        echo json_encode(['status'=>'error','message'=>'Solo el administrador puede modificar seminarios.']);

        exit;
        }

    $a=$_POST['accion']??'crear';

    $id=(int)($_POST['id']??0);

    if($a==='eliminar') {

        if($id<=0) throw new Exception('Seminario/evento no válido.');

        $check=$conexion->prepare('SELECT ID_Seminario FROM SEMINARIO WHERE ID_Seminario=? LIMIT 1');

        $check->execute([$id]);

        if(!$check->fetch()) throw new Exception('El seminario/evento no existe.');

        $ins=$conexion->prepare("SELECT COUNT(*) FROM INSCRIPCION_SEMINARIO WHERE ID_Seminario=? AND Estado='Activa'");
        $ins->execute([$id]);
        $activas=(int)$ins->fetchColumn();

        $espera=$conexion->prepare("SELECT COUNT(*) FROM LISTA_ESPERA_SEMINARIO WHERE ID_Seminario=? AND Estado='En espera'");
        $espera->execute([$id]);
        $enEspera=(int)$espera->fetchColumn();

        // Evitar que una acción administrativa destruya inscripciones o turnos de espera.
        if($activas>0 || $enEspera>0) {
            http_response_code(409);
            echo json_encode(['status'=>'error','message'=>'No se puede eliminar: hay '.$activas.' inscripción(es) activa(s) y '.$enEspera.' persona(s) en lista de espera. Conservá el evento o gestioná primero esas inscripciones.'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $conexion->prepare('DELETE FROM SEMINARIO WHERE ID_Seminario=?')->execute([$id]);
        echo json_encode(['status'=>'success','message'=>'Seminario/evento eliminado.']);

        exit;
        }

    $n=trim((string)($_POST['nombre']??''));
    $d=trim((string)($_POST['descripcion']??''));
    $cRaw=trim((string)($_POST['costo']??'0'));
    $c=filter_var($cRaw,FILTER_VALIDATE_FLOAT);
    $f=trim((string)($_POST['fecha']??''));
    $hora=trim((string)($_POST['hora']??''));
    $lugar=trim((string)($_POST['lugar']??''));
    $cupoRaw=trim((string)($_POST['cupo']??'0'));
    $cupo=filter_var($cupoRaw,FILTER_VALIDATE_INT);

    $fechaObj=DateTime::createFromFormat('!Y-m-d',$f);
    if($n==='' || !$fechaObj || $fechaObj->format('Y-m-d')!==$f) throw new Exception('Ingresá un nombre y una fecha válida.');
    if($c===false || $c<0 || $cupo===false || $cupo<0) throw new Exception('El costo y el cupo deben ser números válidos y no negativos.');
    if($hora!=='' && !preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d(?:[:][0-5]\d)?$/',$hora)) throw new Exception('La hora no es válida.');
    if($a==='editar') {
        if($id<=0) throw new Exception('Seminario/evento no válido.');
        $exists=$conexion->prepare('SELECT ID_Seminario FROM SEMINARIO WHERE ID_Seminario=?');
        $exists->execute([$id]);
        if(!$exists->fetchColumn()) { http_response_code(404); throw new Exception('El seminario/evento no existe.'); }
        if($cupo>0) {
            $q=$conexion->prepare("SELECT COUNT(*) FROM INSCRIPCION_SEMINARIO WHERE ID_Seminario=? AND Estado='Activa'");
            $q->execute([$id]);
            if($cupo<(int)$q->fetchColumn()) { http_response_code(409); throw new Exception('El cupo no puede ser menor que la cantidad de inscripciones activas.'); }
        }
        $conexion->prepare('UPDATE SEMINARIO SET Nombre=?,Descripcion=?,Costo=?,Fecha=?,Titulo=?,Hora=?,Lugar=?,Cupo=? WHERE ID_Seminario=?')->execute([$n,$d,$c,$f,$n,$hora?:null,$lugar?:null,$cupo?:null,$id]);
    } else {
        $conexion->prepare('INSERT INTO SEMINARIO(Nombre,Descripcion,Costo,Fecha,Titulo,Ponente,Hora,Lugar,Cupo) VALUES(?,?,?,?,?,?,?,?,?)')->execute([$n,$d,$c,$f,$n,'Por confirmar',$hora?:null,$lugar?:null,$cupo?:null]);
    }

    echo json_encode(['status'=>'success','message'=>$a==='editar'?'Seminario/evento actualizado.':'Seminario/evento creado.'], JSON_UNESCAPED_UNICODE);
    }

catch(Throwable $e) {

    error_log('api/seminarios: '.$e->getMessage());

    if(http_response_code() < 400) http_response_code(500);

    echo json_encode(['status'=>'error','message'=>($e instanceof PDOException ? 'No se pudo completar la operación. Verifique los datos e inténtelo nuevamente.' : $e->getMessage())], JSON_UNESCAPED_UNICODE);
    }

