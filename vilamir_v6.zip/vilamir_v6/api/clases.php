<?php

/*
 * ARCHIVO: clases.php
 * PROPÓSITO: Endpoints de API relacionados con clases; validan solicitudes y comunican datos entre la interfaz y el servidor.
 */
// Descripción: endpoint/configuración de clases. Gestiona la comunicación entre la interfaz y la base de datos.
require_once dirname(__DIR__).'/config/conexion.php';

require_once dirname(__DIR__).'/config/sesion.php';

if(session_status()===PHP_SESSION_NONE)session_start();

header('Content-Type: application/json; charset=utf-8');

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

header('Pragma: no-cache');

if(!isset($_SESSION['usuario_id'])) {

    http_response_code(401);

    echo json_encode(['status'=>'error','message'=>'No autorizado.']);

    exit;
    }

$admin=($_SESSION['usuario_rol']??'')==='Administrador';

try {

    if($_SERVER['REQUEST_METHOD']==='GET') {

        $s=$conexion->query('SELECT ID_Disciplina,ID_Disciplina AS ID_Clase,Nombre,Descripcion,Costo FROM DISCIPLINA ORDER BY Nombre');

        echo json_encode(['status'=>'success','clases'=>$s->fetchAll()]);

        exit;
        }

    if(!$admin) {

        http_response_code(403);

        echo json_encode(['status'=>'error','message'=>'Solo el administrador puede modificar las clases.']);

        exit;
        }

    $a=$_POST['accion']??'crear';

    $id=(int)($_POST['id']??0);

    if($a==='eliminar') {

        if($id<=0) throw new Exception('Disciplina no válida.');

        $check=$conexion->prepare('SELECT ID_Disciplina,Nombre FROM DISCIPLINA WHERE ID_Disciplina=? LIMIT 1');

        $check->execute([$id]);

        $disc=$check->fetch();

        if(!$disc) throw new Exception('La disciplina no existe.');

        $q=$conexion->prepare('SELECT COUNT(*) FROM GRUPO WHERE ID_Disciplina=?');
        $q->execute([$id]);
        $grupos=(int)$q->fetchColumn();
        if($grupos>0) { http_response_code(409); echo json_encode(['status'=>'error','message'=>'No puedes eliminar esta disciplina porque tiene '.$grupos.' grupo(s) asociado(s). Primero elimina o reasigna esos grupos.']); exit; }

        $q=$conexion->prepare('SELECT COUNT(*) FROM INSCRIPCION_DISCIPLINA WHERE ID_Disciplina=?');
        $q->execute([$id]);
        $inscripciones=(int)$q->fetchColumn();
        if($inscripciones>0) { http_response_code(409); echo json_encode(['status'=>'error','message'=>'No puedes eliminar esta disciplina porque conserva '.$inscripciones.' inscripción(es) en el historial.']); exit; }

        $conexion->prepare('DELETE FROM DISCIPLINA WHERE ID_Disciplina=?')->execute([$id]);

        echo json_encode(['status'=>'success','message'=>'Disciplina eliminada.']);

        exit;
        }

    $n=trim($_POST['nombre']??'');

    $d=trim($_POST['descripcion']??'');

    $c=(float)($_POST['costo']??0);

    if($n==='')throw new Exception('El nombre es obligatorio.');

    if($a==='editar')$conexion->prepare('UPDATE DISCIPLINA SET Nombre=?,Descripcion=?,Costo=? WHERE ID_Disciplina=?')->execute([$n,$d,$c,$id]);

    else$conexion->prepare('INSERT INTO DISCIPLINA(Nombre,Descripcion,Costo) VALUES(?,?,?)')->execute([$n,$d,$c]);

    echo json_encode(['status'=>'success','message'=>$a==='editar'?'Disciplina actualizada.':'Disciplina creada.']);
    }

catch(Throwable $e) {

    error_log('api/clases: '.$e->getMessage());

    http_response_code(500);

    echo json_encode(['status'=>'error','message'=>'No se pudo modificar la disciplina.']);
    }

