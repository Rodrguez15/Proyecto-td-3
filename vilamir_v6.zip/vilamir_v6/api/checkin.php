<?php
/*
 * ACADEMIA VILAMIR V21
 * Check-in por QR: valida alumno, registra asistencia sin duplicados
 * y consulta el estado de la cuota del mes vigente.
 * No requiere migraciones ni cambios de estructura de la base de datos.
 */
require_once dirname(__DIR__) . '/config/conexion.php';
require_once dirname(__DIR__) . '/config/sesion.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

function checkinResponder(array $datos, int $codigo = 200): void
{
    http_response_code($codigo);
    echo json_encode($datos, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function checkinDiaSemana(string $fecha): ?string
{
    $dias = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
    $obj = DateTimeImmutable::createFromFormat('!Y-m-d', $fecha);
    $errores = DateTimeImmutable::getLastErrors();
    if (!$obj || ($errores !== false && ($errores['warning_count'] > 0 || $errores['error_count'] > 0)) || $obj->format('Y-m-d') !== $fecha) {
        return null;
    }
    return $dias[(int)$obj->format('w')];
}

function checkinProfesorId(PDO $conexion): int
{
    $idUsuario = (int)($_SESSION['usuario_id'] ?? 0);
    $q = $conexion->prepare('SELECT ID_Profesor FROM PROFESOR WHERE ID_Usuario = ? LIMIT 1');
    $q->execute([$idUsuario]);
    $id = (int)$q->fetchColumn();
    if ($id > 0) return $id;

    // Compatibilidad de perfiles docentes históricos vinculados por correo.
    $email = trim((string)($_SESSION['usuario_email'] ?? ''));
    if ($email !== '') {
        $q = $conexion->prepare('SELECT ID_Profesor FROM PROFESOR WHERE LOWER(Email) = LOWER(?) AND (ID_Usuario IS NULL OR ID_Usuario = 0) LIMIT 1');
        $q->execute([$email]);
        return (int)$q->fetchColumn();
    }
    return 0;
}

function checkinValidarGrupo(PDO $conexion, string $rol, int $idProfesor, int $grupo): bool
{
    if ($grupo <= 0) return false;
    if ($rol === 'administrador') {
        $q = $conexion->prepare('SELECT 1 FROM GRUPO WHERE ID_Grupo = ? LIMIT 1');
        $q->execute([$grupo]);
        return (bool)$q->fetchColumn();
    }
    if ($idProfesor <= 0) return false;
    $q = $conexion->prepare("SELECT 1 FROM INSCRIPCION_GRUPO_PROFESOR WHERE ID_Profesor = ? AND ID_Grupo = ? AND Estado = 'Activa' LIMIT 1");
    $q->execute([$idProfesor, $grupo]);
    return (bool)$q->fetchColumn();
}

function checkinCodigo(string $valor): string
{
    $valor = trim($valor);
    if (preg_match('~^https?://~i', $valor)) {
        $partes = parse_url($valor);
        if (is_array($partes) && !empty($partes['query'])) {
            parse_str($partes['query'], $query);
            if (!empty($query['codigo'])) $valor = trim((string)$query['codigo']);
        }
    }
    return strlen($valor) <= 100 ? $valor : '';
}

$rol = strtolower(trim((string)($_SESSION['usuario_rol'] ?? '')));
if (!isset($_SESSION['usuario_id']) || !in_array($rol, ['administrador', 'profesor'], true)) {
    checkinResponder(['status' => 'error', 'message' => 'Acceso exclusivo para administración y profesores.'], 403);
}

$metodo = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
if (!in_array($metodo, ['GET', 'POST'], true)) {
    header('Allow: GET, POST');
    checkinResponder(['status' => 'error', 'message' => 'Método no permitido.'], 405);
}

try {
    $idProfesor = $rol === 'profesor' ? checkinProfesorId($conexion) : 0;
    if ($rol === 'profesor' && $idProfesor <= 0) {
        checkinResponder(['status' => 'error', 'message' => 'Tu cuenta no está vinculada a un perfil de profesor. Contactá a Administración.'], 404);
    }

    if ($metodo === 'GET') {
        $accion = strtolower(trim((string)($_GET['accion'] ?? 'grupos')));
        if ($accion === 'grupos') {
            if ($rol === 'administrador') {
                $q = $conexion->query("SELECT g.ID_Grupo, g.Nombre, d.Nombre AS Disciplina FROM GRUPO g LEFT JOIN DISCIPLINA d ON d.ID_Disciplina = g.ID_Disciplina ORDER BY d.Nombre, g.Nombre");
                $grupos = $q->fetchAll(PDO::FETCH_ASSOC);
            } else {
                $q = $conexion->prepare("SELECT g.ID_Grupo, g.Nombre, d.Nombre AS Disciplina FROM GRUPO g LEFT JOIN DISCIPLINA d ON d.ID_Disciplina = g.ID_Disciplina JOIN INSCRIPCION_GRUPO_PROFESOR igp ON igp.ID_Grupo = g.ID_Grupo WHERE igp.ID_Profesor = ? AND igp.Estado = 'Activa' ORDER BY d.Nombre, g.Nombre");
                $q->execute([$idProfesor]);
                $grupos = $q->fetchAll(PDO::FETCH_ASSOC);
            }
            checkinResponder(['status' => 'success', 'grupos' => $grupos]);
        }

        if ($accion === 'horarios') {
            $grupo = (int)($_GET['grupo'] ?? 0);
            $fecha = trim((string)($_GET['fecha'] ?? date('Y-m-d')));
            $dia = checkinDiaSemana($fecha);
            if ($dia === null) checkinResponder(['status' => 'error', 'message' => 'La fecha seleccionada no es válida.'], 400);
            if (!checkinValidarGrupo($conexion, $rol, $idProfesor, $grupo)) {
                checkinResponder(['status' => 'error', 'message' => 'No tenés permisos para consultar ese grupo.'], 403);
            }
            $q = $conexion->prepare('SELECT ID_Horario, Dia, Hora_inicio, Hora_fin FROM HORARIO WHERE ID_Grupo = ? AND Dia = ? ORDER BY Hora_inicio');
            $q->execute([$grupo, $dia]);
            checkinResponder(['status' => 'success', 'dia' => $dia, 'horarios' => $q->fetchAll(PDO::FETCH_ASSOC)]);
        }

        checkinResponder(['status' => 'error', 'message' => 'Consulta no reconocida.'], 400);
    }

    // POST: cada lectura válida verifica la cuota vigente y registra presente si corresponde.
    $codigo = checkinCodigo((string)($_POST['codigo_qr'] ?? ''));
    $grupo = (int)($_POST['grupo'] ?? 0);
    $horario = (int)($_POST['horario'] ?? 0);
    $fecha = trim((string)($_POST['fecha'] ?? date('Y-m-d')));
    $dia = checkinDiaSemana($fecha);

    if ($codigo === '') checkinResponder(['status' => 'error', 'message' => 'El código QR está vacío o no es válido.'], 400);
    if ($grupo <= 0 || $horario <= 0) checkinResponder(['status' => 'error', 'message' => 'Seleccioná el grupo y el horario antes de escanear.'], 400);
    if ($dia === null) checkinResponder(['status' => 'error', 'message' => 'La fecha de asistencia no es válida.'], 400);
    if ($fecha > date('Y-m-d')) checkinResponder(['status' => 'error', 'message' => 'No se puede registrar asistencia en una fecha futura.'], 400);
    if (!checkinValidarGrupo($conexion, $rol, $idProfesor, $grupo)) checkinResponder(['status' => 'error', 'message' => 'No estás autorizado para tomar asistencia en ese grupo.'], 403);

    $qHorario = $conexion->prepare('SELECT ID_Horario, Hora_inicio, Hora_fin FROM HORARIO WHERE ID_Horario = ? AND ID_Grupo = ? AND Dia = ? LIMIT 1');
    $qHorario->execute([$horario, $grupo, $dia]);
    $datosHorario = $qHorario->fetch(PDO::FETCH_ASSOC);
    if (!$datosHorario) checkinResponder(['status' => 'error', 'message' => 'El horario no corresponde al grupo y a la fecha seleccionados.'], 400);

    $qAlumno = $conexion->prepare('SELECT a.ID_Alumno, a.Nombre, a.Apellido, a.Cedula, a.Categoria, a.Cobertura_medica FROM ALUMNO a WHERE a.Codigo_qr = ? LIMIT 1');
    $qAlumno->execute([$codigo]);
    $alumno = $qAlumno->fetch(PDO::FETCH_ASSOC);
    if (!$alumno) checkinResponder(['status' => 'error', 'message' => 'Código QR no reconocido. Alumno no registrado.'], 404);

    $idAlumno = (int)$alumno['ID_Alumno'];
    $qGrupo = $conexion->prepare('SELECT g.Nombre, d.Nombre AS Disciplina FROM GRUPO g LEFT JOIN DISCIPLINA d ON d.ID_Disciplina = g.ID_Disciplina WHERE g.ID_Grupo = ? LIMIT 1');
    $qGrupo->execute([$grupo]);
    $datosGrupo = $qGrupo->fetch(PDO::FETCH_ASSOC) ?: ['Nombre' => 'Grupo', 'Disciplina' => ''];

    // Cuota del mes calendario actual. Los conceptos existentes incluyen el mes/año;
    // también se contempla una cuota mensual genérica cuyo vencimiento cae en este mes.
    $meses = [1=>'Enero', 2=>'Febrero', 3=>'Marzo', 4=>'Abril', 5=>'Mayo', 6=>'Junio', 7=>'Julio', 8=>'Agosto', 9=>'Septiembre', 10=>'Octubre', 11=>'Noviembre', 12=>'Diciembre'];
    $mesNombre = $meses[(int)date('n')];
    $anio = date('Y');
    $patronMes = '%' . $mesNombre . ' ' . $anio . '%';
    $inicioMes = date('Y-m-01');
    $inicioMesSiguiente = date('Y-m-01', strtotime('first day of next month'));
    $qCuota = $conexion->prepare("SELECT ID_Pago, Tipo, Importe, Fecha_vencimiento, Estado FROM PAGO WHERE ID_Alumno = ? AND LOWER(Estado) <> 'anulado' AND (LOWER(Tipo) LIKE '%cuota%' OR LOWER(Tipo) LIKE '%pase libre%') AND (Tipo LIKE ? OR (Fecha_vencimiento >= ? AND Fecha_vencimiento < ?)) ORDER BY Fecha DESC, ID_Pago DESC LIMIT 1");
    $qCuota->execute([$idAlumno, $patronMes, $inicioMes, $inicioMesSiguiente]);
    $cuota = $qCuota->fetch(PDO::FETCH_ASSOC) ?: null;

    $cuotaEstado = 'Sin cuota generada';
    if ($cuota) {
        $estadoPago = strtolower(trim((string)$cuota['Estado']));
        if (in_array($estadoPago, ['pagado', 'aprobado'], true)) {
            $cuotaEstado = 'Pagada';
        } elseif ($estadoPago === 'pendiente') {
            $cuotaEstado = (!empty($cuota['Fecha_vencimiento']) && $cuota['Fecha_vencimiento'] < date('Y-m-d')) ? 'Vencida' : 'Pendiente';
        } else {
            $cuotaEstado = (string)$cuota['Estado'];
        }
    }

    // La asistencia por QR sólo se registra si el alumno tiene inscripción activa en el grupo.
    $qInscripto = $conexion->prepare("SELECT 1 FROM INSCRIPCION_GRUPO_ALUMNO WHERE ID_Alumno = ? AND ID_Grupo = ? AND Estado = 'Activa' LIMIT 1");
    $qInscripto->execute([$idAlumno, $grupo]);
    $inscripto = (bool)$qInscripto->fetchColumn();

    $asistencia = [
        'registrada' => false,
        'ya_registrada' => false,
        'estado' => null,
        'mensaje' => 'El alumno no tiene una inscripción activa en el grupo seleccionado. No se registró la asistencia.'
    ];

    if ($inscripto) {
        $qExistente = $conexion->prepare('SELECT Estado FROM ASISTENCIA WHERE ID_Alumno = ? AND ID_Grupo = ? AND Fecha = ? AND ID_Horario = ? LIMIT 1');
        $qExistente->execute([$idAlumno, $grupo, $fecha, $horario]);
        $estadoExistente = $qExistente->fetchColumn();

        if ($estadoExistente !== false) {
            $asistencia = [
                'registrada' => false,
                'ya_registrada' => true,
                'estado' => (string)$estadoExistente,
                'mensaje' => 'La asistencia ya estaba registrada. No se creó un duplicado ni se modificó el estado existente.'
            ];
        } else {
            try {
                $conexion->beginTransaction();
                $guardar = $conexion->prepare("INSERT INTO ASISTENCIA (ID_Alumno, ID_Grupo, ID_Horario, ID_Profesor, Fecha, Estado, Observacion) VALUES (?, ?, ?, ?, ?, 'Presente', 'Registrada mediante lector QR')");
                $guardar->execute([$idAlumno, $grupo, $horario, $rol === 'profesor' ? $idProfesor : null, $fecha]);

                $detalle = sprintf('%s %s · %s · %s %s', $alumno['Nombre'], $alumno['Apellido'], $datosGrupo['Nombre'], $fecha, substr((string)$datosHorario['Hora_inicio'], 0, 5));
                $log = $conexion->prepare("INSERT INTO ACTIVIDAD_SISTEMA (ID_Usuario, Accion, Detalle) VALUES (?, 'Asistencia QR', ?)");
                $log->execute([(int)$_SESSION['usuario_id'], $detalle]);
                $conexion->commit();

                $asistencia = [
                    'registrada' => true,
                    'ya_registrada' => false,
                    'estado' => 'Presente',
                    'mensaje' => 'Asistencia registrada como presente.'
                ];
            } catch (PDOException $e) {
                if ($conexion->inTransaction()) $conexion->rollBack();
                // Si dos lecturas llegan a la vez, la clave única evita duplicar asistencia.
                if ((string)$e->getCode() === '23000') {
                    $qExistente->execute([$idAlumno, $grupo, $fecha, $horario]);
                    $estadoExistente = $qExistente->fetchColumn();
                    if ($estadoExistente !== false) {
                        $asistencia = ['registrada'=>false, 'ya_registrada'=>true, 'estado'=>(string)$estadoExistente, 'mensaje'=>'La asistencia ya estaba registrada. No se creó un duplicado.'];
                    } else {
                        throw $e;
                    }
                } else {
                    throw $e;
                }
            }
        }
    }

    $qDisciplinas = $conexion->prepare("SELECT d.Nombre FROM INSCRIPCION_DISCIPLINA i JOIN DISCIPLINA d ON d.ID_Disciplina = i.ID_Disciplina WHERE i.ID_Alumno = ? AND i.Estado = 'Activa' ORDER BY d.Nombre");
    $qDisciplinas->execute([$idAlumno]);
    $disciplinas = $qDisciplinas->fetchAll(PDO::FETCH_COLUMN);

    checkinResponder([
        'status' => 'success',
        'alumno' => [
            'id' => $idAlumno,
            'nombre' => $alumno['Nombre'] . ' ' . $alumno['Apellido'],
            'cedula' => $alumno['Cedula'] ?: 'No informada',
            'categoria' => $alumno['Categoria'] ?: 'General',
            'cobertura' => $alumno['Cobertura_medica'] ?: 'Particular',
            'disciplinas' => !empty($disciplinas) ? implode(', ', $disciplinas) : 'Sin disciplinas activas'
        ],
        'grupo' => [
            'nombre' => $datosGrupo['Nombre'],
            'disciplina' => $datosGrupo['Disciplina'] ?: 'General',
            'fecha' => $fecha,
            'hora' => substr((string)$datosHorario['Hora_inicio'], 0, 5) . ' - ' . substr((string)$datosHorario['Hora_fin'], 0, 5)
        ],
        'asistencia' => $asistencia,
        'cuota_mes' => [
            'mes' => $mesNombre . ' ' . $anio,
            'estado' => $cuotaEstado,
            'importe' => $cuota ? (float)$cuota['Importe'] : null,
            'vencimiento' => $cuota['Fecha_vencimiento'] ?? null,
            'concepto' => $cuota['Tipo'] ?? null
        ]
    ]);

} catch (Throwable $e) {
    if (isset($conexion) && $conexion->inTransaction()) $conexion->rollBack();
    error_log('api/checkin.php: ' . $e->getMessage());
    checkinResponder(['status' => 'error', 'message' => 'No se pudo procesar el lector QR. Verificá la conexión y que estén disponibles las tablas de asistencia actuales.'], 500);
}
