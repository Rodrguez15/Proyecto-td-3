<?php
ob_start();
ini_set('display_errors', '0');
error_reporting(E_ALL);

/*
 * ARCHIVO: api/portal.php
 * PROPÓSITO: API integral del portal del alumno (resumen, clases, pagos, asistencia, seminarios y perfil).
 */
require_once dirname(__DIR__) . '/config/conexion.php';
require_once dirname(__DIR__) . '/config/sesion.php';
require_once dirname(__DIR__) . '/config/notificaciones.php';
require_once dirname(__DIR__) . '/config/qr.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

// Función de salida blindada: borra cualquier espacio o aviso previo antes de enviar el JSON
function outp($data, $code = 200) {
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

if (!isset($_SESSION['usuario_id'])) {
    outp(['status' => 'error', 'message' => 'Sesión requerida.'], 401);
}

$rol = trim((string)($_SESSION['usuario_rol'] ?? ''));
if (strcasecmp($rol, 'Alumno') !== 0 && strcasecmp($rol, 'Administrador') !== 0) {
    outp(['status' => 'error', 'message' => 'Esta función está disponible únicamente para alumnos.'], 403);
}

try {
    $uid = (int)$_SESSION['usuario_id'];

    $q = $conexion->prepare('SELECT ID_Alumno FROM ALUMNO WHERE ID_Usuario = ? LIMIT 1');
    $q->execute([$uid]);
    $alumno = $q->fetchColumn();

    if (!$alumno) {
        outp(['status' => 'error', 'message' => 'Tu usuario no está asociado a un perfil de alumno.'], 403);
    }

    // Garantizar un QR persistente incluso para cuentas antiguas sin código asignado.
    vilamir_asignar_qr_alumno($conexion, (int)$alumno);

    // Generar avisos automáticos de vencimientos al alumno
    if (function_exists('vilamirGenerarAvisosAlumno')) {
        vilamirGenerarAvisosAlumno($conexion, (int)$alumno);
    }

    // ============================================================
    // PETICIONES POST (ACCIONES DEL ALUMNO)
    // ============================================================
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $raw = file_get_contents('php://input');
        if ($raw) {
            $parsed = json_decode($raw, true);
            if (is_array($parsed)) {
                $_POST = array_merge($_POST, $parsed);
            }
        }

        $accion = trim((string)($_POST['accion'] ?? $_POST['action'] ?? ''));
        $id = (int)($_POST['id'] ?? $_POST['id_seminario'] ?? $_POST['id_ins_seminario'] ?? $_POST['id_disciplina'] ?? 0);

        // 1. CAMBIAR CONTRASEÑA
        if ($accion === 'cambiar_contrasena') {
            $actual = (string)($_POST['contrasena_actual'] ?? '');
            $nueva = (string)($_POST['contrasena_nueva'] ?? '');
            $confirmacion = (string)($_POST['confirmar_contrasena'] ?? '');

            if ($actual === '' || $nueva === '' || $confirmacion === '') outp(['status' => 'error', 'message' => 'Completá los tres campos de contraseña.'], 400);
            if (strlen($nueva) < 8) outp(['status' => 'error', 'message' => 'La nueva contraseña debe tener al menos 8 caracteres.'], 400);
            if ($nueva !== $confirmacion) outp(['status' => 'error', 'message' => 'La confirmación no coincide con la nueva contraseña.'], 400);

            $q = $conexion->prepare('SELECT Contraseña FROM USUARIO WHERE ID_Usuario = ? LIMIT 1');
            $q->execute([$uid]);
            $hashActual = $q->fetchColumn();
            if (!$hashActual || !password_verify($actual, (string)$hashActual)) {
                outp(['status' => 'error', 'message' => 'La contraseña actual es incorrecta.'], 403);
            }

            $nuevoHash = password_hash($nueva, PASSWORD_DEFAULT);
            $conexion->prepare('UPDATE USUARIO SET Contraseña = ? WHERE ID_Usuario = ?')->execute([$nuevoHash, $uid]);

            outp(['status' => 'success', 'message' => 'Tu contraseña se cambió correctamente.']);
        }

        // 2. ACTUALIZAR PERFIL
        if ($accion === 'actualizar_perfil') {
            $nombre = trim((string)($_POST['nombre'] ?? ''));
            $apellido = trim((string)($_POST['apellido'] ?? ''));
            $email = trim((string)($_POST['email'] ?? ''));
            $telefono = trim((string)($_POST['telefono'] ?? ''));
            $fechaNacimiento = trim((string)($_POST['fecha_nacimiento'] ?? ''));
            $direccion = trim((string)($_POST['direccion'] ?? ''));
            $cobertura = trim((string)($_POST['cobertura_medica'] ?? ''));

            if ($nombre === '' || $apellido === '') outp(['status' => 'error', 'message' => 'Nombre y apellido son obligatorios.'], 400);
            if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) outp(['status' => 'error', 'message' => 'Ingresá un correo electrónico válido.'], 400);

            $conexion->beginTransaction();
            try {
                $q = $conexion->prepare('UPDATE ALUMNO SET Nombre = ?, Apellido = ?, Telefono = ?, Fecha_nacimiento = NULLIF(?,\'\'), Direccion = ?, Cobertura_medica = ? WHERE ID_Alumno = ?');
                $q->execute([$nombre, $apellido, $telefono ?: null, $fechaNacimiento ?: null, $direccion ?: null, $cobertura ?: null, (int)$alumno]);

                $q = $conexion->prepare('UPDATE USUARIO SET Email = ? WHERE ID_Usuario = ?');
                $q->execute([$email, $uid]);

                $conexion->commit();
                $_SESSION['usuario_nombre'] = $nombre . ' ' . $apellido;
                outp(['status' => 'success', 'message' => 'Tus datos se actualizaron correctamente.']);
            } catch (Throwable $e) {
                if ($conexion->inTransaction()) $conexion->rollBack();
                outp(['status' => 'error', 'message' => 'No se pudieron actualizar los datos.'], 500);
            }
        }

        // 3. INSCRIBIRSE A UN SEMINARIO
        if ($accion === 'inscribir_seminario' || $accion === 'inscribir') {
            if ($id <= 0) outp(['status' => 'error', 'message' => 'Seminario no válido.'], 400);

            $conexion->beginTransaction();

            $q = $conexion->prepare("SELECT ID_Seminario, COALESCE(NULLIF(Nombre,''), Titulo) AS Nombre, Fecha, Cupo, Costo FROM SEMINARIO WHERE ID_Seminario = ? LIMIT 1 FOR UPDATE");
            $q->execute([$id]);
            $seminario = $q->fetch(PDO::FETCH_ASSOC);

            if (!$seminario) {
                $conexion->rollBack();
                outp(['status' => 'error', 'message' => 'El seminario/evento no existe.'], 404);
            }

            if (!empty($seminario['Fecha']) && $seminario['Fecha'] < date('Y-m-d')) {
                $conexion->rollBack();
                outp(['status' => 'error', 'message' => 'No podés inscribirte a un evento que ya finalizó.'], 400);
            }

            $q = $conexion->prepare("SELECT ID_Ins_seminario, Estado FROM INSCRIPCION_SEMINARIO WHERE ID_Alumno=? AND ID_Seminario=? LIMIT 1");
            $q->execute([(int)$alumno, $id]);
            $exist = $q->fetch(PDO::FETCH_ASSOC);

            if ($exist && strcasecmp((string)$exist['Estado'], 'Activa') === 0) {
                $conexion->rollBack();
                outp(['status' => 'error', 'message' => 'Ya estás inscripto en este evento.'], 409);
            }

            $q = $conexion->prepare("SELECT COUNT(*) FROM INSCRIPCION_SEMINARIO WHERE ID_Seminario=? AND Estado='Activa'");
            $q->execute([$id]);
            $inscritos = (int)$q->fetchColumn();
            $cupo = (int)($seminario['Cupo'] ?? 0);

            if ($cupo > 0 && $inscritos >= $cupo) {
                $conexion->rollBack();
                outp(['status' => 'error', 'message' => 'Este evento ya alcanzó su cupo máximo.'], 409);
            }

            try {
                if ($exist) {
                    $q = $conexion->prepare("UPDATE INSCRIPCION_SEMINARIO SET Fecha_ins=CURDATE(), Estado='Activa' WHERE ID_Ins_seminario=?");
                    $q->execute([(int)$exist['ID_Ins_seminario']]);
                } else {
                    $q = $conexion->prepare("INSERT INTO INSCRIPCION_SEMINARIO(ID_Alumno, ID_Seminario, Fecha_ins, Estado) VALUES(?, ?, CURDATE(), 'Activa')");
                    $q->execute([(int)$alumno, $id]);
                }

                try {
                    $conexion->prepare("UPDATE LISTA_ESPERA_SEMINARIO SET Estado='Admitido' WHERE ID_Alumno=? AND ID_Seminario=? AND Estado='En espera'")->execute([(int)$alumno, $id]);
                } catch (Throwable $eIgnored) {}

                $pagoInfo = null;
                $costoEvento = (float)($seminario['Costo'] ?? 0);

                if ($costoEvento > 0) {
                    $tipo = 'Inscripción ' . $seminario['Nombre'];
                    $qc = $conexion->prepare("INSERT INTO PAGO(ID_Alumno, Tipo, Fecha, Importe, Estado, Metodo_pago) VALUES(?, ?, CURDATE(), ?, 'Pendiente', 'A confirmar')");
                    $qc->execute([(int)$alumno, $tipo, $costoEvento]);

                    $idPago = (int)$conexion->lastInsertId();
                    $comprobante = 'VIL-' . date('Y-m-d') . '-' . str_pad((string)$idPago, 6, '0', STR_PAD_LEFT);

                    $conexion->prepare('UPDATE PAGO SET Numero_comprobante=? WHERE ID_Pago=?')->execute([$comprobante, $idPago]);
                    $pagoInfo = ['importe' => $costoEvento, 'comprobante' => $comprobante];

                    vilamirNotificarAlumno($conexion, (int)$alumno, "Inscripción a {$seminario['Nombre']}: se generó un pago pendiente de $" . number_format($costoEvento, 2, ',', '.') . ". Comprobante: {$comprobante}");
                }

                $conexion->commit();
            } catch (Throwable $e) {
                if ($conexion->inTransaction()) $conexion->rollBack();
                outp(['status' => 'error', 'message' => 'No se pudo completar la inscripción.'], 500);
            }

            $mensajeExito = '¡Inscripción realizada correctamente!';
            if ($pagoInfo) {
                $mensajeExito .= ' Se generó un pago pendiente de $' . number_format($pagoInfo['importe'], 2, ',', '.') . ' (comprobante ' . $pagoInfo['comprobante'] . ').';
            }

            outp(['status' => 'success', 'message' => $mensajeExito, 'pago' => $pagoInfo]);
        }

        // 4. CANCELAR INSCRIPCIÓN A UN SEMINARIO
        if ($accion === 'cancelar_seminario' || $accion === 'cancelar' || $accion === 'desinscribir') {
            if ($id <= 0) outp(['status' => 'error', 'message' => 'Inscripción no válida.'], 400);

            $q = $conexion->prepare("SELECT ID_Ins_seminario, ID_Seminario 
                                     FROM INSCRIPCION_SEMINARIO 
                                     WHERE (ID_Ins_seminario = ? OR ID_Seminario = ?) 
                                       AND ID_Alumno = ? 
                                       AND Estado = 'Activa' 
                                     LIMIT 1");
            $q->execute([$id, $id, (int)$alumno]);
            $ins = $q->fetch(PDO::FETCH_ASSOC);

            if (!$ins) {
                outp(['status' => 'success', 'message' => 'La inscripción ya está cancelada.']);
            }

            $insId = (int)$ins['ID_Ins_seminario'];
            $sid = (int)$ins['ID_Seminario'];

            $conexion->prepare("UPDATE INSCRIPCION_SEMINARIO SET Estado='Cancelada' WHERE ID_Ins_seminario=?")->execute([$insId]);

            try {
                $archivoCupos = dirname(__DIR__) . '/config/cupos.php';
                if (is_file($archivoCupos)) {
                    require_once $archivoCupos;
                    if (function_exists('vilamirPromoverListaSeminario')) {
                        vilamirPromoverListaSeminario($conexion, $sid);
                    }
                }
            } catch (Throwable $eCupos) {}

            outp(['status' => 'success', 'message' => 'Inscripción cancelada correctamente.']);
        }

        // 5. INSCRIBIRSE A DISCIPLINA
        if ($accion === 'inscribir_disciplina') {
            if ($id <= 0) outp(['status' => 'error', 'message' => 'Disciplina no válida.'], 400);

            $conexion->beginTransaction();
            $q = $conexion->prepare('SELECT ID_Ins_disciplina, Estado FROM INSCRIPCION_DISCIPLINA WHERE ID_Alumno=? AND ID_Disciplina=? LIMIT 1 FOR UPDATE');
            $q->execute([(int)$alumno, $id]);
            $existente = $q->fetch(PDO::FETCH_ASSOC);

            if ($existente && strcasecmp((string)$existente['Estado'], 'Activa') === 0) {
                $conexion->rollBack();
                outp(['status' => 'error', 'message' => 'Ya estás inscripto en esta disciplina.'], 409);
            }

            if ($existente) {
                $conexion->prepare("UPDATE INSCRIPCION_DISCIPLINA SET Estado='Activa', Fecha_ins=CURDATE() WHERE ID_Ins_disciplina=?")->execute([(int)$existente['ID_Ins_disciplina']]);
            } else {
                $conexion->prepare("INSERT INTO INSCRIPCION_DISCIPLINA(ID_Alumno, ID_Disciplina, Fecha_ins, Estado) VALUES(?, ?, CURDATE(), 'Activa')")->execute([(int)$alumno, $id]);
            }

            $pagoInfo = null;
            $qc = $conexion->prepare('SELECT Nombre, Costo FROM DISCIPLINA WHERE ID_Disciplina=? LIMIT 1');
            $qc->execute([$id]);
            $discData = $qc->fetch(PDO::FETCH_ASSOC);

            if ($discData && (float)($discData['Costo'] ?? 0) > 0) {
                $importe = (float)$discData['Costo'];
                $tipo = 'Inscripción ' . $discData['Nombre'];

                $qc = $conexion->prepare("INSERT INTO PAGO(ID_Alumno, Tipo, Fecha, Importe, Estado, Metodo_pago) VALUES(?, ?, CURDATE(), ?, 'Pendiente', 'A confirmar')");
                $qc->execute([(int)$alumno, $tipo, $importe]);

                $idPago = (int)$conexion->lastInsertId();
                $comprobante = 'VIL-' . date('Y-m-d') . '-' . str_pad((string)$idPago, 6, '0', STR_PAD_LEFT);
                $conexion->prepare('UPDATE PAGO SET Numero_comprobante=? WHERE ID_Pago=?')->execute([$comprobante, $idPago]);

                $pagoInfo = ['importe' => $importe, 'comprobante' => $comprobante];
                vilamirNotificarAlumno($conexion, (int)$alumno, "Inscripción a {$discData['Nombre']}: se generó un pago pendiente de $" . number_format($importe, 2, ',', '.') . ". Comprobante: {$comprobante}");
            }

            $conexion->commit();
            outp(['status' => 'success', 'message' => 'Inscripción a disciplina realizada con éxito.', 'pago' => $pagoInfo]);
        }

        // 6. CANCELAR DISCIPLINA
        if ($accion === 'cancelar_disciplina') {
            if ($id <= 0) outp(['status' => 'error', 'message' => 'Inscripción no válida.'], 400);
            $q = $conexion->prepare("UPDATE INSCRIPCION_DISCIPLINA SET Estado='Cancelada' WHERE (ID_Ins_disciplina = ? OR ID_Disciplina = ?) AND ID_Alumno = ? AND Estado='Activa'");
            $q->execute([$id, $id, (int)$alumno]);
            outp(['status' => 'success', 'message' => 'Inscripción cancelada correctamente.']);
        }

        // 7. LEER NOTIFICACIONES
        if ($accion === 'leer_notificacion') {
            $conexion->prepare('UPDATE NOTIFICACION SET Leida=1 WHERE ID_Notificacion=? AND ID_Alumno=?')->execute([$id, (int)$alumno]);
            outp(['status' => 'success', 'message' => 'Notificación leída.']);
        }

        if ($accion === 'leer_todas_notificaciones') {
            $conexion->prepare('UPDATE NOTIFICACION SET Leida=1 WHERE ID_Alumno=?')->execute([(int)$alumno]);
            outp(['status' => 'success', 'message' => 'Todas las notificaciones marcadas como leídas.']);
        }

        outp(['status' => 'error', 'message' => 'Acción no válida.'], 400);
    }

    // ============================================================
    // PETICIONES GET (CARGA DE PANELES Y RESUMEN DE MI CUENTA)
    // ============================================================
    $entity = $_GET['entity'] ?? 'resumen';

    if ($entity === 'resumen') {
        // 1. Perfil
        $q = $conexion->prepare('SELECT a.*, u.Email FROM ALUMNO a JOIN USUARIO u ON u.ID_Usuario = a.ID_Usuario WHERE a.ID_Alumno = ?');
        $q->execute([(int)$alumno]);
        $perfil = $q->fetch(PDO::FETCH_ASSOC);

        // 2. Disciplinas
        $q = $conexion->prepare("SELECT i.ID_Ins_disciplina, i.Fecha_ins, i.Estado, d.Nombre, d.Descripcion, d.Costo 
                                 FROM INSCRIPCION_DISCIPLINA i 
                                 JOIN DISCIPLINA d ON d.ID_Disciplina = i.ID_Disciplina 
                                 WHERE i.ID_Alumno = ? AND i.Estado = 'Activa' 
                                 ORDER BY i.Fecha_ins DESC");
        $q->execute([(int)$alumno]);
        $disciplinas = $q->fetchAll(PDO::FETCH_ASSOC);

        // 3. Seminarios
        $q = $conexion->prepare("SELECT i.ID_Ins_seminario, i.Fecha_ins, i.Estado, s.Nombre, s.Descripcion, s.Costo, s.Fecha 
                                 FROM INSCRIPCION_SEMINARIO i 
                                 JOIN SEMINARIO s ON s.ID_Seminario = i.ID_Seminario 
                                 WHERE i.ID_Alumno = ? 
                                 ORDER BY s.Fecha DESC");
        $q->execute([(int)$alumno]);
        $seminarios = $q->fetchAll(PDO::FETCH_ASSOC);

        // 4. Pagos
        $q = $conexion->prepare("SELECT * FROM PAGO WHERE ID_Alumno = ? ORDER BY Fecha DESC, ID_Pago DESC");
        $q->execute([(int)$alumno]);
        $pagos = $q->fetchAll(PDO::FETCH_ASSOC);

        $resumenPagos = ['mes' => date('Y-m'), 'pagados' => 0, 'pendientes' => 0, 'vencidos' => 0, 'anulados' => 0, 'cobrado_mes' => 0, 'pendiente_total' => 0, 'vencido_total' => 0];
        foreach ($pagos as $p) {
            $e = strtolower(trim((string)$p['Estado']));
            $imp = (float)($p['Importe'] ?? 0);

            if (strpos($e, 'anul') !== false) {
                $resumenPagos['anulados']++;
            } elseif (strpos($e, 'pag') !== false) {
                $resumenPagos['pagados']++;
                if (substr((string)$p['Fecha'], 0, 7) === date('Y-m')) $resumenPagos['cobrado_mes'] += $imp;
            } elseif (!empty($p['Fecha_vencimiento']) && $p['Fecha_vencimiento'] < date('Y-m-d')) {
                $resumenPagos['vencidos']++;
                $resumenPagos['vencido_total'] += $imp;
            } else {
                $resumenPagos['pendientes']++;
                $resumenPagos['pendiente_total'] += $imp;
            }
        }

        // 5. Asistencia
        $asistencia = ['total' => 0, 'presentes' => 0, 'justificados' => 0, 'ausentes' => 0];
        $historialAsistencia = [];
        try {
            $q = $conexion->prepare("SELECT COUNT(*) AS total, SUM(Estado='Presente') AS presentes, SUM(Estado='Justificado') AS justificados, SUM(Estado='Ausente') AS ausentes FROM ASISTENCIA WHERE ID_Alumno = ?");
            $q->execute([(int)$alumno]);
            $asistencia = $q->fetch(PDO::FETCH_ASSOC) ?: $asistencia;

            $q = $conexion->prepare("SELECT asis.Fecha, asis.Estado, COALESCE(asis.Observacion,'') AS Observacion, g.Nombre AS Grupo, d.Nombre AS Disciplina 
                                     FROM ASISTENCIA asis 
                                     LEFT JOIN GRUPO g ON g.ID_Grupo = asis.ID_Grupo 
                                     LEFT JOIN DISCIPLINA d ON d.ID_Disciplina = g.ID_Disciplina 
                                     WHERE asis.ID_Alumno = ? 
                                     ORDER BY asis.Fecha DESC, asis.ID_Asistencia DESC LIMIT 50");
            $q->execute([(int)$alumno]);
            $historialAsistencia = $q->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $eIgnored) {}

        // 6. Notificaciones
        $notificaciones = [];
        try {
            $q = $conexion->prepare("SELECT * FROM NOTIFICACION WHERE ID_Alumno = ? ORDER BY Fecha DESC, ID_Notificacion DESC LIMIT 30");
            $q->execute([(int)$alumno]);
            $notificaciones = $q->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $eIgnored) {}

        // 7. Próximas actividades
        $proximasActividades = [];
        try {
            $qa = $conexion->query("SELECT ID_Seminario, COALESCE(NULLIF(Nombre,''), Titulo) AS Nombre, Descripcion, Fecha, Hora, Lugar, Costo FROM SEMINARIO WHERE Fecha >= CURDATE() ORDER BY Fecha ASC, Hora ASC LIMIT 6");
            $proximasActividades = $qa->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $eIgnored) {}

        // 8. Promociones
        $promociones = [];
        try {
            $qp = $conexion->query("SELECT * FROM PROMOCION WHERE Activa = 1 AND (Fecha_inicio IS NULL OR Fecha_inicio <= CURDATE()) AND (Fecha_fin IS NULL OR Fecha_fin >= CURDATE()) ORDER BY Nombre");
            $promociones = $qp->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $eIgnored) {}

        // 9. Certificados
        $certificados = [];
        try {
            $qc = $conexion->prepare("SELECT * FROM CERTIFICADO WHERE ID_Alumno = ? ORDER BY Fecha_emision DESC");
            $qc->execute([(int)$alumno]);
            $certificados = $qc->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $eIgnored) {}

        outp([
            'status' => 'success',
            'perfil' => $perfil,
            'disciplinas' => $disciplinas,
            'seminarios' => $seminarios,
            'pagos' => $pagos,
            'resumen_pagos' => $resumenPagos,
            'notificaciones' => $notificaciones,
            'asistencia' => $asistencia,
            'historial_asistencia' => $historialAsistencia,
            'certificados' => $certificados,
            'proximas_actividades' => $proximasActividades,
            'promociones' => $promociones
        ]);
    }

    if ($entity === 'disciplinas') {
        $q = $conexion->prepare("SELECT d.*, IF(i.ID_Ins_disciplina IS NULL, 0, 1) AS Inscrito FROM DISCIPLINA d LEFT JOIN INSCRIPCION_DISCIPLINA i ON i.ID_Disciplina = d.ID_Disciplina AND i.ID_Alumno = ? AND i.Estado = 'Activa' ORDER BY d.Nombre");
        $q->execute([(int)$alumno]);
        outp(['status' => 'success', 'rows' => $q->fetchAll(PDO::FETCH_ASSOC)]);
    }

    if ($entity === 'seminarios') {
        $q = $conexion->prepare("SELECT s.*, IF(i.ID_Ins_seminario IS NULL, 0, 1) AS Inscrito, i.ID_Ins_seminario FROM SEMINARIO s LEFT JOIN INSCRIPCION_SEMINARIO i ON i.ID_Seminario = s.ID_Seminario AND i.ID_Alumno = ? WHERE s.Fecha >= CURDATE() ORDER BY s.Fecha");
        $q->execute([(int)$alumno]);
        outp(['status' => 'success', 'rows' => $q->fetchAll(PDO::FETCH_ASSOC)]);
    }

if ($entity === 'horarios') {
        $q = $conexion->prepare("SELECT h.ID_Horario, h.Dia, h.Hora_inicio, h.Hora_fin, g.ID_Grupo, g.Nombre AS Grupo, d.Nombre AS Disciplina, IF(iga.ID_Inscripcion IS NULL, 0, 1) AS MiGrupo FROM HORARIO h JOIN GRUPO g ON g.ID_Grupo = h.ID_Grupo LEFT JOIN DISCIPLINA d ON d.ID_Disciplina = g.ID_Disciplina LEFT JOIN INSCRIPCION_GRUPO_ALUMNO iga ON iga.ID_Grupo = g.ID_Grupo AND iga.ID_Alumno = ? AND iga.Estado = 'Activa' ORDER BY FIELD(h.Dia,'Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo'), h.Hora_inicio, g.Nombre");
        $q->execute([(int)$alumno]);
        outp(['status' => 'success', 'rows' => $q->fetchAll(PDO::FETCH_ASSOC)]);
    }

    if ($entity === 'promociones') {
        $q = $conexion->query("SELECT * FROM PROMOCION WHERE Activa = 1 AND (Fecha_inicio IS NULL OR Fecha_inicio <= CURDATE()) AND (Fecha_fin IS NULL OR Fecha_fin >= CURDATE()) ORDER BY Nombre");
        outp(['status' => 'success', 'rows' => $q->fetchAll(PDO::FETCH_ASSOC)]);
    }

    outp(['status' => 'error', 'message' => 'Módulo no válido.'], 400);

} catch (Throwable $e) {
    error_log('Error en portal: ' . $e->getMessage());
    outp(['status' => 'error', 'message' => 'No se pudo completar la operación en este momento.'], 500);
}