<?php

/*
 * ARCHIVO: api/inscripciones.php
 * PROPÓSITO: Endpoints de API para gestionar inscripciones individuales y paquetes promocionales dinámicos (RN-06 / TC-05).
 */
require_once dirname(__DIR__) . '/config/conexion.php';
require_once dirname(__DIR__) . '/config/sesion.php';
require_once dirname(__DIR__) . '/config/notificaciones.php';

if (session_status() === PHP_SESSION_NONE) session_start();

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['usuario_id'])) {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'No autorizado.']);
    exit;
}

try {
    function cancelarInscripcion(PDO $conexion, int $aid, int $did): bool {
        $s = $conexion->prepare("UPDATE INSCRIPCION_DISCIPLINA SET Estado='Cancelada' WHERE ID_Alumno=? AND ID_Disciplina=? AND Estado='Activa'");
        $s->execute([$aid, $did]);
        return $s->rowCount() > 0;
    }

    $uid = (int)$_SESSION['usuario_id'];
    $rol = trim((string)($_SESSION['usuario_rol'] ?? ''));

    if (strcasecmp($rol, 'Alumno') !== 0) {
        http_response_code(403);
        echo json_encode(['status' => 'error', 'message' => 'Solo los alumnos pueden consultar o gestionar inscripciones.']);
        exit;
    }

    $s = $conexion->prepare('SELECT ID_Alumno FROM ALUMNO WHERE ID_Usuario=? LIMIT 1');
    $s->execute([$uid]);
    $al = $s->fetch();

    if (!$al) {
        http_response_code(403);
        echo json_encode(['status' => 'error', 'message' => 'No se encontró el alumno asociado a la cuenta.']);
        exit;
    }

    $aid = (int)$al['ID_Alumno'];

    // GET: Listado de disciplinas y estado
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $s = $conexion->prepare("
            SELECT d.ID_Disciplina, d.Nombre, d.Descripcion, d.Costo,
                   CASE WHEN i.ID_Ins_disciplina IS NULL THEN 0 ELSE 1 END AS Inscrito
            FROM DISCIPLINA d 
            LEFT JOIN INSCRIPCION_DISCIPLINA i 
                   ON i.ID_Disciplina = d.ID_Disciplina 
                  AND i.ID_Alumno = ? 
                  AND i.Estado = 'Activa' 
            ORDER BY d.Nombre ASC
        ");
        $s->execute([$aid]);
        echo json_encode(['status' => 'success', 'clases' => $s->fetchAll(PDO::FETCH_ASSOC)]);
        exit;
    }

    // POST: Acciones de inscripción
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $accion = trim((string)($_POST['accion'] ?? ''));
        $did = (int)($_POST['id_disciplina'] ?? 0);

        // MATRICULACIÓN POR PAQUETE PROMOCIONAL DINÁMICO (LEYENDO PRECIOS DEL ADMIN)
        if ($accion === 'inscribir_paquete') {
            $tipoPlan = trim((string)($_POST['tipo_plan'] ?? ''));
            $disciplinasSeleccionadas = $_POST['disciplinas'] ?? [];

            if (!is_array($disciplinasSeleccionadas)) {
                $disciplinasSeleccionadas = [];
            }
            $disciplinasSeleccionadas = array_values(array_unique(array_filter(array_map('intval', $disciplinasSeleccionadas), fn($d) => $d > 0)));

            $conexion->beginTransaction();
            try {
                $todasQ = $conexion->query("SELECT ID_Disciplina, Nombre, Costo FROM DISCIPLINA ORDER BY ID_Disciplina ASC");
                $todas = $todasQ->fetchAll(PDO::FETCH_ASSOC);
                $todasIds = array_column($todas, 'ID_Disciplina');

                // Leer tarifas configuradas por el Administrador en la tabla PROMOCION
                $tarifasQ = $conexion->query("SELECT Nombre, Descuento FROM PROMOCION WHERE Activa = 1");
                $tarifasLista = $tarifasQ->fetchAll(PDO::FETCH_ASSOC);
                
                $tarifa1 = 1500.00;
                $tarifa2 = 1900.00;
                $tarifa3 = 2100.00;
                $tarifaLibre = 2500.00;

                foreach ($tarifasLista as $tRow) {
                    $n = strtolower($tRow['Nombre']);
                    $val = (float)$tRow['Descuento'];
                    if (str_contains($n, '1') || str_contains($n, 'individual') || str_contains($n, 'básico')) $tarifa1 = $val;
                    if (str_contains($n, '2') || str_contains($n, 'doble')) $tarifa2 = $val;
                    if (str_contains($n, '3') || str_contains($n, 'triple')) $tarifa3 = $val;
                    if (str_contains($n, 'libre') || str_contains($n, 'todas')) $tarifaLibre = $val;
                }

                if ($tipoPlan === 'libre') {
                    $disciplinasSeleccionadas = $todasIds;
                    $importeFinal = $tarifaLibre;
                    $nombrePlan = "Pase Libre Total";
                } elseif ($tipoPlan === '1') {
                    if (count($disciplinasSeleccionadas) !== 1) {
                        $conexion->rollBack();
                        echo json_encode(['status' => 'error', 'message' => 'Debes seleccionar exactamente 1 disciplina.']);
                        exit;
                    }
                    $importeFinal = $tarifa1;
                    $nombrePlan = "Plan 1 Disciplina";
                } elseif ($tipoPlan === '2') {
                    if (count($disciplinasSeleccionadas) !== 2) {
                        $conexion->rollBack();
                        echo json_encode(['status' => 'error', 'message' => 'Debes seleccionar exactamente 2 disciplinas.']);
                        exit;
                    }
                    $importeFinal = $tarifa2;
                    $nombrePlan = "Promoción 2 Disciplinas";
                } elseif ($tipoPlan === '3') {
                    if (count($disciplinasSeleccionadas) !== 3) {
                        $conexion->rollBack();
                        echo json_encode(['status' => 'error', 'message' => 'Debes seleccionar exactamente 3 disciplinas.']);
                        exit;
                    }
                    $importeFinal = $tarifa3;
                    $nombrePlan = "Promoción 3 Disciplinas";
                } else {
                    $conexion->rollBack();
                    echo json_encode(['status' => 'error', 'message' => 'Plan no válido.']);
                    exit;
                }

                // 1. Dar de baja disciplinas no seleccionadas
                if (!empty($disciplinasSeleccionadas)) {
                    $placeholders = implode(',', array_fill(0, count($disciplinasSeleccionadas), '?'));
                    $stmtBaja = $conexion->prepare("UPDATE INSCRIPCION_DISCIPLINA SET Estado='Cancelada' WHERE ID_Alumno=? AND ID_Disciplina NOT IN ($placeholders)");
                    $stmtBaja->execute(array_merge([$aid], $disciplinasSeleccionadas));
                }

                // 2. Activar disciplinas seleccionadas
                $nombresElegidos = [];
                $checkD = $conexion->prepare("SELECT ID_Ins_disciplina, Estado FROM INSCRIPCION_DISCIPLINA WHERE ID_Alumno=? AND ID_Disciplina=? LIMIT 1 FOR UPDATE");
                $activarD = $conexion->prepare("UPDATE INSCRIPCION_DISCIPLINA SET Estado='Activa', Fecha_ins=CURDATE() WHERE ID_Ins_disciplina=?");
                $crearD = $conexion->prepare("INSERT INTO INSCRIPCION_DISCIPLINA (ID_Alumno, ID_Disciplina, Fecha_ins, Estado) VALUES (?, ?, CURDATE(), 'Activa')");

                foreach ($disciplinasSeleccionadas as $selId) {
                    $checkD->execute([$aid, $selId]);
                    $exist = $checkD->fetch();
                    if ($exist) {
                        $activarD->execute([(int)$exist['ID_Ins_disciplina']]);
                    } else {
                        $crearD->execute([$aid, $selId]);
                    }

                    foreach ($todas as $t) {
                        if ((int)$t['ID_Disciplina'] === $selId) {
                            $nombresElegidos[] = $t['Nombre'];
                            break;
                        }
                    }

                    // Asignación de grupo con cupo
                    $stmtGrupo = $conexion->prepare("SELECT ID_Grupo, Cupo_maximo FROM GRUPO WHERE ID_Disciplina = ? ORDER BY ID_Grupo ASC LIMIT 1");
                    $stmtGrupo->execute([$selId]);
                    $grupo = $stmtGrupo->fetch();

                    if ($grupo) {
                        $gid = (int)$grupo['ID_Grupo'];
                        $cupoMax = (int)$grupo['Cupo_maximo'];

                        $stmtCount = $conexion->prepare("SELECT COUNT(*) FROM INSCRIPCION_GRUPO_ALUMNO WHERE ID_Grupo = ? AND Estado = 'Activa'");
                        $stmtCount->execute([$gid]);
                        $ocupados = (int)$stmtCount->fetchColumn();

                        if ($ocupados < $cupoMax) {
                            $checkG = $conexion->prepare("SELECT ID_Inscripcion FROM INSCRIPCION_GRUPO_ALUMNO WHERE ID_Alumno=? AND ID_Grupo=? LIMIT 1 FOR UPDATE");
                            $checkG->execute([$aid, $gid]);
                            $idGExist = $checkG->fetchColumn();
                            if ($idGExist) {
                                $conexion->prepare("UPDATE INSCRIPCION_GRUPO_ALUMNO SET Estado='Activa' WHERE ID_Inscripcion=?")->execute([$idGExist]);
                            } else {
                                $conexion->prepare("INSERT INTO INSCRIPCION_GRUPO_ALUMNO (ID_Alumno, ID_Grupo, Estado) VALUES (?, ?, 'Activa')")->execute([$aid, $gid]);
                            }
                        }
                    }
                }

                // 3. Generar cuota unificada
                $mesActual = date('n');
                $anioActual = date('Y');
                $mesesNombres = [1=>'Enero',2=>'Febrero',3=>'Marzo',4=>'Abril',5=>'Mayo',6=>'Junio',7=>'Julio',8=>'Agosto',9=>'Septiembre',10=>'Octubre',11=>'Noviembre',12=>'Diciembre'];
                $nombreMes = $mesesNombres[$mesActual] ?? 'Mes';
                $conceptoPago = "Cuota {$nombrePlan} ({$nombreMes} {$anioActual}) - " . implode(', ', $nombresElegidos);
                $fechaVenc = date('Y-m-d', strtotime('+30 days'));

                $checkPago = $conexion->prepare("SELECT ID_Pago FROM PAGO WHERE ID_Alumno=? AND Estado='Pendiente' AND YEAR(Fecha)=? AND MONTH(Fecha)=? LIMIT 1");
                $checkPago->execute([$aid, $anioActual, $mesActual]);
                $pagoPendienteId = $checkPago->fetchColumn();

                if ($pagoPendienteId) {
                    $conexion->prepare("UPDATE PAGO SET Tipo=?, Importe=?, Fecha_vencimiento=? WHERE ID_Pago=?")
                             ->execute([$conceptoPago, $importeFinal, $fechaVenc, $pagoPendienteId]);
                    $codigoComp = 'VIL-' . date('Y-m-d') . '-' . str_pad((string)$pagoPendienteId, 6, '0', STR_PAD_LEFT);
                } else {
                    $insertP = $conexion->prepare("INSERT INTO PAGO (ID_Alumno, Tipo, Fecha, Fecha_vencimiento, Importe, Estado, Metodo_pago) VALUES (?, ?, CURDATE(), ?, ?, 'Pendiente', 'A confirmar')");
                    $insertP->execute([$aid, $conceptoPago, $fechaVenc, $importeFinal]);
                    $pagoPendienteId = (int)$conexion->lastInsertId();
                    $codigoComp = 'VIL-' . date('Y-m-d') . '-' . str_pad((string)$pagoPendienteId, 6, '0', STR_PAD_LEFT);
                    $conexion->prepare("UPDATE PAGO SET Numero_comprobante=? WHERE ID_Pago=?")->execute([$codigoComp, $pagoPendienteId]);
                }

                vilamirNotificarAlumno($conexion, $aid, "¡Tu suscripción a {$nombrePlan} fue actualizada! Cuota: $" . number_format($importeFinal, 2, ',', '.') . " UYU. Comprobante: {$codigoComp}");

                $conexion->commit();

                echo json_encode([
                    'status' => 'success',
                    'message' => "¡Suscripción actualizada a {$nombrePlan}! Se aplicó la tarifa vigente de $" . number_format($importeFinal, 2, ',', '.') . " UYU.",
                    'total_disciplinas' => count($disciplinasSeleccionadas),
                    'importe' => $importeFinal,
                    'comprobante' => $codigoComp
                ]);
                exit;

            } catch (Throwable $e) {
                if ($conexion->inTransaction()) $conexion->rollBack();
                error_log("Error en inscribir_paquete: " . $e->getMessage());
                echo json_encode(['status' => 'error', 'message' => 'No se pudo procesar la suscripción.']);
                exit;
            }
        }

        // Cancelar disciplina
        if ($accion === 'cancelar_disciplina') {
            if ($did <= 0) {
                echo json_encode(['status' => 'error', 'message' => 'Disciplina no válida.']);
                exit;
            }
            $cancelada = cancelarInscripcion($conexion, $aid, $did);
            echo json_encode(['status' => 'success', 'message' => $cancelada ? 'Te has dado de baja.' : 'No tenías inscripción activa.']);
            exit;
        }

        // Inscripción individual
        if ($did <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'Disciplina no válida.']);
            exit;
        }

        $s = $conexion->prepare('SELECT ID_Disciplina, Nombre, Costo FROM DISCIPLINA WHERE ID_Disciplina=?');
        $s->execute([$did]);
        $discData = $s->fetch();

        if (!$discData) {
            echo json_encode(['status' => 'error', 'message' => 'La disciplina no existe.']);
            exit;
        }

        $conexion->beginTransaction();
        $s = $conexion->prepare('SELECT ID_Ins_disciplina, Estado FROM INSCRIPCION_DISCIPLINA WHERE ID_Alumno=? AND ID_Disciplina=? LIMIT 1 FOR UPDATE');
        $s->execute([$aid, $did]);
        $existente = $s->fetch();

        if ($existente && strcasecmp((string)$existente['Estado'], 'Activa') === 0) {
            $conexion->rollBack();
            echo json_encode(['status' => 'error', 'message' => 'Ya estás inscrito en esta clase.']);
            exit;
        }

        if ($existente) {
            $s = $conexion->prepare("UPDATE INSCRIPCION_DISCIPLINA SET Estado='Activa', Fecha_ins=CURDATE() WHERE ID_Ins_disciplina=?");
            $s->execute([(int)$existente['ID_Ins_disciplina']]);
        } else {
            $s = $conexion->prepare("INSERT INTO INSCRIPCION_DISCIPLINA(ID_Alumno, ID_Disciplina, Fecha_ins, Estado) VALUES(?, ?, CURDATE(), 'Activa')");
            $s->execute([$aid, $did]);
        }

        $pagoInfo = null;
        if ((float)$discData['Costo'] > 0) {
            $importe = (float)$discData['Costo'];
            $tipo = 'Inscripción ' . $discData['Nombre'];

            $s = $conexion->prepare("INSERT INTO PAGO(ID_Alumno, Tipo, Fecha, Importe, Estado, Metodo_pago) VALUES(?, ?, CURDATE(), ?, 'Pendiente', 'A confirmar')");
            $s->execute([$aid, $tipo, $importe]);

            $idPago = (int)$conexion->lastInsertId();
            $comprobante = 'VIL-' . date('Y-m-d') . '-' . str_pad((string)$idPago, 6, '0', STR_PAD_LEFT);

            $s = $conexion->prepare('UPDATE PAGO SET Numero_comprobante=? WHERE ID_Pago=?');
            $s->execute([$comprobante, $idPago]);

            $pagoInfo = ['importe' => $importe, 'comprobante' => $comprobante, 'tipo' => $tipo];

            vilamirNotificarAlumno($conexion, $aid, "Inscripción a {$discData['Nombre']}: cuota de $" . number_format($importe, 2, ',', '.') . ". Comprobante: {$comprobante}");
        }

        $conexion->commit();
        echo json_encode(['status' => 'success', 'message' => 'Inscripción realizada correctamente.', 'pago' => $pagoInfo]);
        exit;
    }

    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Método no permitido.']);

} catch (Throwable $e) {
    if (isset($conexion) && $conexion instanceof PDO && $conexion->inTransaction()) {
        $conexion->rollBack();
    }
    error_log('api/inscripciones error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'No se pudo completar la operación.']);
}