<?php

/*
 * ARCHIVO: mis_clases.php
 * PROPÓSITO: Página o módulo PHP de mis clases dentro del sistema Academia VILAMIR.
 */
// Portal del alumno para consultar las disciplinas en las que está inscrito.
require_once 'config/autenticacion.php';

if (($_SESSION['usuario_rol'] ?? '') !== 'Alumno') {

    header('Location: index.php');

    exit;
    }

$nombreUsuario = $_SESSION['usuario_nombre'] ?? 'Alumno';

?>
<!DOCTYPE html>
<html lang="es">
<head>
<?php vilamir_enviar_token_csrf(); ?>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mis clases - Vilamir</title>
<link rel="stylesheet" href="css/style.css?v=20261026-etapa2-seminarios-galeria-v1">
<script src="js/csrf.js"></script>
</head>
<body class="about-page mis-clases-page">
<header class="navbar">
<div class="logo">
<img src="images/logo-vilamir.jpg" alt="Escuela Vilamir" class="logo-img">
</div>
<nav>
<a href="index.php">Inicio</a>
<a href="clases.php">Clases</a>
<a href="mis_clases.php">Mis clases</a>
<a href="grupos.php">Grupos</a>
<a href="seminarios.php">Seminarios y eventos</a>
<a href="logout.php">Cerrar sesión</a>
</nav>
</header>
<main class="admin mis-clases-container">
<section class="hero mis-clases-hero">
<p class="mis-clases-eyebrow">ACADEMIA VILAMIR · ESPACIO DEL ALUMNO</p>
<h1>Mis clases</h1>
<p>Hola <?php echo htmlspecialchars($nombreUsuario, ENT_QUOTES, 'UTF-8'); ?>. Consultá tus disciplinas, grupos y horarios de entrenamiento desde un solo lugar.</p>
<div class="mis-clases-hero-meta"><span>🥋 Tus disciplinas</span><span>📅 Tus horarios</span><span>👥 Tus grupos</span></div>
</section>
<section class="module mis-clases-list-panel">
<div class="mis-clases-section-heading"><span class="mis-clases-heading-mark" aria-hidden="true"></span><div><h2>Tu plan de entrenamiento</h2><p>Revisá tus inscripciones y los horarios asignados a cada grupo.</p></div></div>
<div id="misClases" class="team cards-grid mis-clases-grid">
<p class="muted-center full-grid">Cargando tus clases...</p>
</div>
<p id="mensajeMisClases" class="message-center"></p>
</section>
</main>
<footer>© 2026 Academia VILAMIR</footer>
<script src="js/mis_clases.js">
</script>
<script src="js/mobile.js">
</script>
</body>
</html>
