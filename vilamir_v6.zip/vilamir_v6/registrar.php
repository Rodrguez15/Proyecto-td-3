<?php

/*
 * ARCHIVO: registrar.php
 * PROPÓSITO: Página o módulo PHP de registrar dentro del sistema Academia VILAMIR.
 */
// Procesa el registro de nuevos usuarios y crea el alumno asociado.
// ============================================================
// REGISTRO DE USUARIOS - MMA SYSTEMS
// Crea una cuenta (rol Alumno) con contraseña hasheada y sus
// datos personales en ALUMNO. Responde JSON hacia registrar.js.
// ============================================================
require_once __DIR__ . '/config/sesion.php';
require_once __DIR__ . '/config/conexion.php';
require_once 'config/qr.php';

$response = ['status' => 'error', 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    header('Content-Type: application/json; charset=utf-8');

    // Recibir y limpiar los datos del formulario
    $nombre = isset($_POST['nombre']) ? trim($_POST['nombre']) : '';

    $apellido = isset($_POST['apellido']) ? trim($_POST['apellido']) : '';

    $email = isset($_POST['email']) ? trim($_POST['email']) : '';

    $password = isset($_POST['password']) ? $_POST['password'] : '';

    $confirmPassword = isset($_POST['confirmPassword']) ? $_POST['confirmPassword'] : '';

    // --- Validaciones server-side ---
    if ($nombre === '' || $apellido === '' || $email === '' || $password === '' || $confirmPassword === '') {

        $response['message'] = "Debe completar todos los campos.";

        echo json_encode($response);

        exit;
        }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $response['message'] = "Correo electrónico no válido.";

        echo json_encode($response);

        exit;
        }

    if (mb_strlen($password) < 8) {

        $response['message'] = "La contraseña debe tener al menos 8 caracteres.";

        echo json_encode($response);

        exit;
        }

    if ($password !== $confirmPassword) {

        $response['message'] = "Las contraseñas no coinciden.";

        echo json_encode($response);

        exit;
        }

    try {

        // Evitar correos duplicados
        $stmt = $conexion->prepare("SELECT ID_Usuario FROM USUARIO WHERE Email = :email LIMIT 1");

        $stmt->bindParam(':email', $email, PDO::PARAM_STR);

        $stmt->execute();

        if ($stmt->fetch()) {

            $response['message'] = "Ese correo ya está registrado en el sistema.";

            echo json_encode($response);

            exit;
            }

        // Hash seguro de la contraseña
        $hash = password_hash($password, PASSWORD_DEFAULT);

        // Insertar cuenta y datos del alumno en una transacción
        $conexion->beginTransaction();

        $stmt = $conexion->prepare(
        "INSERT INTO USUARIO (Email, Contraseña, Rol) VALUES (:email, :hash, 'Alumno')"
        );

        $stmt->bindParam(':email', $email, PDO::PARAM_STR);

        $stmt->bindParam(':hash', $hash, PDO::PARAM_STR);

        $stmt->execute();

        $idUsuario = (int)$conexion->lastInsertId();

        $codigoQr = vilamir_nuevo_codigo_qr($conexion);
        $stmt = $conexion->prepare(
            "INSERT INTO ALUMNO (ID_Usuario, Nombre, Apellido, Codigo_qr) VALUES (:id, :nombre, :apellido, :qr)"
        );
        $stmt->execute([
            ':id' => $idUsuario,
            ':nombre' => $nombre,
            ':apellido' => $apellido,
            ':qr' => $codigoQr
        ]);

        $conexion->commit();

        $response['status'] = 'success';

        $response['message'] = "Cuenta creada correctamente. Tu código QR ya fue generado automáticamente. Ya puedes iniciar sesión.";
        $response['codigo_qr'] = $codigoQr;
        }
    catch (Throwable $e) {

        if ($conexion->inTransaction()) {

            $conexion->rollBack();
            }

        error_log("Error en registrar.php: " . $e->getMessage());

        $response['message'] = "Hubo un problema en el servidor. Intente más tarde.";
        }

    echo json_encode($response);

    exit;
    }

http_response_code(405);
header('Allow: POST');
header('Content-Type: application/json; charset=utf-8');
echo json_encode(['status' => 'error', 'message' => 'Método no permitido.'], JSON_UNESCAPED_UNICODE);
exit;
