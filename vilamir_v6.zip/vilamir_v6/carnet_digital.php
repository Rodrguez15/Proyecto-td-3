<?php
/*
 * ARCHIVO: carnet_digital.php
 * PROPÓSITO: Carnet digital oficial del alumno con QR offline para acceso al Dojo VILAMIR.
 */
require_once 'config/sesion.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.html');
    exit;
}

$uid = (int)$_SESSION['usuario_id'];
$rol = (string)($_SESSION['usuario_rol'] ?? '');
$codigo = trim((string)($_GET['codigo'] ?? ''));
require_once 'config/conexion.php';
require_once 'config/qr.php';

// Permitir que el alumno abra su carnet directamente; el QR se asigna si aún falta.
if (strcasecmp($rol, 'Alumno') === 0 && $codigo === '') {
    $codigo = (string)(vilamir_obtener_qr_usuario($conexion, $uid) ?? '');
}
if ($codigo === '' || strlen($codigo) > 100) {
    http_response_code(400);
    exit('Código no válido.');
}

$q = $conexion->prepare("
    SELECT a.Nombre, a.Apellido, a.Cedula, a.Categoria, a.Codigo_qr,
           GROUP_CONCAT(d.Nombre SEPARATOR ' • ') AS Disciplinas
    FROM ALUMNO a
    LEFT JOIN INSCRIPCION_DISCIPLINA i ON i.ID_Alumno = a.ID_Alumno AND i.Estado = 'Activa'
    LEFT JOIN DISCIPLINA d ON d.ID_Disciplina = i.ID_Disciplina
    WHERE a.Codigo_qr = ?
    GROUP BY a.ID_Alumno
    LIMIT 1
");
$q->execute([$codigo]);
$al = $q->fetch(PDO::FETCH_ASSOC);
if (!$al) { http_response_code(404); exit('Alumno no encontrado.'); }

if (strcasecmp($rol, 'Administrador') !== 0) {
    if (strcasecmp($rol, 'Alumno') !== 0) {
        http_response_code(403);
        exit('No tenés permiso para ver este carnet.');
    }
    $propio = $conexion->prepare('SELECT 1 FROM ALUMNO WHERE ID_Usuario = ? AND Codigo_qr = ? LIMIT 1');
    $propio->execute([$uid, $codigo]);
    if (!$propio->fetchColumn()) {
        http_response_code(403);
        exit('Solo podés consultar tu propio carnet.');
    }
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carnet Digital | <?= htmlspecialchars($al['Nombre'] . ' ' . $al['Apellido']) ?></title>
    <style>
        *{box-sizing:border-box}
        body{background:radial-gradient(ellipse at 50% 0,rgba(215,25,32,.2),transparent 42%),#09090c;color:#f8f8fa;font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100vh;margin:0;padding:24px 14px}
        .carnet-card{width:100%;max-width:390px;background:linear-gradient(155deg,#1c1c22,#101014 68%);border:1px solid rgba(255,255,255,.14);border-radius:24px;box-shadow:0 24px 65px rgba(0,0,0,.48),0 0 34px rgba(215,25,32,.12);overflow:hidden;text-align:center;position:relative}
        .carnet-head{background:linear-gradient(120deg,#d71920,#8b0000);padding:20px 22px;display:flex;align-items:center;justify-content:center;gap:12px;position:relative}
        .carnet-head img{width:52px;height:52px;object-fit:cover;border-radius:50%;background:#fff;padding:3px;border:1px solid rgba(255,255,255,.45)}
        .carnet-head h2{margin:0;font-size:16px;letter-spacing:1.5px;color:#fff;font-weight:950}
        .carnet-head small{display:block;margin-top:4px;font-size:10px;letter-spacing:2px;color:rgba(255,255,255,.78);font-weight:800}
        .carnet-body{padding:25px 24px 23px}
        .carnet-label{display:inline-flex;padding:6px 11px;border-radius:999px;background:rgba(215,25,32,.13);border:1px solid rgba(215,25,32,.3);color:#ff8589;font-size:10px;font-weight:900;letter-spacing:1.5px;margin-bottom:14px}
        .carnet-avatar{display:grid;place-items:center;width:64px;height:64px;border-radius:20px;margin:0 auto 12px;background:linear-gradient(145deg,rgba(215,25,32,.2),rgba(255,255,255,.04));border:1px solid rgba(255,255,255,.1);font-size:34px}
        .carnet-name{font-size:22px;line-height:1.2;font-weight:900;margin:0 0 6px;color:#fff}
        .carnet-ci{font-size:12px;color:#aaa;margin-bottom:16px}
        .carnet-disciplinas{background:rgba(255,255,255,.045);border:1px solid rgba(255,255,255,.09);border-radius:11px;padding:10px 13px;font-size:12px;color:#8ce8b8;font-weight:800;margin-bottom:20px}
        .qr-caption{font-size:11px;color:#b8b8c0;font-weight:800;letter-spacing:1.2px;margin-bottom:10px}
        .carnet-qr{background:#fff;display:flex;align-items:center;justify-content:center;width:244px;height:244px;margin:0 auto;padding:12px;border-radius:17px;box-shadow:0 8px 26px rgba(0,0,0,.38)}
        .carnet-qr canvas,.carnet-qr img{display:block;width:220px!important;height:220px!important;image-rendering:pixelated}
        .carnet-footer{font-size:11px;color:#92929c;line-height:1.7;margin-top:17px;overflow-wrap:anywhere}
        .carnet-footer strong{color:#d9d9df}
        .carnet-actions{display:flex;justify-content:center;gap:10px;flex-wrap:wrap;margin-top:18px}
        .btn-imprimir{background:linear-gradient(135deg,#d71920,#a80f17);color:#fff;border:1px solid rgba(255,255,255,.1);padding:12px 20px;border-radius:11px;cursor:pointer;font-weight:900;text-decoration:none;box-shadow:0 8px 20px rgba(215,25,32,.18)}
        .btn-volver{background:#25252b;color:#e7e7eb;border:1px solid #444;padding:12px 18px;border-radius:11px;text-decoration:none;font-weight:800}
        .btn-imprimir:hover,.btn-volver:hover{filter:brightness(1.12)}
        @media(max-width:420px){.carnet-card{max-width:360px}.carnet-body{padding:22px 17px}.carnet-qr{width:226px;height:226px}.carnet-qr canvas,.carnet-qr img{width:202px!important;height:202px!important}}
        @media print{body{background:#fff;color:#111;padding:0;min-height:auto}.carnet-card{border:2px solid #222;box-shadow:none;break-inside:avoid}.carnet-head{print-color-adjust:exact;-webkit-print-color-adjust:exact}.carnet-disciplinas,.carnet-label{print-color-adjust:exact;-webkit-print-color-adjust:exact}.carnet-name{color:#111}.carnet-ci,.carnet-footer{color:#444}.carnet-actions{display:none}}
    </style>
</head>
<body>
    <div class="carnet-card">
        <div class="carnet-head">
            <img src="images/logo-vilamir.jpg" alt="Vilamir">
            <h2>ACADEMIA VILAMIR</h2>
        </div>
        <div class="carnet-body">
            <span class="carnet-label">CARNET DIGITAL OFICIAL</span>
            <div class="carnet-avatar">🥋</div>
            <h1 class="carnet-name"><?= htmlspecialchars($al['Nombre'] . ' ' . $al['Apellido']) ?></h1>
            <div class="carnet-ci"><?= $al['Cedula'] ? 'CI: ' . htmlspecialchars($al['Cedula']) : 'Socio Activo' ?></div>
            
            <div class="carnet-disciplinas">
                <?= htmlspecialchars($al['Disciplinas'] ?: 'Entrenamiento General') ?>
            </div>

            <div class="qr-caption">CÓDIGO PERSONAL DE IDENTIFICACIÓN</div>
            <div class="carnet-qr" id="qrContainer" role="img" aria-label="Código QR personal del alumno"></div>

            <div class="carnet-footer">
                <strong>ID de socio:</strong> <?= htmlspecialchars($al['Codigo_qr']) ?><br>
                Presentá este código en recepción para registrar tu asistencia.
            </div>
        </div>
    </div>

    <div class="carnet-actions">
        <button type="button" class="btn-imprimir" onclick="window.print()">🖨️ Imprimir / Guardar carnet</button>
        <a class="btn-volver" href="portal.php">Volver a mi cuenta</a>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js" referrerpolicy="no-referrer"></script>
    <script>
        const qrContenedor = document.getElementById("qrContainer");
        if (window.QRCode) {
            new QRCode(qrContenedor, {
                text: <?= json_encode($al['Codigo_qr'], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT) ?>,
                width: 220,
                height: 220,
                colorDark: "#111111",
                colorLight: "#ffffff",
                correctLevel: QRCode.CorrectLevel.M
            });
        } else {
            qrContenedor.textContent = "No se pudo cargar el QR. Recargá la página con conexión a internet.";
            qrContenedor.style.color = "#333";
            qrContenedor.style.fontSize = "12px";
        }
    </script>
</body>
</html>