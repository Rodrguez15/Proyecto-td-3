<?php

/*
 * ARCHIVO: verificar_comprobante.php
 * PROPÓSITO: Página o módulo PHP de verificar comprobante dentro del sistema Academia VILAMIR.
 */
require_once 'config/conexion.php';

// Necesario para vilamir_enviar_token_csrf() y la seguridad HTTP común.
require_once 'config/sesion.php';

// Página pública de verificación: no exige sesión, pero aplica seguridad HTTP.
vilamir_aplicar_seguridad_http();

$codigo = trim((string)($_GET['codigo'] ?? ''));

if ($codigo === '' || !preg_match('/^VIL-([0-9]{4}-[0-9]{2}-[0-9]{2})-([0-9]{6,})$/', $codigo, $codigoPartes)) {

    http_response_code(400);

    exit('Código de comprobante no válido.');
    }

$q = $conexion->prepare("SELECT p.Numero_comprobante,p.Fecha,p.Fecha_vencimiento,p.Importe,p.Estado,p.Tipo,p.Metodo_pago,
    CONCAT(a.Nombre,' ',a.Apellido) Alumno
    FROM PAGO p JOIN ALUMNO a ON a.ID_Alumno=p.ID_Alumno
    WHERE p.Numero_comprobante=? LIMIT 1");

$q->execute([$codigo]);

$p = $q->fetch();

// Compatibilidad con pagos antiguos que aún no tienen Numero_comprobante guardado.
if (!$p && isset($codigoPartes[1], $codigoPartes[2])) {
    $fechaCodigo = $codigoPartes[1];
    $idCodigo = (int)$codigoPartes[2];
    $q = $conexion->prepare("SELECT p.Numero_comprobante,p.Fecha,p.Fecha_vencimiento,p.Importe,p.Estado,p.Tipo,p.Metodo_pago,
        CONCAT(a.Nombre,' ',a.Apellido) Alumno
        FROM PAGO p JOIN ALUMNO a ON a.ID_Alumno=p.ID_Alumno
        WHERE p.ID_Pago=? AND p.Fecha=? AND (p.Numero_comprobante IS NULL OR p.Numero_comprobante='') LIMIT 1");
    $q->execute([$idCodigo, $fechaCodigo]);
    $p = $q->fetch();
}

if (!$p) {
    http_response_code(404);
    exit('Comprobante no encontrado.');
    }

$estado = trim((string)$p['Estado']);

if (strcasecmp($estado,'Pendiente')===0 && !empty($p['Fecha_vencimiento']) && $p['Fecha_vencimiento'] < date('Y-m-d')) $estado='Vencido';

$nombreCompleto = trim((string)$p['Alumno']);

$partesNombre = preg_split('/\s+/', $nombreCompleto);

$alumnoVisible = $partesNombre[0] ?? $nombreCompleto;

if (count($partesNombre) > 1) {
    $apellido = (string)$partesNombre[count($partesNombre)-1];
    $inicial = function_exists('mb_substr') ? mb_substr($apellido, 0, 1, 'UTF-8') : substr($apellido, 0, 1);
    $alumnoVisible .= ' ' . $inicial . '.';
}

$importe = number_format((float)$p['Importe'],2,',','.');

$fecha = $p['Fecha'] ? date('d/m/Y', strtotime($p['Fecha'])) : '—';

$venc = !empty($p['Fecha_vencimiento']) ? date('d/m/Y', strtotime($p['Fecha_vencimiento'])) : '—';

?>
<!DOCTYPE html>
<html lang="es">
<head>
<?php vilamir_enviar_token_csrf(); ?>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Verificación <?= htmlspecialchars($codigo) ?>
 | VILAMIR</title>
<link rel="stylesheet" href="css/style.css?v=20261026-etapa2-seminarios-galeria-v1">
<script src="js/csrf.js"></script>
</head>
<body class="payment-receipt-page">
<main class="payment-receipt verification-page">
<div class="receipt-top">
<div class="receipt-brand">
<span class="receipt-brand-mark">
<img src="images/logo-vilamir.jpg" alt="Escuela Vilamir">
</span>
<div>
<strong>ACADEMIA VILAMIR</strong>
<span>Verificación de comprobante</span>
</div>
</div>
</div>
<div class="receipt-heading">
<span class="account-eyebrow">COMPROBANTE VERIFICADO</span>
<h1><?= htmlspecialchars($codigo) ?>
</h1>
<p>El sistema encontró un registro asociado a este número de comprobante.</p>
</div>
<section class="receipt-card">
<div class="receipt-status">
<span>Estado</span>
<b class="receipt-state receipt-state-<?= htmlspecialchars(strtolower(preg_replace('/[^a-z0-9]+/i','-', $estado))) ?>
"><?= htmlspecialchars($estado) ?>
</b>
</div>
<div class="receipt-amount">
<small>Importe</small>
<strong>$<?= $importe ?>
</strong>
</div>
<div class="receipt-grid">
<div>
<span>Alumno</span>
<b><?= htmlspecialchars($alumnoVisible) ?>
</b>
</div>
<div>
<span>Concepto</span>
<b><?= htmlspecialchars($p['Tipo'] ?: 'Pago') ?>
</b>
</div>
<div>
<span>Fecha</span>
<b><?= $fecha ?>
</b>
</div>
<div>
<span>Vencimiento</span>
<b><?= $venc ?>
</b>
</div>
<div>
<span>Método</span>
<b><?= htmlspecialchars($p['Metodo_pago'] ?: 'No informado') ?>
</b>
</div>
<div>
<span>N.º de comprobante</span>
<b><?= htmlspecialchars($codigo) ?>
</b>
</div>
</div>
<p class="receipt-note">Esta consulta muestra únicamente los datos necesarios para verificar la existencia del comprobante.</p>
</section>
</main>
</body>
</html>
