<?php

/*
 * DESCRIPCIÓN DEL ARCHIVO
 * Genera exportaciones de información del sistema para su descarga.
 */
require_once 'config/admin.php';
require_once 'config/conexion.php';

$tipo=$_GET['tipo']??'alumnos';
$formato=$_GET['formato']??'csv';

$map=[
'alumnos'=>['titulo'=>'Alumnos','sql'=>"SELECT a.ID_Alumno AS ID, a.Nombre, a.Apellido, u.Email, a.Telefono, a.Fecha_nacimiento FROM ALUMNO a JOIN USUARIO u ON u.ID_Usuario=a.ID_Usuario ORDER BY a.Apellido,a.Nombre"],
'pagos'=>['titulo'=>'Historial de pagos','sql'=>"SELECT p.ID_Pago, CONCAT(a.Nombre,' ',a.Apellido) AS Alumno, p.Tipo, p.Fecha, p.Fecha_vencimiento, p.Importe, p.Estado, p.Metodo_pago, p.Numero_comprobante, p.Anulado_en, p.Motivo_anulacion FROM PAGO p JOIN ALUMNO a ON a.ID_Alumno=p.ID_Alumno ORDER BY p.Fecha DESC, p.ID_Pago DESC"],
'asistencia'=>['titulo'=>'Asistencia','sql'=>"SELECT x.Fecha,CONCAT(a.Nombre,' ',a.Apellido) Alumno,g.Nombre Grupo,x.Estado,x.Observacion FROM ASISTENCIA x JOIN ALUMNO a ON a.ID_Alumno=x.ID_Alumno JOIN GRUPO g ON g.ID_Grupo=x.ID_Grupo ORDER BY x.Fecha DESC"],
'seminarios'=>['titulo'=>'Seminarios','sql'=>"SELECT s.ID_Seminario,COALESCE(NULLIF(s.Nombre,''),s.Titulo) Nombre,s.Fecha,s.Costo,s.Lugar,s.Cupo FROM SEMINARIO s ORDER BY s.Fecha DESC"],
];
if(!isset($map[$tipo])) die('Tipo no válido');
$rows=$conexion->query($map[$tipo]['sql'])->fetchAll(PDO::FETCH_ASSOC);

if($formato==='csv') {
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="vilamir_'.$tipo.'.csv"');
    $out=fopen('php://output','w');
    // Marca UTF-8 para que Excel abra correctamente tildes y caracteres españoles.
    fwrite($out, "\xEF\xBB\xBF");
    if($rows) {
        fputcsv($out,array_keys($rows[0]),';');
        foreach($rows as $r) {
            // Muestra el vencimiento calculado sin alterar el estado almacenado.
            if ($tipo === 'pagos' && ($r['Estado'] ?? '') === 'Pendiente'
                && !empty($r['Fecha_vencimiento']) && $r['Fecha_vencimiento'] < date('Y-m-d')) {
                $r['Estado'] = 'Vencido';
            }
            foreach ($r as $key => $value) {
                if (is_string($value) && preg_match('/^[\s]*[=+@\-]/u', $value)) {
                    // Neutraliza fórmulas al abrir datos de texto en hojas de cálculo.
                    $r[$key] = "'" . $value;
                }
            }
            fputcsv($out,$r,';');
        }
    }
    fclose($out);
    exit;
}

if($formato==='xls') {
    header('Content-Type:application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition:attachment; filename="vilamir_'.$tipo.'.xls"');
    echo '<table border="1"><tr>';
    foreach(array_keys($rows[0]??['Sin datos']) as $h)echo '<th>'.htmlspecialchars((string)$h, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8').'</th>';
    echo '</tr>';
    foreach($rows as $r) {
        echo '<tr>';
        foreach($r as $v) {
            $valor = (string)$v;
            if (preg_match('/^[\s]*[=+@\-]/u', $valor)) $valor = "'" . $valor;
            echo '<td>'.htmlspecialchars($valor, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8').'</td>';
        }
        echo '</tr>';
        }
    echo '</table>';
    exit;
    }

?>
<!doctype html>
<html lang="es">
<head>
<?php vilamir_enviar_token_csrf(); ?>
<meta charset="utf-8">
<title><?=htmlspecialchars($map[$tipo]['titulo'])?>
</title>
<link rel="stylesheet" href="css/style.css?v=20261026-etapa2-seminarios-galeria-v1">
<script src="js/csrf.js"></script>
</head>
<body class="export-page">
<button class="no-print export-print-button" onclick="window.print()">Guardar como PDF</button>
<h1><?=htmlspecialchars($map[$tipo]['titulo'])?>
 - VILAMIR</h1>
<table class="export-table">
<tr><?php foreach(array_keys($rows[0]??['Sin datos']) as $h): ?>
<th><?=htmlspecialchars((string)$h, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')?>
</th><?php endforeach;
?>
</tr><?php foreach($rows as $r): ?>
<tr><?php foreach($r as $v): ?>
<td><?=htmlspecialchars((string)$v)?>
</td><?php endforeach;
?>
</tr><?php endforeach;
?>
</table>
</body>
</html>
