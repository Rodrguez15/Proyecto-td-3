<?php

/*
 * ARCHIVO: admin.php
 * PROPÓSITO: Página o módulo PHP de admin dentro del sistema Academia VILAMIR.
 */
// Panel principal de administración.
// La autenticación verifica que el usuario tenga rol Administrador.
require_once 'config/admin.php';
require_once 'config/conexion.php';
require_once 'config/qr.php';

$qrGeneradosPendientes = 0;
try {
    $qrGeneradosPendientes = vilamir_generar_qr_pendientes($conexion);
} catch (Throwable $e) {
    error_log('No se pudieron completar los QR pendientes: ' . $e->getMessage());
}

// Obtiene el nombre del administrador para mostrarlo en pantalla.
$nombre = $_SESSION['usuario_nombre'] ?? 'Administrador';

?>
<!DOCTYPE html>
<html lang="es">
<head>
<?php vilamir_enviar_token_csrf(); ?>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Administración - VILAMIR</title>
<link rel="stylesheet" href="css/style.css?v=20261115-unificado-v1">
<script src="js/csrf.js"></script>
</head>
<body class="about-page admin-panel-page">
<header class="navbar">
<div class="logo">
<img src="images/logo-vilamir.jpg" alt="Escuela Vilamir" class="logo-img">
</div>
<nav>
<a href="index.php">Inicio</a>
<a href="admin.php">Administración</a>
<a href="reportes.php">Reportes</a>
<a href="estadisticas.php">Estadísticas</a>
<a href="herramientas.php">Herramientas</a>
        <a href="checkin.php">Check-in</a>
<a href="publica.php">Web pública</a>
<a href="calendario.php">Calendario</a>
<a href="about.html">About Us</a>
<a class="logout" href="logout.php">Cerrar sesión</a>
</nav>
</header>
<main class="admin">
<section class="hero">
<h1>Panel de Administración</h1>
<p>
                Bienvenido,
                <strong><?= htmlspecialchars($nombre) ?>
</strong>.
                Gestiona alumnos, profesores, disciplinas, horarios, grupos,
                pagos, notificaciones, seminarios, promociones, usuarios
                e inscripciones.
            </p>
            <?php if ($qrGeneradosPendientes > 0): ?>
                <p class="admin-notice" role="status">Se generaron automáticamente <?= (int)$qrGeneradosPendientes ?> código(s) QR para alumnos que todavía no tenían uno.</p>
            <?php endif; ?>
</section>
<!-- JavaScript carga aquí las estadísticas del sistema. -->
<div id="stats" class="stats">
</div>
<!-- Resumen operativo del día. -->
<section id="dashboard-extra" class="dashboard-extra" aria-label="Resumen administrativo">
</section>
<!-- Generador masivo de cuotas mensuales -->
<section id="panel-cuotas-mes" class="dashboard-extra" aria-label="Generador de cuotas mensuales">
    <div class="cuotas-generator-card">
        <div class="cuotas-generator-head">
            <span class="eyebrow">COBRANZAS AUTOMÁTICAS</span>
            <h2>Generador masivo de cuotas del mes</h2>
            <p class="small">Generá las cuotas pendientes para todos los alumnos con disciplinas activas en 1 solo clic. El sistema evita automáticamente duplicar cobros ya existentes.</p>
        </div>
        <div class="cuotas-generator-form">
            <div class="cuotas-field">
                <label for="cuotasMes">Mes</label>
                <select id="cuotasMes"></select>
            </div>
            <div class="cuotas-field">
                <label for="cuotasAnio">Año</label>
                <select id="cuotasAnio"></select>
            </div>
            <div class="cuotas-field">
                <label for="cuotasVencimiento">Día de vencimiento</label>
                <input type="number" id="cuotasVencimiento" min="1" max="28" value="10">
            </div>
            <div class="cuotas-field-action">
                <button type="button" id="btnGenerarCuotasMes" class="btn-cuotas-submit">
                    ⚡ Generar cuotas del mes
                </button>
            </div>
        </div>
        <div id="resultadoCuotasMes" class="cuotas-feedback" style="display:none;"></div>
    </div>
</section>
<!-- Notificaciones para el administrador: pagos nuevos de inscripciones, avisos del sistema. -->
<section id="notificaciones-admin" class="dashboard-extra" aria-label="Notificaciones del administrador">
    <div class="notif-admin-top">
        <div>
            <h2>
                Mis notificaciones 
                <span id="badgeNotificacionesAdmin" class="notif-count-badge" style="display:none;">0</span>
            </h2>
            <p class="small">Avisos de pagos generados por inscripciones de alumnos y novedades del sistema.</p>
        </div>
        <div class="notif-admin-actions">
            <button type="button" id="btnMarcarTodasLeidasAdmin" class="btn-notif-action">
                ✓ Marcar todas como leídas
            </button>
        </div>
    </div>

    <div id="listaNotificacionesAdmin" class="notifications-admin-list"></div>
    <p id="mensajeNotificacionesAdmin" class="message-center" role="status" aria-live="polite"></p>
</section>
<!-- JavaScript genera aquí las pestañas de cada módulo. -->
<div id="tabs" class="tabs">
</div>
<!-- Aquí se muestra el formulario y la tabla del módulo seleccionado. -->
<section id="module" class="module">
</section>
</main>
<footer>© 2026 Academia VILAMIR</footer>
<script src="js/admin.js?v=20261115-unificado-v1">
</script>
<script src="js/mobile.js">
</script>
<script>
document.addEventListener('DOMContentLoaded', () => {
    const list = document.getElementById('listaNotificacionesAdmin');
    const badge = document.getElementById('badgeNotificacionesAdmin');
    const btnMarcar = document.getElementById('btnMarcarTodasLeidasAdmin');

    function formatearNotificaciones() {
        if (!list) return;
        const items = list.querySelectorAll(':scope > *:not(.notif-procesada)');

        items.forEach(item => {
            item.classList.add('notif-procesada');

            // 1. Extraer título
            const titleEl = item.querySelector('h2, h3, h4, strong');
            const title = titleEl ? titleEl.textContent.trim() : 'Notificación';

            // 2. Extraer fecha y mensaje
            const allText = Array.from(item.querySelectorAll('p, small, span'));
            let date = '';
            let message = '';

            allText.forEach(el => {
                const txt = el.textContent.trim();
                if (txt.match(/\d{4}-\d{2}-\d{2}/) || txt.includes('leída') || txt.includes('leida')) {
                    date = txt;
                } else if (txt && txt !== title && !message) {
                    message = txt;
                }
            });

            if (!message) {
                message = item.textContent.replace(title, '').replace(date, '').trim();
            }

            // 3. Estado leído / no leído
            const isRead = item.textContent.includes('leída') || item.textContent.includes('leida');
            if (isRead) {
                item.classList.add('leida');
                item.classList.remove('no-leida');
            } else {
                item.classList.add('no-leida');
                item.classList.remove('leida');
            }

            // 4. Buscar código de comprobante (VIL-...)
            const match = item.textContent.match(/VIL-\d{4}-\d{2}-\d{2}-\d+/);
            const codigo = match ? match[0] : null;

            // 5. Reestructurar el contenido en una plantilla limpia de 2 líneas
            item.innerHTML = `
                <div class="notif-row-header">
                    <div class="notif-title-group">
                        <span class="notif-status-dot"></span>
                        <strong class="notif-title-text">${title}</strong>
                    </div>
                    <div class="notif-meta-group">
                        <span class="notif-date-text">${date}</span>
                        <span class="notif-arrow">▾</span>
                    </div>
                </div>
                <div class="notif-row-content">
                    <p class="notif-message-text">${message}</p>
                    ${codigo ? `
                        <div class="notif-actions-bar">
                            <a href="verificar_comprobante.php?codigo=${encodeURIComponent(codigo)}" target="_blank" rel="noopener" class="notif-comprobante-btn" onclick="event.stopPropagation()">
                                📄 Ver comprobante (${codigo})
                            </a>
                        </div>
                    ` : ''}
                </div>
            `;
        });

        // Actualizar contador badge
        if (badge) {
            const noLeidas = list.querySelectorAll(':scope > .no-leida').length;
            if (noLeidas > 0) {
                badge.textContent = noLeidas;
                badge.style.display = 'inline-block';
            } else {
                badge.style.display = 'none';
            }
        }
    }

    formatearNotificaciones();
    if (list) {
        const observer = new MutationObserver(() => formatearNotificaciones());
        observer.observe(list, { childList: true, subtree: true });

        // Clic para abrir / cerrar
        list.addEventListener('click', (e) => {
            const item = e.target.closest('#listaNotificacionesAdmin > *');
            if (item && !e.target.closest('a, button')) {
                item.classList.toggle('is-open');
            }
        });
    }

    // Botón marcar todas como leídas
    if (btnMarcar) {
        btnMarcar.addEventListener('click', async () => {
            btnMarcar.disabled = true;
            btnMarcar.textContent = 'Actualizando…';
            try {
                const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
                const fd = new FormData();
                fd.set('accion', 'leer_todas');
                if (csrf) fd.set('csrf_token', csrf);

                const r = await fetch('api/notificaciones_usuario.php', {
                    method: 'POST',
                    body: fd,
                    headers: { 'X-CSRF-Token': csrf }
                });
                const d = await r.json();

                if (d.status === 'success') {
                    document.querySelectorAll('#listaNotificacionesAdmin > *').forEach(card => {
                        card.classList.add('leida');
                        card.classList.remove('no-leida');
                        const dateEl = card.querySelector('.notif-date-text');
                        if (dateEl && !dateEl.textContent.includes('leída')) {
                            dateEl.textContent = dateEl.textContent.replace('no leída', '').trim() + ' · leída';
                        }
                    });
                    if (badge) badge.style.display = 'none';
                    const msg = document.getElementById('mensajeNotificacionesAdmin');
                    if (msg) msg.textContent = 'Estás al día: no tenés notificaciones sin leer.';
                }
            } catch (err) {
                console.error(err);
            } finally {
                btnMarcar.disabled = false;
                btnMarcar.textContent = '✓ Marcar todas como leídas';
            }
        });
    }
});
</script>
<script>
document.addEventListener('DOMContentLoaded', () => {
    const selectMes = document.getElementById('cuotasMes');
    const selectAnio = document.getElementById('cuotasAnio');
    const inputVenc = document.getElementById('cuotasVencimiento');
    const btnGenerar = document.getElementById('btnGenerarCuotasMes');
    const divFeedback = document.getElementById('resultadoCuotasMes');

    if (!selectMes || !selectAnio) return;

    const meses = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
    const now = new Date();
    const currentMonth = now.getMonth() + 1;
    const currentYear = now.getFullYear();

    // Llenar selector de meses
    meses.forEach((m, idx) => {
        const opt = document.createElement('option');
        opt.value = idx + 1;
        opt.textContent = m;
        if (idx + 1 === currentMonth) opt.selected = true;
        selectMes.appendChild(opt);
    });

    // Llenar selector de años (año anterior, actual y siguiente)
    for (let y = currentYear - 1; y <= currentYear + 1; y++) {
        const opt = document.createElement('option');
        opt.value = y;
        opt.textContent = y;
        if (y === currentYear) opt.selected = true;
        selectAnio.appendChild(opt);
    }

    btnGenerar.addEventListener('click', async () => {
        const mesElegido = selectMes.value;
        const nombreMes = selectMes.options[selectMes.selectedIndex].text;
        const anioElegido = selectAnio.value;
        const diaVenc = inputVenc.value || 10;

        const confirma = confirm(`¿Confirmás la generación de cuotas para todos los alumnos activos de ${nombreMes} ${anioElegido} con vencimiento el día ${diaVenc}?`);
        if (!confirma) return;

        btnGenerar.disabled = true;
        btnGenerar.textContent = '⏳ Procesando cuotas…';
        divFeedback.style.display = 'none';

        try {
            const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
            const fd = new FormData();
            fd.set('entity', 'pagos');
            fd.set('accion', 'generar_cuotas_mes');
            fd.set('mes', mesElegido);
            fd.set('anio', anioElegido);
            fd.set('dia_vencimiento', diaVenc);
            if (csrf) fd.set('csrf_token', csrf);

            const res = await fetch('api/admin.php', {
                method: 'POST',
                body: fd,
                headers: { 'X-CSRF-Token': csrf }
            });
            const data = await res.json();

            divFeedback.style.display = 'block';
            if (data.status === 'success') {
                divFeedback.className = 'cuotas-feedback success';
                divFeedback.innerHTML = `<strong>✔ Éxito:</strong> ${data.message}`;
            } else {
                divFeedback.className = 'cuotas-feedback error';
                divFeedback.innerHTML = `<strong>✖ Error:</strong> ${data.message || 'No se pudieron generar las cuotas.'}`;
            }
        } catch (err) {
            divFeedback.style.display = 'block';
            divFeedback.className = 'cuotas-feedback error';
            divFeedback.innerHTML = `<strong>✖ Error de conexión:</strong> Intenta nuevamente.`;
            console.error(err);
        } finally {
            btnGenerar.disabled = false;
            btnGenerar.textContent = '⚡ Generar cuotas del mes';
        }
    });
});
</script>
<!-- MODAL FLOTANTE PARA CONFIRMAR PAGO -->
<div id="modalConfirmarPago" class="modal-vilamir-backdrop" style="display:none;">
    <div class="modal-vilamir-card">
        <div class="modal-vilamir-head">
            <h3>✔ Confirmar Cobro de Pago</h3>
            <button type="button" class="modal-vilamir-close" id="btnCerrarModalConfirmar">&times;</button>
        </div>
        <form id="formConfirmarPago">
            <input type="hidden" id="confirmarIdPago" name="id">
            <div class="modal-info-pago" id="infoDetallePago">
                <!-- Se llena con JS: Alumno y Comprobante -->
            </div>
            <div class="modal-field">
                <label for="confirmarMetodo">Método de pago recibido</label>
                <select id="confirmarMetodo" name="metodo_pago" required>
                    <option value="Efectivo" selected>💵 Efectivo</option>
                    <option value="Transferencia bancaria">🏦 Transferencia bancaria</option>
                    <option value="Tarjeta de Débito">💳 Tarjeta de Débito</option>
                    <option value="Tarjeta de Crédito">💳 Tarjeta de Crédito</option>
                    <option value="Mercado Pago">📱 Mercado Pago</option>
                    <option value="A convenir">🤝 A convenir</option>
                </select>
            </div>
            <div class="modal-field">
                <label for="confirmarFecha">Fecha de cobro</label>
                <input type="date" id="confirmarFecha" name="fecha" required>
            </div>
            <div class="modal-actions">
                <button type="button" class="btn secondary" id="btnCancelarConfirmar">Cancelar</button>
                <button type="submit" class="btn btn-confirmar-submit">✔ Confirmar como Pagado</button>
            </div>
        </form>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('modalConfirmarPago');
    const form = document.getElementById('formConfirmarPago');
    const btnCerrar = document.getElementById('btnCerrarModalConfirmar');
    const btnCancelar = document.getElementById('btnCancelarConfirmar');
    const inputFecha = document.getElementById('confirmarFecha');
    const inputId = document.getElementById('confirmarIdPago');
    const divInfo = document.getElementById('infoDetallePago');

    // Cerrar modal
    const cerrar = () => { if (modal) modal.style.display = 'none'; };
    if (btnCerrar) btnCerrar.addEventListener('click', cerrar);
    if (btnCancelar) btnCancelar.addEventListener('click', cerrar);

    // Inyectar botón "Confirmar" en la tabla de pagos cuando aparezca
    function inyectarBotonesConfirmar() {
        const filas = document.querySelectorAll('#module table tbody tr');
        filas.forEach(fila => {
            // Verificar si esta fila corresponde a pagos buscando el link de comprobante
            const linkComprobante = fila.querySelector('a[href*="comprobante_pago.php"]');
            if (!linkComprobante) return;

            // Extraer ID del pago desde el enlace
            const matchId = linkComprobante.href.match(/id=(\d+)/);
            if (!matchId) return;
            const idPago = matchId[1];

            // Revisar si ya tiene el botón inyectado
            if (fila.querySelector('.btn-confirmar-pago')) return;

            // Revisar si el estado es 'Pendiente'
            const textoFila = fila.textContent.toLowerCase();
            const esPendiente = textoFila.includes('pendiente');

            const celdaAcciones = fila.querySelector('td:last-child');
            if (celdaAcciones && esPendiente) {
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'btn-confirmar-pago';
                btn.innerHTML = '✔ Confirmar';
                btn.title = 'Marcar este pago como Pagado y elegir método';

                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();

                    // Extraer datos de la fila para mostrarlos en el modal
                    const comprobante = fila.querySelector('td:nth-child(3)')?.textContent.trim() || `#${idPago}`;
                    const alumno = fila.querySelector('td:nth-child(7)')?.textContent.trim() || 'Alumno';

                    inputId.value = idPago;
                    inputFecha.value = new Date().toISOString().split('T')[0];
                    divInfo.innerHTML = `
                        <strong>Alumno:</strong> ${alumno}<br>
                        <strong>Comprobante:</strong> ${comprobante}
                    `;
                    modal.style.display = 'flex';
                });

                // Insertar al inicio de las acciones
                celdaAcciones.insertBefore(btn, celdaAcciones.firstChild);
            }
        });
    }

    // Observar cuando se cargue o cambie la pestaña de pagos
    const contenedorModulo = document.getElementById('module');
    if (contenedorModulo) {
        inyectarBotonesConfirmar();
        const obs = new MutationObserver(() => inyectarBotonesConfirmar());
        obs.observe(contenedorModulo, { childList: true, subtree: true });
    }

    // Enviar confirmación al backend
    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const btnSubmit = form.querySelector('.btn-confirmar-submit');
            btnSubmit.disabled = true;
            btnSubmit.textContent = 'Guardando…';

            try {
                const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
                const fd = new FormData(form);
                fd.set('entity', 'pagos');
                fd.set('accion', 'confirmar');
                if (csrf) fd.set('csrf_token', csrf);

                const res = await fetch('api/admin.php', {
                    method: 'POST',
                    body: fd,
                    headers: { 'X-CSRF-Token': csrf }
                });
                const data = await res.json();

                if (data.status === 'success') {
                    cerrar();
                    if (typeof window.mostrarToast === 'function') {
                        window.mostrarToast(data.message, 'success');
                    } else {
                        alert(data.message);
                    }

                    // Actualizar visualmente la fila en la tabla sin recargar toda la página
                    const idPago = inputId.value;
                    const fila = Array.from(document.querySelectorAll('#module table tbody tr')).find(tr => 
                        tr.innerHTML.includes(`id=${idPago}`)
                    );

                    if (fila) {
                        // Cambiar 'Pendiente' a 'Pagado'
                        const celdaEstado = fila.querySelector('td:nth-child(1)');
                        if (celdaEstado) celdaEstado.innerHTML = '<span style="color:#39d98a; font-weight:750;">Pagado</span>';

                        // Actualizar método de pago
                        const celdaMetodo = fila.querySelector('td:nth-child(2)');
                        if (celdaMetodo) celdaMetodo.textContent = data.metodo_pago;

                        // Quitar el botón de confirmar ya que quedó pagado
                        const btnConf = fila.querySelector('.btn-confirmar-pago');
                        if (btnConf) btnConf.remove();
                    }
                } else {
                    alert(data.message || 'Error al confirmar pago');
                }
            } catch (err) {
                console.error(err);
                alert('Ocurrió un error al procesar la confirmación.');
            } finally {
                btnSubmit.disabled = false;
                btnSubmit.textContent = '✔ Confirmar como Pagado';
            }
        });
    }
});
</script>
</body>
</html>
