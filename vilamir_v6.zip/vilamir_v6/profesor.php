<?php

/*
 * DESCRIPCIÓN DEL ARCHIVO
 * Portal del profesor para consultar clases y grupos asignados.
 */
require_once 'config/autenticacion.php';

if (($_SESSION['usuario_rol'] ?? '') !== 'Profesor') {
    header('Location: index.php');
    exit;
}

$nombre = $_SESSION['usuario_nombre'] ?? 'Profesor';

?>
<!DOCTYPE html>
<html lang="es">
<head>
<?php vilamir_enviar_token_csrf(); ?>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mi espacio docente | VILAMIR</title>
<link rel="stylesheet" href="css/style.css?v=20261026-etapa4-portal-profesor-v1">
<script src="js/csrf.js"></script>
</head>
<body class="account-page teacher-page">
<header class="navbar">
<div class="logo">
<img src="images/logo-vilamir.jpg" alt="Escuela Vilamir" class="logo-img">
</div>
<nav>
<a href="index.php">Inicio</a>
<a class="active" href="profesor.php">Mi espacio</a>
<a href="horarios.php">Mi cronograma</a>
<a href="calendario.php">Calendario</a>
<a href="grupos.php">Grupos</a>
<a href="seminarios.php">Eventos</a>
<a href="checkin.php">Check-in</a>
<a href="logout.php">Cerrar sesión</a>
</nav>
</header>
<main class="teacher-shell">
<section class="teacher-welcome">
<div>
<span class="teacher-eyebrow">MI ESPACIO DOCENTE</span>
<h1>Hola, <?= htmlspecialchars($nombre, ENT_QUOTES, 'UTF-8') ?> 👋</h1>
<p>Tu jornada, tus grupos y el seguimiento de tus alumnos, organizados en un solo lugar.</p>
</div>
<div class="teacher-actions">
<a class="teacher-btn" href="calendario.php">📅 Ver calendario</a>
<a class="teacher-btn secondary" href="horarios.php">🗓️ Mi cronograma</a>
<a class="teacher-btn secondary" href="estadisticas.php">📊 Asistencias avanzadas</a>
</div>
</section>

<section id="profStats" class="teacher-stats">
</section>

<section id="profResumen" class="teacher-layout teacher-summary-layout">
</section>

<div class="teacher-layout teacher-groups-layout">
<section class="teacher-panel teacher-groups-panel">
<div class="teacher-panel-head">
<div>
<span class="teacher-kicker">ORGANIZACIÓN</span>
<h2>👥 Mis grupos</h2>
</div>
<a class="teacher-link" href="grupos.php">Ver grupos →</a>
</div>
<div id="listaGruposProfesor" class="cards-grid">
<div class="teacher-empty">Cargando grupos…</div>
</div>
</section>
</div>

<section class="teacher-panel full">
<div class="teacher-panel-head">
<div>
<span class="teacher-kicker">AVISOS</span>
<h2>🔔 Notificaciones</h2>
<p class="teacher-subtitle">Cambios de horarios y avisos relacionados con tus grupos.</p>
</div>
<button class="teacher-btn secondary" type="button" id="marcarNotifProfesor">Marcar todas como leídas</button>
</div>
<div id="notificacionesProfesor" class="teacher-notifications">
<div class="teacher-empty">Cargando notificaciones…</div>
</div>
</section>

<section class="teacher-panel full">
<div class="teacher-panel-head">
<div>
<span class="teacher-kicker">PERFIL DOCENTE</span>
<h2>🥋 Disciplinas que enseño</h2>
<p class="teacher-subtitle">Seleccioná las disciplinas que podés enseñar. La asignación de grupos se administra por separado.</p>
</div>
</div>
<div id="listaDisciplinasProfesor" class="cards-grid">
<div class="teacher-empty">Cargando disciplinas…</div>
</div>
<button id="btnGuardarDisciplinasProfesor" class="teacher-btn">Guardar disciplinas</button>
<p id="mensajeProfesorPortal" role="status" aria-live="polite">
</p>
</section>

<section class="teacher-panel full">
<div class="teacher-panel-head">
<div>
<span class="teacher-kicker">PLANIFICACIÓN</span>
<h2>🗓️ Mi semana de trabajo</h2>
</div>
<a class="teacher-link" href="calendario.php">Calendario completo →</a>
</div>
<div class="teacher-calendar-wrap">
<div id="calendarioProfesor" class="calendar">
<div class="teacher-empty">Cargando calendario…</div>
</div>
</div>
</section>

<!-- SECCIÓN ÚNICA DE CONTROL DE ASISTENCIA -->
<section class="teacher-panel full attendance-panel">
<div class="teacher-panel-head">
<div>
<span class="teacher-kicker">SEGUIMIENTO</span>
<h2>✅ Control de asistencia</h2>
<p class="teacher-subtitle">Elegí el grupo, la fecha y el horario para registrar la asistencia de tus alumnos.</p>
</div>
</div>
<div class="teacher-toolbar">
<select id="grupoAsistencia">
<option value="">Seleccionar grupo</option>
</select>
<input type="date" id="fechaAsistencia">
<select id="horarioAsistencia">
<option value="">Seleccionar horario</option>
</select>
<button id="cargarAsistencia" class="teacher-btn">Cargar alumnos</button>
</div>

<!-- ACCIONES RÁPIDAS (SE ACTIVAN CUANDO HAY ALUMNOS EN PANTALLA) -->
<div id="asistenciaAccionesRapidas" class="attendance-quick-actions" style="display:none;">
<span>Acciones rápidas:</span>
<button type="button" id="btnTodosPresentes" class="btn-quick-attendance">⚡ Marcar todos Presentes</button>
<button type="button" id="btnLimpiarMarcas" class="btn-quick-attendance secondary">Restablecer a Sin marcar</button>
</div>

<div id="resumenAsistencia" class="attendance-summary">
</div>
<div id="listaAsistencia" class="attendance-list">
</div>
<button id="guardarAsistencia" class="teacher-btn attendance-save-button" hidden>Guardar asistencia</button>
<p id="mensajeAsistencia" role="status" aria-live="polite">
</p>
</section>

<section class="teacher-panel full">
<div class="teacher-panel-head">
<div>
<span class="teacher-kicker">RESUMEN DE GRUPOS</span>
<h2>📊 Ocupación de mis grupos</h2>
<p class="teacher-subtitle">Cantidad de alumnos activos y cupos disponibles en cada grupo asignado.</p>
</div>
</div>
<div id="resumenGruposProfesor" class="teacher-group-summary">
</div>
</section>

<section class="teacher-panel full">
<div class="teacher-panel-head">
<div>
<span class="teacher-kicker">COMUNICACIONES</span>
<h2>🔔 Avisos de la academia</h2>
<p class="teacher-subtitle">Cambios de organización y mensajes enviados por administración.</p>
</div>
<button type="button" class="teacher-btn secondary" onclick="cargarAvisosProfesor()">Actualizar</button>
</div>
<div id="avisosProfesor" class="teacher-group-summary">
<div class="teacher-empty">Cargando avisos…</div>
</div>
</section>
</main>
<footer>© 2026 VILAMIR · Enseñanza práctica de artes marciales</footer>

<script src="js/profesor.js">
</script>
<script src="js/mobile.js">
</script>

<!-- CONTROL DE BOTONES RÁPIDOS DE ASISTENCIA -->
<script>
document.addEventListener('DOMContentLoaded', () => {
    const lista = document.getElementById('listaAsistencia');
    const barraRapida = document.getElementById('asistenciaAccionesRapidas');
    const btnTodos = document.getElementById('btnTodosPresentes');
    const btnLimpiar = document.getElementById('btnLimpiarMarcas');
    const btnGuardar = document.getElementById('guardarAsistencia');

    if (lista && barraRapida) {
        const obs = new MutationObserver(() => {
            const selects = lista.querySelectorAll('select');
            barraRapida.style.display = selects.length > 0 ? 'flex' : 'none';
        });
        obs.observe(lista, { childList: true });
    }

    if (btnTodos) {
        btnTodos.addEventListener('click', () => {
            const selects = lista.querySelectorAll('select');
            if (selects.length === 0) return;

            selects.forEach(sel => {
                sel.value = 'Presente';
                sel.dispatchEvent(new Event('change', { bubbles: true }));
            });

            if (btnGuardar) btnGuardar.hidden = false;
            if (typeof window.mostrarToast === 'function') {
                window.mostrarToast(`Se marcaron ${selects.length} alumnos como Presentes. Modificá solo los ausentes antes de guardar.`, 'info');
            }
        });
    }

    if (btnLimpiar) {
        btnLimpiar.addEventListener('click', () => {
            const selects = lista.querySelectorAll('select');
            selects.forEach(sel => {
                sel.value = 'Sin marcar';
                sel.dispatchEvent(new Event('change', { bubbles: true }));
            });
            if (typeof window.mostrarToast === 'function') {
                window.mostrarToast('Se restablecieron las marcas de asistencia.', 'info');
            }
        });
    }
});
</script>
</body>
</html>