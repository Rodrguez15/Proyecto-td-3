# Revisión de protección CSRF — VILAMIR V6

Fecha: 16/11/2026  
Base de trabajo: `VILAMIR_V6_BAJAS_TEMPORAL_DEFINITIVA.zip`  
Alcance: revisión estática y corrección del cliente CSRF. No se modificó el esquema ni se ejecutaron consultas contra una base activa.

## Resultado de la revisión

- Las API ubicadas en `api/*.php` incluyen `config/sesion.php`; esta capa aplica verificación CSRF central a solicitudes POST, PUT, PATCH y DELETE.
- Los formularios y páginas dinámicas principales publican el token mediante `vilamir_enviar_token_csrf()` y cargan `js/csrf.js`.
- `login.php` valida el token explícitamente. `login.html` obtiene el token desde `csrf_token.php` antes de enviar credenciales.
- `registrar.php`, `recuperar_contrasena.php` y `logout.php` usan la sesión común; sus solicitudes de modificación quedan sujetas a la validación central.
- `api/checkin.php` requiere POST y utiliza la sesión común; la página `checkin.php` publica el token.
- `cron_notificaciones.php` es una excepción deliberada: permite CLI o POST autenticado mediante `CRON_KEY`. No utiliza una sesión de navegador ni debe recibir el token CSRF de usuario. En producción debe configurarse una clave secreta fuerte y no exponerse en URLs.
- `tutor.php` y `api/tutor.php` realizan consultas de lectura por GET; no se identificó modificación de datos en ese flujo.

## Corrección aplicada

Se ajustó `js/csrf.js` para:

1. Agregar `X-CSRF-Token` solo a fetch mutables del mismo origen.
2. Reconocer el método de objetos `Request` cuando se usa `fetch(new Request(...))`.
3. No enviar el token a dominios externos.
4. No insertar tokens en formularios GET ni en formularios con destino externo.
5. Mantener el token en formularios mutables locales y en el cierre de sesión heredado por POST.

La validación del servidor sigue siendo obligatoria: el token agregado por JavaScript no sustituye la comprobación de `config/sesion.php`.

## Archivos modificados

- `js/csrf.js`
- `docs/REVISION_SEGURIDAD_CSRF_2026-11-16.md` (este documento)

## Validaciones realizadas

- Sintaxis PHP: validación con `php -l` sobre archivos PHP del proyecto.
- Sintaxis JavaScript: validación con `node --check` sobre archivos JS del proyecto.
- Pruebas aisladas del helper: destino local con POST agrega token; GET no agrega token; POST externo no recibe token; formulario GET y formulario externo no reciben campo; formulario POST local recibe campo.
- Integridad del ZIP: `unzip -t`.
- Revisión de cambios: solo los dos archivos indicados fueron modificados en esta etapa.

## Pruebas manuales pendientes

No se afirma que estas pruebas hayan sido ejecutadas. Deben realizarse en una copia de XAMPP y luego en InfinityFree:

1. Enviar POST sin token a una API de prueba y comprobar HTTP 403 sin cambios en datos.
2. Enviar POST con token incorrecto y comprobar HTTP 403.
3. Enviar POST con token válido y comprobar que la operación legítima funciona.
4. Probar login, registro, formularios administrativos, pagos, inscripciones, asistencia, notificaciones, recuperación y logout.
5. Confirmar que el cron solo funciona por CLI o con `CRON_KEY` válida.
6. Repetir pruebas con sesión expirada y varias pestañas abiertas.

## Límites

La revisión estática no sustituye pruebas dinámicas contra MySQL ni pruebas de navegador. No se importó ni ejecutó ningún archivo SQL. No se cambió el esquema, las tablas, las columnas, las claves foráneas ni los datos.
