# Informe de correcciones VILAMIR V5 — 16/11/2026

## Alcance y preservación

Se revisó `vilamir_v5.zip` y el archivo `mma_systems.sql` aportado por separado. El trabajo se realizó sobre una extracción de trabajo; el ZIP y el volcado originales no fueron sobrescritos.

- ZIP original: SHA-256 `dc38f29506ed3a621e0ccc0972a0e2955fcb946f837cc10651430ad2da74c81b`.
- Volcado SQL externo revisado: SHA-256 `fe4fed6cbd28b0066c17dd0f90414e1010697b9a52d70849f78c3eb137aafb92`.
- `sql/mma_systems.sql` del ZIP original: SHA-256 `d56dcf7e69ba34994f938c96140cbdfc1c1ca01e8d6e144fb71b381340d28725`; permanece idéntico.
- No se ejecutó SQL, no se conectó a la base activa y no se modificó ninguna tabla, columna, índice, relación ni dato.
- El volcado externo contiene datos personales y hashes de contraseñas; no se incorpora al paquete corregido.

## Cambios aplicados

1. **Configuración XAMPP / InfinityFree:** se retiraron valores predeterminados de MySQL. `config/db_config.php` carga un archivo privado `config/db_config.local.php`, excluido por `.gitignore` y no incluido en el ZIP. Se agregó plantilla sin credenciales reales. La conexión falla de forma controlada si faltan valores; en producción también exige contraseña no vacía.
2. **Borrado de alumnos:** `api/alumnos.php` ya rechazaba la eliminación física. Se agregó protección en la operación genérica de borrado de `USUARIO` para bloquear cualquier cuenta vinculada a `ALUMNO`, ya que las FK actuales permiten cascadas hacia pagos e historial. No se implementó baja lógica porque no hay un estado independiente en el esquema y no se autorizó modificarlo.
3. **CSRF:** el middleware de sesión valida POST/PUT/PATCH/DELETE también para operaciones públicas. Login valida token explícitamente; registro obtiene token desde `csrf_token.php`; recuperación tiene token en los formularios; cierre de sesión pasó a POST y los enlaces se convierten mediante `js/csrf.js`. Esto es una corrección estática: falta probarla en navegador y con cada rol.
4. **Correo / recuperación:** se eliminó el fallback silencioso a `mail()` cuando SMTP no está configurado. Se exige SMTP con TLS en puerto 465 o 587 y una `VILAMIR_BASE_URL` válida. Sin ambos datos no se crea un token que no pueda entregarse. La pantalla mantiene mensaje genérico y no afirma entrega. No se probó recepción real.
5. **Cron / notificaciones:** se quitó la clave web predeterminada. El cron genera avisos internos en tablas de notificación, no correos. Se recomienda CLI; el acceso web opcional exige `CRON_KEY` y POST, y GET queda deshabilitado.
6. **Móvil:** no se modificaron CSS ni reglas responsive porque no fue posible reproducir el problema en navegador/dispositivo real. La versión ya contiene wrappers de desplazamiento horizontal; se preparó una matriz concreta para verificarlo a 320/360/390 px en Android/iOS.
7. **Documentación académica:** se creó inventario del esquema real, anexo de consultas SQL, matriz de pruebas, checklist de entregables y guía de cron/recuperación. Se actualizó una copia del documento principal, manteniendo las 12 tablas y 24 imágenes incrustadas; se agregó `RECUPERACION_CONTRASENA`, se corrigió la relación de promociones, se corrigió COCOMO, se retiró una contraseña del script de backup, se etiquetaron RPO/RTO como objetivos no medidos y se limpió bibliografía genérica.
8. **Rutinas opcionales:** se preparó `sql/opcionales/rutinas_informes.sql` con una función y un procedimiento de lectura. No se ejecutaron; agregan objetos de rutina si se autorizan, pero no crean ni alteran tablas ni filas.

## Hallazgos de esquema que no se modificaron

El volcado externo revisado contiene 25 tablas y 33 FK; el SQL base del ZIP contiene 24 tablas y la recuperación se entrega en una migración separada. Además, el volcado tiene `PROMOCION.Clave_promocion` y `Descuento DECIMAL(10,2)`, mientras el SQL base del ZIP omite esa columna y define `Descuento DECIMAL(5,2)`, que no admite importes mayores a 999,99. Esto puede afectar una instalación nueva; se documentó, pero no se corrigió ni se generó migración porque el esquema debe permanecer intacto hasta recibir autorización.

El volcado externo contiene una sola fila en `PAGO` y 20 filas en `ACTIVIDAD_SISTEMA`; varias actividades mencionan otros IDs de pago. Si el volcado se considera completo, debe verificarse en la base activa o en una exportación íntegra. No se inventaron ni reconstruyeron pagos.

## Validaciones ejecutadas en esta copia

- `php -l`: **62 archivos PHP, 0 errores** (PHP 8.4.24).
- `node --check`: **18 archivos JavaScript, 0 errores** (Node.js 22.16.0).
- `php csrf_token.php`: respondió JSON con token de sesión en prueba CLI; el token no se conserva en este informe.
- `vilamirSmtpConfigurado()`: devuelve `false` sin configuración, como se espera.
- `config/conexion.php`: sin archivo local ni variables de entorno, falla con mensaje genérico y sin credenciales predeterminadas.
- `logout.php` por GET: responde método no permitido; el flujo previsto es POST con CSRF.
- Búsqueda de cadenas de credenciales antiguas y clave cron predeterminada: sin coincidencias en el paquete corregido.
- Comparación de archivos SQL: todos los SQL existentes del ZIP original permanecen sin cambios; se agregó únicamente el script opcional separado.
- Se verificó que el documento principal corregido conserva 12 tablas y 24 imágenes incrustadas.

## No probado / pendiente de ejecución manual

- No hay controlador PDO MySQL disponible en este entorno (`PDO::getAvailableDrivers()` vacío); no se pudo conectar a MariaDB/MySQL.
- No se probaron formularios, APIs, transacciones ni roles en XAMPP o InfinityFree.
- No se probó el envío/recepción SMTP ni la expiración/uso único de tokens con correo real.
- No se ejecutó `cron_notificaciones.php` contra una base de prueba.
- No se ejecutaron las consultas del anexo ni las rutinas opcionales en un motor SQL.
- No se probó restauración de backups ni se midieron RPO/RTO.
- No se realizó prueba de navegador ni de móvil real; la matriz mantiene esas pruebas como Pendientes.
- La imagen del MER no se pudo editar sin su fuente original; el documento señala que debe incorporar visualmente la tabla de recuperación y reflejar la ausencia de relación FK directa de PROMOCION con SEMINARIO.
- La portada y los datos de autoría del documento principal se conservaron sin cambios porque no se confirmó el nombre final que debe figurar como responsable actual.

## Despliegue recomendado

1. Guardar copia de archivos y exportación íntegra de la base actual antes de sustituir archivos.
2. Extraer el contenido de `vilamir_v5/` del ZIP corregido dentro de `htdocs` (sin crear un nivel de carpeta adicional, si el sitio actual está en la raíz de `htdocs`).
3. Crear `config/db_config.local.php` en el servidor a partir de la plantilla y cargar los datos exactos del panel. En InfinityFree establecer `VILAMIR_ENV` como `production` y `VILAMIR_BASE_URL` HTTPS real.
4. No importar `sql/mma_systems.sql`, migraciones ni scripts opcionales sobre la base activa.
5. Configurar SMTP solo si se desea recuperación por correo y comprobar recepción real. Configurar cron únicamente si el hosting lo permite y con clave privada.
6. Completar `MATRIZ_DE_PRUEBAS.md` con evidencia antes de considerar el despliegue validado.
