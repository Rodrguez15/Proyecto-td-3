# Anexo — Consultas SQL representativas de VILAMIR

Las siguientes consultas se corresponden con patrones encontrados en el código PHP de la versión revisada. Los parámetros `?` se envían mediante `PDO::prepare()` y `execute()`; no se concatenan datos del usuario dentro del SQL. Son ejemplos documentales: **no fueron ejecutados contra la base activa durante esta revisión**.

## 1. Consultar alumnos y su correo

**Origen:** `api/alumnos.php` (listado). **Tipo:** `SELECT` con `LEFT JOIN`.

```sql
SELECT a.*, COALESCE(u.Email, '') AS Email
FROM ALUMNO AS a
LEFT JOIN USUARIO AS u ON u.ID_Usuario = a.ID_Usuario
ORDER BY a.Apellido ASC, a.Nombre ASC;
```

**Función:** listar las fichas de alumnos y asociar el correo de la cuenta cuando existe. `LEFT JOIN` permite conservar la fila del alumno aunque no haya coincidencia de cuenta en una base heredada.

## 2. Crear la cuenta de acceso de un alumno

**Origen:** `api/admin.php` / `api/alumnos.php`. **Tipo:** `INSERT`.

```sql
INSERT INTO USUARIO (Email, Contraseña, Rol)
VALUES (?, ?, 'Alumno');
```

**Función:** crear la cuenta. El segundo parámetro debe ser el resultado de `password_hash()` calculado en PHP; nunca se debe enviar ni almacenar la contraseña en texto plano. La aplicación obtiene el ID generado con `lastInsertId()`.

## 3. Crear la ficha académica vinculada

**Origen:** `api/admin.php` / `api/alumnos.php`. **Tipo:** `INSERT`.

```sql
INSERT INTO ALUMNO
    (ID_Usuario, Nombre, Apellido, Cedula, Telefono,
     Fecha_nacimiento, Direccion, Cobertura_medica, Peso, Categoria, Codigo_qr)
VALUES (?, ?, ?, NULLIF(?, ''), NULLIF(?, ''), NULLIF(?, ''),
        NULLIF(?, ''), NULLIF(?, ''), ?, NULLIF(?, ''), ?);
```

**Función:** crear la ficha de alumno vinculada al usuario creado en la consulta anterior. Ambas operaciones deben ejecutarse en una transacción para evitar cuentas huérfanas.

## 4. Modificar los datos de una ficha

**Origen:** `api/admin.php` / `api/alumnos.php`. **Tipo:** `UPDATE`.

```sql
UPDATE ALUMNO
SET Nombre = ?, Apellido = ?, Cedula = NULLIF(?, ''),
    Telefono = NULLIF(?, ''), Fecha_nacimiento = NULLIF(?, ''),
    Direccion = NULLIF(?, ''), Cobertura_medica = NULLIF(?, ''),
    Peso = ?, Categoria = NULLIF(?, '')
WHERE ID_Alumno = ?;
```

**Función:** actualizar la ficha sin cambiar el identificador del alumno. El correo se actualiza en `USUARIO` dentro de la misma transacción cuando corresponde.

## 5. Resumir pagos por período

**Origen:** `api/admin.php` (resumen mensual). **Tipo:** `SELECT` agregado.

```sql
SELECT Estado, Fecha_vencimiento, COALESCE(Importe, 0) AS Importe
FROM PAGO
WHERE YEAR(Fecha) = ? AND MONTH(Fecha) = ?;
```

**Función:** obtener los registros del mes seleccionado para calcular cantidades e importes por estado en la capa de aplicación.

## 6. Confirmar un pago sin eliminar el registro

**Origen:** `api/admin.php`. **Tipo:** `UPDATE`.

```sql
UPDATE PAGO
SET Estado = 'Pagado', Metodo_pago = ?, Fecha = ?
WHERE ID_Pago = ?;
```

**Función:** registrar la confirmación de cobro. Para anular un pago, la aplicación también usa `UPDATE` y completa `Anulado_en`, `Anulado_por` y `Motivo_anulacion`; no elimina la fila.

## 7. Registrar o actualizar asistencia

**Origen:** `api/asistencia.php`. **Tipo:** `INSERT ... ON DUPLICATE KEY UPDATE`.

```sql
INSERT INTO ASISTENCIA
    (ID_Alumno, ID_Grupo, ID_Horario, ID_Profesor, Fecha, Estado, Observacion)
VALUES (?, ?, ?, ?, ?, ?, ?)
ON DUPLICATE KEY UPDATE
    ID_Profesor = VALUES(ID_Profesor),
    Estado = VALUES(Estado),
    Observacion = VALUES(Observacion);
```

**Función:** guardar la asistencia del alumno para el grupo, horario y fecha. Si ya existe la combinación protegida por el índice único, actualiza el resultado en lugar de duplicarlo.

## 8. Crear una notificación para un alumno

**Origen:** `api/admin.php` / `config/notificaciones.php`. **Tipo:** `INSERT`.

```sql
INSERT INTO NOTIFICACION (ID_Alumno, Mensaje, Estado, Fecha)
VALUES (?, ?, ?, ?);
```

**Función:** guardar un aviso visible en el sistema para el alumno.

## 9. Eliminar una notificación puntual

**Origen:** `api/admin.php`. **Tipo:** `DELETE` limitado a una notificación.

```sql
DELETE FROM NOTIFICACION
WHERE ID_Notificacion = ?;
```

**Función:** retirar una notificación seleccionada. Esta operación no debe confundirse con el borrado de alumnos ni pagos. El sistema bloquea el borrado físico de alumnos porque las claves foráneas actuales podrían eliminar su historial.

---

## Criterios de uso y seguridad

- Los ejemplos describen SQL localizado en el código; para la carpeta impresa se debe adjuntar evidencia de las consultas efectivamente utilizadas y su prueba manual.
- No ejecutar los ejemplos de `INSERT`, `UPDATE` o `DELETE` manualmente sobre producción.
- No incluir datos personales, tokens ni contraseñas reales en el anexo.
- No existe en el esquema una relación FK directa entre `PROMOCION` y `SEMINARIO`.
- No se documenta un `DELETE FROM ALUMNO` como operación permitida. La eliminación física se bloquea desde la API.
