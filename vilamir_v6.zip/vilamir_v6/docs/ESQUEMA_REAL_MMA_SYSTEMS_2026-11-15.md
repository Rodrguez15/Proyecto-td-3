# Esquema real de MMA Systems / VILAMIR

**Referencia analizada:** archivo `mma_systems.sql` aportado en la conversación, volcado phpMyAdmin del 15/11/2026 23:55:29, MariaDB 10.4.32. Esta documentación describe su estructura; no ejecuta ni importa el archivo.

- Tablas detectadas: **25**.
- Claves foráneas detectadas: **33**.
- SHA-256 del archivo fuente (para identificar exactamente la copia revisada): `fe4fed6cbd28b0066c17dd0f90414e1010697b9a52d70849f78c3eb137aafb92`.
- El volcado contiene datos personales y hashes de contraseñas. Por seguridad, **no se incorpora al ZIP corregido ni debe publicarse**.
- No se ejecutó SQL ni se modificó ninguna tabla, índice, dato o relación.

## Inventario de tablas y columnas

- **ACTIVIDAD_SISTEMA**: `ID_Actividad`, `ID_Usuario`, `Accion`, `Detalle`, `Fecha`.
- **ALUMNO**: `ID_Alumno`, `ID_Usuario`, `Nombre`, `Apellido`, `Cedula`, `Fecha_nacimiento`, `Direccion`, `Telefono`, `Cobertura_medica`, `Peso`, `Categoria`, `Codigo_qr`, `Creado_en`.
- **ASISTENCIA**: `ID_Asistencia`, `ID_Alumno`, `ID_Grupo`, `ID_Horario`, `ID_Profesor`, `Fecha`, `Estado`, `Observacion`, `Creado_en`.
- **CERTIFICADO**: `ID_Certificado`, `ID_Alumno`, `ID_Seminario`, `Titulo`, `Descripcion`, `Codigo`, `Fecha_emision`.
- **DISCIPLINA**: `ID_Disciplina`, `Nombre`, `Descripcion`, `Costo`.
- **GALERIA_EVENTO**: `ID_Galeria`, `ID_Seminario`, `Titulo`, `Imagen`, `Descripcion`, `Fecha`.
- **GRUPO**: `ID_Grupo`, `Nombre`, `ID_Disciplina`, `Cupo_maximo`, `Nivel`, `Descripcion`, `Creado_en`.
- **HORARIO**: `ID_Horario`, `ID_Grupo`, `Dia`, `Hora_inicio`, `Hora_fin`, `Creado_en`.
- **INSCRIPCION_DISCIPLINA**: `ID_Ins_disciplina`, `ID_Alumno`, `ID_Disciplina`, `Fecha_ins`, `Estado`.
- **INSCRIPCION_GRUPO_ALUMNO**: `ID_Inscripcion`, `ID_Alumno`, `ID_Grupo`, `Fecha_inscripcion`, `Estado`.
- **INSCRIPCION_GRUPO_PROFESOR**: `ID_Inscripcion`, `ID_Profesor`, `ID_Grupo`, `Fecha_inscripcion`, `Estado`.
- **INSCRIPCION_SEMINARIO**: `ID_Ins_seminario`, `ID_Alumno`, `ID_Seminario`, `Fecha_ins`, `Estado`.
- **LISTA_ESPERA**: `ID_Espera`, `ID_Alumno`, `ID_Grupo`, `Fecha_solicitud`, `Estado`.
- **LISTA_ESPERA_SEMINARIO**: `ID_Espera`, `ID_Alumno`, `ID_Seminario`, `Fecha_solicitud`, `Estado`.
- **NOTIFICACION**: `ID_Notificacion`, `ID_Alumno`, `Estado`, `Mensaje`, `Fecha`, `Leida`.
- **NOTIFICACION_PROFESOR**: `ID_Notificacion_Profesor`, `ID_Profesor`, `Categoria`, `Mensaje`, `Fecha`, `Leida`.
- **NOTIFICACION_USUARIO**: `ID_Notificacion_Usuario`, `ID_Usuario`, `Titulo`, `Mensaje`, `Fecha`, `Leida`, `Clave`.
- **PAGO**: `ID_Pago`, `ID_Alumno`, `Tipo`, `Fecha`, `Fecha_vencimiento`, `Importe`, `Estado`, `Metodo_pago`, `Numero_comprobante`, `Anulado_en`, `Anulado_por`, `Motivo_anulacion`.
- **PROFESOR**: `ID_Profesor`, `ID_Usuario`, `Nombre`, `Apellido`, `Telefono`, `Cedula`, `Direccion`, `Especialidad`, `Email`, `Creado_en`.
- **PROFESOR_DISCIPLINA**: `ID_Profesor`, `ID_Disciplina`, `Fecha_asignacion`.
- **PROMOCION**: `ID_Promocion`, `Clave_promocion`, `Nombre`, `Descripcion`, `Descuento`, `Fecha_inicio`, `Fecha_fin`, `Activa`, `Imagen`.
- **RECUPERACION_CONTRASENA**: `id_recuperacion`, `id_usuario`, `token_hash`, `creado_en`, `vence_en`, `usado`.
- **RESPONSABLE**: `ID_Responsable`, `ID_Alumno`, `Nombre`, `Apellido`, `Parentesco`, `Cedula`, `Telefono`, `Direccion`.
- **SEMINARIO**: `ID_Seminario`, `Nombre`, `Titulo`, `Descripcion`, `Costo`, `Ponente`, `Fecha`, `Hora`, `Lugar`, `Cupo`, `Creado_en`.
- **USUARIO**: `ID_Usuario`, `Email`, `Contraseña`, `Rol`, `Creado_en`.

## Relaciones referenciales observadas

- `actividad_sistema.ID_Usuario` → `usuario.ID_Usuario` — `ON DELETE SET NULL`.
- `alumno.ID_Usuario` → `usuario.ID_Usuario` — `ON DELETE CASCADE`.
- `asistencia.ID_Alumno` → `alumno.ID_Alumno` — `ON DELETE CASCADE`.
- `asistencia.ID_Grupo` → `grupo.ID_Grupo` — `ON DELETE CASCADE`.
- `asistencia.ID_Horario` → `horario.ID_Horario` — `ON DELETE SET NULL`.
- `asistencia.ID_Profesor` → `profesor.ID_Profesor` — `ON DELETE SET NULL`.
- `certificado.ID_Alumno` → `alumno.ID_Alumno` — `ON DELETE CASCADE`.
- `certificado.ID_Seminario` → `seminario.ID_Seminario` — `ON DELETE SET NULL`.
- `galeria_evento.ID_Seminario` → `seminario.ID_Seminario` — `ON DELETE SET NULL`.
- `grupo.ID_Disciplina` → `disciplina.ID_Disciplina` — `ON DELETE SET NULL`.
- `horario.ID_Grupo` → `grupo.ID_Grupo` — `ON DELETE CASCADE`.
- `inscripcion_disciplina.ID_Alumno` → `alumno.ID_Alumno` — `ON DELETE CASCADE`.
- `inscripcion_disciplina.ID_Disciplina` → `disciplina.ID_Disciplina` — `ON DELETE CASCADE`.
- `inscripcion_grupo_alumno.ID_Alumno` → `alumno.ID_Alumno` — `ON DELETE CASCADE`.
- `inscripcion_grupo_alumno.ID_Grupo` → `grupo.ID_Grupo` — `ON DELETE CASCADE`.
- `inscripcion_grupo_profesor.ID_Grupo` → `grupo.ID_Grupo` — `ON DELETE CASCADE`.
- `inscripcion_grupo_profesor.ID_Profesor` → `profesor.ID_Profesor` — `ON DELETE CASCADE`.
- `inscripcion_seminario.ID_Alumno` → `alumno.ID_Alumno` — `ON DELETE CASCADE`.
- `inscripcion_seminario.ID_Seminario` → `seminario.ID_Seminario` — `ON DELETE CASCADE`.
- `lista_espera.ID_Alumno` → `alumno.ID_Alumno` — `ON DELETE CASCADE`.
- `lista_espera.ID_Grupo` → `grupo.ID_Grupo` — `ON DELETE CASCADE`.
- `lista_espera_seminario.ID_Alumno` → `alumno.ID_Alumno` — `ON DELETE CASCADE`.
- `lista_espera_seminario.ID_Seminario` → `seminario.ID_Seminario` — `ON DELETE CASCADE`.
- `notificacion.ID_Alumno` → `alumno.ID_Alumno` — `ON DELETE CASCADE`.
- `notificacion_profesor.ID_Profesor` → `profesor.ID_Profesor` — `ON DELETE CASCADE`.
- `notificacion_usuario.ID_Usuario` → `usuario.ID_Usuario` — `ON DELETE CASCADE`.
- `pago.ID_Alumno` → `alumno.ID_Alumno` — `ON DELETE CASCADE`.
- `pago.Anulado_por` → `usuario.ID_Usuario` — `ON DELETE SET NULL`.
- `profesor.ID_Usuario` → `usuario.ID_Usuario` — `ON DELETE SET NULL`.
- `profesor_disciplina.ID_Disciplina` → `disciplina.ID_Disciplina` — `ON DELETE CASCADE`.
- `profesor_disciplina.ID_Profesor` → `profesor.ID_Profesor` — `ON DELETE CASCADE`.
- `recuperacion_contrasena.id_usuario` → `usuario.ID_Usuario` — `ON DELETE CASCADE`.
- `responsable.ID_Alumno` → `alumno.ID_Alumno` — `ON DELETE CASCADE`.

## Decisiones importantes para la documentación

1. **Recuperación de contraseña:** el volcado revisado contiene `RECUPERACION_CONTRASENA` (6 columnas). La base de instalación del ZIP (`sql/mma_systems.sql`) no la incluye dentro del archivo principal y la contempla en `sql/migraciones/migracion_recuperacion_contrasena_v21.sql`. La tabla se debe comprobar en cada entorno; no ejecutar la migración sobre la base activa si ya existe.
2. **Promociones:** `PROMOCION` es una tabla independiente. En el esquema revisado no hay clave foránea que vincule una promoción directamente con `SEMINARIO`, `ALUMNO` o `PAGO`. Por tanto, la documentación no debe afirmar que una promoción está asociada relacionalmente a uno o varios seminarios.
3. **Pagos:** `PAGO` se vincula a `ALUMNO` mediante `ID_Alumno`; no contiene una FK directa a `SEMINARIO`, `DISCIPLINA` o `GRUPO`. El concepto se expresa en `Tipo` y los detalles adicionales se guardan como texto según la lógica de la aplicación.
4. **Conservación de historial:** `ALUMNO.ID_Usuario` referencia `USUARIO.ID_Usuario` con `ON DELETE CASCADE`; `PAGO.ID_Alumno` referencia `ALUMNO.ID_Alumno` con `ON DELETE CASCADE`. También hay cascadas para asistencia, certificados, inscripciones, listas de espera, notificaciones y responsables. El código de aplicación debe impedir el borrado físico de una cuenta asociada a un alumno.
5. **Anulación de pagos:** el flujo administrativo utiliza `UPDATE PAGO` para marcar el estado `Anulado` y guardar fecha, usuario y motivo. No debe borrarse físicamente un pago.
6. **Rutinas almacenadas:** el volcado revisado no contiene definiciones `CREATE PROCEDURE`, `CREATE FUNCTION` ni triggers. Se preparó un archivo opcional separado; no fue ejecutado.

## Diferencia entre el volcado recibido y el SQL del ZIP

El SQL incluido en `vilamir_v5.zip` está orientado a una instalación nueva y contiene el esquema base de 24 tablas. La tabla de recuperación se entrega por separado como migración. Además, en `PROMOCION` el SQL del ZIP define `Descuento DECIMAL(5,2)` y no incluye `Clave_promocion`; el volcado de referencia contiene `Descuento DECIMAL(10,2)` y `Clave_promocion VARCHAR(50)` con índice único. El límite de `DECIMAL(5,2)` es 999,99 y no representa importes como 1.500, 1.900, 2.100 o 2.500 observados en el volcado. El archivo externo aportado es un volcado con 25 tablas y datos. Son artefactos distintos: no intercambiarlos ni importarlos sobre una base existente. Esta discrepancia queda documentada, no corregida mediante ALTER ni migración por la restricción expresa de conservar el esquema activo.

## Discrepancia de esquema que requiere decisión antes de una instalación nueva

La definición de `PROMOCION` del SQL de instalación del ZIP no coincide con el volcado real en la precisión de `Descuento` ni en la columna `Clave_promocion`. La aplicación muestra importes de planes superiores a 999,99; por tanto, una base recién creada con la definición del ZIP podría no admitir esos importes. No se cambió el SQL de instalación ni se generó una migración porque no se autorizó modificar el esquema. La base activa debe permanecer intacta; si se necesita una instalación nueva, esta discrepancia debe resolverse y aprobarse expresamente en una etapa separada antes de importar nada.

## Observación sobre los datos del volcado

En el archivo revisado se observa(n) 1 registro(s) en `PAGO` y 20 en `ACTIVIDAD_SISTEMA`. Varias entradas de actividad mencionan identificadores de pagos distintos del único registro de `PAGO` presente. Si el archivo se considera un respaldo completo, debe verificarse la integridad y el alcance de la exportación en phpMyAdmin o en la base activa. **No se reconstruyeron pagos ni se inventaron datos históricos.**

## Recomendación de conservación

- Mantener una copia privada e íntegra del volcado original.
- Para la entrega académica, generar una copia de muestra anonimizada y revisada, sin correos, cédulas, teléfonos, direcciones, hashes ni tokens reales.
- Antes de cualquier actualización de base, respaldar, comparar el esquema real y probar en una copia aislada. Este trabajo no autoriza migraciones sobre InfinityFree.
