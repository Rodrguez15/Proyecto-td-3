# Guía segura para mantener la base de datos V21

## Antes de cualquier cambio

1. Detener temporalmente los cambios de datos mientras se hace la copia.
2. En phpMyAdmin, seleccionar la base correcta y exportarla en formato SQL.
3. Guardar la copia fuera de la carpeta pública del sitio y comprobar que el archivo tenga tamaño razonable.
4. Anotar el nombre de la base y la fecha del respaldo.
5. Probar la actualización primero en una copia de la base, nunca directamente en la única copia disponible.

## Instalación nueva frente a actualización

- `sql/mma_systems.sql` es para una base nueva y vacía.
- Una base existente debe actualizarse solo con la migración que corresponda a su estructura real.
- No ejecutar todos los archivos SQL en bloque ni asumir que el número de versión del proyecto coincide con el esquema de la base.
- No ejecutar `sql/legacy_no_ejecutar/NO_EJECUTAR_migracion_v17_limpieza.sql` sobre una base V18/V19/V20/V21. Es un archivo histórico y potencialmente destructivo.
- `sql/datos_demo/datos_demo_v20.sql` contiene datos ficticios; usar únicamente en entornos de prueba.

## Inventario orientativo de migraciones

| Archivo | Propósito indicado | Condición previa |
|---|---|---|
| `migraciones/migracion_pagos_v18.sql` | Campos de comprobantes/anulaciones | Ejecutar solo si faltan los campos requeridos |
| `migraciones/migracion_asistencia_v19.sql` | Cambios de asistencia de V19 | Revisar tablas y columnas antes de ejecutar |
| `migraciones/migracion_cupos_v20.sql` | Cambios de cupos | Confirmar que el cambio no exista ya |
| `migraciones/migracion_asistencia_v21.sql` | Normalización de índices de asistencia | Requiere `ID_Horario` e `ID_Profesor` en `ASISTENCIA`; verificar antes |

Esta tabla orienta la revisión, no certifica que una migración sea necesaria en una instalación particular. Inspeccionar el contenido SQL y el esquema real antes de ejecutar.

## Después de aplicar una migración

1. Revisar el resultado de phpMyAdmin y cualquier error.
2. Confirmar tablas, columnas, índices y claves foráneas afectados.
3. Probar inicio de sesión, alta/edición relacionada y consultas de los módulos afectados.
4. Mantener el respaldo original hasta terminar las pruebas funcionales.
5. Documentar archivo aplicado, fecha, base de pruebas y resultado.

## Reglas de seguridad

- Nunca compartir archivos con contraseñas reales.
- No guardar exportaciones de datos personales en `public_html` ni en directorios públicos.
- No borrar registros históricos de pagos, comprobantes o inscripciones sin un procedimiento aprobado.
- No ejecutar SQL destructivo sin revisión explícita, respaldo verificado y plan de recuperación.
