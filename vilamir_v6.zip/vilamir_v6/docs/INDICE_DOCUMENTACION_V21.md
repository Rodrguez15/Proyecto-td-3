# Academia VILAMIR V21 — índice de documentación

La documentación de mantenimiento se organiza en `docs/`, y todos los informes técnicos y de etapas se centralizan en `informes/`. Los README de instalación y uso se conservan en la raíz.

## Documentos de mantenimiento

- `informes/INFORME_ETAPA_ASISTENCIA_HORARIOS_V21.md`: mejoras de validación de asistencia y prevención de superposición de horarios.

- `MAPA_PROYECTO_V21.md`: directorios y responsabilidades principales.
- `GUIA_SEGURA_BASE_DATOS_V21.md`: respaldo, diagnóstico y aplicación prudente de migraciones.
- `CONFIGURACION_SEGURA_V21.md`: configuración privada XAMPP/InfinityFree, correo, cron y conservación del historial.
- `ESQUEMA_REAL_MMA_SYSTEMS_2026-11-15.md`: inventario del esquema de referencia (25 tablas, 33 FK) y diferencias con el SQL de instalación del ZIP.
- `ANEXO_CONSULTAS_SQL.md`: consultas representativas localizadas en la aplicación y explicadas.
- `MATRIZ_DE_PRUEBAS.md`: pruebas manuales pendientes con evidencia requerida.
- `CHECKLIST_ENTREGABLES.md`: lista de entregables académicos según la guía.
- `CRON_RECUPERACION_CORREO.md`: configuración y límites de notificaciones programadas y recuperación.
- `INFORME_CORRECCIONES_2026-11-16.md`: resumen de cambios, validaciones y riesgos pendientes.
- `MMA_Systems_Documento_Principal_Corregido_2026-11-16.docx`: copia corregida del documento académico principal; conserva imágenes y tablas originales.
- `informes/INFORME_ETAPA_10_ORGANIZACION_V21.md`: alcance y verificaciones de esta etapa.

## Documentación existente que se conserva

- `README.md` y `README_FINAL.md`: introducción e instalación.
- `README_V21.md`: notas de la versión.
- `informes/INFORME_AUDITORIA_COMPLETA_V21.md`: resultados de esta auditoría, correcciones y riesgos pendientes.
- `informes/INFORME_REVISION_GENERAL_V21.md`: revisión histórica y límites de pruebas.
- `informes/INFORME_ETAPA_*_V21.md`: informes de etapas específicas.
- `sql/README.md`: índice de scripts SQL.
- `sql/migraciones/README_GESTION_ALUMNOS_V21.md`: notas de la revisión de alumnos.

## Regla de mantenimiento

No mover ni renombrar páginas PHP, endpoints, archivos JS/CSS ni scripts SQL sin revisar antes todas sus referencias (`require`, `include`, rutas de `fetch`, enlaces, formularios, tareas programadas e instrucciones de instalación). En esta etapa no se cambiaron las rutas públicas de la aplicación.
