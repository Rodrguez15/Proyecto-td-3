# Checklist de entregables del Proyecto Integrador

Referencia: `Proyecto Integrador - C.T.T. Redes y Software 2026.docx`. La fecha de entrega final indicada en la guía es **25 de noviembre de 2026**. Este checklist organiza lo que debe reunirse; no declara completado aquello para lo que no se aportó evidencia.

## Documentación y gestión del proyecto

- [ ] Resumen, fundamentación, objetivos y conclusión final.
- [ ] Bibliografía con referencias individualizadas, URL y fecha real de consulta.
- [ ] Carpeta organizada según la estructura indicada en el curso.
- [ ] Diagrama de Gantt actualizado, máximo dos carillas.
- [ ] Evidencia de Google Drive, Trello, GitHub y Slack compartidos con los docentes según corresponda.
- [ ] Repositorio público y evidencia real de contribuciones. No atribuir commits ni tareas no verificadas.
- [ ] Evidencia de validación del cliente / entrevista, sin inventar fecha ni respuestas.

## Bases de Datos II

- [ ] Esquema de la base actualizado y coherente con la base realmente utilizada.
- [ ] MER con al menos siete entidades y relaciones legibles.
- [ ] Modelo relacional con PK y FK identificadas.
- [ ] Anexo impreso con al menos siete consultas diferentes, explicación y evidencia de uso en la aplicación.
- [ ] Usuarios MySQL diferenciados y privilegios mínimos; adjuntar `SHOW GRANTS` o capturas sanitizadas.
- [ ] Copia de base de datos con datos ficticios/anónimos para el disco de entrega; nunca usar un volcado con datos personales reales.
- [ ] Funciones/procedimientos que mejoren la base, si se implementan y el servidor concede permisos. Los scripts opcionales de este paquete no están ejecutados.
- [ ] Verificar en la base activa la discrepancia observada entre filas de `PAGO` y referencias de `ACTIVIDAD_SISTEMA` en el volcado aportado.
- [ ] Resolver, antes de una instalación nueva, la diferencia entre `PROMOCION.Descuento DECIMAL(5,2)` del SQL del ZIP y `DECIMAL(10,2)` + `Clave_promocion` del volcado real. No alterar la base activa sin autorización.

## Programación II y documentación del software

- [ ] Aplicación funcional y código fuente organizado.
- [ ] Consultas y reportes gráficos probados.
- [ ] Análisis de requerimientos actualizado.
- [ ] DFD actualizado.
- [ ] Diagrama de casos de uso y especificaciones textuales.
- [ ] Diagrama de clases UML actualizado y generado con herramienta CASE, sin marcas de agua.
- [ ] Matriz de pruebas completada con evidencias reales.
- [ ] Manual de usuario final.

## Inglés

- [ ] Manual de usuario bilingüe español–inglés.
- [ ] Abstract en inglés con objetivo, problemática, tecnologías y funcionalidades implementadas.

## Conectividad y Seguridad de Redes I y II

- [ ] Topología final de red.
- [ ] Normas y estándares aplicados.
- [ ] Reportes de rendimiento y seguridad.
- [ ] Evidencia de VLAN, direccionamiento, enrutamiento/inter-VLAN, NAT y controles de seguridad, según el diseño final.
- [ ] Archivo de simulación de red (por ejemplo, Packet Tracer) y capturas de pruebas.

## Redes Microsoft II

- [ ] Infraestructura de dominio completa y funcional.
- [ ] Servicios de red integrados.
- [ ] Usuarios, grupos, OU, GPO y aplicación de políticas con evidencia.
- [ ] Auditoría/monitoreo y cuotas/FSRM si corresponden al alcance.
- [ ] Entorno virtualizado estable con evidencia.

## Redes POSIX II

- [ ] Diseño de infraestructura Linux documentado.
- [ ] Firewall y servicios documentados y probados.
- [ ] Política de respaldos automatizados con evidencia de ejecución.
- [ ] Restauración de base y archivos en entorno aislado.
- [ ] Política de recuperación ante incidentes y simulacro documentado.
- [ ] RPO/RTO presentados como objetivos hasta que se midan mediante pruebas.

## Presentación final

- [ ] Presentación tecnológica que cubra las asignaturas implicadas.
- [ ] Duración prevista entre 30 y 45 minutos, conforme a la guía.
- [ ] Demostración funcional en un entorno preparado y con datos ficticios.
- [ ] Copia impresa de la carpeta y medio digital con código y datos de muestra anonimizados.
