# Configuración segura de Academia VILAMIR — revisión 16/11/2026

## Regla general

El ZIP no contiene credenciales reales ni valores predeterminados de usuario/contraseña MySQL. `config/db_config.php` solo carga, si existe, `config/db_config.local.php`. Ese archivo privado está excluido por `.gitignore` y no se incluye en el ZIP. La carpeta `config/` permanece bloqueada para acceso HTTP directo mediante `.htaccess`.

`.env.example` es una plantilla de referencia: **PHP no carga archivos `.env` automáticamente** en este proyecto. Para utilizar variables de entorno, deben configurarse en Apache/hosting; si eso no está disponible, usar el archivo privado local.

## XAMPP local

1. Copiar `config/db_config.local.php.example` como `config/db_config.local.php`.
2. Completar host, base, usuario y contraseña según la instalación local de MySQL/MariaDB. XAMPP puede usar `root` sin contraseña en una instalación nueva, pero no se debe asumir: verificarlo en phpMyAdmin.
3. Dejar `VILAMIR_ENV` en `development` y `VILAMIR_BASE_URL` vacía para que la aplicación infiera la ruta solo cuando se accede desde `localhost`, `127.0.0.1` o `[::1]`.
4. No importar `sql/mma_systems.sql` si la base ya contiene datos.

## InfinityFree / producción

1. Crear `config/db_config.local.php` en la instalación del hosting, a partir de la plantilla, y copiar los cuatro valores exactos que muestra el panel de MySQL: host, nombre de base, usuario y contraseña.
2. Cambiar `VILAMIR_ENV` a `production` y completar `VILAMIR_BASE_URL` con la URL HTTPS canónica real, incluyendo subdirectorio si existe.
3. No subir el archivo privado al repositorio ni incorporarlo al ZIP de distribución. No compartir capturas con credenciales visibles.
4. Mantener la carpeta `config/` protegida y verificar desde el navegador que una petición directa sea denegada.
5. La aplicación no importa, crea, altera ni migra tablas automáticamente. No ejecutar el SQL de instalación ni las migraciones sobre la base activa como parte del despliegue.

## Correo y recuperación de contraseña

El correo requiere SMTP configurado con `config/smtp_config.php` (copiado desde `config/smtp_config.php.example`) o variables de entorno. Se necesita también `VILAMIR_BASE_URL`. Si falta SMTP o la URL base, no se genera un token que no pueda entregarse. La pantalla usa un mensaje genérico; la entrega solo se considera verificada después de recibir un correo real.

## Tarea de notificaciones

`cron_notificaciones.php` genera notificaciones internas en la base de datos; no envía correos. Preferir PHP CLI. El acceso web exige `CRON_KEY`/`VILAMIR_CRON_KEY` y POST con cabecera `X-Cron-Key` o campo `key`; GET está deshabilitado. No asumir que InfinityFree permite tareas programadas o cron: verificar las funciones del plan.

## Seguridad de datos e historial

No eliminar físicamente alumnos ni cuentas `USUARIO` vinculadas a alumnos. El esquema actual tiene cascadas desde `USUARIO` hacia `ALUMNO` y desde `ALUMNO` hacia `PAGO`, asistencia, certificados, inscripciones y otras relaciones. La API bloquea esas eliminaciones. La baja administrativa sin borrado físico no está implementada como estado independiente porque no se modifica el esquema.

## Validación pendiente

La sintaxis PHP/JavaScript y la integridad del ZIP se comprueban estáticamente. Aún deben probarse conexión, roles, formularios, CSRF, recuperación SMTP, cron, permisos, restauración de respaldos y tablas móviles en XAMPP, InfinityFree y dispositivos reales. Ver `MATRIZ_DE_PRUEBAS.md`.
