# Mapa del proyecto Academia VILAMIR V21

## Estructura principal

| Ruta | Responsabilidad | Precaución |
|---|---|---|
| `api/` | Endpoints usados por la interfaz | Revisar sesión, rol, validación y respuesta JSON antes de modificar |
| `config/` | Conexión, sesión, autenticación, seguridad y utilidades compartidas | No publicar credenciales; mantener validaciones comunes |
| `css/style.css` | Estilos centrales de la aplicación | Mantener secciones numeradas y revisar escritorio/móvil |
| `js/` | Interacción del navegador | Comprobar sintaxis y todas las pantallas que importan cada script |
| `images/` | Recursos gráficos | Verificar rutas y licencias antes de sustituir recursos |
| `sql/mma_systems.sql` | Esquema de referencia para una instalación nueva | Nunca importar sobre una base que ya contiene datos |
| `sql/migraciones/` | Cambios incrementales de esquema | Aplicar solo después de inspeccionar la versión real de la base |
| `sql/datos_demo/` | Datos ficticios para pruebas | Solo en una base de pruebas, nunca en producción |
| `sql/legacy_no_ejecutar/` | Script histórico potencialmente destructivo | No ejecutar como parte de una actualización V21 |
| `uploads/` | Archivos cargados por la aplicación | Revisar permisos y evitar ejecutar scripts subidos |
| `docs/` | Guías de mantenimiento y organización | Actualizar al cambiar estructura o procedimientos |

## Páginas que tienen nombres parecidos

- `profesor.php`: espacio de trabajo del profesor.
- `profesores.php`: administración de profesores.

Son funciones distintas y no deben fusionarse por similitud del nombre.

## Flujo académico

**Disciplina → Grupo → Horario → Inscripción → Asistencia**

Pagos, comprobantes, seminarios/eventos, promociones y notificaciones se relacionan con sus entidades respectivas. Antes de cambiar una relación, verificar las claves foráneas, los nombres reales de las columnas y los datos históricos.

## Convenciones recomendadas

1. No mezclar credenciales con archivos públicos.
2. Usar consultas preparadas para datos aportados por usuarios.
3. Comprobar permisos en el servidor; ocultar un botón no es control de acceso.
4. Validar datos en servidor incluso cuando exista validación en JavaScript.
5. Conservar historiales financieros y de inscripciones; preferir estados de cancelación/anulación cuando el diseño lo permita.
6. No introducir módulos de exámenes ni niveles: no forman parte del funcionamiento de esta academia.
