# Notificaciones programadas y recuperación de contraseña

## Notificaciones automáticas

`cron_notificaciones.php` revisa alumnos y genera avisos internos en las tablas de notificación para pagos pendientes próximos/vencidos y seminarios próximos. No es un envío de correo: los avisos se almacenan en la base de datos y aparecen dentro del sistema.

- Preferir ejecución desde PHP CLI, por ejemplo desde el Programador de tareas de Windows en XAMPP.
- La ejecución web está deshabilitada salvo que se defina `CRON_KEY` en el entorno o `VILAMIR_CRON_KEY` en el archivo privado y se envíe por POST (`X-Cron-Key` o campo `key`).
- GET no ejecuta la tarea. No colocar secretos en la URL, historial del navegador, logs ni enlaces públicos.
- No se afirma que InfinityFree admita cron o tareas programadas. Verificar las funciones disponibles en el plan. Si solo permite llamadas GET, no habilitar este endpoint web.
- Registrar salida, fecha, número de alumnos revisados y errores de forma sanitizada.

## Recuperación de contraseña

El flujo usa `RECUPERACION_CONTRASENA`, almacena el hash SHA-256 del token, limita su vigencia a 60 minutos y marca el token como usado al cambiar la contraseña. El token no se guarda en claro en la tabla.

Para que el flujo pueda enviar un enlace real se requieren ambas configuraciones:

1. SMTP válido: `SMTP_HOST`, `SMTP_PORT` (465 o 587), `SMTP_USER`, `SMTP_PASS` y un remitente válido (`VILAMIR_MAIL_FROM` o `VILAMIR_SMTP_FROM`).
2. `VILAMIR_BASE_URL` con la URL canónica HTTP(S) de la aplicación, incluyendo el subdirectorio si lo hay.

En producción no se construye el enlace desde `HTTP_HOST`. Si falta la URL base o SMTP, el sistema no genera un token que no pueda entregarse. La pantalla mantiene un mensaje genérico para no revelar si una cuenta existe. El resultado de la función SMTP no sustituye una prueba de recepción real.

## Prueba manual requerida

- Configurar SMTP en un entorno de prueba, solicitar recuperación y comprobar recepción real.
- Abrir el enlace, establecer una contraseña, intentar reutilizarlo y comprobar expiración.
- Repetir sin SMTP configurado y comprobar que no se crea un token sin posibilidad de entrega.
- No usar direcciones ni contraseñas reales en capturas académicas.
