# Matriz de pruebas — VILAMIR V5 corregido

**Estado inicial de esta matriz:** todas las pruebas funcionales que requieren navegador, MySQL/MariaDB, correo, hosting o dispositivos quedan **Pendientes** hasta ejecutarse y adjuntar evidencia. La revisión estática de sintaxis se registra por separado en `INFORME_CORRECCIONES_2026-11-16.md`.

| ID | Área | Prueba / pasos | Resultado esperado | Estado | Evidencia / fecha |
|---|---|---|---|---|---|
| CFG-01 | XAMPP | Copiar `config/db_config.local.php.example` como `config/db_config.local.php`; completar credenciales de una BD de pruebas; abrir inicio. | Conecta a la BD local sin credenciales predeterminadas en el código. | Pendiente | |
| CFG-02 | InfinityFree | Crear `config/db_config.local.php` privado con los valores del panel; mantener `config/` bloqueada por `.htaccess`; probar conexión. | La app conecta sin publicar credenciales ni modificar tablas. | Pendiente | |
| CFG-03 | Seguridad | Intentar abrir por URL `config/db_config.local.php` y `config/db_config.php`. | El servidor deniega el acceso directo al directorio de configuración. | Pendiente | |
| AUTH-01 | Login | Ingresar credenciales válidas desde `login.html`. | Autentica, regenera sesión y redirige según el flujo actual. | Pendiente | |
| AUTH-02 | Login | Enviar POST sin token CSRF o con token inválido. | Respuesta 403; no crea sesión autenticada. | Pendiente | |
| AUTH-03 | Registro | Crear una cuenta nueva desde `registrar.html`. | Obtiene token de `csrf_token.php`, crea usuario/alumno en transacción y permite iniciar sesión. | Pendiente | |
| AUTH-04 | Registro | Enviar POST sin token CSRF y probar correo duplicado. | Rechaza la petición sin token; el correo duplicado no genera otra cuenta. | Pendiente | |
| AUTH-05 | Logout | Usar el enlace Cerrar sesión. Probar también GET directo a `logout.php`. | El enlace envía POST con token; GET responde 405; la sesión queda invalidada. | Pendiente | |
| CSRF-01 | Formularios | Probar formularios autenticados de administración, portal, pagos, asistencia y seminarios con token válido, ausente e inválido. | Los POST/PUT/PATCH/DELETE sin token válido reciben 403; las operaciones válidas conservan su comportamiento. | Pendiente | |
| CSRF-02 | Público | Probar solicitud y restablecimiento de contraseña, check-in y registro con token válido/ausente. | Las operaciones públicas con estado también exigen token CSRF. | Pendiente | |
| ALU-01 | Conservación | Intentar eliminar un alumno por `api/alumnos.php` con rol administrador. | HTTP 409; no se ejecuta DELETE de ALUMNO. | Pendiente | |
| ALU-02 | Conservación | Intentar borrar desde `api/admin.php?entity=usuarios` una cuenta vinculada a ALUMNO. | HTTP 409; se conserva alumno, pagos y relaciones. | Pendiente | |
| ALU-03 | Conservación | Verificar la anulación de un pago desde el panel. | Se actualiza estado y datos de anulación; la fila PAGO permanece. | Pendiente | |
| DB-01 | Base de datos | Ejecutar consultas del anexo en una copia de prueba, con datos ficticios. | Consultas compatibles con el esquema real y resultados revisados. | Pendiente | |
| DB-02 | Integridad | Consultar recuentos de PAGO y ACTIVIDAD_SISTEMA en la base activa y comparar con un respaldo íntegro. | Se aclara si el volcado aportado era completo; no se inventan pagos históricos. | Pendiente | |
| MAIL-01 | SMTP | Configurar SMTP y `VILAMIR_BASE_URL` reales en entorno de prueba; solicitar recuperación. | Se recibe correo real con enlace válido por 60 minutos; token de un solo uso. | Pendiente | |
| MAIL-02 | SMTP | Repetir sin SMTP o sin URL base configurada. | Mensaje genérico; no se crea token imposible de entregar; log sin secretos. | Pendiente | |
| MAIL-03 | SMTP | Probar token vencido, inválido y reutilizado. | Se rechaza; un token usado no vuelve a cambiar la contraseña. | Pendiente | |
| CRON-01 | Cron | Ejecutar `php cron_notificaciones.php` en una copia de prueba con PHP CLI y BD configurada. | Revisa avisos internos y finaliza sin exponer credenciales. | Pendiente | |
| CRON-02 | Cron web | Probar GET, POST sin clave, POST con clave incorrecta y POST con clave correcta. | GET 405; claves ausentes/incorrectas 403; POST válido ejecuta solo si se configuró CRON_KEY. | Pendiente | |
| MOB-01 | Móvil | Probar tablas de alumnos, pagos, reportes, grupos y asistencia a 320, 360 y 390 px. | Cada tabla ancha puede desplazarse horizontalmente sin desplazar toda la página. | Pendiente | |
| MOB-02 | Móvil | Probar menú, modales, formularios, calendario y botones en Android y iOS reales. | Controles accesibles, sin recortes ni solapamientos. | Pendiente | |
| DEP-01 | InfinityFree | Subir copia de archivos sin archivos locales privados; completar config privada; probar inicio y módulos de lectura. | No hay error de conexión ni exposición de archivos sensibles. | Pendiente | |
| DEP-02 | InfinityFree | Probar formularios POST y límites reales del hosting (PHP, SMTP, tareas programadas, permisos). | Se documentan capacidades reales del plan; no se presume cron ni SMTP habilitado. | Pendiente | |
| DR-01 | Recuperación | Restaurar un respaldo en un entorno aislado y probar login, pagos, alumnos y archivos. | Se documentan tiempos reales y resultado; no se afirma RPO/RTO sin simulacro. | Pendiente | |

**Regla de evidencia:** registrar fecha, entorno, versión PHP/MariaDB, pasos realizados, resultado, captura o log sanitizado y responsable. No marcar una prueba como aprobada por haber revisado el código.
