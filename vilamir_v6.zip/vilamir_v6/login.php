<?php

/*
 * ARCHIVO: login.php
 * PROPÓSITO: API de autenticación y verificación de credenciales para Academia VILAMIR.
 */
require_once __DIR__ . '/config/sesion.php';
require_once __DIR__ . '/config/conexion.php';
require_once __DIR__ . '/config/alumnos_estado.php';

// Si alguien intenta ingresar directamente por GET a login.php, se redirige a login.html
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: login.html');
    exit;
}

// El login también valida token CSRF; el token inicial se obtiene desde csrf_token.php.
vilamir_verificar_csrf();
header('Content-Type: application/json; charset=utf-8');

/**
 * Devuelve el nombre para mostrar según el rol del usuario autenticado.
 */
function obtenerNombreUsuario(PDO $conexion, int $idUsuario, string $rol): string {
    if (strcasecmp($rol, 'Alumno') === 0 || strcasecmp($rol, 'Profesor') === 0) {
        $tabla = strcasecmp($rol, 'Alumno') === 0 ? 'ALUMNO' : 'PROFESOR';
        $stmt = $conexion->prepare("SELECT Nombre, Apellido FROM {$tabla} WHERE ID_Usuario = :id_usuario LIMIT 1");
        $stmt->bindParam(':id_usuario', $idUsuario, PDO::PARAM_INT);
        $stmt->execute();
        $fila = $stmt->fetch();
        if ($fila) {
            return $fila['Nombre'] . ' ' . $fila['Apellido'];
        }
    }
    return strcasecmp($rol, 'Administrador') === 0 ? 'Administrador' : 'Usuario';
}

$response = ['status' => 'error', 'message' => ''];

// --- Rate limiting simple contra ataques de fuerza bruta ---
$maxIntentos = 5;
$tiempoBloqueo = 30;
$maxIntentosLargo = 10;
$tiempoBloqueoLargo = 60;

$intentos = (int)($_SESSION['intentos_login'] ?? 0);
$ultimo = (int)($_SESSION['ultimo_intento'] ?? 0);
$intentosTotales = (int)($_SESSION['intentos_login_total'] ?? 0);

if ($intentosTotales >= $maxIntentosLargo) {
    $espera = $tiempoBloqueoLargo - (time() - $ultimo);
    if ($espera > 0) {
        $minutos = (int)ceil($espera / 60);
        $response['message'] = "Demasiados intentos fallidos. Espere {$minutos} minuto(s) antes de volver a intentar.";
        echo json_encode($response);
        exit;
    }
    $_SESSION['intentos_login'] = 0;
    $_SESSION['intentos_login_total'] = 0;
} elseif ($intentos >= $maxIntentos) {
    $espera = $tiempoBloqueo - (time() - $ultimo);
    if ($espera > 0) {
        $response['message'] = "Demasiados intentos fallidos. Espere {$espera} segundos.";
        echo json_encode($response);
        exit;
    }
    $_SESSION['intentos_login'] = 0;
}

$email = strtolower(trim((string)($_POST['email'] ?? '')));
$password = (string)($_POST['password'] ?? '');

if (empty($email) || empty($password)) {
    $response['message'] = "Complete todos los campos.";
    echo json_encode($response);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $response['message'] = "Correo electrónico no válido.";
    echo json_encode($response);
    exit;
}

try {
    $query = "SELECT ID_Usuario, Email, Contraseña, Rol FROM USUARIO WHERE LOWER(Email) = LOWER(:email) LIMIT 1";
    $stmt = $conexion->prepare($query);
    $stmt->execute([':email' => $email]);
    $usuario = $stmt->fetch();

    $mensajeError = "Credenciales incorrectas.";

    if ($usuario && strcasecmp((string)$usuario['Rol'], 'Alumno') === 0) {
        $estadoAlumno = vilamir_estado_baja_usuario($conexion, (int)$usuario['ID_Usuario']);
        if ($estadoAlumno === 'BAJA_DEFINITIVA') {
            $response['message'] = 'La cuenta tiene baja definitiva. Comunicate con la administración.';
            echo json_encode($response, JSON_UNESCAPED_UNICODE);
            exit;
        }
    }

    if (!$usuario || !password_verify($password, (string)$usuario['Contraseña'])) {
        $_SESSION['intentos_login'] = ($_SESSION['intentos_login'] ?? 0) + 1;
        $_SESSION['intentos_login_total'] = ($_SESSION['intentos_login_total'] ?? 0) + 1;
        $_SESSION['ultimo_intento'] = time();

        $response['message'] = $mensajeError;
        echo json_encode($response);
        exit;
    }

    // Credenciales correctas: regenerar sesión contra session fixation
    session_regenerate_id(true);
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

    unset($_SESSION['intentos_login'], $_SESSION['ultimo_intento'], $_SESSION['intentos_login_total']);

    $_SESSION['usuario_id'] = $usuario['ID_Usuario'];
    $_SESSION['usuario_email'] = $usuario['Email'];

    $rolUsuario = normalizarRol((string)$usuario['Rol']);
    $_SESSION['usuario_rol'] = $rolUsuario;
    $_SESSION['usuario_nombre'] = obtenerNombreUsuario($conexion, (int)$usuario['ID_Usuario'], $rolUsuario);

    $response['status'] = 'success';
    $response['message'] = "Inicio de sesión correcto.";
    $response['rol'] = $_SESSION['usuario_rol'];
    $response['redirect'] = 'index.php';
} catch (PDOException $e) {
    error_log("Error en login.php [" . $e->getCode() . "]: " . $e->getMessage());
    $response['message'] = "Hubo un problema en el servidor. Intente más tarde.";
}

echo json_encode($response);
exit;