<?php

/*
 * ARCHIVO: publica.php
 * PROPÓSITO: Página o módulo PHP de publica dentro del sistema Academia VILAMIR.
 */
require_once 'config/conexion.php';

// Necesario para vilamir_enviar_token_csrf() y la seguridad HTTP común.
require_once 'config/sesion.php';

// La web pública no exige sesión, pero la seguridad HTTP se aplica igual.
vilamir_aplicar_seguridad_http();

$disc = $conexion->query(
"SELECT ID_Disciplina,Nombre,Descripcion,Costo FROM DISCIPLINA ORDER BY Nombre"
)->fetchAll();

$prof = $conexion->query(
"SELECT ID_Profesor,Nombre,Apellido,Especialidad FROM PROFESOR ORDER BY Apellido,Nombre"
)->fetchAll();

$event = $conexion->query(
"SELECT ID_Seminario,COALESCE(NULLIF(Nombre,''),Titulo) Nombre,Descripcion,Fecha,Costo,Lugar,Hora,Cupo,Ponente
     FROM SEMINARIO
     WHERE Fecha>=CURDATE()
     ORDER BY Fecha,Hora
     LIMIT 6"
)->fetchAll();

$promo = $conexion->query(
"SELECT * FROM PROMOCION
     WHERE Activa=1
       AND (Fecha_inicio IS NULL OR Fecha_inicio<=CURDATE())
       AND (Fecha_fin IS NULL OR Fecha_fin>=CURDATE())
     ORDER BY Nombre
     LIMIT 6"
)->fetchAll();

try {

    $galeria = $conexion->query(
    "SELECT g.Titulo,g.Imagen,g.Descripcion,COALESCE(s.Nombre,s.Titulo) Evento
         FROM GALERIA_EVENTO g
         LEFT JOIN SEMINARIO s ON s.ID_Seminario=g.ID_Seminario
         ORDER BY g.Fecha DESC
         LIMIT 6"
    )->fetchAll();
    }
catch (Throwable $e) {

    $galeria = [];
    }

$stats = [
'disciplinas' => count($disc),
'profesores' => count($prof),
'eventos' => count($event),
];

function pubDate($fecha) {

    return $fecha ? date('d/m/Y', strtotime($fecha)) : 'Fecha a confirmar';
    }

function moneyPub($value) {

    return '$' . number_format((float)$value, 2, ',', '.');
    }

?>
<!doctype html>
<html lang="es">
<head>
<?php vilamir_enviar_token_csrf(); ?>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="description" content="Conocé Academia VILAMIR: MMA, Kickboxing, Muay Thai, Jiu-jitsu brasileño, profesores, horarios y seminarios. Encontrá tu disciplina y empezá a entrenar.">
<meta name="theme-color" content="#0b0b0d">
<meta property="og:type" content="website">
<meta property="og:title" content="Academia VILAMIR | Encontrá tu disciplina">
<meta property="og:description" content="Entrená con objetivos claros. Conocé nuestras disciplinas, profesores y próximos eventos.">
<title>Academia VILAMIR | Entrená. Aprendé. Superate.</title>
<link rel="stylesheet" href="css/style.css?v=20261026-etapa2-seminarios-galeria-v1">
<script src="js/csrf.js"></script>
</head>
<body class="public-page public-v16">
<header class="navbar public-navbar">
<a class="logo public-logo" href="publica.php" aria-label="Academia VILAMIR - inicio">
<img src="images/logo-vilamir.jpg" alt="Escuela Vilamir" class="logo-img">
</a>
<nav>
<a href="tutor.php">Portal Padres</a>
<a href="#disciplinas">Disciplinas</a>
<a href="#equipo">Equipo</a>
<a href="#eventos">Eventos</a>
<a href="#promociones">Promociones</a>
<a href="#preguntas">Preguntas</a>
<a href="#contacto">Contacto</a>
<a class="public-nav-cta" href="login.html">Ingresar</a>
</nav>
</header>
<main>
<section class="public-hero public-hero-v16">
<div class="public-hero-content">
<span class="eyebrow">ESCUELA DE COMBATE · VILAMIR</span>
<h1>Tu próximo desafío empieza acá.</h1>
<p>Descubrí disciplinas de combate, conocé al equipo y encontrá una actividad que se adapte a tus objetivos. El primer paso es elegir empezar.</p>
<div class="public-hero-actions">
<a class="btn" href="registrar.html">Quiero empezar</a>
<a class="btn public-btn-secondary" href="#disciplinas">Explorar disciplinas</a>
<a class="public-text-link" href="login.html">Ya tengo cuenta →</a>
</div>
<div class="public-hero-stats" aria-label="Resumen de la academia">
<div>
<strong><?= $stats['disciplinas'] ?>
</strong>
<span>disciplinas</span>
</div>
<div>
<strong><?= $stats['profesores'] ?>
</strong>
<span>profesores</span>
</div>
<div>
<strong><?= $stats['eventos'] ?>
</strong>
<span>próximos eventos</span>
</div>
</div>
</div>
</section>
<section class="public-section public-intro">
<div class="public-section-heading">
<span class="eyebrow">VIVÍ VILAMIR</span>
<h2>Entrenamiento, comunidad y progreso</h2>
<p>Un espacio para aprender, mejorar tu técnica y formar parte de una comunidad de entrenamiento.</p>
</div>
<div class="public-feature-grid">
<article class="public-feature">
<span>🥋</span>
<h3>Disciplinas</h3>
<p>Elegí la disciplina que mejor se adapte a tus objetivos y consultá sus clases.</p>
</article>
<article class="public-feature">
<span>📅</span>
<h3>Clases y horarios</h3>
<p>Consultá grupos, días y horarios desde tu cuenta de alumno.</p>
</article>
<article class="public-feature">
<span>🏆</span>
<h3>Seminarios y eventos</h3>
<p>Reservá tu lugar en actividades especiales y mantené tus inscripciones al día.</p>
</article>
<article class="public-feature">
<span>📲</span>
<h3>Todo en un lugar</h3>
<p>Accedé desde el celular o la computadora a la plataforma de VILAMIR.</p>
</article>
</div>
</section>
<section id="disciplinas" class="public-section alt">
<div class="public-section-heading">
<span class="eyebrow">ENTRENAMIENTO</span>
<h2>Nuestras disciplinas</h2>
<p>Explorá las opciones disponibles y consultá la información de cada disciplina antes de dar el primer paso.</p>
</div>
<div class="cards-grid public-cards-v16">
            <?php foreach ($disc as $d): ?>
            <article class="public-card public-discipline-card">
<div class="public-card-icon">🥋</div>
<h3>
        <?= htmlspecialchars($d['Nombre']) ?>
</h3>
<p>
        <?= htmlspecialchars($d['Descripcion'] ?: 'Entrenamiento y formación integral.') ?>
</p>
                <?php if ((float)$d['Costo'] > 0): ?>
<strong>
        <?= moneyPub($d['Costo']) ?>
</strong>
<?php else: ?>
<strong>Consultar</strong>
<?php endif;
?>
            </article>
            <?php endforeach;
?>
            <?php if (!$disc): ?>
<p class="public-empty">No hay disciplinas publicadas todavía.</p>
<?php endif;
?>
        </div>
</section>
<section id="equipo" class="public-section">
<div class="public-section-heading">
<span class="eyebrow">EQUIPO VILAMIR</span>
<h2>Profesores</h2>
<p>Conocé al equipo que acompaña el entrenamiento.</p>
</div>
<div class="cards-grid public-cards-v16">
            <?php foreach ($prof as $p): ?>
            <article class="public-card public-prof-card">
<div class="public-prof-avatar">🥊</div>
<div>
<h3>
        <?= htmlspecialchars($p['Nombre'].' '.$p['Apellido']) ?>
</h3>
<p>
        <?= htmlspecialchars($p['Especialidad'] ?: 'Profesor VILAMIR') ?>
</p>
</div>
</article>
            <?php endforeach;
?>
            <?php if (!$prof): ?>
<p class="public-empty">No hay profesores publicados todavía.</p>
<?php endif;
?>
        </div>
</section>
<section id="eventos" class="public-section alt">
<div class="public-section-heading">
<span class="eyebrow">AGENDA</span>
<h2>Próximos eventos</h2>
<p>Seminarios y actividades especiales disponibles para inscripción.</p>
</div>
<div class="cards-grid public-cards-v16">
            <?php foreach ($event as $e): ?>
            <article class="public-card public-event-card">
<div class="public-event-date">
<strong>
        <?= date('d', strtotime($e['Fecha'])) ?>
</strong>
<span>
        <?= strtoupper(date('M', strtotime($e['Fecha']))) ?>
</span>
</div>
<h3>
        <?= htmlspecialchars($e['Nombre'] ?: 'Seminario / evento') ?>
</h3>
<p>
        <?= htmlspecialchars($e['Descripcion'] ?: 'Actividad especial de Academia VILAMIR.') ?>
</p>
<div class="public-event-meta">
<span>🕒 <?= $e['Hora'] ? htmlspecialchars(substr($e['Hora'],0,5)) : 'Horario a confirmar' ?>
</span>
<span>📍 <?= htmlspecialchars($e['Lugar'] ?: 'Lugar a confirmar') ?>
</span>
</div>
<strong>
        <?= (float)$e['Costo'] > 0 ? moneyPub($e['Costo']) : 'Actividad gratuita' ?>
</strong>
</article>
            <?php endforeach;
?>
            <?php if (!$event): ?>
<p class="public-empty">No hay próximos eventos publicados.</p><?php endif;
?>
        </div>
</section>
<section id="promociones" class="public-section">
    <div class="public-section-heading">
        <span class="eyebrow">PLANES Y ARANCELES MENSUALES</span>
        <h2>Promociones por Disciplinas</h2>
        <p>Elegí tu plan de entrenamiento. Cuantas más disciplinas practiques, mayor es el descuento en tu cuota mensual.</p>
    </div>

    <!-- TARJETAS DE PRECIOS PROMOCIONALES (REGLA RN-06 / TC-05) -->
    <div class="pricing-grid">
        <!-- Plan 1 Disciplina -->
        <article class="pricing-card">
            <span class="pricing-tag">BÁSICO</span>
            <h3>1 Disciplina</h3>
            <p class="pricing-desc">Ideal para iniciarse en un arte marcial o deporte de combate específico.</p>
            <div class="pricing-price">
                <strong>$1.500</strong>
                <span>UYU / mes</span>
            </div>
            <ul class="pricing-features">
                <li>✓ Acceso completo a 1 disciplina</li>
                <li>✓ Turnos y grupos asignados</li>
                <li>✓ Seguimiento de asistencia</li>
                <li>✓ Acceso a Portal de Alumno</li>
            </ul>
            <a href="registrar.html" class="btn btn-pricing">Elegir plan</a>
        </article>

        <!-- Plan 2 Disciplinas (DESTACADO / TC-05) -->
        <article class="pricing-card featured">
            <div class="pricing-badge-popular">MÁS POPULAR 🔥</div>
            <span class="pricing-tag">COMBINADO</span>
            <h3>2 Disciplinas</h3>
            <p class="pricing-desc">Combina golpeo y lucha (ej: Kick Boxing + Jiu Jitsu o Muay Thai + MMA).</p>
            <div class="pricing-price">
                <strong>$1.900</strong>
                <span>UYU / mes</span>
            </div>
            <div class="pricing-savings">Ahorras $1.100 UYU al mes</div>
            <ul class="pricing-features">
                <li>✓ Acceso a 2 disciplinas a elección</li>
                <li>✓ Descuento automático aplicado</li>
                <li>✓ Horarios flexibles combinables</li>
                <li>✓ Portal web y carnet digital QR</li>
            </ul>
            <a href="registrar.html" class="btn btn-pricing btn-featured">Elegir plan</a>
        </article>

        <!-- Plan 3 Disciplinas -->
        <article class="pricing-card">
            <span class="pricing-tag">AVANZADO</span>
            <h3>3 Disciplinas</h3>
            <p class="pricing-desc">Para deportistas dedicados que buscan un entrenamiento integral de combate.</p>
            <div class="pricing-price">
                <strong>$2.100</strong>
                <span>UYU / mes</span>
            </div>
            <div class="pricing-savings">Ahorras $2.400 UYU al mes</div>
            <ul class="pricing-features">
                <li>✓ Acceso a 3 disciplinas completas</li>
                <li>✓ Entrenamiento de golpeo, derribos y suelo</li>
                <li>✓ Preparación física específica</li>
                <li>✓ Descuento especial en seminarios</li>
            </ul>
            <a href="registrar.html" class="btn btn-pricing">Elegir plan</a>
        </article>

        <!-- Pase Libre -->
        <article class="pricing-card vip">
            <span class="pricing-tag vip-tag">TOTAL ACCESS 🥋</span>
            <h3>Pase Libre</h3>
            <p class="pricing-desc">Entrenamiento ilimitado en todas las disciplinas y horarios de la academia.</p>
            <div class="pricing-price">
                <strong>$2.500</strong>
                <span>UYU / mes</span>
            </div>
            <div class="pricing-savings">Todas las disciplinas sin límite</div>
            <ul class="pricing-features">
                <li>✓ <strong>MMA, Muay Thai, Kick Boxing, K-1 y BJJ</strong></li>
                <li>✓ Sin límite de días ni horarios</li>
                <li>✓ Entrada prioritaria a eventos y seminarios</li>
                <li>✓ Ideal competidores y alto rendimiento</li>
            </ul>
            <a href="registrar.html" class="btn btn-pricing btn-vip">Obtener Pase Libre</a>
        </article>
    </div>
</section>
<section class="public-section alt">
<div class="public-section-heading">
<span class="eyebrow">MOMENTOS VILAMIR</span>
<h2>Galería</h2>
<p>Una mirada a las actividades de la academia.</p>
</div>
<div class="public-gallery-v16">
            <?php foreach ($galeria as $g): ?>
                <article class="public-gallery-item">
<img src="uploads/gallery/<?= rawurlencode($g['Imagen']) ?>
" alt="<?= htmlspecialchars($g['Titulo']) ?>
" loading="lazy">
<div>
<h3>
        <?= htmlspecialchars($g['Titulo']) ?>
</h3>
<?php if ($g['Evento']): ?>
<small>
        <?= htmlspecialchars($g['Evento']) ?>
</small>
<?php endif;
?>
</div>
</article>
            <?php endforeach;
?>
            <?php if (!$galeria): ?>
<div class="public-gallery-empty">🖼️ Las fotos de la academia aparecerán aquí cuando se carguen desde la galería.</div><?php endif;
?>
        </div>
</section>
<section id="preguntas" class="public-section public-faq-section">
<div class="public-section-heading">
<span class="eyebrow">ANTES DE EMPEZAR</span>
<h2>Preguntas frecuentes</h2>
<p>Información rápida para dar tu primer paso.</p>
</div>
<div class="public-faq-grid">
<details class="public-faq"><summary>¿Cómo elijo una disciplina?</summary><p>Revisá las disciplinas publicadas y sus descripciones. Si tenés dudas, consultá con la academia antes de inscribirte.</p></details>
<details class="public-faq"><summary>¿Dónde consulto los horarios?</summary><p>Ingresá a tu cuenta para consultar clases y grupos disponibles según la información publicada.</p></details>
<details class="public-faq"><summary>¿Cómo participo en un seminario?</summary><p>Consultá los próximos eventos y luego ingresá a la plataforma para revisar las opciones de inscripción.</p></details>
<details class="public-faq"><summary>¿Puedo acceder desde el celular?</summary><p>Sí. La web está preparada para adaptarse a pantallas de celular, tablet y computadora.</p></details>
</div>
</section>
<section id="contacto" class="public-contact">
<div>
<span class="eyebrow">¿LISTO PARA EMPEZAR?</span>
<h2>Sumate a VILAMIR.</h2>
<p>Creá tu cuenta para empezar a explorar las actividades disponibles. Si ya sos parte de la academia, ingresá para gestionar tus clases y eventos.</p>
</div>
<div class="public-contact-actions">
<a class="btn" href="login.html">Ingresar</a>
<a class="btn public-btn-secondary" href="registrar.html">Crear cuenta</a>
</div>
</section>
</main>
<footer class="public-footer-v16">
<div>
<strong>🥋 Academia VILAMIR</strong>
<span>Entrená. Aprendé. Superate.</span>
</div>
<div>
<a href="#disciplinas">Disciplinas</a>
<a href="#eventos">Eventos</a>
<a href="#contacto">Contacto</a>
<a href="login.html">Ingresar</a>
</div>
<small>© 2026 Academia VILAMIR · Plataforma de gestión</small>
</footer>
<script src="js/mobile.js">
</script>
</body>
</html>
