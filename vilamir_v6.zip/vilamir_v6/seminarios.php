<?php

/*
 * ARCHIVO: seminarios.php
 * PROPÓSITO: Página de seminarios y eventos de Academia VILAMIR.
 */
require_once 'config/autenticacion.php';

$admin = (($_SESSION['usuario_rol'] ?? '') === 'Administrador');

?>
<!DOCTYPE html>
<html lang="es">
<head>
<?php vilamir_enviar_token_csrf(); ?>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Seminarios y eventos - VILAMIR</title>
<link rel="stylesheet" href="css/style.css?v=20261026-etapa2-seminarios-galeria-v1">
<script src="js/csrf.js"></script>
</head>
<body class="about-page">
<header class="navbar">
<div class="logo">
<img src="images/logo-vilamir.jpg" alt="Escuela Vilamir" class="logo-img">
</div>
<nav>
<a href="index.php">Inicio</a>
<?php if ($admin): ?>
    <a href="admin.php">Administración</a>
<?php else: ?>
    <a href="clases.php">Clases</a>
    <a href="mis_clases.php">Mis clases</a>
<?php endif; ?>
<a href="grupos.php">Grupos</a>
<a href="seminarios.php">Seminarios y eventos</a>
<a href="logout.php">Cerrar sesión</a>
</nav>
</header>

<main class="admin seminars-admin-page">
<section class="hero">
<h1>Seminarios y eventos</h1>
<p>Consultá las próximas actividades de la academia y gestioná tus inscripciones desde un mismo lugar.</p>
</section>

<?php if ($admin): ?>
<section class="module section-spaced seminar-section">
<h2>Crear seminario o evento</h2>
<div class="form-stack">
<input id="tituloSeminario" placeholder="Nombre">
<textarea id="descripcionSeminario" placeholder="Descripción"></textarea>
<input id="costoSeminario" type="number" step="0.01" placeholder="Costo">
<input id="fechaSeminario" type="date">
<div class="form-grid-two form-grid-inline-fields">
<input id="horaSeminario" type="time" aria-label="Hora" placeholder="Hora">
<input id="lugarSeminario" type="text" aria-label="Lugar" placeholder="Lugar">
<input id="cupoSeminario" type="number" min="0" aria-label="Cupo máximo" placeholder="Cupo máximo (0 = sin límite)">
</div>
<button id="btnGuardarSeminario">Guardar</button>
</div>
</section>
<?php endif; ?>

<section class="module section-spaced seminar-section">
<h2>Próximos seminarios y eventos</h2>
<p class="small">Consulta las actividades disponibles y gestiona tu inscripción directamente desde aquí.</p>
<!-- Contenedor dinámico de tarjetas -->
<div id="listaSeminarios" class="team cards-grid">
</div>
<!-- El mensaje debe estar visible SIEMPRE para que los alumnos reciban la confirmación -->
<p id="mensajeSeminario" class="message-center" style="margin-top:14px;"></p>
</section>
</main>

<footer>© 2026 Academia VILAMIR</footer>
<script src="js/seminarios.js"></script>
<script src="js/mobile.js"></script>
</body>
</html>