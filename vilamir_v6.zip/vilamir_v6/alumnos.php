<?php
/*
 * ARCHIVO: alumnos.php
 * PROPÓSITO: Gestión completa de alumnos (formulario ampliado, edición y listado).
 */
require_once 'config/autenticacion.php';

if (($_SESSION['usuario_rol'] ?? '') !== 'Administrador') {
    header('Location: index.php');
    exit;
}

$titulo = 'Gestión de Alumnos';
?>
<!DOCTYPE html>
<html lang="es">
<head>
<?php vilamir_enviar_token_csrf(); ?>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo htmlspecialchars($titulo); ?> - Academia VILAMIR</title>
<link rel="stylesheet" href="css/style.css?v=20261115-unificado-v1">
<script src="js/csrf.js"></script>
</head>
<body class="about-page">
<header class="navbar">
<div class="logo">
<img src="images/logo-vilamir.jpg" alt="Escuela Vilamir" class="logo-img">
</div>
<nav>
<a href="index.php">Inicio</a>
<a href="alumnos.php">Alumnos</a>
<a href="profesores.php">Profesores</a>
<a href="responsables.php">Responsables</a>
<a href="clases.php">Clases</a>
<a href="grupos.php">Grupos</a>
<a href="seminarios.php">Seminarios</a>
<a href="about.html">About Us</a>
</nav>
</header>
<main class="admin student-admin-page">
<section class="hero">
<h1><?php echo htmlspecialchars($titulo); ?></h1>
<p>Gestioná los datos de los alumnos, buscá registros y mantené su información actualizada desde un solo lugar.</p>
</section>

<!-- SECCIÓN 1: Registro de nuevo alumno con ficha completa -->
<section class="module section-spaced">
<h2>Registrar nuevo alumno</h2>
<form id="formNuevoAlumno" class="form-grid-two">
    <label>Nombre<input type="text" id="nombreAlumno" name="nombre" maxlength="100" required></label>
    <label>Apellido<input type="text" id="apellidoAlumno" name="apellido" maxlength="100" required></label>
    <label>Correo electrónico<input type="email" id="emailAlumno" name="email" maxlength="150" required></label>
    <label>Cédula de Identidad<input type="text" id="cedulaAlumno" name="cedula" placeholder="Ej: 4.567.890-1" maxlength="20"></label>
    <label>Teléfono / Celular<input type="tel" id="telefonoAlumno" name="telefono" placeholder="Ej: 099123456" maxlength="40"></label>
    <label>Fecha de Nacimiento<input type="date" id="fechaNacimientoAlumno" name="fecha_nacimiento"></label>
    <label>Cobertura Médica<input type="text" id="coberturaAlumno" name="cobertura_medica" placeholder="Ej: ASSE, Española, etc." maxlength="150"></label>
    <label>Dirección<input type="text" id="direccionAlumno" name="direccion" placeholder="Calle y número" maxlength="255"></label>
    <label>Peso (kg)<input type="number" step="0.1" id="pesoAlumno" name="peso" placeholder="Ej: 75.5"></label>
    <label>Categoría<input type="text" id="categoriaAlumno" name="categoria" placeholder="Ej: Welter, Juvenil, etc." maxlength="50"></label>
    <div class="wide-field"><button type="submit" id="btnGuardarAlumno">Registrar alumno</button></div>
</form>
<p id="mensajeAlumno" class="message-center message-top" role="status" aria-live="polite"></p>
</section>

<!-- SECCIÓN 2: Edición completa del alumno -->
<section class="module section-spaced" id="editarAlumnoPanel" hidden>
<h2>Editar datos completos del alumno</h2>
<form id="formEditarAlumno" class="form-grid-two">
    <input type="hidden" name="id" id="editarIdAlumno">
    <label>Nombre<input type="text" name="nombre" id="editarNombreAlumno" maxlength="100" required></label>
    <label>Apellido<input type="text" name="apellido" id="editarApellidoAlumno" maxlength="100" required></label>
    <label>Correo electrónico<input type="email" name="email" id="editarEmailAlumno" maxlength="150" required></label>
    <label>Cédula de Identidad<input type="text" name="cedula" id="editarCedulaAlumno" maxlength="20"></label>
    <label>Teléfono<input type="tel" name="telefono" id="editarTelefonoAlumno" maxlength="40"></label>
    <label>Fecha de Nacimiento<input type="date" name="fecha_nacimiento" id="editarFechaNacAlumno"></label>
    <label>Cobertura Médica<input type="text" name="cobertura_medica" id="editarCoberturaAlumno" maxlength="150"></label>
    <label>Dirección<input type="text" name="direccion" id="editarDireccionAlumno" maxlength="255"></label>
    <label>Peso (kg)<input type="number" step="0.1" name="peso" id="editarPesoAlumno"></label>
    <label>Categoría<input type="text" name="categoria" id="editarCategoriaAlumno" maxlength="50"></label>
    <div class="wide-field form-action-row">
        <button type="submit">Guardar cambios completos</button>
        <button type="button" id="cancelarEdicionAlumno" class="secondary-btn">Cancelar</button>
    </div>
</form>
</section>

<!-- SECCIÓN 3: Buscador, exportación y listado de alumnos (LA QUE FALTABA) -->
<section class="module student-management-panel">
<div class="student-management-toolbar">
    <div>
        <h2>Listado de alumnos</h2>
        <p class="student-management-help">Buscá por nombre, apellido, correo, teléfono o cédula. La edición conserva el historial académico y financiero.</p>
    </div>
    <button type="button" id="exportarAlumnosCsv" class="secondary-btn">Exportar CSV</button>
</div>
<label class="student-search-label" for="buscarAlumno">Buscar alumno</label>
<input type="search" id="buscarAlumno" placeholder="Nombre, apellido, correo, teléfono o cédula…" autocomplete="off">
<p id="contadorAlumnos" class="student-count" aria-live="polite">Cargando alumnos…</p>
<div id="listaAlumnos" class="student-table-wrap"><p>Cargando alumnos...</p></div>
</section>

</main>
<footer>© 2026 Academia VILAMIR</footer>
<script src="js/alumnos.js"></script>
<script src="js/mobile.js"></script>
</body>
</html>