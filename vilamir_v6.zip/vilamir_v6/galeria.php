<?php 
/*
 * ARCHIVO: galeria.php
 * PROPÓSITO: Galería de fotografías de eventos y actividades de Academia VILAMIR.
 */
require_once 'config/autenticacion.php';
require_once 'config/conexion.php';

$admin = strcasecmp(trim((string)($_SESSION['usuario_rol'] ?? '')), 'Administrador') === 0;

$eventos = $conexion->query(
    "SELECT ID_Seminario, COALESCE(NULLIF(Nombre,''), Titulo) AS Nombre 
     FROM SEMINARIO 
     ORDER BY Fecha DESC"
)->fetchAll(PDO::FETCH_ASSOC);

?>
<!doctype html>
<html lang="es">
<head>
<?php vilamir_enviar_token_csrf(); ?>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Galería | Academia VILAMIR</title>
<link rel="stylesheet" href="css/style.css?v=20261115-unificado-v1">
<script src="js/csrf.js"></script>
</head>
<body class="about-page">
<header class="navbar">
<div class="logo">
<img src="images/logo-vilamir.jpg" alt="Escuela Vilamir" class="logo-img">
</div>
<nav>
<a href="index.php">Inicio</a>
<?php if ($admin): ?>
<a href="admin.php">Administración</a>
<a href="herramientas.php">Herramientas</a>
<?php endif; ?>
<a href="publica.php">Web pública</a>
<a href="logout.php">Cerrar sesión</a>
</nav>
</header>

<main class="about-container">
<h1>🖼️ Galería de eventos</h1>

<?php if ($admin): ?>
<section class="project-info" style="text-align:left; max-width:760px; margin:0 auto 24px;">
<h2>Agregar fotografía</h2>
<p class="small" style="margin-bottom:14px; color:#aaa;">Las imágenes se redimensionan y optimizan automáticamente para no ralentizar la web.</p>
<form id="formGaleriaNueva" class="form-grid-two">
    <input name="titulo" placeholder="Título de la foto" required maxlength="150">
    <select name="seminario">
        <option value="0">Sin evento relacionado</option>
        <?php foreach ($eventos as $e): ?>
            <option value="<?= (int)$e['ID_Seminario'] ?>"><?= htmlspecialchars($e['Nombre'], ENT_QUOTES, 'UTF-8') ?></option>
        <?php endforeach; ?>
    </select>
    <input type="file" name="imagen" accept="image/jpeg,image/png,image/webp" required>
    <input name="descripcion" placeholder="Descripción breve (opcional)" maxlength="255">
    <div class="wide-field">
        <button type="submit" id="btnSubirFoto">Subir imagen</button>
    </div>
</form>
<p id="galeriaMensaje" class="message-center" style="display:none; margin-top:12px;"></p>
</section>
<?php endif; ?>

<section class="gallery-grid" id="gallery">
    <p>Cargando galería…</p>
</section>
</main>

<footer>© 2026 Academia VILAMIR</footer>

<script>
(() => {
    const esAdmin = <?= $admin ? 'true' : 'false' ?>;
    const eventos = <?= json_encode(array_map(static fn($e) => ['id'=>(int)$e['ID_Seminario'],'nombre'=>(string)($e['Nombre']??'')], $eventos), JSON_UNESCAPED_UNICODE) ?>;
    const galeria = document.getElementById('gallery');
    const mensaje = document.getElementById('galeriaMensaje');
    const endpoint = 'api/avanzadas.php?entity=galeria';

    function elemento(tag, texto, clase) {
        const n = document.createElement(tag);
        if (texto !== undefined && texto !== null) n.textContent = texto;
        if (clase) n.className = clase;
        return n;
    }

    function selectorEvento(valor) {
        const select = document.createElement('select');
        select.name = 'seminario';
        select.appendChild(new Option('Sin evento relacionado', '0'));
        eventos.forEach(e => select.appendChild(new Option(e.nombre, String(e.id))));
        select.value = String(valor || 0);
        return select;
    }

    async function cargarGaleria() {
        galeria.replaceChildren(elemento('p', 'Cargando galería…'));
        try {
            const r = await fetch(endpoint, { headers: { 'Accept': 'application/json' } });
            const d = await r.json();

            if (!r.ok || d.status !== 'success') {
                throw new Error(d.message || 'No se pudo cargar la galería.');
            }

            galeria.replaceChildren();

            if (!d.rows || d.rows.length === 0) {
                galeria.appendChild(elemento('p', 'No hay fotografías publicadas en la galería todavía.'));
                return;
            }

            d.rows.forEach(x => {
                const card = elemento('article', null, 'gallery-card');
                const img = document.createElement('img');
                img.src = 'uploads/gallery/' + encodeURIComponent(String(x.Imagen || ''));
                img.alt = String(x.Titulo || 'Fotografía de evento');
                img.loading = 'lazy';
                card.appendChild(img);

                const contenido = elemento('div');
                contenido.appendChild(elemento('h3', x.Titulo || 'Sin título'));
                if (x.Descripcion) contenido.appendChild(elemento('p', x.Descripcion));
                if (x.Evento) contenido.appendChild(elemento('small', '📍 ' + x.Evento));

                if (esAdmin) {
                    const acciones = elemento('div', null, 'gallery-actions');
                    const editar = elemento('button', 'Editar', 'btn btn-secondary');
                    editar.type = 'button';
                    editar.addEventListener('click', () => mostrarEdicion(card, x));

                    const borrar = elemento('button', 'Borrar', 'btn btn-danger');
                    borrar.type = 'button';
                    borrar.addEventListener('click', async () => {
                        if (!confirm('¿Seguro que querés borrar esta fotografía? Esta acción no se puede deshacer.')) return;
                        const fd = new FormData();
                        fd.set('accion', 'borrar');
                        fd.set('id_galeria', String(x.ID_Galeria));
                        await enviar(fd, borrar);
                    });

                    acciones.append(editar, borrar);
                    contenido.appendChild(acciones);
                }

                card.appendChild(contenido);
                galeria.appendChild(card);
            });
        } catch (e) {
            galeria.replaceChildren(elemento('p', 'No hay fotografías o no se pudieron cargar en este momento.'));
            console.error('Error al cargar galería:', e);
        }
    }

    function mostrarEdicion(card, x) {
        const anterior = card.querySelector('.gallery-edit-form');
        if (anterior) { anterior.remove(); return; }

        const form = elemento('form', null, 'gallery-edit-form form-grid-two');
        form.appendChild(elemento('h3', 'Editar fotografía'));

        const titulo = document.createElement('input');
        titulo.name = 'titulo';
        titulo.maxLength = 150;
        titulo.required = true;
        titulo.value = x.Titulo || '';
        titulo.placeholder = 'Título';

        const descripcion = document.createElement('input');
        descripcion.name = 'descripcion';
        descripcion.maxLength = 255;
        descripcion.value = x.Descripcion || '';
        descripcion.placeholder = 'Descripción';

        const evento = selectorEvento(x.ID_Seminario);
        const imagen = document.createElement('input');
        imagen.type = 'file';
        imagen.name = 'imagen';
        imagen.accept = 'image/jpeg,image/png,image/webp';

        const nota = elemento('small', 'Dejá el campo de archivo vacío si querés conservar la imagen actual.');
        const guardar = elemento('button', 'Guardar cambios');
        guardar.type = 'submit';

        const cancelar = elemento('button', 'Cancelar', 'btn-secondary');
        cancelar.type = 'button';
        cancelar.addEventListener('click', () => form.remove());

        form.append(titulo, descripcion, evento, imagen, nota, guardar, cancelar);
        form.addEventListener('submit', async ev => {
            ev.preventDefault();
            const fd = new FormData(form);
            fd.set('accion', 'editar');
            fd.set('id_galeria', String(x.ID_Galeria));
            await enviar(fd, guardar);
        });

        card.appendChild(form);
    }

    async function enviar(fd, boton) {
        if (boton) boton.disabled = true;
        if (mensaje) {
            mensaje.style.display = 'block';
            mensaje.className = 'message-center';
            mensaje.textContent = 'Procesando…';
        }

        try {
            const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
            if (csrf) fd.set('csrf_token', csrf);

            const r = await fetch(endpoint, {
                method: 'POST',
                body: fd,
                headers: { 'X-CSRF-Token': csrf }
            });
            const respuesta = await r.text();
            let d;
            try {
                d = JSON.parse(respuesta);
            } catch (error) {
                console.error('Respuesta no JSON de la galería:', respuesta);
                throw new Error('El servidor devolvió una respuesta inesperada. Revisá el registro de PHP de XAMPP.');
            }

            if (!r.ok || d.status !== 'success') {
                throw new Error(d.message || 'La operación no se pudo completar.');
            }

            if (mensaje) {
                mensaje.className = 'message-center success';
                mensaje.textContent = d.message || 'Cambios guardados con éxito.';
            }
            if (typeof window.mostrarToast === 'function') {
                window.mostrarToast(d.message || 'Galería actualizada', 'success');
            }

            await cargarGaleria();
        } catch (e) {
            if (mensaje) {
                mensaje.className = 'message-center err';
                mensaje.textContent = e.message || 'Ocurrió un error.';
            } else {
                alert(e.message || 'Ocurrió un error.');
            }
        } finally {
            if (boton) boton.disabled = false;
        }
    }

    const formNueva = document.getElementById('formGaleriaNueva');
    if (formNueva) {
        formNueva.addEventListener('submit', async ev => {
            ev.preventDefault();
            const fd = new FormData(formNueva);
            fd.set('accion', 'agregar');
            const btn = document.getElementById('btnSubirFoto');
            await enviar(fd, btn);
            formNueva.reset();
        });
    }

    cargarGaleria();
})();
</script>
<script src="js/mobile.js"></script>
</body>
</html>