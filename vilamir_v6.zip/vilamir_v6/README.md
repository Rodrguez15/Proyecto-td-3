# Academia VILAMIR — Escuela de Combate

Sistema web de gestión académica y administrativa desarrollado con PHP, MySQL, HTML, CSS y JavaScript.

Modelo vigente:

**Disciplina → Grupo → Horario → Inscripciones → Asistencia**

Incluye alumnos, profesores, responsables, pagos/comprobantes, seminarios y eventos, promociones, notificaciones, certificados, QR, galería, calendario, reportes y web pública.

No incluye módulos de exámenes.

Ver `README_FINAL.md` para instalación y migraciones.


## Revisión técnica

Consultar `informes/INFORME_REVISION_GENERAL_V21.md` para las comprobaciones estáticas, las limitaciones de prueba y la lista de validaciones manuales en XAMPP. El script V17 potencialmente destructivo está archivado en `sql/legacy_no_ejecutar/` y no debe ejecutarse como parte de V21.

Nota: `profesor.php` corresponde al espacio del profesor y `profesores.php` a la gestión administrativa de profesores; son páginas diferentes y no deben fusionarse por similitud de nombre.

## V21 — Diseño adaptable a celulares

La revisión responsive está documentada en `informes/INFORME_RESPONSIVE_V21.md`. Los ajustes visuales están centralizados en la sección 52 de `css/style.css`; `js/mobile.js` controla el menú móvil. No se requiere migración SQL para estos cambios.

## Auditoría por etapas

Consultar `informes/INFORME_ETAPAS_0_1_V21.md` para el inventario de verificaciones estáticas, limitaciones del entorno y la lista de pruebas funcionales que deben completarse en XAMPP antes de dar por validada la versión.

## Etapa 2 — Asistencia y espacio del profesor
Se endureció la validación del lote de asistencia para rechazar alumnos duplicados, datos inválidos y listas incompletas antes de escribir en la base. Ver `informes/INFORME_ETAPA_2_ASISTENCIA_PROFESOR_V21.md` para alcance, límites y pruebas manuales. No se agregó ninguna función de exámenes o niveles.

## Etapa 3 — Cuenta y gestión de alumnos

Se reforzó la búsqueda, alta y edición administrativa de alumnos, la actualización del perfil propio y la validación de correos duplicados. La API rechaza los intentos de eliminación física para proteger el historial académico y financiero. No se agrega una migración SQL nueva. Consultar `informes/INFORME_GESTION_ALUMNOS_CUENTA_V21.md` para el alcance y las pruebas manuales.

## Etapa 4 — Diseño adaptable a celulares
Se mejoró la accesibilidad y robustez del menú móvil y se agregaron ajustes responsive complementarios en la sección 53 de `css/style.css`. No hay cambios de base de datos ni migraciones. Consultar `informes/INFORME_ETAPA_4_RESPONSIVE_V21.md` y completar las pruebas manuales en XAMPP antes de publicar.

## Etapa 5 — Pagos y comprobantes
Se endureció la validación del registro de pagos, la asignación atómica del número de comprobante, el flujo de anulación con trazabilidad y la presentación de vencidos en el CSV del historial. No requiere migración SQL. Consultar `informes/INFORME_ETAPA_5_PAGOS_COMPROBANTES_V21.md` y completar las pruebas manuales en XAMPP.

## Etapa 6 — Disciplinas e inscripciones

Se reforzaron las altas, bajas y reactivaciones de inscripciones, se preserva el historial de bajas, se evita eliminar disciplinas con grupos o inscripciones asociados y se validan costos no negativos. No se agrega una migración SQL. Ver `informes/INFORME_ETAPA_6_DISCIPLINAS_INSCRIPCIONES_V21.md` para el alcance y las pruebas manuales recomendadas.


## Etapa 8 — Informes, estadísticas y reportes

- Se corrigió el cálculo de asistencia: el porcentaje cuenta únicamente los registros `Presente`; las asistencias `Justificado` se muestran por separado para no inflar la tasa de presencia.
- El panel por grupo ahora distingue presentes, justificadas y total de registros.
- Se incorporó el conteo histórico de pagos anulados al resumen administrativo y a la exportación CSV.
- Se mantienen los filtros de período, los detalles financieros y las exportaciones existentes.
- No se modificó la base de datos ni se añadieron módulos de exámenes o niveles.


## Etapa 9 — Notificaciones y calendario

Se unificaron los textos de avisos automáticos de pagos y eventos entre la tarea programada y la generación manual para reducir duplicados. Se añadieron regiones accesibles al calendario. No requiere migración SQL. Revisar `informes/INFORME_ETAPA_9_NOTIFICACIONES_CALENDARIO_V21.md`.

## Etapa 10 — Organización de archivos y base de datos

Se agregó `docs/` con un índice de documentación, mapa del proyecto y guía segura para mantener la base de datos. Se conservaron las rutas existentes de PHP, API, CSS, JavaScript y SQL para reducir el riesgo de romper referencias. No se agregó migración SQL. Consultar `informes/INFORME_ETAPA_10_ORGANIZACION_V21.md`.


## Etapa 11 — Seguridad y preparación para publicación

Se redujo la exposición de errores internos en APIs administrativas y complementarias, se evita filtrar excepciones PDO desde la API de seminarios y se añadieron reglas para proteger `uploads/gallery` contra listado de directorios y ejecución de scripts. No se modificó la base de datos. Antes de publicar, es obligatorio configurar credenciales de entorno seguras, HTTPS, `display_errors=Off` y probar los permisos en el servidor real. Ver `informes/INFORME_ETAPA_11_SEGURIDAD_PUBLICACION_V21.md`. Las verificaciones estáticas no sustituyen pruebas funcionales en XAMPP.


## Organización de informes

Todos los informes técnicos y de etapas se encuentran centralizados en la carpeta `informes/`. Esta organización no modifica rutas de ejecución de PHP, JavaScript, CSS ni SQL.
