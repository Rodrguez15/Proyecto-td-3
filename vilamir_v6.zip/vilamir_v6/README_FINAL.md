# ACADEMIA VILAMIR — guía de instalación V21

## Estado

Esta versión reúne el sistema de gestión de la Academia VILAMIR con el modelo vigente **DISCIPLINA → GRUPO → HORARIO**, asistencia avanzada, pagos/comprobantes, notificaciones, certificados, lista de espera, galería, promociones y web pública.

**No existe módulo de exámenes ni niveles de examen.**

## Instalación nueva
1. Copiar el proyecto a `C:\xampp\htdocs\vilamir_v3`.
2. Iniciar Apache y MySQL desde XAMPP.
3. Abrir phpMyAdmin.
4. Crear/importar la base `mma_systems` usando `sql/mma_systems.sql`.
5. Abrir `http://localhost/vilamir_v3/login.html`.

Administrador inicial:
- El correo y la contraseña dependen del esquema o script de datos que hayas importado. Consultá el SQL usado; no asumas que una credencial de ejemplo aplica a una base existente.
- Cambiá cualquier contraseña de demostración antes de publicar el sitio.

## Base existente
Si ya tenés una base de una versión anterior, exportá primero una copia de seguridad desde phpMyAdmin. Revisá las migraciones disponibles dentro de `sql/` y ejecutá únicamente las que correspondan al esquema que ya tenés instalado. No importes `sql/mma_systems.sql` encima de una base con datos ni ejecutes migraciones a ciegas.

## Módulos incluidos
- Administración de alumnos, profesores, responsables, disciplinas, grupos y horarios.
- Inscripciones a disciplinas y grupos.
- Portal del alumno / Mi cuenta.
- Portal del profesor / Mi espacio.
- Asistencia por grupo, fecha y horario.
- Historial y porcentaje de asistencia.
- Pagos con comprobante único y anulación conservando historial.
- Verificación de comprobantes.
- Seminarios y eventos con fecha, hora, lugar y cupo.
- Lista de espera para grupos completos.
- Promociones.
- Notificaciones para alumnos y profesores.
- Certificados descargables.
- Código QR del alumno y perfil público de identificación.
- Galería de eventos.
- Reportes, exportación CSV/PDF e impresión.
- Calendario.
- Web pública.
- Seguridad de sesión y control por roles.

## Estilos
Todos los estilos específicos de las páginas están centralizados en `css/style.css`. No se utilizan bloques `<style>` dentro de PHP/HTML.

## Logo
El logo oficial de la academia está en `images/logo-vilamir.jpg` y se utiliza en la navegación, web pública y comprobantes.
## Actualización de pagos e informes

La revisión financiera más reciente está documentada en `informes/INFORME_REVISION_V21_FINANZAS.md`. Incluye detalle de pagos por período, exportación CSV con el historial y datos de anulación, compatibilidad de verificación de comprobantes y la nueva organización de `sql/`. Consultá `sql/README.md` antes de ejecutar cualquier SQL.

## Etapa 7 — Seminarios, eventos y promociones
- Validación de fecha real, costo, cupo y hora en la API de seminarios.
- Protección contra reducción de cupo por debajo de las inscripciones activas.
- Se impide eliminar eventos con inscripciones activas o lista de espera.
- Se desactivan promociones en vez de borrarlas físicamente, preservando historial.
- Se reforzó el escape de datos al generar acciones administrativas en las tarjetas de seminarios.
- Informe: `informes/INFORME_ETAPA_7_SEMINARIOS_EVENTOS_PROMOCIONES_V21.md`.


## Organización de informes

Todos los informes técnicos y de etapas se encuentran centralizados en la carpeta `informes/`. Esta organización no modifica rutas de ejecución de PHP, JavaScript, CSS ni SQL.

## Etapa — Asistencia y horarios
- Los estados de asistencia sin registrar ya no aparecen preseleccionados como presentes.
- El resumen se actualiza al marcar alumnos y el guardado exige un estado válido para cada uno.
- La administración rechaza horarios superpuestos dentro del mismo grupo y detecta conflictos de horario de profesores cuando hay asignaciones activas.
- Informe: `informes/INFORME_ETAPA_ASISTENCIA_HORARIOS_V21.md`.
