# ACADEMIA VILAMIR — V20

## Cupos, inscripciones y listas de espera

Esta versión mejora el control de capacidad de grupos y seminarios/eventos.

### Incluye
- Cupo de grupos controlado en transacciones.
- Lista de espera de grupos.
- Promoción automática al liberar un lugar.
- Lista de espera para seminarios/eventos con cupo.
- Promoción automática al cancelar una inscripción.
- Promoción cuando el administrador aumenta un cupo.
- Estado de espera visible para el alumno.
- Conservación de historial: las bajas pasan a `Cancelada` en vez de borrar la inscripción.
- Notificaciones al alumno promovido.
- Índices adicionales para acelerar cupos y listas.
- Sin módulo de exámenes.

## Migración
Para una instalación V19.1 existente, ejecutar:

`sql/migraciones/migracion_cupos_v20.sql`

Después reemplazar los archivos del proyecto por esta versión.
