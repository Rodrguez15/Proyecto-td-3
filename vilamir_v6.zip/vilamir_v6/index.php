<?php

/*
 * DESCRIPCIÓN DEL ARCHIVO
 * Página principal autenticada; organiza la navegación según el rol del usuario.
 */
// Página principal autenticada: muestra el menú y contenido según el rol guardado en sesión.
require_once __DIR__ . '/config/sesion.php';

// La raíz del sitio debe mostrar la web pública a quienes no iniciaron sesión.
// Los usuarios autenticados conservan el acceso a su panel según el rol.
if (empty($_SESSION['usuario_id'])) {
    header('Location: publica.php');
    exit;
}

require_once __DIR__ . '/config/autenticacion.php';

$nombreUsuario = $_SESSION['usuario_nombre'] ?? 'Usuario';

$rol = $_SESSION['usuario_rol'] ?? '';

$esAdmin = ($rol === 'Administrador');

$esProfesor = ($rol === 'Profesor');

?>
<!DOCTYPE html>
<html lang="es">
<head>
<?php vilamir_enviar_token_csrf(); ?>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Vilamir - Inicio</title>
<link rel="stylesheet" href="css/style.css?v=20261026-etapa2-seminarios-galeria-v1">
<script src="js/csrf.js"></script>
</head>
<body class="home-dashboard-page">
<header class="navbar home-navbar">
<div class="logo">
<img src="images/logo-vilamir.jpg" alt="Escuela Vilamir" class="logo-img">
</div>
<nav>
<?php if ($esAdmin): ?>
<a href="index.php">Inicio</a>
<a href="alumnos.php">Alumnos</a>
<a href="profesores.php">Profesores</a>
<a href="responsables.php">Responsables</a>
<a href="clases.php">Clases</a>
<a href="grupos.php">Grupos</a>
<a href="seminarios.php">Seminarios</a>
<a href="about.html">About Us</a>
<a href="publica.php">Web pública</a>
<?php elseif ($esProfesor): ?>
<a href="index.php">Inicio</a>
<a href="profesor.php">Mi espacio</a>
<a href="estadisticas.php">Asistencia avanzada</a>
<a href="grupos.php">Grupos</a>
<a href="seminarios.php">Seminarios y eventos</a>
<a href="about.html">About Us</a>
<a href="logout.php">Cerrar sesión</a><?php else: ?>
<a href="index.php">Inicio</a>
<a href="grupos.php">Grupos</a>
<a href="seminarios.php">Seminarios y eventos</a>
<a href="portal.php">Mi cuenta</a>
<a href="about.html">About Us</a><?php endif;
?>
</nav>
</header>
<main class="container home-main">
<section class="login-card dashboard-card home-welcome">
<span class="home-eyebrow">ACADEMIA VILAMIR · TU ESPACIO</span>
<h1>¡Bienvenido, <?php echo htmlspecialchars($nombreUsuario);
?>
!</h1>
<p>Rol: <strong><?php echo htmlspecialchars($rol);
?>
</strong>
</p>
<p><?php echo $esAdmin ? 'Desde aquí puedes administrar el sistema de Vilamir.' : 'Desde aquí puedes consultar clases, grupos, seminarios y eventos, e inscribirte a tus clases.';
?>
</p>
<div class="text-center">
<a href="logout.php" class="register-link logout-button">Cerrar sesión</a>
</div>
</section>
<section class="home-shortcuts dashboard-wide no-top-margin" aria-label="Accesos directos">
<div class="panel home-shortcut-grid">
<?php if ($esAdmin): ?>
<a class="opcion home-shortcut" href="admin.php">
<span class="home-shortcut-icon" aria-hidden="true">▦</span>
<h2>Panel de administración</h2>
<p>Gestioná la plataforma desde un solo lugar.</p>
<span class="home-shortcut-action">Abrir sección <span aria-hidden="true">→</span></span>
</a>
<a class="opcion home-shortcut" href="clases.php">
<span class="home-shortcut-icon" aria-hidden="true">🥋</span>
<h2>Clases</h2><p>Gestionar clases y horarios.</p>
<span class="home-shortcut-action">Abrir sección <span aria-hidden="true">→</span></span>
</a>
<a class="opcion home-shortcut" href="grupos.php">
<span class="home-shortcut-icon" aria-hidden="true">◉</span>
<h2>Grupos</h2><p>Gestionar grupos de entrenamiento.</p>
<span class="home-shortcut-action">Abrir sección <span aria-hidden="true">→</span></span>
</a>
<a class="opcion home-shortcut" href="seminarios.php">
<span class="home-shortcut-icon" aria-hidden="true">✦</span>
<h2>Seminarios</h2><p>Gestionar eventos y seminarios.</p>
<span class="home-shortcut-action">Abrir sección <span aria-hidden="true">→</span></span>
</a>
<a class="opcion home-shortcut" href="alumnos.php">
<span class="home-shortcut-icon" aria-hidden="true">♙</span>
<h2>Alumnos</h2><p>Administrar alumnos.</p>
<span class="home-shortcut-action">Abrir sección <span aria-hidden="true">→</span></span>
</a>
<?php elseif ($esProfesor): ?>
<a class="opcion home-shortcut" href="profesor.php">
<span class="home-shortcut-icon" aria-hidden="true">🥋</span>
<h2>Mi espacio como profesor</h2><p>Consultar tus grupos y disciplinas.</p>
<span class="home-shortcut-action">Abrir sección <span aria-hidden="true">→</span></span>
</a>
<a class="opcion home-shortcut" href="grupos.php">
<span class="home-shortcut-icon" aria-hidden="true">◉</span>
<h2>Grupos</h2><p>Consultar los grupos de entrenamiento.</p>
<span class="home-shortcut-action">Abrir sección <span aria-hidden="true">→</span></span>
</a>
<a class="opcion home-shortcut" href="seminarios.php">
<span class="home-shortcut-icon" aria-hidden="true">✦</span>
<h2>Seminarios y eventos</h2><p>Consultar próximos eventos.</p>
<span class="home-shortcut-action">Abrir sección <span aria-hidden="true">→</span></span>
</a>
<?php else: ?>
<a class="opcion home-shortcut" href="clases.php">
<span class="home-shortcut-icon" aria-hidden="true">🥋</span>
<h2>Clases y cursos</h2><p>Ver clases disponibles e inscribirte.</p>
<span class="home-shortcut-action">Abrir sección <span aria-hidden="true">→</span></span>
</a>
<a class="opcion home-shortcut" href="mis_clases.php">
<span class="home-shortcut-icon" aria-hidden="true">✓</span>
<h2>Mis clases</h2><p>Ver las clases en las que estás inscrito.</p>
<span class="home-shortcut-action">Abrir sección <span aria-hidden="true">→</span></span>
</a>
<a class="opcion home-shortcut" href="grupos.php">
<span class="home-shortcut-icon" aria-hidden="true">◉</span>
<h2>Grupos</h2><p>Consultar grupos de entrenamiento.</p>
<span class="home-shortcut-action">Abrir sección <span aria-hidden="true">→</span></span>
</a>
<a class="opcion home-shortcut" href="seminarios.php">
<span class="home-shortcut-icon" aria-hidden="true">✦</span>
<h2>Seminarios y eventos</h2><p>Consultar próximos eventos.</p>
<span class="home-shortcut-action">Abrir sección <span aria-hidden="true">→</span></span>
</a>
<?php endif; ?>
</div>
</section>
</main>
<footer>© 2026 Academia VILAMIR</footer>
<script src="js/mobile.js">
</script>
</body>
</html>
