# Academia VILAMIR — V18 Pagos y comprobantes

## Objetivo
Mejorar la trazabilidad de los pagos y evitar la eliminación definitiva de registros financieros.

## Cambios
- Cada pago nuevo recibe un número `VIL-AAAA-MM-DD-######`.
- Los pagos históricos reciben un código al ejecutar la migración V18.
- El botón de eliminar pagos ahora los **anula**.
- Se guarda fecha, usuario y motivo de la anulación.
- Un pago anulado no puede volver a editarse.
- Se registran las operaciones de pago importantes en `ACTIVIDAD_SISTEMA`.
- El comprobante muestra el número único y un enlace de verificación.
- `verificar_comprobante.php` permite comprobar públicamente la existencia del comprobante mostrando solo datos mínimos.
- El comprobante mantiene control de acceso: un alumno solo puede consultar sus propios pagos.
- La impresión del comprobante está preparada para formato limpio.

## Base de datos
Para una instalación nueva, `sql/mma_systems.sql` ya contiene las columnas V18.

Para una base existente V17, ejecutar una sola vez:

`sql/migraciones/migracion_pagos_v18.sql`

## Estados válidos
- `Pendiente`
- `Pagado`
- `Anulado`

Los estados históricos comunes se normalizan durante la migración.

## Importante
No se borran pagos para conservar el historial financiero. La anulación es reversible únicamente mediante una futura operación administrativa específica; en V18 no se permite editar un pago ya anulado.
