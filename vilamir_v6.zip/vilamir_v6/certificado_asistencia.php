<?php
/*
 * ARCHIVO: certificado_asistencia.php
 * PROPÓSITO: Certificado e informe de presentismo deportivo para alumnos y deportistas federados.
 */
require_once 'config/sesion.php';
require_once 'config/conexion.php';

if (!isset($_SESSION['usuario_id'])) {
    http_response_code(401);
    exit('Sesión requerida.');
}

$uid = (int)$_SESSION['usuario_id'];
$rol = (string)($_SESSION['usuario_rol'] ?? '');
$idAlumno = 0;

if (strcasecmp($rol, 'Administrador') === 0) {
    $idAlumno = (int)($_GET['id'] ?? 0);
} elseif (strcasecmp($rol, 'Alumno') === 0) {
    $q = $conexion->prepare('SELECT ID_Alumno FROM ALUMNO WHERE ID_Usuario = ? LIMIT 1');
    $q->execute([$uid]);
    $idAlumno = (int)$q->fetchColumn();
} else {
    http_response_code(403);
    exit('No tenés permiso para emitir esta constancia.');
}

if ($idAlumno <= 0) {
    http_response_code(404);
    exit('Alumno no válido.');
}

// Datos del alumno
$stmtA = $conexion->prepare("SELECT Nombre, Apellido, Cedula FROM ALUMNO WHERE ID_Alumno=?");
$stmtA->execute([$idAlumno]);
$alumno = $stmtA->fetch(PDO::FETCH_ASSOC);
if (!$alumno) { http_response_code(404); exit('Alumno no encontrado.'); }

// Asistencias de los últimos 90 días
$stmtAsis = $conexion->prepare("
    SELECT a.Fecha, a.Estado, g.Nombre AS Grupo, d.Nombre AS Disciplina
    FROM ASISTENCIA a
    JOIN GRUPO g ON g.ID_Grupo = a.ID_Grupo
    LEFT JOIN DISCIPLINA d ON d.ID_Disciplina = g.ID_Disciplina
    WHERE a.ID_Alumno = ? AND a.Fecha >= DATE_SUB(CURDATE(), INTERVAL 90 DAY)
    ORDER BY a.Fecha DESC
");
$stmtAsis->execute([$idAlumno]);
$asistencias = $stmtAsis->fetchAll(PDO::FETCH_ASSOC);

$total = count($asistencias);
$presentes = count(array_filter($asistencias, fn($r) => $r['Estado'] === 'Presente'));
$pct = $total > 0 ? round(($presentes / $total) * 100) : 0;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Certificado de Asistencia | <?= htmlspecialchars($alumno['Nombre'] . ' ' . $alumno['Apellido']) ?></title>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; background: #fff; color: #111; margin: 0; padding: 40px; }
        .document-container { max-width: 750px; margin: 0 auto; border: 2px solid #333; padding: 40px; border-radius: 12px; }
        .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #d71920; padding-bottom: 20px; }
        .header img { width: 70px; height: 70px; }
        .title { text-align: right; }
        .title h1 { margin: 0; font-size: 22px; color: #d71920; }
        .title p { margin: 4px 0 0; font-size: 13px; color: #666; }
        .cert-body { margin: 30px 0; font-size: 15px; line-height: 1.8; text-align: justify; }
        .kpis { display: flex; gap: 15px; margin: 25px 0; }
        .kpi { flex: 1; border: 1px solid #ddd; padding: 12px; text-align: center; border-radius: 8px; background: #f9f9f9; }
        .kpi strong { display: block; font-size: 20px; color: #d71920; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; font-size: 13px; }
        th, td { border: 1px solid #ddd; padding: 8px 10px; text-align: left; }
        th { background: #f2f2f2; }
        .signatures { display: flex; justify-content: space-between; margin-top: 60px; padding-top: 20px; }
        .sig { text-align: center; width: 220px; border-top: 1px solid #555; font-size: 12px; padding-top: 6px; }
        @media (max-width: 640px) {
            body { padding: 12px; }
            .document-container { padding: 16px; }
            .header { gap: 12px; align-items: flex-start; }
            .title h1 { font-size: 17px; }
            .kpis { flex-wrap: wrap; }
            .kpi { min-width: 120px; }
            .signatures { gap: 24px; flex-wrap: wrap; }
            .sig { width: 100%; }
            .document-container table { display: block; overflow-x: auto; white-space: nowrap; }
        }
        @media print {
            .no-print { display: none; }
            body { padding: 0; }
            .document-container { border: none; }
        }
    </style>
</head>
<body>
    <div style="text-align: center; margin-bottom: 20px;" class="no-print">
        <button onclick="window.print()" style="background:#d71920; color:#fff; border:none; padding:10px 20px; font-weight:700; border-radius:6px; cursor:pointer;">
            🖨️ Imprimir / Guardar en PDF
        </button>
    </div>

    <div class="document-container">
        <div class="header">
            <img src="images/logo-vilamir.jpg" alt="Logo">
            <div class="title">
                <h1>ACADEMIA VILAMIR</h1>
                <p>Constancia Oficial de Asistencia y Entrenamiento</p>
            </div>
        </div>

        <div class="cert-body">
            Se deja constancia por medio del presente documento de que el/la alumno/a <strong><?= htmlspecialchars($alumno['Nombre'] . ' ' . $alumno['Apellido']) ?></strong><?= $alumno['Cedula'] ? ' (C.I. ' . htmlspecialchars($alumno['Cedula']) . ')' : '' ?>, registra actividad deportiva y entrenamiento en nuestras instalaciones en el período de los últimos 90 días.
        </div>

        <div class="kpis">
            <div class="kpi"><span>Clases Registradas</span><strong><?= $total ?></strong></div>
            <div class="kpi"><span>Clases Asistidas</span><strong><?= $presentes ?></strong></div>
            <div class="kpi"><span>Presentismo Efectivo</span><strong><?= $pct ?>%</strong></div>
        </div>

        <h3>Detalle de Clases:</h3>
        <table>
            <thead>
                <tr>
                    <th>Fecha</th>
                    <th>Disciplina</th>
                    <th>Grupo</th>
                    <th>Estado</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($asistencias)): ?>
                    <tr><td colspan="4" style="text-align:center;">Sin asistencias en el período.</td></tr>
                <?php else: foreach (array_slice($asistencias, 0, 15) as $as): ?>
                    <tr>
                        <td><?= date('d/m/Y', strtotime($as['Fecha'])) ?></td>
                        <td><?= htmlspecialchars($as['Disciplina'] ?: 'Combate') ?></td>
                        <td><?= htmlspecialchars($as['Grupo']) ?></td>
                        <td><strong><?= htmlspecialchars($as['Estado']) ?></strong></td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>

        <div class="signatures">
            <div class="sig">Firma de Dirección / Instructor</div>
            <div class="sig">Sello Oficial Academia VILAMIR</div>
        </div>
    </div>
</body>
</html>