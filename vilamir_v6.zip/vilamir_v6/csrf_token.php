<?php
/** Token CSRF de sesión para formularios servidos como HTML estático. */
require_once __DIR__ . '/config/sesion.php';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
    http_response_code(405);
    header('Allow: GET');
    exit;
}

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
echo json_encode(['status' => 'success', 'csrf_token' => vilamir_token_csrf()], JSON_UNESCAPED_UNICODE);
