/** Archivo: horarios.js — Carga y muestra horarios y promociones del portal. */
const escapeHtml=v=>String(v??'').replace(/[&<>"']/g,c=>({
'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'
}[c]));
const formatoHora=v=>String(v??'').slice(0,5);
const dias=['Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo'];
async function cargarAlumno(){
const [h,p]=await Promise.all([fetch('api/portal.php?entity=horarios').then(r=>r.json()),fetch('api/portal.php?entity=promociones').then(r=>r.json())]);
const hb=document.getElementById('horarios'),pb=document.getElementById('promociones');
const porcentajePromocion=nombre=>{
const n=String(nombre||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
if(n.includes('pase libre')||n.includes('todas'))return 25;
if(n.includes('1 disciplina')||n.includes('una disciplina')||n.includes('individual'))return 15;
if(n.includes('2 disciplina')||n.includes('dos disciplina')||n.includes('doble'))return 19;
if(n.includes('3 disciplina')||n.includes('tres disciplina')||n.includes('triple'))return 21;
return null;
};
const formatoPrecio=valor=>'$ ' + new Intl.NumberFormat('es-UY',{maximumFractionDigits:0}).format(Number(valor)||0);
if(p.status==='success')pb.innerHTML=p.rows.length?p.rows.map(x=>{
const porcentaje=porcentajePromocion(x.Nombre);
const precio=Number(x.Descuento);
return `<article class="card promo-card"><span class="badge">PROMOCIÓN</span><h3>${escapeHtml(x.Nombre)}</h3>${porcentaje!==null?`<div class="promo-value">${porcentaje}% OFF</div>`:''}<div class="promo-price"><span>Precio mensual</span><strong>${formatoPrecio(precio)}</strong></div><p>${escapeHtml(x.Descripcion||'Sin descripción')}</p>${x.Fecha_fin?`<div class="promo-date">Válida hasta ${escapeHtml(x.Fecha_fin)}</div>`:''}</article>`;
}).join(''):'<div class="empty-state">No hay promociones vigentes.</div>';
if(h.status!=='success'){
hb.innerHTML='<div class="empty-state">No se pudieron cargar los horarios.</div>';
return;
}const rows=h.rows||[];
hb.innerHTML=rows.length?rows.map(x=>`<article class="card"><h3>${escapeHtml(x.Disciplina||'Clase')} — ${escapeHtml(x.Grupo)}</h3><p><strong>${escapeHtml(x.Dia)}</strong></p><p>${formatoHora(x.Hora_inicio)} a ${formatoHora(x.Hora_fin)}</p>${Number(x.MiGrupo)?'<span class="badge success">Mi grupo</span>':''}</article>`).join(''):'<div class="empty-state">No hay horarios cargados.</div>';
const cal=document.getElementById('calendarioAlumno');
if(cal)cal.innerHTML=dias.map(d=>`<div class="calendar-day"><h4>${d}</h4>${rows.filter(x=>x.Dia===d).map(x=>`<div class="calendar-event"><strong>${
formatoHora(x.Hora_inicio)
} - ${
formatoHora(x.Hora_fin)
}</strong><span>${
escapeHtml(x.Disciplina||'Clase')
}</span><span>${
escapeHtml(x.Grupo)
} ${
Number(x.MiGrupo)?'':''
}</span></div>`).join('')||'<span class="small">Sin clases</span>'}</div>`).join('');
}
async function cargarProfesor(){
const r=await fetch(`api/profesor_portal.php?accion=datos&t=${Date.now()}`,{
cache:'no-store',credentials:'same-origin'
}).then(x=>x.json());
const box=document.getElementById('horariosProfesor');
if(r.status!=='success'){
box.innerHTML=`<div class="empty-state">${escapeHtml(r.message||'No se pudo cargar el cronograma.')}</div>`;
return;
}box.innerHTML=r.horarios?.length?r.horarios.map(x=>`<article class="card"><h3>${escapeHtml(x.Disciplina||'Clase')} — ${escapeHtml(x.Grupo)}</h3><p><strong>${escapeHtml(x.Dia)}</strong></p><p>${formatoHora(x.Hora_inicio)} a ${formatoHora(x.Hora_fin)}</p><span class="badge success">Clase asignada</span></article>`).join(''):'<div class="empty-state">No tienes horarios asignados.</div>';
}
document.addEventListener('DOMContentLoaded',()=>{
(ROL==='Alumno'?cargarAlumno():cargarProfesor()).catch(()=>{
const e=document.querySelector('#horarios,#horariosProfesor');if(e)e.innerHTML='<div class="empty-state">No se pudo comunicar con el servidor.</div>';
});
});
