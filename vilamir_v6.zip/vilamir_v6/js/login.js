/** Archivo: login.js — Interacciones del navegador relacionadas con login. */
// ===============================
// LOGIN MMA SYSTEMS
// ===============================

// Escuchar cuando el usuario presiona "Login"
document.getElementById("loginForm").addEventListener("submit", function(e) {
    e.preventDefault();

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    const mensaje = document.getElementById("mensaje");

    mensaje.textContent = "";

    if (email === "" || password === "") {
        mensaje.className = "error message-center";
        mensaje.textContent = "Complete todos los campos.";
        return;

}

    // Preparar los datos del formulario para la solicitud POST
    const formData = new FormData();
    formData.append('email', email);
    formData.append('password', password);

    // Obtener token de la sesión y enviarlo junto con las credenciales.
    fetch('csrf_token.php', { credentials: 'same-origin', cache: 'no-store' })
    .then(response => response.json())
    .then(tokenData => {
        if (!tokenData.csrf_token) throw new Error('No se pudo obtener el token de seguridad.');
        return fetch('login.php', {
            method: 'POST',
            body: formData,
            credentials: 'same-origin',
            headers: { 'X-CSRF-Token': tokenData.csrf_token }
        });
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            mensaje.className = "success message-center";
            mensaje.textContent = data.message;

            // Redirigir al panel principal tras un segundo
            setTimeout(function() {
                window.location.href = data.redirect || "index.php";

}, 1000);

} else {
            mensaje.className = "error message-center";
            mensaje.textContent = data.message;

}

})
    .catch(error => {
        mensaje.className = "error message-center";
        mensaje.textContent = "Error en la comunicación con el servidor.";

});
});
