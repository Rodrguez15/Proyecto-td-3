/** Archivo: mis_clases.js — Interacciones del navegador relacionadas con mis clases. */
// ============================================================
// VILAMIR - MIS CLASES
// Muestra disciplinas inscritas + grupos + horarios del alumno.
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
    const box = document.getElementById('misClases');
    const msg = document.getElementById('mensajeMisClases');

    const esc = (value) => String(value ?? '').replace(
        /[&<>"']/g,
        (match) => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;',
            '"': '&quot;', "'": '&#039;'

}[match])
    );

    const hora = (value) => String(value || '').slice(0, 5);

    function mostrarMensaje(texto, error = false) {
        if (!msg) return;
        msg.textContent = texto || '';
        msg.className = error ? 'error message-center' : 'message-center';

}

    function horarioTexto(h) {
        return `${esc(h.Dia)} · ${hora(h.Hora_inicio)} - ${hora(h.Hora_fin)}`;

}

    function render(data) {
        const disciplinas = data.disciplinas || data.clases || [];
        const grupos = data.grupos || [];

        if (!disciplinas.length && !grupos.length) {
            box.innerHTML = '<p class="full-grid muted-center">Todavía no estás inscrito en ninguna disciplina o grupo.</p>';
            return;

}

        // Si hay grupos pero por alguna razón la disciplina no aparece en la tabla
        // de inscripciones, también los mostramos para no ocultar información real.
        const disciplinaMap = new Map();
        disciplinas.forEach(d => disciplinaMap.set(Number(d.ID_Disciplina), d));

        grupos.forEach(g => {
            const did = Number(g.ID_Disciplina || 0);
            if (did > 0 && !disciplinaMap.has(did)) {
                disciplinaMap.set(did, {
                    ID_Disciplina: did,
                    Nombre: g.Disciplina || 'Disciplina',
                    Descripcion: 'Disciplina asociada al grupo',
                    Estado: 'Activa',
                    Fecha_ins: g.Fecha_inscripcion,
                    Grupos: [g]

});

}

});

        box.innerHTML = Array.from(disciplinaMap.values()).map((d) => {
            const gruposDisciplina = d.Grupos || grupos.filter(g => Number(g.ID_Disciplina) === Number(d.ID_Disciplina));
            const gruposHtml = gruposDisciplina.length
                ? gruposDisciplina.map(g => `
                    <div class="mis-clases-group">
                        <div class="mis-clases-group-head">
                            <div>
                                <strong>${esc(g.Grupo)}</strong>
                                <span>${esc(g.Nivel || 'Nivel no indicado')}</span>
                            </div>
                            <b>Grupo activo</b>
                        </div>
                        ${g.Horarios && g.Horarios.length
                            ? `<div class="mis-clases-schedules">${
g.Horarios.map(h => `<span> ${horarioTexto(h)}</span>`).join('')
}</div>`
                            : '<p class="muted-center small-note">Este grupo todavía no tiene horarios asignados.</p>'}
                    </div>`).join('')
                : '<div class="mis-clases-unassigned"> Estás inscrito en esta disciplina, pero todavía no tenés un grupo asignado.</div>';

            return `
                <article class="member dynamic-card mis-clases-card">
                    <div class="mis-clases-title">
                        <div class="mis-clases-icon">🥋</div>
                        <div>
                            <h2>${esc(d.Nombre)}</h2>
                            <p>${esc(d.Descripcion || 'Disciplina de entrenamiento')}</p>
                        </div>
                        <span class="badge success">${esc(d.Estado || 'Activa')}</span>
                    </div>
                    <p class="mis-clases-date"><strong>Inscripción:</strong> ${esc(d.Fecha_ins || '—')}</p>
                    <div class="mis-clases-groups">${gruposHtml}</div>
                </article>
            `;

}).join('');

}

    async function cargar(intentos = 0) {
        mostrarMensaje(intentos ? 'Reintentando cargar tus clases…' : '');
        box.innerHTML = '<p class="full-grid muted-center">Cargando tus clases...</p>';

        try {
            const respuesta = await fetch(`api/mis_clases.php?t=${Date.now()}`, {
                cache: 'no-store',
                credentials: 'same-origin'

});
            const data = await respuesta.json();

            if (!respuesta.ok || data.status !== 'success') {
                throw new Error(data.message || 'No se pudieron cargar tus clases.');

}

            render(data);

} catch (error) {
            console.error(error);
            if (intentos < 2) {
                setTimeout(() => cargar(intentos + 1), 500);
                return;

}
            box.innerHTML = '<p class="full-grid muted-center">No se pudieron cargar tus clases.</p>';
            mostrarMensaje(error.message || 'Error en la comunicación con el servidor.', true);

}

}

    cargar();
});
