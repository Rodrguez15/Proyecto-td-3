/** Archivo: calendario.js — Interacciones y carga de datos del calendario. */
const escC=v=>String(v??'').replace(/[&<>"']/g,c=>({
'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'
}[c]));
let datosC=null,inicioSemana=new Date(),filtros={
disciplina:'0',grupo:'0',tipo:'todos'
};
const dias=['Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo'];
function inicioDeSemana(d){
const x=new Date(d);
x.setHours(0,0,0,0);
const n=(x.getDay()+6)%7;
x.setDate(x.getDate()-n);
return x;
}
function fechaLocal(v){
if(!v)return null;
const [y,m,d]=String(v).slice(0,10).split('-').map(Number);
return y&&m&&d?new Date(y,m-1,d):null;
}
function keyFecha(d){
return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}
function hora(v){
return v?String(v).slice(0,5):'';
}
function tituloSemana(){
const a=new Date(inicioSemana),b=new Date(inicioSemana);
b.setDate(b.getDate()+6);
const f=x=>x.toLocaleDateString('es-UY',{
day:'numeric',month:'short'
});
return `${f(a)} – ${f(b)} ${b.getFullYear()}`;
}
function poblarFiltros(){
 const d=document.getElementById('filtroDisciplina'),g=document.getElementById('filtroGrupo');
 if(!datosC||!d||!g)return;
 const oldD=filtros.disciplina,oldG=filtros.grupo;
 d.innerHTML='<option value="0">Todas</option>'+(datosC.disciplinas||[]).map(x=>`<option value="${x.ID_Disciplina}">${escC(x.Nombre)}</option>`).join('');
 g.innerHTML='<option value="0">Todos</option>'+(datosC.grupos||[]).map(x=>`<option value="${x.ID_Grupo}" data-disciplina="${x.ID_Disciplina}">${escC(x.Nombre)}${x.Disciplina?' — '+escC(x.Disciplina):''}</option>`).join('');
 d.value=oldD;
 g.value=oldG;
}
function renderCalendario(){
 const cal=document.getElementById('calendarioGeneral'),titulo=document.getElementById('tituloMes');
if(!cal||!datosC)return;
 titulo.textContent=tituloSemana();
 const h=datosC.horarios||[],s=datosC.seminarios||[],hoy=keyFecha(new Date());
 const fh=h.filter(x=>(filtros.grupo==='0'||String(x.ID_Grupo)===filtros.grupo)&&(filtros.disciplina==='0'||String(x.ID_Disciplina)===filtros.disciplina));
 const columnas=[];
 for(let i=0;i<7;i++){
  const d=new Date(inicioSemana);
d.setDate(d.getDate()+i);
const k=keyFecha(d);
  const clases=filtros.tipo==='eventos'?[]:fh.filter(x=>dias.findIndex(v=>v.toLowerCase()===String(x.Dia||'').toLowerCase())===i);
  const eventos=filtros.tipo==='clases'?[]:s.filter(x=>{
const f=fechaLocal(x.Fecha);return f&&keyFecha(f)===k;
});
  let contenido='';
  clases.sort((a,b)=>String(a.Hora_inicio).localeCompare(String(b.Hora_inicio))).forEach(x=>{
contenido+=`<div class="week-event class-event"><strong>🥋 ${escC(hora(x.Hora_inicio))}</strong><span>${escC(x.Disciplina||'Clase')}</span><small>Grupo: ${escC(x.Grupo||'')}</small><small>${escC(hora(x.Hora_inicio))} - ${escC(hora(x.Hora_fin))}</small></div>`;
});
  eventos.forEach(x=>{
contenido+=`<div class="week-event event-event"><strong>🎓 ${escC(x.Nombre||'Evento')}</strong>${x.Hora?`<small> ${
escC(hora(x.Hora))
}</small>`:''}${x.Lugar?`<small> ${
escC(x.Lugar)
}</small>`:''}${x.Costo!==undefined?`<small> ${
escC(x.Costo)
}</small>`:''}</div>`;
});
  if(!contenido)contenido='<div class="calendar-empty">Sin actividades</div>';
  columnas.push(`<article class="week-day ${k===hoy?'today':''}"><header><span>${dias[i]}</span><b>${d.getDate()}</b></header><div class="week-day-body">${contenido}</div></article>`);

}
 cal.innerHTML=`<div class="calendar-week-grid">${columnas.join('')}</div>`;
 const box=document.getElementById('proximasActividades'),hoyDate=new Date();
hoyDate.setHours(0,0,0,0);
 const upcoming=(filtros.tipo==='clases'?[]:s.filter(x=>{
const f=fechaLocal(x.Fecha);return f&&f>=hoyDate;
})).sort((a,b)=>fechaLocal(a.Fecha)-fechaLocal(b.Fecha)).slice(0,6);
 if(box)box.innerHTML=upcoming.length?upcoming.map(x=>`<article class="card upcoming-card"><h3>🎓 ${escC(x.Nombre||'Actividad')}</h3><p>${escC(x.Descripcion||'Actividad de VILAMIR')}</p><div><span class="badge">${escC(x.Fecha)}</span>${x.Hora?` <span class="badge"> ${
escC(hora(x.Hora))
}</span>`:''}</div>${x.Lugar?`<p> ${
escC(x.Lugar)
}</p>`:''}</article>`).join(''):'<div class="empty-state">No hay actividades próximas.</div>';
}
async function cargarCalendario(){
try{
const qs=new URLSearchParams({
disciplina:filtros.disciplina,grupo:filtros.grupo,tipo:filtros.tipo,t:Date.now()
});
const r=await fetch(`api/calendario.php?${qs}`,{
credentials:'same-origin',cache:'no-store'
});
const data=await r.json();
if(!r.ok||data.status!=='success')throw new Error(data.message||'No se pudo cargar el calendario.');
datosC=data;
poblarFiltros();
renderCalendario();
}catch(e){
const el=document.getElementById('calendarioGeneral');
if(el)el.innerHTML=`<div class="empty-state error">${escC(e.message)}</div>`;
}
}
function aplicarFiltros(){
filtros={
disciplina:document.getElementById('filtroDisciplina')?.value||'0',grupo:document.getElementById('filtroGrupo')?.value||'0',tipo:document.getElementById('filtroTipo')?.value||'todos'
};
cargarCalendario();
}
document.addEventListener('DOMContentLoaded',()=>{
inicioSemana=inicioDeSemana(new Date());document.getElementById('prevMes')?.addEventListener('click',()=>{
inicioSemana.setDate(inicioSemana.getDate()-7);renderCalendario();
});document.getElementById('nextMes')?.addEventListener('click',()=>{
inicioSemana.setDate(inicioSemana.getDate()+7);renderCalendario();
});document.getElementById('hoyMes')?.addEventListener('click',()=>{
inicioSemana=inicioDeSemana(new Date());renderCalendario();
});document.getElementById('filtroDisciplina')?.addEventListener('change',aplicarFiltros);document.getElementById('filtroGrupo')?.addEventListener('change',aplicarFiltros);document.getElementById('filtroTipo')?.addEventListener('change',aplicarFiltros);document.getElementById('limpiarFiltros')?.addEventListener('click',()=>{
filtros={
disciplina:'0',grupo:'0',tipo:'todos'
};poblarFiltros();renderCalendario();
});cargarCalendario();
});
