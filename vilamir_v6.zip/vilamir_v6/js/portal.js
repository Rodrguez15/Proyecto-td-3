/** Archivo: portal.js — Comportamiento del portal del alumno: cuenta, inscripciones y datos personales. */
function pctClassPortal(v){
const n=Math.max(0,Math.min(100,Math.round(Number(v||0)/5)*5));
return `progress-pct-${n}`;
}
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({
'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'
}[c]));
const hora=v=>String(v??'').slice(0,5);
const money=v=>`$${Number(v||0).toFixed(2)}`;
// Fecha local YYYY-MM-DD: evita que UTC adelante o atrase el vencimiento cerca de medianoche.
function fechaLocalYMD(fecha=new Date()){
const anio=fecha.getFullYear();
const mes=String(fecha.getMonth()+1).padStart(2,'0');
const dia=String(fecha.getDate()).padStart(2,'0');
return `${anio}-${mes}-${dia}`;
}
async function api(url,opt={
}){
const r=await fetch(url,{
cache:'no-store',credentials:'same-origin',...opt
});
let d;
try{
d=await r.json();
}catch(e){
throw new Error('Respuesta inválida del servidor');
}if(!r.ok)throw new Error(d.message||'Error del servidor');
return d;
}
function stat(icon,label,value,extra=''){
return `<article class="account-stat"><span class="stat-icon">${icon}</span><div><span>${label}</span><strong>${value}</strong>${extra?`<small>${
extra
}</small>`:''}</div></article>`
}
function empty(text){
return `<div class="account-empty"><span>○</span><p>${text}</p></div>`
}
let accountMessageTimer=null;
function setMessage(text,error=false){
const el=document.getElementById('accountMessage');
if(!el)return;
if(accountMessageTimer!==null)clearTimeout(accountMessageTimer);
el.textContent=text;
el.className='account-message '+(error?'error':'success');
el.hidden=!text;
if(text)accountMessageTimer=setTimeout(()=>{el.hidden=true;accountMessageTimer=null;},4500);
}
function mostrarErrorCargaPortal(error){
  const texto='No se pudieron cargar los datos de tu cuenta. Verificá que XAMPP y MySQL estén activos y volvé a intentar.';
  setMessage(texto,true);
  const ids=['perfil','estadoActividad','proximasClases','notificaciones','disciplinas','promociones','proximosEventos','resumenPagosAlumno','pagos','seminarios','historialPagos','historialActividades','historialAsistencia','certificadosAlumno'];
  ids.forEach(id=>{const el=document.getElementById(id);if(el)el.innerHTML=empty('No se pudieron cargar estos datos. Intentá nuevamente.');});
  const qr=document.getElementById('qrAlumno');if(qr)qr.textContent='QR no disponible';
  const resumen=document.getElementById('resumenCards');
  if(resumen){
    resumen.innerHTML=`${stat('','Estado','No disponible')}<button type="button" class="account-btn" id="retryPortalLoad">Reintentar carga</button>`;
    const retry=document.getElementById('retryPortalLoad');
    if(retry)retry.addEventListener('click',()=>{retry.disabled=true;load();});
  }
  if(error)console.error('Error al cargar Mi cuenta:',error);
}
function estadoPago(pagos){
if(!pagos.length)return ['Sin pagos','No hay registros'];
const hoy=fechaLocalYMD();
const venc=pagos.find(p=>String(p.Estado||'').toLowerCase().includes('pend')&&p.Fecha_vencimiento&&String(p.Fecha_vencimiento)<hoy);
if(venc)return ['Vencido','Hay un pago fuera de fecha'];
const pend=pagos.find(p=>{
const e=String(p.Estado||'').toLowerCase();return !e.includes('pag')&&!e.includes('anul');
});
return pend?['Pendiente','Hay un pago por revisar']:['Al día','Tus pagos registrados están al día'];
}
async function load(intentos=0){
 try{
  // El resumen es obligatorio; horarios es complementario. Las promociones no
  // deben bloquear Mi cuenta si esa tabla/migración todavía no está disponible.
  const r=await api(`api/portal.php?entity=resumen&t=${Date.now()}`);
  if(!r || r.status!=='success')throw new Error((r&&r.message)||'El servidor no pudo devolver el resumen de tu cuenta.');
  let h={status:'success',rows:[]};
  try{
    h=await api(`api/portal.php?entity=horarios&t=${Date.now()}`);
    if(!h || h.status!=='success')throw new Error((h&&h.message)||'No se pudieron consultar los horarios.');
  }catch(e){
    // Los horarios son complementarios: el resto del portal debe seguir disponible.
    console.warn('Horarios no disponibles:',e);
    h={status:'error',rows:[]};
    setMessage('Tu cuenta cargó, pero no se pudieron consultar los horarios.',true);
  }
  const perfil=r.perfil||{}, grupos=(h.rows||[]).filter(x=>Number(x.MiGrupo)), gruposUnicos=[...new Map(grupos.map(x=>[String(x.ID_Grupo),x])).values()], pagos=r.pagos||[], resumenPagos=r.resumen_pagos||{}, disciplinas=r.disciplinas||[], seminarios=r.seminarios||[], disciplinasActivas=disciplinas.filter(x=>!x.Estado||String(x.Estado).toLowerCase()==='activa'), seminariosActivos=seminarios.filter(x=>!x.Estado||String(x.Estado).toLowerCase()==='activa'), notificaciones=r.notificaciones||[], certificados=r.certificados||[], promociones=r.promociones||[], proximasActividades=r.proximas_actividades||[], at=r.asistencia||{};
  const total=Number(at.total||0), presentes=Number(at.presentes||0), justificados=Number(at.justificados||0), pct=total?Math.round(((presentes+justificados)/total)*100):0;
  const [pagoEstado,pagoDetalle]=estadoPago(pagos);
  document.getElementById('resumenCards').innerHTML=[stat('🥋','Disciplinas',disciplinasActivas.length,'activas'),stat('','Clases asignadas',gruposUnicos.length,'grupos'),stat('🎓','Actividades',seminariosActivos.length,'activas'),stat('','Asistencia',pct+'%',total?`${presentes} presentes`:'Sin registros')].join('');
  document.getElementById('perfil').innerHTML=`<div class="profile-name">${esc(perfil.Nombre)} ${esc(perfil.Apellido)}</div><div class="profile-grid"><div><small>Correo</small><b>${esc(perfil.Email||'No informado')}</b></div><div><small>Teléfono</small><b>${esc(perfil.Telefono||'No informado')}</b></div><div><small>Fecha de nacimiento</small><b>${esc(perfil.Fecha_nacimiento||'No informada')}</b></div><div><small>Cobertura médica</small><b>${esc(perfil.Cobertura_medica||'No informada')}</b></div><div class="profile-wide"><small>Dirección</small><b>${esc(perfil.Direccion||'No informada')}</b></div></div>`;
  const formPerfil=document.getElementById('formEditarPerfil');
  if(formPerfil){
    const campos={nombre:perfil.Nombre||'',apellido:perfil.Apellido||'',email:perfil.Email||'',telefono:perfil.Telefono||'',fecha_nacimiento:String(perfil.Fecha_nacimiento||'').slice(0,10),direccion:perfil.Direccion||'',cobertura_medica:perfil.Cobertura_medica||''};
    Object.entries(campos).forEach(([campo,valor])=>{if(formPerfil.elements[campo])formPerfil.elements[campo].value=valor;});
  }
  const pagados=pagos.filter(p=>String(p.Estado||'').toLowerCase().includes('pag')).reduce((a,p)=>a+Number(p.Importe||p.Monto||0),0);
  const pendientes=pagos.filter(p=>{
const e=String(p.Estado||'').toLowerCase();return e.includes('pend')||e.includes('venc');
}).reduce((a,p)=>a+Number(p.Importe||p.Monto||0),0);
  document.getElementById('resumenPagosAlumno').innerHTML=`<div class="payment-account-head"><div><span>Este mes</span><b>${money(resumenPagos.cobrado_mes)}</b></div><div><span>Pendiente</span><b>${money(resumenPagos.pendiente_total)}</b></div><div><span>Vencido</span><b>${money(resumenPagos.vencido_total)}</b></div></div>`;
  document.getElementById('estadoActividad').innerHTML=`<div class="activity-row"><span>Asistencia</span><b>${pct}%</b></div><div class="progress"><i class="progress-fill ${pctClassPortal(pct)}"></i></div><div class="activity-row"><span>Estado de pagos</span><b>${esc(pagoEstado)}</b></div><small class="activity-note">${esc(pagoDetalle)}</small><div class="activity-row"><span>Total cobrado</span><b>${money(pagados)}</b></div><div class="activity-row"><span>Importe pendiente</span><b>${money(pendientes)}</b></div><div class="activity-row"><span>Notificaciones</span><b>${notificaciones.length}</b></div>`;
  document.getElementById('proximasClases').innerHTML=grupos.length?grupos.slice(0,6).map(x=>`<div class="account-row"><div class="class-time"><b>${hora(x.Hora_inicio)}</b><span>${esc(x.Dia)}</span></div><div class="row-main"><strong>${esc(x.Disciplina||'Clase')}</strong><small>${esc(x.Grupo)} · ${hora(x.Hora_inicio)} - ${hora(x.Hora_fin)}</small></div><span class="row-icon">🥋</span></div>`).join(''):empty('Todavía no tenés grupos asignados.');
  document.getElementById('notificaciones').innerHTML=notificaciones.length?notificaciones.slice(0,5).map(x=>`<div class="account-row notification-row ${Number(x.Leida)?'read':''}"><span class="notification-dot"></span><div class="row-main"><strong>${esc(x.Mensaje)}</strong><small>${esc(x.Fecha)} · ${esc(x.Estado)}</small></div>${Number(x.Leida)?'<span class="badge">Leída</span>':`<button class="account-cancel" onclick="leerNotificacion(${Number(x.ID_Notificacion)})">Marcar leída</button>`}</div>`).join(''):empty('No tenés notificaciones.');
  document.getElementById('disciplinas').innerHTML=disciplinas.length?disciplinas.map(x=>`<article class="account-mini-card"><div class="mini-icon">🥋</div><div><strong>${esc(x.Nombre)}</strong><p>${esc(x.Descripcion||'Disciplina de entrenamiento')}</p><span class="badge success">${esc(x.Estado||'Activa')}</span></div></article>`).join(''):empty('No estás inscripto en disciplinas.');
  document.getElementById('pagos').innerHTML=pagos.length?pagos.slice(0,6).map(x=>{
const est=String(x.Estado||'Pendiente');const venc=est.toLowerCase().includes('pend')&&x.Fecha_vencimiento&&String(x.Fecha_vencimiento)<fechaLocalYMD();const etiqueta=venc?'Vencido':est;const clase=venc?'danger':est.toLowerCase().includes('pag')?'success':'warning';return `<div class="account-row"><div class="payment-icon"></div><div class="row-main"><strong>${esc(x.Tipo)}</strong><small>${esc(x.Fecha)}${x.Fecha_vencimiento?' · Vence: '+esc(x.Fecha_vencimiento):''}${x.Metodo_pago?' · '+esc(x.Metodo_pago):''}</small></div><div class="payment-value"><b>${money(x.Importe)}</b><span class="badge ${clase}">${esc(etiqueta)}</span><a class="account-link payment-receipt-link" href="comprobante_pago.php?id=${Number(x.ID_Pago)}" target="_blank" rel="noopener noreferrer">Comprobante</a></div></div>`
}).join(''):empty('No hay pagos registrados.');
  document.getElementById('seminarios').innerHTML=seminarios.length?seminarios.slice(0,6).map(x=>{
    const estado=String(x.Estado||'Activa');
    const activa=estado.toLowerCase()==='activa';
    const accion=activa?`<button class="account-cancel" type="button" onclick="cancelar('seminario',${Number(x.ID_Ins_seminario)})">Cancelar</button>`:`<span class="badge">${esc(estado)}</span>`;
    return `<article class="account-mini-card event-card"><div class="event-date"><b>${esc(String(x.Fecha||'').slice(8,10)||'--')}</b><span>${esc(String(x.Fecha||'').slice(5,7)||'--')}</span></div><div><strong>${esc(x.Nombre)}</strong><p>${esc(x.Descripcion||'Actividad de VILAMIR')}</p><span class="badge">${money(x.Costo)}</span> ${accion}</div></article>`;
  }).join(''):empty('No tenés seminarios o eventos inscriptos.');
  document.getElementById('promociones').innerHTML=promociones.length?promociones.map(x=>`<article class="account-mini-card promotion-card"><div class="mini-icon">🏷️</div><div><strong>${esc(x.Nombre||'Promoción')}</strong><p>${esc(x.Descripcion||x.Beneficio||'Beneficio disponible para alumnos.')}</p><span class="badge success">${x.Porcentaje_descuento?esc(x.Porcentaje_descuento)+'% OFF':x.Descuento?money(x.Descuento)+' de descuento':'Disponible'}</span></div></article>`).join(''):empty('No hay promociones activas en este momento.');
  document.getElementById('proximosEventos').innerHTML=proximasActividades.length?proximasActividades.map(x=>`<div class="account-row"><div class="class-time"><b>${esc(String(x.Fecha||'').slice(8,10)||'--')}</b><span>${esc(String(x.Fecha||'').slice(5,7)||'--')}</span></div><div class="row-main"><strong>${esc(x.Nombre||'Actividad')}</strong><small>${esc(x.Lugar||'VILAMIR')}${x.Hora?' · '+hora(x.Hora):''} · ${money(x.Costo)}</small></div><a class="account-link" href="seminarios.php">Ver</a></div>`).join(''):empty('No hay próximos eventos publicados.');
  document.getElementById('certificadosAlumno').innerHTML=certificados.length?certificados.map(c=>`<article class="account-mini-card certificate-card"><div class="mini-icon">🏅</div><div><strong>${esc(c.Titulo)}</strong><p>${esc(c.Descripcion||'Certificado de participación')}</p><small>Emitido: ${esc(c.Fecha_emision)}</small></div><a class="account-btn account-btn-small" href="certificado.php?id=${Number(c.ID_Certificado)}" target="_blank" rel="noopener noreferrer">PDF</a></article>`).join(''):empty('Todavía no tenés certificados emitidos.');
  const historialAsistencia=r.historial_asistencia||[];
  document.getElementById('historialPagos').innerHTML=pagos.length?pagos.map(x=>{
const est=String(x.Estado||'Pendiente');const venc=x.Fecha_vencimiento&&est.toLowerCase().includes('pend')&&x.Fecha_vencimiento < fechaLocalYMD();return `<div class="account-row"><div class="row-main"><strong>${esc(x.Tipo)}</strong><small>Pago: ${esc(x.Fecha)}${x.Fecha_vencimiento?' · Vence: '+esc(x.Fecha_vencimiento):''}</small></div><div class="payment-value"><b>${money(x.Importe)}</b><span class="badge ${venc?'danger':est.toLowerCase().includes('pag')?'success':'warning'}">${esc(venc?'Vencido':est)}</span><a class="account-link payment-receipt-link" href="comprobante_pago.php?id=${Number(x.ID_Pago)}" target="_blank" rel="noopener noreferrer">Comprobante</a></div></div>`
}).join(''):empty('No hay pagos registrados.');
  document.getElementById('historialActividades').innerHTML=seminarios.length?seminarios.map(x=>`<div class="account-row"><div class="row-main"><strong>${esc(x.Nombre)}</strong><small>${esc(x.Fecha||'Fecha no informada')} · ${esc(x.Estado||'Activa')}</small></div><span class="badge">${money(x.Costo)}</span></div>`).join(''):empty('No hay actividades registradas.');
  document.getElementById('historialAsistencia').innerHTML=historialAsistencia.length?historialAsistencia.map(x=>{
const est=String(x.Estado||'');const cls=est==='Presente'?'success':est==='Justificado'?'warning':'danger';return `<div class="account-row"><div class="row-main"><strong>${esc(x.Disciplina||'Clase')} · ${esc(x.Grupo||'Grupo')}</strong><small>${esc(x.Fecha)}${x.Observacion?' · '+esc(x.Observacion):''}</small></div><span class="badge ${cls}">${esc(est)}</span></div>`
}).join(''):empty('Todavía no hay asistencia registrada.');
  const qr=document.getElementById('qrAlumno');
qr.innerHTML='';
if(perfil.Codigo_qr&&window.QRCode){
new QRCode(qr,{
text:location.origin+location.pathname.replace('portal.php','perfil_publico.php')+'?codigo='+encodeURIComponent(perfil.Codigo_qr),width:145,height:145
});
const carnetLink=document.getElementById('linkCarnetDigital');
if(carnetLink){
  carnetLink.href='carnet_digital.php?codigo='+encodeURIComponent(perfil.Codigo_qr);
  carnetLink.style.display='inline-flex';
}
}else{
qr.innerHTML='<span class="qr-unavailable">QR no disponible</span>';
}

}catch(e){
  if(intentos<2){
    setTimeout(()=>load(intentos+1),500);
    return;
  }
  mostrarErrorCargaPortal(e);
}
}
const cancelacionesEnCurso=new Set();
async function cancelar(tipo,id){
const numeroId=Number(id);
if(!['seminario','disciplina'].includes(tipo)||!Number.isSafeInteger(numeroId)||numeroId<=0){
setMessage('No se pudo identificar la inscripción que querés cancelar.',true);
return;
}
const clave=`${tipo}:${numeroId}`;
if(cancelacionesEnCurso.has(clave))return;
if(!confirm('¿Querés cancelar esta inscripción?'))return;
cancelacionesEnCurso.add(clave);
try{
const f=new FormData();
f.append('accion',`cancelar_${tipo}`);
f.append('id',String(numeroId));
const d=await api('api/portal.php',{
method:'POST',body:f
});
setMessage(d.message||'Operación finalizada',d.status!=='success');
if(d.status==='success')await load();
}catch(e){
setMessage(e.message||'No se pudo cancelar la inscripción.',true);
}finally{
cancelacionesEnCurso.delete(clave);
}
}
const btnEditarPerfil=document.getElementById('toggleEditarPerfil');
const formEditarPerfil=document.getElementById('formEditarPerfil');
const btnCancelarPerfil=document.getElementById('cancelarEditarPerfil');
if(btnEditarPerfil&&formEditarPerfil){
  btnEditarPerfil.addEventListener('click',()=>{formEditarPerfil.hidden=!formEditarPerfil.hidden;btnEditarPerfil.textContent=formEditarPerfil.hidden?' Editar mis datos':'Cerrar edición';});
  if(btnCancelarPerfil)btnCancelarPerfil.addEventListener('click',()=>{formEditarPerfil.hidden=true;btnEditarPerfil.textContent=' Editar mis datos';load();});
  formEditarPerfil.addEventListener('submit',async(ev)=>{
    ev.preventDefault();
    const submit=formEditarPerfil.querySelector('button[type="submit"]');
    submit.disabled=true;
    try{
      const datos=new FormData(formEditarPerfil);datos.append('accion','actualizar_perfil');
      const r=await api('api/portal.php',{method:'POST',body:datos});
      setMessage(r.message||'Datos actualizados.',r.status!=='success');
      if(r.status==='success'){formEditarPerfil.hidden=true;btnEditarPerfil.textContent=' Editar mis datos';await load();}
    }catch(e){setMessage(e.message||'No se pudieron guardar los datos.',true);}
    finally{submit.disabled=false;}
  });
}
const formCambiarContrasena=document.getElementById('formCambiarContrasena');
const btnCambiarContrasena=document.getElementById('toggleCambiarContrasena');
const btnCancelarContrasena=document.getElementById('cancelarCambiarContrasena');
if(formCambiarContrasena&&btnCambiarContrasena){
  btnCambiarContrasena.addEventListener('click',()=>{
    formCambiarContrasena.hidden=!formCambiarContrasena.hidden;
    btnCambiarContrasena.textContent=formCambiarContrasena.hidden?' Cambiar contraseña':'Cerrar formulario';
  });
  if(btnCancelarContrasena)btnCancelarContrasena.addEventListener('click',()=>{
    formCambiarContrasena.reset();
    formCambiarContrasena.hidden=true;
    btnCambiarContrasena.textContent=' Cambiar contraseña';
  });
  formCambiarContrasena.addEventListener('submit',async(ev)=>{
    ev.preventDefault();
    const nueva=formCambiarContrasena.elements.contrasena_nueva.value;
    const confirmar=formCambiarContrasena.elements.confirmar_contrasena.value;
    if(nueva.length<8){setMessage('La nueva contraseña debe tener al menos 8 caracteres.',true);return;}
    if(nueva!==confirmar){setMessage('La confirmación no coincide con la nueva contraseña.',true);return;}
    const submit=formCambiarContrasena.querySelector('button[type="submit"]');
    submit.disabled=true;
    try{
      const datos=new FormData(formCambiarContrasena);datos.append('accion','cambiar_contrasena');
      const r=await api('api/portal.php',{method:'POST',body:datos});
      setMessage(r.message||'Contraseña actualizada.',r.status!=='success');
      if(r.status==='success'){formCambiarContrasena.reset();formCambiarContrasena.hidden=true;btnCambiarContrasena.textContent=' Cambiar contraseña';}
    }catch(e){setMessage(e.message||'No se pudo cambiar la contraseña.',true);}
    finally{submit.disabled=false;}
  });
}

load();

async function leerNotificacion(id){
try{
const f=new FormData();
f.append('accion','leer_notificacion');
f.append('id',id);
const d=await api('api/portal.php',{
method:'POST',body:f
});
setMessage(d.message||'Notificación actualizada',d.status!=='success');
if(d.status==='success')load();
}catch(e){
setMessage('No se pudo actualizar la notificación.',true);
}
}
async function leerTodasNotificaciones(){
try{
const f=new FormData();
f.append('accion','leer_todas_notificaciones');
const d=await api('api/portal.php',{
method:'POST',body:f
});
setMessage(d.message||'Notificaciones actualizadas',d.status!=='success');
if(d.status==='success')load();
}catch(e){
setMessage('No se pudieron actualizar las notificaciones.',true);
}
}
// Manejador para activar Pase Libre Total automáticamente
const btnPaseLibre = document.getElementById('btnActivarPaseLibre');
if (btnPaseLibre) {
    btnPaseLibre.addEventListener('click', async () => {
        const confirma = confirm("¿Confirmas la activación del PASE LIBRE TOTAL por $2.500 UYU al mes?\n\nTe matriculará automáticamente en todas las disciplinas y grupos de la academia.");
        if (!confirma) return;

        btnPaseLibre.disabled = true;
        btnPaseLibre.textContent = "⏳ Matriculando en todas las clases…";

        try {
            const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
            const fd = new FormData();
            fd.set('accion', 'inscribir_pase_libre');
            if (csrf) fd.set('csrf_token', csrf);

            const res = await fetch('api/inscripciones.php', {
                method: 'POST',
                body: fd,
                headers: { 'X-CSRF-Token': csrf }
            });
            const data = await res.json();

            if (data.status === 'success') {
                alert("✔ " + data.message);
                // Recargar el portal para ver todas las disciplinas y grupos activos
                window.location.reload();
            } else {
                alert("✖ " + (data.message || 'Error al procesar la solicitud.'));
            }
        } catch (err) {
            console.error(err);
            alert("Error de conexión al activar el Pase Libre.");
        } finally {
            btnPaseLibre.disabled = false;
            btnPaseLibre.textContent = "⚡ Activar Pase Libre Total";
        }
    });
}
// ============================================================
// GESTIÓN DINÁMICA DE PLANES Y PROMOCIONES (RN-06 / TC-05)
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
    const contenedorPlan = document.getElementById('contenedorPlanActual');
    const modal = document.getElementById('modalSelectorPlanes');
    const btnAbrir = document.getElementById('btnAbrirModalPlanes');
    const btnCerrar = document.getElementById('btnCerrarModalPlanes');
    const btnCancelar = document.getElementById('btnCancelarModalPlanes');
    const selectPlan = document.getElementById('selectTipoPlan');
    const contenedorChecks = document.getElementById('listaCheckDisciplinas');
    const labelInstruccion = document.getElementById('labelInstruccionDisciplinas');
    const labelMonto = document.getElementById('montoTotalPlanModal');
    const formPaquete = document.getElementById('formSeleccionPaquete');

    let catalogoDisciplinas = [];

    // 1. Detectar el plan activo según las disciplinas cargadas
    function actualizarTarjetaPlanActivo(disciplinasActivas) {
        if (!contenedorPlan) return;
        const cant = disciplinasActivas.length;

        let badge = '';
        let titulo = '';
        let precio = '';
        let ahorro = '';
        let border = '#333';
        let bgGrad = 'linear-gradient(145deg, #18181c, #111114)';

        if (cant === 0) {
            contenedorPlan.innerHTML = `
                <div style="padding:15px; border:1px dashed #444; border-radius:10px; text-align:center; color:#aaa;">
                    Actualmente no estás inscripto en ninguna disciplina. Hacé clic en <strong>"Cambiar de Plan"</strong> para elegir una promo.
                </div>
            `;
            return;
        } else if (cant === 1) {
            badge = '<span class="badge" style="background:#444; color:#fff;">PLAN BÁSICO</span>';
            titulo = `Plan Individual (1 Disciplina: ${disciplinasActivas[0].Nombre})`;
            precio = '$1.500 UYU / mes';
            ahorro = 'Precio regular estándar.';
            border = '#444';
        } else if (cant === 2) {
            badge = '<span class="badge" style="background:#d71920; color:#fff;">PROMOCIÓN 2 DISCIPLINAS 🔥</span>';
            titulo = `Plan Combinado (2 Disciplinas: ${disciplinasActivas.map(d=>d.Nombre).join(' + ')})`;
            precio = '$1.900 UYU / mes';
            ahorro = '¡Ahorrás $1.100 UYU al mes con la promoción de doble disciplina!';
            border = '#d71920';
            bgGrad = 'linear-gradient(145deg, #241416, #140d0e)';
        } else if (cant === 3) {
            badge = '<span class="badge" style="background:#ff5b5b; color:#fff;">PROMOCIÓN 3 DISCIPLINAS ⭐</span>';
            titulo = `Plan Avanzado (3 Disciplinas: ${disciplinasActivas.map(d=>d.Nombre).join(' + ')})`;
            precio = '$2.100 UYU / mes';
            ahorro = '¡Ahorrás $2.400 UYU al mes con la promoción de triple disciplina!';
            border = '#ff5b5b';
            bgGrad = 'linear-gradient(145deg, #2b1418, #140d0e)';
        } else {
            badge = '<span class="badge" style="background:#b8860b; color:#fff;">PASE LIBRE TOTAL 👑</span>';
            titulo = `Pase Libre Completo (${cant} Disciplinas Activas)`;
            precio = '$2.500 UYU / mes';
            ahorro = '¡Acceso ilimitado a todas las clases y horarios de la academia!';
            border = '#ffd700';
            bgGrad = 'linear-gradient(145deg, #241d0e, #141108)';
        }

        contenedorPlan.innerHTML = `
            <div style="border: 2px solid ${border}; background: ${bgGrad}; border-radius: 14px; padding: 18px; box-shadow: 0 6px 20px rgba(0,0,0,0.3);">
                <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
                    <div>
                        ${badge}
                        <h3 style="margin: 8px 0 4px; color:#fff; font-size:1.2rem;">${titulo}</h3>
                        <p style="margin: 0; color:#39d98a; font-weight:750; font-size:13px;">${ahorro}</p>
                    </div>
                    <div style="text-align:right;">
                        <span style="font-size:11px; color:#aaa; text-transform:uppercase; display:block;">Cuota mensual</span>
                        <strong style="font-size:1.6rem; color:#fff;">${precio}</strong>
                    </div>
                </div>
            </div>
        `;
    }

    // Interceptar la carga de datos del portal para alimentar la tarjeta de promociones
    const originalRender = window.actualizarInterfazPortal;
    // Si portal.js ya tiene las disciplinas cargadas en memoria:
    const chequearDisciplinasCargadas = setInterval(() => {
        const tarjetas = document.querySelectorAll('#disciplinas .account-mini-card');
        if (tarjetas.length > 0) {
            clearInterval(chequearDisciplinasCargadas);
            const discs = Array.from(tarjetas).map(t => ({
                Nombre: t.querySelector('strong')?.textContent.trim() || 'Disciplina'
            }));
            actualizarTarjetaPlanActivo(discs);
        }
    }, 400);

    // 2. Cargar lista de disciplinas en el modal
    async function cargarCatalogoModal() {
        try {
            const r = await fetch('api/inscripciones.php');
            const d = await r.json();
            if (d.status === 'success' && d.clases) {
                catalogoDisciplinas = d.clases;
                dibujarChecks();
            }
        } catch (e) {
            console.error(e);
        }
    }

    function dibujarChecks() {
        if (!contenedorChecks) return;
        const plan = selectPlan.value;
        contenedorChecks.innerHTML = '';

        catalogoDisciplinas.forEach(c => {
            const id = c.ID_Disciplina;
            const nombre = c.Nombre;
            const esActiva = (c.Inscrito == 1);

            const div = document.createElement('div');
            div.style.cssText = "background:#1a1a20; padding:10px 12px; border-radius:8px; border:1px solid #333; display:flex; align-items:center; gap:8px;";
            div.innerHTML = `
                <input type="checkbox" id="chkDisc_${id}" name="disciplinas[]" value="${id}" ${plan === 'libre' ? 'checked disabled' : (esActiva ? 'checked' : '')}>
                <label for="chkDisc_${id}" style="margin:0; cursor:pointer; font-size:13px; color:#eee;">${nombre}</label>
            `;
            contenedorChecks.appendChild(div);
        });

        actualizarReglasLimites();
    }

    function actualizarReglasLimites() {
        const plan = selectPlan.value;
        const checks = contenedorChecks.querySelectorAll('input[type="checkbox"]');

        if (plan === 'libre') {
            labelInstruccion.textContent = "Disciplinas incluidas (Todas):";
            labelMonto.textContent = "$2.500 UYU";
            checks.forEach(c => { c.checked = true; c.disabled = true; });
        } else {
            const max = parseInt(plan);
            labelInstruccion.textContent = `Elegí exactamente ${max} disciplina(s):`;
            labelMonto.textContent = (plan === '1' ? '$1.500' : (plan === '2' ? '$1.900' : '$2.100')) + ' UYU';

            checks.forEach(c => {
                c.disabled = false;
                c.onchange = () => {
                    const marcados = Array.from(checks).filter(ch => ch.checked);
                    if (marcados.length > max) {
                        c.checked = false;
                        alert(`Solo podés seleccionar ${max} disciplina(s) para este plan.`);
                    }
                };
            });
        }
    }

    if (selectPlan) {
        selectPlan.addEventListener('change', () => {
            dibujarChecks();
        });
    }

    // Controles del Modal
    const abrir = () => { cargarCatalogoModal(); if (modal) modal.style.display = 'flex'; };
    const cerrar = () => { if (modal) modal.style.display = 'none'; };

    if (btnAbrir) btnAbrir.addEventListener('click', abrir);
    if (btnCerrar) btnCerrar.addEventListener('click', cerrar);
    if (btnCancelar) btnCancelar.addEventListener('click', cerrar);

    // Enviar formulario de paquete
    if (formPaquete) {
        formPaquete.addEventListener('submit', async (e) => {
            e.preventDefault();
            const btnSub = document.getElementById('btnConfirmarPaquete');
            const plan = selectPlan.value;

            // Validación cliente
            if (plan !== 'libre') {
                const max = parseInt(plan);
                const marcados = contenedorChecks.querySelectorAll('input[type="checkbox"]:checked');
                if (marcados.length !== max) {
                    alert(`Por favor, seleccioná exactamente ${max} disciplina(s). Actualmente tenés ${marcados.length} marcada(s).`);
                    return;
                }
            }

            btnSub.disabled = true;
            btnSub.textContent = "Aplicando suscripción…";

            try {
                const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
                const fd = new FormData(formPaquete);
                fd.set('accion', 'inscribir_paquete');
                if (csrf) fd.set('csrf_token', csrf);

                const res = await fetch('api/inscripciones.php', {
                    method: 'POST',
                    body: fd,
                    headers: { 'X-CSRF-Token': csrf }
                });
                const data = await res.json();

                if (data.status === 'success') {
                    alert("✔ " + data.message);
                    window.location.reload();
                } else {
                    alert("✖ " + (data.message || 'Error al procesar la solicitud.'));
                }
            } catch (err) {
                console.error(err);
                alert("Error de conexión al aplicar el plan.");
            } finally {
                btnSub.disabled = false;
                btnSub.textContent = "Confirmar y Aplicar Promoción";
            }
        });
    }
});