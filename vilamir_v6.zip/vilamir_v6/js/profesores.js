/** Archivo: profesores.js — Interacciones del navegador relacionadas con profesores. */
// ============================================================
// GESTIÓN DE PROFESORES - Escuela de Combate VILAMIR
// Persistencia en servidor vía api/profesores.php (GET/POST JSON).
// Renderizado seguro: createElement + textContent (sin XSS).
// ============================================================

document.addEventListener("DOMContentLoaded", function () {
    const btnGuardar = document.getElementById("btnGuardarProfesor");
    const listaDiv = document.getElementById("listaProfesores");
    const mensajeEl = document.getElementById("mensajeProfesor");

    function mostrarMensaje(texto, esError) {
        if (!mensajeEl) return;
        mensajeEl.className = esError ? "error message-center" : "success message-center";
        mensajeEl.textContent = texto;

}

    function crearTarjeta(profesor) {
        const div = document.createElement("div");

        const h3 = document.createElement("h3");

        h3.textContent = (profesor.Nombre || "") + " " + (profesor.Apellido || "");

        const span = document.createElement("span");
        span.className = "role";

        span.textContent = profesor.Especialidad || "";

        const p = document.createElement("p");

        p.textContent = profesor.Email || "";

        div.appendChild(h3);
        div.appendChild(span);
        div.appendChild(p);
        return div;

}

    function renderProfesores(profesores) {
        listaDiv.innerHTML = "";

        if (!profesores || profesores.length === 0) {
            const div = document.createElement("div");

            const p = document.createElement("p");

            p.textContent = "No hay profesores registrados en el cuerpo docente actual.";
            div.appendChild(p);
            listaDiv.appendChild(div);
            return;

}

        const contenedor = document.createElement("div");
        contenedor.className = "cards-grid";

        profesores.forEach(function (profesor) {
            contenedor.appendChild(crearTarjeta(profesor));

});
        listaDiv.appendChild(contenedor);

}

    function cargarProfesores() {
        fetch("api/profesores.php")
            .then(function (r) {
 return r.json();
})
            .then(function (data) {
                if (data.status === "success") {
                    renderProfesores(data.profesores);

} else {
                    mostrarMensaje(data.message || "Error al cargar profesores.", true);

}

})
            .catch(function () {
                mostrarMensaje("Error en la comunicación con el servidor.", true);

});

}

    if (btnGuardar) {
        btnGuardar.addEventListener("click", function () {
            const nombre = document.getElementById("nombreProfesor").value.trim();
            const apellido = document.getElementById("apellidoProfesor").value.trim();
            const especialidad = document.getElementById("especialidadProfesor").value.trim();
            const email = document.getElementById("emailProfesor").value.trim();

            if (!nombre || !apellido || !especialidad || !email) {
                mostrarMensaje("Completa todos los campos para registrar al profesor.", true);
                return;

}

            const formData = new FormData();
            formData.append("nombre", nombre);
            formData.append("apellido", apellido);
            formData.append("especialidad", especialidad);
            formData.append("email", email);

            fetch("api/profesores.php", {
 method: "POST", body: formData
})
                .then(function (r) {
 return r.json();
})
                .then(function (data) {
                    if (data.status === "success") {
                        mostrarMensaje(data.message, false);
                        document.getElementById("nombreProfesor").value = "";
                        document.getElementById("apellidoProfesor").value = "";
                        document.getElementById("especialidadProfesor").value = "";
                        document.getElementById("emailProfesor").value = "";
                        cargarProfesores();

} else {
                        mostrarMensaje(data.message, true);

}

})
                .catch(function () {
                    mostrarMensaje("Error en la comunicación con el servidor.", true);

});

});

}

    cargarProfesores();
});
