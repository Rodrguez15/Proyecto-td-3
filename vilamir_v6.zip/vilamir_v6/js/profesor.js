/** Archivo: profesor.js — Comportamiento de la interfaz del profesor y sus grupos. */
const API_PROFESOR='api/profesor_portal.php';
let intentosProfesor=0;
const escP=v=>String(v??'').replace(/[&<>"']/g,c=>({
'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'
}[c]));
const horaP=v=>String(v??'').slice(0,5);
function pctClassP(v){return Number(v)>=90?'danger':Number(v)>=70?'warning':'success';}
const dias=['Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo'];
let datosProfesor=null;
// Conserva abiertas las listas de alumnos aunque se recarguen los datos del portal.
const listasAlumnosAbiertas = new Set();
async function cargar(){
try{
const r=await fetch(`${API_PROFESOR}?accion=datos&t=${Date.now()}`,{
cache:'no-store',credentials:'same-origin',headers:{
'Accept':'application/json'
}
}).then(async x=>{
const texto=await x.text();let d;try{
d=JSON.parse(texto);
}catch(_){
throw new Error('El servidor devolvió una respuesta inválida. Revisá la configuración de PHP.');
}if(!x.ok)throw new Error(d.message||'Error del servidor');return d;
});
if(r.status!=='success')throw new Error(r.message||'No se pudo cargar.');
datosProfesor=r;
intentosProfesor=0;
try{
const q=await fetch(`${API_PROFESOR}?accion=dashboard&t=${Date.now()}`,{
cache:'no-store',credentials:'same-origin'
});
const dash=await q.json();
if(dash.status==='success')datosProfesor.dashboard=dash;
}catch(_){
datosProfesor.dashboard={
stats:{
}
};
}render();
cargarAvisosProfesor();
}catch(e){
if(intentosProfesor<2){
intentosProfesor++;
setTimeout(cargar,500);
return;
}mostrar(e.message||'No se pudo cargar.',true);
}
}
function render(){
const d=datosProfesor;
document.getElementById('profStats').innerHTML=`<div class="dash-stat"><span>🥋 Disciplinas</span><b>${d.disciplinas.length}</b></div><div class="dash-stat"><span> Grupos</span><b>${d.grupos.length}</b></div><div class="dash-stat"><span>🧑‍🎓 Alumnos activos</span><b>${d.dashboard?.stats?.alumnos??0}</b></div><div class="dash-stat"><span> Asistencia del mes</span><b>${d.dashboard?.stats?.asistencia_mes??0}%</b></div>`;
 document.getElementById('listaDisciplinasProfesor').innerHTML=d.disciplinas.length?d.disciplinas.map(x=>`<label class="card professor-discipline-option"><input type="checkbox" name="disciplinasProfesor" value="${x.ID_Disciplina}" ${Number(x.Seleccionada)?'checked':''}> <strong>${escP(x.Nombre)}</strong><span>${escP(x.Descripcion||'Sin descripción')}</span></label>`).join(''):'<div class="empty-state">No hay disciplinas registradas.</div>';
 document.getElementById('listaGruposProfesor').innerHTML=d.grupos.length?d.grupos.map(x=>{const alumnos=(d.alumnos_grupos||[]).filter(a=>Number(a.ID_Grupo)===Number(x.ID_Grupo));const horariosGrupo=(d.horarios||[]).filter(h=>Number(h.ID_Grupo)===Number(x.ID_Grupo));return `<article class="card teacher-assigned-group"><h3>${escP(x.Nombre)}</h3><p><b>Disciplina:</b> ${escP(x.Disciplina||'Sin disciplina')}</p><p><b>Cupo:</b> ${escP(x.Cupo_maximo||'Sin límite')}</p>${Number(x.Asignado)?`<span class="badge success"> Grupo asignado</span><p><b>Horarios:</b></p>${horariosGrupo.length?`<ul class="teacher-group-schedules">${horariosGrupo.map(h=>`<li>${escP(h.Dia)} · ${horaP(h.Hora_inicio)} - ${horaP(h.Hora_fin)}</li>`).join('')}</ul>`:'<p>Sin horarios cargados.</p>'}<div class="teacher-roster"><button type="button" class="teacher-roster-toggle" aria-expanded="${listasAlumnosAbiertas.has(String(x.ID_Grupo))?'true':'false'}" aria-controls="lista-alumnos-${Number(x.ID_Grupo)}" data-lista-alumnos="${Number(x.ID_Grupo)}">Lista de alumnos (${alumnos.length}) <span aria-hidden="true">${listasAlumnosAbiertas.has(String(x.ID_Grupo))?'−':'＋'}</span></button><div id="lista-alumnos-${Number(x.ID_Grupo)}" class="teacher-roster-content" ${listasAlumnosAbiertas.has(String(x.ID_Grupo))?'':'hidden'}>${alumnos.length?`<ul>${alumnos.map(a=>`<li>${escP(a.Apellido)}, ${escP(a.Nombre)}</li>`).join('')}</ul>`:'<p>No hay alumnos activos en este grupo.</p>'}</div></div><button type="button" class="teacher-btn secondary" data-grupo-asistencia="${x.ID_Grupo}">Tomar asistencia</button>`:`<span class="badge warning">Disciplina relacionada</span><p>Este grupo todavía no está asignado a tu perfil. Contactá a Administración para habilitar la lista y el control de asistencia.</p>`}</article>`}).join(''):'<div class="empty-state">No tienes grupos relacionados todavía.</div>';
 document.querySelectorAll('[data-grupo-asistencia]').forEach(b=>b.addEventListener('click',()=>{const select=document.getElementById('grupoAsistencia');if(select){select.value=b.dataset.grupoAsistencia;cargarHorariosAsistencia([]);limpiarVistaAsistencia();document.querySelector('.attendance-panel')?.scrollIntoView({behavior:'smooth',block:'start'});mostrarAsistencia('Elegí la fecha y el horario de la clase, luego presioná «Cargar alumnos».',false);}}));
 const hs=d.horarios||[];
 document.getElementById('calendarioProfesor').innerHTML=dias.map(day=>`<div class="calendar-day"><h4>${day}</h4>${hs.filter(x=>x.Dia===day).map(x=>`<div class="calendar-event"><strong>${
horaP(x.Hora_inicio)
} - ${
horaP(x.Hora_fin)
}</strong><span>${
escP(x.Disciplina)
}</span><span>${
escP(x.Grupo)
}</span></div>`).join('')||'<span class="small">Sin clases</span>'}</div>`).join('');
 const st=d.dashboard?.stats||{
};
document.getElementById('profResumen').innerHTML=`<article class="teacher-summary-card"><span class="teacher-summary-icon"></span><h2>${st.alumnos??0} alumnos activos</h2><p>Alumnos inscriptos actualmente en tus grupos asignados.</p></article><article class="teacher-summary-card"><span class="teacher-summary-icon"></span><h2>${st.presentes_mes??0} asistencias registradas</h2><p>${st.registros_mes??0} registros durante este mes. Promedio de asistencia: <strong>${st.asistencia_mes??0}%</strong>.</p></article>`;
 // El resumen se calcula con los grupos y alumnos que ya devolvió la API principal.
 // Así sigue mostrando datos aunque el endpoint secundario del dashboard falle.
 const gruposAsignados=(d.grupos||[]).filter(g=>Number(g.Asignado)===1);
 const alumnosPorGrupo=d.alumnos_grupos||[];
 const resumenGrupos=gruposAsignados.map(g=>{
  const idGrupo=Number(g.ID_Grupo);
  const cupo=Number(g.Cupo_maximo||0);
  const alumnos=alumnosPorGrupo.filter(a=>Number(a.ID_Grupo)===idGrupo).length;
  const porcentaje=cupo?Math.min(100,Math.round(alumnos/cupo*100)):0;
  const disponibles=cupo?Math.max(0,cupo-alumnos):null;
  return `<div class="teacher-group-row">
   <div><strong>${escP(g.Nombre||'Grupo sin nombre')}</strong><small>${escP(g.Disciplina||'Sin disciplina')}</small></div>
   <div><div class="teacher-progress"><span class="${pctClassP(porcentaje)}" style="width:${porcentaje}%"></span></div><small>${alumnos} alumno${alumnos===1?'':'s'} activo${alumnos===1?'':'s'} · ${cupo?`${alumnos} de ${cupo} cupos (${porcentaje}%)`:'sin cupo máximo definido'}</small></div>
   <div class="teacher-capacity ${cupo&&alumnos>=cupo?'full':'ok'}">${cupo&&alumnos>=cupo?'Cupo completo':cupo?`${disponibles} ${disponibles===1?'lugar disponible':'lugares disponibles'}`:'Cupo abierto'}</div>
  </div>`;
 }).join('');
 document.getElementById('resumenGruposProfesor').innerHTML=resumenGrupos||'<div class="teacher-empty">Todavía no tenés grupos asignados. Cuando Administración te asigne uno, acá aparecerán sus alumnos activos y los cupos disponibles.</div>';
}
function mostrar(t,e=false){
const x=document.getElementById('mensajeProfesorPortal');
if(x){
x.className=e?'error':'success';
x.textContent=t;
}
}
document.addEventListener('click',event=>{
 const boton=event.target.closest('[data-lista-alumnos]');
 if(!boton)return;
 event.preventDefault();
 event.stopPropagation();
 const panel=document.getElementById(boton.getAttribute('aria-controls'));
 if(!panel)return;
 const id=String(boton.dataset.listaAlumnos||'');
 const abrir=panel.hidden;
 panel.hidden=!abrir;
 if(abrir)listasAlumnosAbiertas.add(id);else listasAlumnosAbiertas.delete(id);
 boton.setAttribute('aria-expanded',String(abrir));
 const icono=boton.querySelector('span');
 if(icono)icono.textContent=abrir?'−':'＋';
}, true);
document.addEventListener('DOMContentLoaded',()=>{
cargar().catch(()=>mostrar('Error de comunicación con el servidor.',true));const botonGuardarDisciplinas=document.getElementById('btnGuardarDisciplinasProfesor');
if(botonGuardarDisciplinas)botonGuardarDisciplinas.addEventListener('click',async()=>{
 if(botonGuardarDisciplinas.disabled)return;
 botonGuardarDisciplinas.disabled=true;
 try{
  const ids=[...document.querySelectorAll('input[name="disciplinasProfesor"]:checked')].map(x=>x.value);
  const f=new FormData();ids.forEach(id=>f.append('disciplinas[]',id));
  const respuesta=await fetch(`${API_PROFESOR}?accion=guardar_disciplinas`,{method:'POST',body:f,credentials:'same-origin',headers:{'Accept':'application/json'}});
  const texto=await respuesta.text();let r;
  try{r=JSON.parse(texto);}catch(_){throw new Error('El servidor devolvió una respuesta inválida al guardar las disciplinas.');}
  if(!respuesta.ok||r.status!=='success')throw new Error(r.message||'No se pudieron actualizar las disciplinas.');
  mostrar(r.message||'Disciplinas actualizadas.',false);
  // Recarga grupos, horarios y listas dependientes de las disciplinas guardadas.
  await cargar();
 }catch(error){mostrar(error.message||'No se pudieron actualizar las disciplinas.',true);}
 finally{botonGuardarDisciplinas.disabled=false;}
});
});

async function cargarGruposAsistencia(){
 try{
  const r=await fetch(`api/asistencia.php?t=${Date.now()}`,{
   cache:'no-store',credentials:'same-origin',headers:{'Accept':'application/json'}
  }).then(async x=>{
   const texto=await x.text();
   let d;try{d=JSON.parse(texto);}catch(_){throw new Error('El servidor devolvió una respuesta inválida al cargar los grupos.');}
   if(!x.ok)throw new Error(d.message||'No se pudieron cargar los grupos.');
   return d;
  });
  if(r.status!=='success')return mostrarAsistencia(r.message||'No se pudieron cargar tus grupos.',true);
  const s=document.getElementById('grupoAsistencia');
  s.innerHTML='<option value="">Seleccionar grupo</option>'+(r.grupos||[]).map(g=>`<option value="${g.ID_Grupo}">${escP(g.Disciplina)} - ${escP(g.Nombre)}</option>`).join('');
  const fecha=document.getElementById('fechaAsistencia');
  if(fecha&&!fecha.value){
   const ahora=new Date();
   fecha.value=`${ahora.getFullYear()}-${String(ahora.getMonth()+1).padStart(2,'0')}-${String(ahora.getDate()).padStart(2,'0')}`;
  }
 }catch(e){
  mostrarAsistencia(e.message||'No se pudieron cargar los grupos de asistencia.',true);
 }
}
function cargarHorariosAsistencia(horarios, seleccionado=''){
 const s=document.getElementById('horarioAsistencia');
 if(!s)return;
 s.innerHTML='<option value="">Seleccionar horario</option>'+(horarios||[]).map(h=>`<option value="${h.ID_Horario}" ${String(h.ID_Horario)===String(seleccionado)?'selected':''}>${escP(h.Dia)} · ${horaP(h.Hora_inicio)} - ${horaP(h.Hora_fin)}</option>`).join('');
}
function limpiarVistaAsistencia(){
 const lista=document.getElementById('listaAsistencia');
 const resumen=document.getElementById('resumenAsistencia');
 const guardar=document.getElementById('guardarAsistencia');
 if(lista)lista.innerHTML='';
 if(resumen)resumen.innerHTML='';
 if(guardar){guardar.hidden=true;guardar.classList.remove('is-visible');}
}
async function cargarAsistencia(){
 const grupo=document.getElementById('grupoAsistencia').value;
 const fecha=document.getElementById('fechaAsistencia').value;
 const horario=document.getElementById('horarioAsistencia').value;
 if(!grupo||!fecha)return mostrarAsistencia('Seleccioná un grupo y una fecha.',true);
 try{
  const params=new URLSearchParams({grupo,fecha,t:String(Date.now())});
  if(horario)params.set('horario',horario);
  const r=await fetch(`api/asistencia.php?${params.toString()}`,{
   cache:'no-store',credentials:'same-origin',headers:{'Accept':'application/json'}
  }).then(async x=>{
   const texto=await x.text();let d;
   try{d=JSON.parse(texto);}catch(_){throw new Error('El servidor devolvió una respuesta inválida al cargar la asistencia.');}
   if(!x.ok)throw new Error(d.message||'No se pudo cargar la asistencia.');
   return d;
  });
  if(r.status!=='success')return mostrarAsistencia(r.message||'No se pudo cargar la asistencia.',true);
  cargarHorariosAsistencia(r.horarios||[],r.horario_seleccionado||horario||'');
  if(r.requiere_horario){
   limpiarVistaAsistencia();
   return mostrarAsistencia(r.message||'Seleccioná el horario y volvé a cargar los alumnos.',false);
  }
  if(!(r.horarios||[]).length){
   limpiarVistaAsistencia();
   return mostrarAsistencia(r.message||'No hay horario configurado para ese día.',true);
  }
  if(!r.horario_seleccionado){
   limpiarVistaAsistencia();
   return mostrarAsistencia('Seleccioná un horario antes de cargar los alumnos.',true);
  }
  const alumnos=r.alumnos||[];
  if(!alumnos.length){
   document.getElementById('resumenAsistencia').innerHTML='';
   document.getElementById('listaAsistencia').innerHTML='<div class="empty-state">No hay alumnos activos en este grupo.</div>';
   const botonVacio=document.getElementById('guardarAsistencia');
   if(botonVacio){botonVacio.hidden=true;botonVacio.classList.remove('is-visible');}
   return mostrarAsistencia('No hay alumnos activos para registrar en este grupo.',false);
  }
  const marcados=alumnos.filter(a=>['Presente','Ausente','Justificado'].includes(a.Estado));
  const presentes=marcados.filter(a=>a.Estado==='Presente').length;
  document.getElementById('resumenAsistencia').innerHTML=`<div class="attendance-summary-card"><strong>${marcados.length}/${alumnos.length}</strong><span>alumnos marcados</span></div><div class="attendance-summary-card success"><strong>${presentes}</strong><span>presentes</span></div><div class="attendance-summary-card"><strong>${alumnos.length?Math.round(presentes/alumnos.length*100):0}%</strong><span>asistencia de esta clase</span></div><div class="attendance-summary-note">${escP(r.dia||'')} · ${escP(horaP((r.horarios||[]).find(h=>String(h.ID_Horario)===String(r.horario_seleccionado))?.Hora_inicio))} - ${escP(horaP((r.horarios||[]).find(h=>String(h.ID_Horario)===String(r.horario_seleccionado))?.Hora_fin))}</div>`;
  document.getElementById('listaAsistencia').innerHTML=alumnos.map(a=>{
   const estadoValido=['Presente','Ausente','Justificado'].includes(a.Estado);
   return `<div class="attendance-row"><div class="attendance-student"><strong>${escP(a.Apellido)}, ${escP(a.Nombre)}</strong><small>Últimos 30 días: <b>${Number(a.Porcentaje30||0)}%</b></small></div><select data-alumno="${a.ID_Alumno}" aria-label="Estado de asistencia de ${escP(a.Nombre)} ${escP(a.Apellido)}" required><option value="" ${estadoValido?'':'selected'}>Seleccionar estado</option><option value="Presente" ${a.Estado==='Presente'?'selected':''}>Presente</option><option value="Ausente" ${a.Estado==='Ausente'?'selected':''}>Ausente</option><option value="Justificado" ${a.Estado==='Justificado'?'selected':''}>Justificado</option></select><input data-obs="${a.ID_Alumno}" maxlength="255" aria-label="Observación de ${escP(a.Nombre)} ${escP(a.Apellido)}" placeholder="Observación (opcional)" value="${escP(a.Observacion||'')}"></div>`;
  }).join('')||'<div class="empty-state">No hay alumnos activos en este grupo.</div>';
  actualizarResumenAsistencia();
  const guardar=document.getElementById('guardarAsistencia');
  guardar.hidden=false;guardar.classList.add('is-visible');
  mostrarAsistencia('',false);
 }catch(e){
  mostrarAsistencia(e.message||'No se pudo cargar la asistencia.',true);
 }
}
async function guardarAsistencia(){
 const grupo=document.getElementById('grupoAsistencia').value;
 const fecha=document.getElementById('fechaAsistencia').value;
 const horario=document.getElementById('horarioAsistencia').value;
 if(!grupo||!fecha||!horario)return mostrarAsistencia('Seleccioná grupo, fecha y horario antes de guardar.',true);
 const selectores=[...document.querySelectorAll('#listaAsistencia select[data-alumno]')];
 if(selectores.some(select=>!['Presente','Ausente','Justificado'].includes(select.value))){
  return mostrarAsistencia('Marcá el estado de asistencia de cada alumno antes de guardar. No se guardó ningún cambio.',true);
 }
 const items=selectores.map(select=>({
  alumno:Number(select.dataset.alumno),estado:select.value,
  observacion:document.querySelector(`[data-obs="${select.dataset.alumno}"]`)?.value||''
 }));
 const datos=new FormData();
 datos.append('grupo',grupo);datos.append('fecha',fecha);datos.append('horario',horario);
 datos.append('asistencias',JSON.stringify(items));
 try{
  const r=await fetch(`api/asistencia.php?t=${Date.now()}`,{
   method:'POST',body:datos,credentials:'same-origin',headers:{'Accept':'application/json'}
  }).then(async x=>{
   const texto=await x.text();let d;
   try{d=JSON.parse(texto);}catch(_){throw new Error('El servidor devolvió una respuesta inválida al guardar.');}
   if(!x.ok)throw new Error(d.message||'No se pudo guardar la asistencia.');
   return d;
  });
  mostrarAsistencia(r.message||'Asistencia actualizada.',r.status!=='success');
  if(r.status==='success')cargarAsistencia();
 }catch(e){
  mostrarAsistencia(e.message||'No se pudo guardar la asistencia.',true);
 }
}
function actualizarResumenAsistencia(){
 const selects=[...document.querySelectorAll('#listaAsistencia select[data-alumno]')];
 const marcados=selects.filter(s=>['Presente','Ausente','Justificado'].includes(s.value));
 const presentes=selects.filter(s=>s.value==='Presente').length;
 const tarjetas=document.querySelectorAll('#resumenAsistencia .attendance-summary-card');
 if(tarjetas.length>=3){
  const total=selects.length;
  tarjetas[0].querySelector('strong').textContent=`${marcados.length}/${total}`;
  tarjetas[1].querySelector('strong').textContent=String(presentes);
  tarjetas[2].querySelector('strong').textContent=`${total?Math.round(presentes/total*100):0}%`;
 }
}
function mostrarAsistencia(t,e){
const x=document.getElementById('mensajeAsistencia');
if(x){
x.className=e?'error':'success';
x.textContent=t;
}
}
document.addEventListener('DOMContentLoaded',()=>{
 cargarGruposAsistencia();
 document.getElementById('cargarAsistencia')?.addEventListener('click',cargarAsistencia);
 document.getElementById('guardarAsistencia')?.addEventListener('click',guardarAsistencia);
 document.getElementById('grupoAsistencia')?.addEventListener('change',()=>{cargarHorariosAsistencia([]);limpiarVistaAsistencia();mostrarAsistencia('',false);});
 document.getElementById('fechaAsistencia')?.addEventListener('change',()=>{cargarHorariosAsistencia([]);limpiarVistaAsistencia();mostrarAsistencia('',false);});
 document.getElementById('horarioAsistencia')?.addEventListener('change',()=>{limpiarVistaAsistencia();mostrarAsistencia('',false);});
 document.getElementById('listaAsistencia')?.addEventListener('change',e=>{if(e.target?.matches('select[data-alumno]'))actualizarResumenAsistencia();});
});

async function cargarAvisosProfesor(){
 const box=document.getElementById('avisosProfesor');
if(!box)return;
 try{
  const r=await fetch(`${API_PROFESOR}?accion=avisos&t=${Date.now()}`,{
cache:'no-store',credentials:'same-origin'
}).then(x=>x.json());
  const avisos=r.avisos||[];
  if(!avisos.length){
box.innerHTML=`<div class="teacher-empty">${escP(r.aviso_migracion||'No tenés avisos nuevos de la academia.')}</div>`;
return;
}
  box.innerHTML=avisos.map(a=>`<article class="teacher-group-row teacher-notice-row ${Number(a.Leida)?'notice-read':'notice-unread'}"><div><strong>${escP(a.Categoria||'Aviso de la academia')}</strong><small>${escP(a.Fecha||'')}</small></div><div>${escP(a.Mensaje||'')}</div><div>${Number(a.Leida)?'<span class="teacher-capacity ok">Leído</span>':`<button class="teacher-btn secondary" type="button" onclick="marcarAvisoProfesor(${Number(a.ID_Notificacion_Profesor)})">Marcar leído</button>`}</div></article>`).join('');

}catch(_){
box.innerHTML='<div class="teacher-empty">No se pudieron cargar los avisos.</div>';
}
}
async function marcarAvisoProfesor(id){
 try{
const f=new FormData();
f.append('id',id);
const r=await fetch(`${API_PROFESOR}?accion=marcar_aviso`,{
method:'POST',body:f,credentials:'same-origin'
}).then(x=>x.json());
if(r.status!=='success')throw new Error(r.message||'No se pudo actualizar.');
cargarAvisosProfesor();
}
 catch(e){
const box=document.getElementById('avisosProfesor');
if(box)box.insertAdjacentHTML('afterbegin',`<div class="teacher-empty">${escP(e.message||'Error al actualizar el aviso.')}</div>`);
}
}

// Notificaciones docentes (requiere sql/migracion_notificaciones_v11.sql).
async function cargarNotificacionesProfesor(){
 const cont=document.getElementById('notificacionesProfesor');
 if(!cont)return;
 try{
  const r=await fetch(`api/notificaciones_usuario.php?t=${Date.now()}`,{
cache:'no-store',credentials:'same-origin'
});
  const d=await r.json();
 if(!r.ok||d.status!=='success')throw new Error(d.message||'No se pudieron cargar los avisos.');
  cont.innerHTML=(d.rows||[]).length?(d.rows||[]).map(n=>`<article class="teacher-notification ${Number(n.Leida)?'read':''}"><span>${Number(n.Leida)?'':''}</span><div><strong>${escP(n.Titulo||'Aviso de VILAMIR')}</strong><p>${escP(n.Mensaje)}</p><small>${escP(n.Fecha)}</small></div>${Number(n.Leida)?'<span class="badge">Leída</span>':`<button type="button" onclick="leerNotificacionProfesor(${Number(n.ID_Notificacion_Usuario)})">Marcar leída</button>`}</article>`).join(''):'<div class="teacher-empty">No tenés notificaciones nuevas.</div>';

}catch(e){
cont.innerHTML=`<div class="teacher-empty">${escP(e.message||'No se pudieron cargar las notificaciones.')}</div>`;
}
}
async function leerNotificacionProfesor(id){
const f=new FormData();
f.append('accion','leer');
f.append('id',id);
try{
const r=await fetch('api/notificaciones_usuario.php',{
method:'POST',body:f,credentials:'same-origin'
});
const d=await r.json();
if(d.status==='success')cargarNotificacionesProfesor();
else alert(d.message||'No se pudo actualizar.');
}catch(e){
alert('No se pudo actualizar la notificación.');
}
}
async function leerTodasNotificacionesProfesor(){
const f=new FormData();
f.append('accion','leer_todas');
try{
const r=await fetch('api/notificaciones_usuario.php',{
method:'POST',body:f,credentials:'same-origin'
});
const d=await r.json();
if(d.status==='success')cargarNotificacionesProfesor();
else alert(d.message||'No se pudo actualizar.');
}catch(e){
alert('No se pudieron actualizar las notificaciones.');
}
}
document.addEventListener('DOMContentLoaded',()=>{
cargarNotificacionesProfesor();document.getElementById('marcarNotifProfesor')?.addEventListener('click',leerTodasNotificacionesProfesor);
});
