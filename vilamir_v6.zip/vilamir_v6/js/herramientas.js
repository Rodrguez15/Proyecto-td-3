/** Archivo: herramientas.js — Funciones JavaScript compartidas para utilidades de la interfaz. */
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({
'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'
}[c]));
const input=document.getElementById('busqueda'),tipo=document.getElementById('tipoBusqueda'),out=document.getElementById('resultadosBusqueda');
let timer;
async function buscar(){
const q=input.value.trim();
if(!q){
out.innerHTML='<p class="small">Escribí algo para buscar.</p>';
return;
}out.innerHTML='<p>Cargando...</p>';
try{
const r=await fetch(`api/avanzadas.php?entity=buscar&q=${encodeURIComponent(q)}&tipo=${encodeURIComponent(tipo.value)}`);
const d=await r.json();
if(d.status!=='success')throw new Error(d.message);
out.innerHTML=d.rows.length?'<div class="search-results">'+d.rows.map(x=>`<div class="search-result"><div class="search-result-main"><strong>${esc(x.nombre)}</strong><small>ID: ${esc(x.ref)}</small></div><span class="search-result-type">${esc(x.tipo)}</span></div>`).join('')+'</div>':'<div class="search-empty">No se encontraron resultados.</div>';
}catch(e){
out.innerHTML='<p class="error">'+e.message+'</p>';
}
}
input.addEventListener('input',()=>{
clearTimeout(timer);timer=setTimeout(buscar,250)
});
tipo.addEventListener('change',buscar);
async function cargarActividad(){
const box=document.getElementById('actividadSistema');
if(!box)return;
try{
const r=await fetch('api/avanzadas.php?entity=actividad');
const d=await r.json();
if(d.status!=='success')throw new Error(d.message);
box.innerHTML=d.rows.length?d.rows.map(x=>`<div class="search-result"><div class="search-result-main"><strong>${esc(x.Accion)}</strong><small>${esc(x.Detalle||'Sin detalle')} · ${esc(x.Usuario)} · ${esc(x.Fecha)}</small></div><span class="search-result-type">Actividad</span></div>`).join(''):'<div class="search-empty">Todavía no hay actividad registrada.</div>';
}catch(e){
box.innerHTML='<div class="search-empty">La actividad todavía no está disponible.</div>';
}
}
cargarActividad();
