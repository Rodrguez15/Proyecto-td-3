/**
 * Archivo: mobile.js
 * Navegación adaptable y accesible para el menú principal de VILAMIR.
 * No modifica permisos, datos ni reglas de negocio.
 */
(function () {
    'use strict';

    function initMobileMenu() {
        document.querySelectorAll('.navbar').forEach(function (navbar, index) {
            const nav = navbar.querySelector('nav');

            // Evita crear dos botones si el archivo se inicializa más de una vez.
            if (!nav || navbar.querySelector('.mobile-menu-toggle')) {
                return;
            }

            if (!nav.id) {
                nav.id = 'mobile-nav-' + (index + 1);
            }

            const button = document.createElement('button');
            button.type = 'button';
            button.className = 'mobile-menu-toggle';
            button.setAttribute('aria-label', 'Abrir menú');
            button.setAttribute('aria-expanded', 'false');
            button.setAttribute('aria-controls', nav.id);
            button.textContent = '≡';
            navbar.appendChild(button);

            function closeMenu(returnFocus) {
                navbar.classList.remove('nav-open');
                button.setAttribute('aria-expanded', 'false');
                button.setAttribute('aria-label', 'Abrir menú');
                button.textContent = '≡';

                if (returnFocus) {
                    button.focus();
                }
            }

            function openMenu() {
                navbar.classList.add('nav-open');
                button.setAttribute('aria-expanded', 'true');
                button.setAttribute('aria-label', 'Cerrar menú');
                button.textContent = 'X';
            }

            button.addEventListener('click', function () {
                const isOpen = navbar.classList.contains('nav-open');
                if (isOpen) {
                    closeMenu(false);
                } else {
                    openMenu();
                }
            });

            nav.addEventListener('click', function (event) {
                if (event.target.closest('a')) {
                    closeMenu(false);
                }
            });

            document.addEventListener('click', function (event) {
                if (!navbar.contains(event.target)) {
                    closeMenu(false);
                }
            });

            document.addEventListener('keydown', function (event) {
                if (event.key === 'Escape' && navbar.classList.contains('nav-open')) {
                    closeMenu(true);
                }
            });

            window.addEventListener('resize', function () {
                if (window.innerWidth > 900) {
                    closeMenu(false);
                }
            });
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initMobileMenu);
    } else {
        initMobileMenu();
    }

    // Envolver tablas que no tengan ya un contenedor desplazable.
    // Evita que las columnas anchas rompan el ancho de pantalla en móviles.
    function prepararTablasDesplazables(raiz) {
        const tablas = (raiz || document).querySelectorAll ? (raiz || document).querySelectorAll('table') : [];
        tablas.forEach(function (tabla) {
            const padre = tabla.parentElement;
            if (!padre || padre.classList.contains('table-wrap') || padre.classList.contains('table-scroll') ||
                padre.classList.contains('table-responsive') || padre.classList.contains('table-wrapper') ||
                padre.classList.contains('table-container') ||
                padre.classList.contains('student-table-wrap') || padre.classList.contains('teacher-calendar-wrap') ||
                padre.classList.contains('attendance-table-wrap') || padre.classList.contains('account-table-wrap')) return;
            const wrapper = document.createElement('div');
            wrapper.className = 'table-wrap vilamir-table-scroll';
            tabla.parentNode.insertBefore(wrapper, tabla);
            wrapper.appendChild(tabla);
        });
    }

    function observarTablasDesplazables() {
        prepararTablasDesplazables(document);
        const observer = new MutationObserver(function (mutations) {
            mutations.forEach(function (mutation) {
                mutation.addedNodes.forEach(function (node) {
                    if (node.nodeType !== 1) return;
                    if (node.matches && node.matches('table')) prepararTablasDesplazables(node.parentElement || document);
                    else prepararTablasDesplazables(node);
                });
            });
        });
        observer.observe(document.body, { childList: true, subtree: true });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', observarTablasDesplazables, { once: true });
    } else {
        observarTablasDesplazables();
    }
})();
// ============================================================
// SISTEMA GLOBAL DE TOASTS FLOTANTES - VILAMIR
// ============================================================
(() => {
    let container = document.querySelector('.toast-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'toast-container';
        document.body.appendChild(container);
    }

    window.mostrarToast = (mensaje, tipo = 'success', duracion = 3500) => {
        if (!mensaje || !mensaje.trim()) return;

        const toast = document.createElement('div');
        toast.className = `toast-item toast-${tipo}`;

        const icono = tipo === 'success' ? '✔' : (tipo === 'error' ? '✖' : 'ℹ');

        toast.innerHTML = `
            <div class="toast-content">
                <span class="toast-icon">${icono}</span>
                <span class="toast-msg"></span>
            </div>
            <button type="button" class="toast-close" aria-label="Cerrar">&times;</button>
        `;

        toast.querySelector('.toast-msg').textContent = String(mensaje);
        toast.querySelector('.toast-close').addEventListener('click', () => {
            toast.classList.add('toast-fadeout');
            setTimeout(() => toast.remove(), 300);
        });

        container.appendChild(toast);

        setTimeout(() => {
            if (toast.isConnected) {
                toast.classList.add('toast-fadeout');
                setTimeout(() => toast.remove(), 300);
            }
        }, duracion);
    };

    // Auto-detectar mensajes viejos en <p id="mensaje..."> y convertirlos en Toasts
    document.addEventListener('DOMContentLoaded', () => {
        const selectoresMensajes = [
            '#mensaje', '#mensajeAlumno', '#mensajeGrupo', '#mensajeClase',
            '#mensajeSeminario', '#mensajeMisClases', '#mensajeAsistencia',
            '#mensajeProfesorPortal', '#mensajeNotificacionesAdmin'
        ];

        selectoresMensajes.forEach(sel => {
            const el = document.querySelector(sel);
            if (!el) return;

            const observer = new MutationObserver(() => {
                const txt = el.textContent.trim();
                if (txt && !el.dataset.toastSilenciado) {
                    const esError = el.classList.contains('error') || el.classList.contains('err') || txt.toLowerCase().includes('error') || txt.toLowerCase().includes('problema');
                    window.mostrarToast(txt, esError ? 'error' : 'success');
                }
            });
            observer.observe(el, { childList: true, characterData: true, subtree: true });
        });
    });
})();