/** Archivo: registrar.js — Interacciones del navegador relacionadas con registrar. */
// ===============================
// REGISTRO DE USUARIOS
// MMA Systems
// ===============================
document.getElementById("registerForm").addEventListener("submit", function(e) {
    // Evitar que la página recargue el formulario de forma convencional
    e.preventDefault();

    const nombre = document.getElementById("nombre").value.trim();
    const apellido = document.getElementById("apellido").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirmPassword").value;
    const mensaje = document.getElementById("mensaje");

    mensaje.textContent = "";

    if (nombre === "" || apellido === "" || email === "" || password === "" || confirmPassword === "") {
        mensaje.className = "error message-center message-top";
        mensaje.textContent = "Debe completar todos los campos.";
        return;

}

    if (password !== confirmPassword) {
        mensaje.className = "error message-center message-top";
        mensaje.textContent = "Las contraseñas no coinciden.";
        return;

}

    if (password.length < 8) {
        mensaje.className = "error message-center message-top";
        mensaje.textContent = "La contraseña debe tener al menos 8 caracteres.";
        return;

}

    // Estructurar los parámetros correspondientes para la solicitud POST
    const formData = new FormData();
    formData.append('nombre', nombre);
    formData.append('apellido', apellido);
    formData.append('email', email);
    formData.append('password', password);
    formData.append('confirmPassword', confirmPassword);

    // Obtener token de la sesión y enviarlo con el alta pública.
    fetch('csrf_token.php', { credentials: 'same-origin', cache: 'no-store' })
    .then(response => response.json())
    .then(tokenData => {
        if (!tokenData.csrf_token) throw new Error('No se pudo obtener el token de seguridad.');
        return fetch('registrar.php', {
            method: 'POST',
            body: formData,
            credentials: 'same-origin',
            headers: { 'X-CSRF-Token': tokenData.csrf_token }
        });
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            mensaje.className = "success message-center message-top";
            mensaje.textContent = data.message;

            // Redirigir a la pantalla de login tras 2 segundos
            setTimeout(function() {
                window.location.href = "login.html";

}, 2000);

} else {
            mensaje.className = "error message-center message-top";
            mensaje.textContent = data.message;

}

})
    .catch(error => {
        mensaje.className = "error message-center message-top";
        mensaje.textContent = "Error en la comunicación con el servidor.";

});
});
