/* Lector QR de VILAMIR: cámara + entrada manual + asistencia + cuota mensual. */
(() => {
  'use strict';

  const $ = id => document.getElementById(id);
  const grupo = $('grupoCheckin');
  const fecha = $('fechaCheckin');
  const horario = $('horarioCheckin');
  const btnIniciar = $('btnIniciarCamara');
  const btnDetener = $('btnDetenerCamara');
  const btnManual = $('btnVerificarManual');
  const estado = $('estadoLector');
  const resultado = $('resultadoCheckin');
  const formManual = $('formCodigoManual');
  const inputManual = $('codigoQrManual');

  let lector = null;
  let camaraActiva = false;
  let procesando = false;
  let ultimoCodigo = '';
  let ultimaLectura = 0;

  const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, ch => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
  }[ch]));

  function setEstado(texto, error = false) {
    estado.textContent = texto;
    estado.style.borderLeft = error ? '4px solid #ff5b5b' : '4px solid #d71920';
  }

  function claseCuota(nombre) {
    if (nombre === 'Pagada') return 'fee-paid';
    if (nombre === 'Pendiente') return 'fee-pending';
    if (nombre === 'Vencida') return 'fee-overdue';
    return 'fee-none';
  }

  function actualizarDisponibilidad() {
    const listo = Boolean(grupo.value && horario.value && !horario.disabled);
    btnIniciar.disabled = !listo || camaraActiva;
    btnManual.disabled = !listo;
    if (!listo) setEstado('Elegí un grupo con horario disponible para la fecha seleccionada.');
    else if (!camaraActiva) setEstado('Clase seleccionada. Activá la cámara o usá el ingreso manual.');
  }

  async function cargarGrupos() {
    grupo.innerHTML = '<option value="">Cargando grupos…</option>';
    try {
      const res = await fetch(`api/checkin.php?accion=grupos&t=${Date.now()}`, {
        credentials: 'same-origin', cache: 'no-store', headers: { 'Accept': 'application/json' }
      });
      const data = await res.json();
      if (!res.ok || data.status !== 'success') throw new Error(data.message || 'No se pudieron cargar los grupos.');
      grupo.innerHTML = '<option value="">Seleccioná un grupo</option>';
      (data.grupos || []).forEach(item => {
        const option = document.createElement('option');
        option.value = item.ID_Grupo;
        option.textContent = `${item.Disciplina || 'General'} · ${item.Nombre}`;
        grupo.appendChild(option);
      });
      if (!data.grupos || !data.grupos.length) setEstado('No hay grupos disponibles para tu usuario.', true);
    } catch (err) {
      grupo.innerHTML = '<option value="">No se pudieron cargar los grupos</option>';
      setEstado(err.message || 'Error al cargar los grupos.', true);
    }
    actualizarDisponibilidad();
  }

  async function cargarHorarios() {
    horario.disabled = true;
    horario.innerHTML = '<option value="">Cargando horarios…</option>';
    actualizarDisponibilidad();
    if (!grupo.value || !fecha.value) {
      horario.innerHTML = '<option value="">Seleccioná un grupo y fecha</option>';
      actualizarDisponibilidad();
      return;
    }
    try {
      const params = new URLSearchParams({ accion: 'horarios', grupo: grupo.value, fecha: fecha.value, t: String(Date.now()) });
      const res = await fetch(`api/checkin.php?${params}`, {
        credentials: 'same-origin', cache: 'no-store', headers: { 'Accept': 'application/json' }
      });
      const data = await res.json();
      if (!res.ok || data.status !== 'success') throw new Error(data.message || 'No se pudieron cargar los horarios.');
      horario.innerHTML = '<option value="">Seleccioná un horario</option>';
      (data.horarios || []).forEach(item => {
        const option = document.createElement('option');
        option.value = item.ID_Horario;
        option.textContent = `${String(item.Hora_inicio).slice(0,5)} - ${String(item.Hora_fin).slice(0,5)}`;
        horario.appendChild(option);
      });
      horario.disabled = !(data.horarios || []).length;
      if (!data.horarios || !data.horarios.length) {
        horario.innerHTML = '<option value="">No hay clase programada ese día</option>';
        setEstado(`No hay horario cargado para ${data.dia || 'esa fecha'} en este grupo.`, true);
      }
    } catch (err) {
      horario.innerHTML = '<option value="">Error al cargar horarios</option>';
      setEstado(err.message || 'Error al cargar los horarios.', true);
    }
    actualizarDisponibilidad();
  }

  function extraerCodigoQR(texto) {
    const original = String(texto || '').trim();
    if (!original) return '';
    try {
      if (/^https?:\/\//i.test(original)) {
        const url = new URL(original);
        return (url.searchParams.get('codigo') || url.searchParams.get('qr') || '').trim();
      }
    } catch (_) { /* El valor puede ser un código plano. */ }
    return original;
  }

  async function procesarCodigo(texto) {
    if (procesando) return;
    const ahora = Date.now();
    const codigo = extraerCodigoQR(texto);
    if (!codigo) {
      setEstado('El QR no contiene un código de alumno válido.', true);
      return;
    }
    if (codigo === ultimoCodigo && ahora - ultimaLectura < 1800) return;
    if (!grupo.value || !horario.value) {
      setEstado('Primero seleccioná el grupo y el horario.', true);
      return;
    }

    procesando = true;
    ultimoCodigo = codigo;
    ultimaLectura = ahora;
    btnManual.disabled = true;
    setEstado('QR leído. Verificando alumno, asistencia y cuota del mes…');

    try {
      const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
      const fd = new FormData();
      fd.set('codigo_qr', codigo);
      fd.set('grupo', grupo.value);
      fd.set('horario', horario.value);
      fd.set('fecha', fecha.value);
      if (csrf) fd.set('csrf_token', csrf);

      const res = await fetch('api/checkin.php', {
        method: 'POST', body: fd, credentials: 'same-origin',
        headers: { 'Accept': 'application/json', 'X-CSRF-Token': csrf }
      });
      const raw = await res.text();
      let data;
      try { data = JSON.parse(raw); }
      catch (_) { throw new Error('El servidor devolvió una respuesta inválida. Revisá la consola de PHP.'); }
      if (!res.ok || data.status !== 'success') throw new Error(data.message || 'No se pudo verificar el QR.');
      mostrarResultado(data);
      setEstado(`Último escaneo: ${data.alumno.nombre}. Podés escanear al siguiente alumno.`);
      inputManual.value = '';
    } catch (err) {
      mostrarError(err.message || 'No se pudo conectar con el servidor.');
      setEstado(err.message || 'No se pudo procesar el QR.', true);
    } finally {
      setTimeout(() => {
        procesando = false;
        btnManual.disabled = !(grupo.value && horario.value);
        if (document.activeElement !== inputManual && !camaraActiva) inputManual.focus();
      }, 700);
    }
  }

  function mostrarResultado(data) {
    const al = data.alumno || {};
    const asis = data.asistencia || {};
    const cuota = data.cuota_mes || {};
    const estaAsistencia = Boolean(asis.registrada || asis.ya_registrada);
    const estadoCuota = cuota.estado || 'Sin información';
    const nombreEstado = asis.registrada ? 'PRESENTE · REGISTRADO' :
      (asis.ya_registrada ? `YA REGISTRADO · ${asis.estado || 'ASISTENCIA EXISTENTE'}` : 'NO SE REGISTRÓ ASISTENCIA');
    resultado.className = `result-card ${!estaAsistencia ? 'warning' : (cuota.estado === 'Vencida' ? 'warning' : 'success')}`;
    const importe = cuota.importe === null || cuota.importe === undefined ? '—' : `$${Number(cuota.importe).toLocaleString('es-UY', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    const vencimiento = cuota.vencimiento ? String(cuota.vencimiento).split('-').reverse().join('/') : '—';
    resultado.innerHTML = `
      <div class="result-title">${escapeHtml(al.nombre || 'Alumno')}</div>
      <div class="result-row"><strong>Asistencia:</strong><br>${escapeHtml(nombreEstado)}<br><span class="small-note">${escapeHtml(asis.mensaje || '')}</span></div>
      <div class="result-row"><strong>Grupo:</strong> ${escapeHtml(data.grupo?.nombre || '—')}<br><strong>Disciplina:</strong> ${escapeHtml(data.grupo?.disciplina || '—')}<br><strong>Clase:</strong> ${escapeHtml(data.grupo?.fecha || '')} · ${escapeHtml(data.grupo?.hora || '')}</div>
      <div class="result-row"><strong>Disciplinas activas:</strong> ${escapeHtml(al.disciplinas || '—')}</div>
      <div class="result-row"><strong>Cuota de ${escapeHtml(cuota.mes || 'este mes')}:</strong><br><span class="fee-pill ${claseCuota(estadoCuota)}">${escapeHtml(estadoCuota.toUpperCase())}</span><br><strong>Importe:</strong> ${escapeHtml(importe)}<br><strong>Vencimiento:</strong> ${escapeHtml(vencimiento)}${cuota.concepto ? `<br><strong>Concepto:</strong> ${escapeHtml(cuota.concepto)}` : ''}</div>
    `;
    resultado.style.display = 'block';
  }

  function mostrarError(mensaje) {
    resultado.className = 'result-card danger';
    resultado.innerHTML = `<div class="result-title">No se pudo completar el escaneo</div><div>${escapeHtml(mensaje)}</div>`;
    resultado.style.display = 'block';
  }

  async function iniciarCamara() {
    if (!grupo.value || !horario.value) {
      setEstado('Seleccioná un grupo y horario antes de activar la cámara.', true);
      return;
    }
    if (!window.Html5Qrcode) {
      setEstado('No se pudo cargar el lector de cámara. Revisá tu conexión o usá el campo manual / lector USB.', true);
      return;
    }
    if (!navigator.mediaDevices?.getUserMedia) {
      setEstado('Este navegador no permite abrir la cámara en esta dirección. Usá HTTPS o localhost, o ingresá el código manualmente.', true);
      return;
    }
    try {
      lector = new Html5Qrcode('qrReader', { verbose: false });
      await lector.start(
        { facingMode: 'environment' },
        { fps: 10, qrbox: { width: 245, height: 245 }, aspectRatio: 1.0, rememberLastUsedCamera: true },
        texto => procesarCodigo(texto),
        () => {}
      );
      camaraActiva = true;
      btnIniciar.disabled = true;
      btnDetener.disabled = false;
      setEstado('Cámara activa. Enfocá el QR del carnet dentro del recuadro.');
    } catch (err) {
      lector = null;
      camaraActiva = false;
      btnDetener.disabled = true;
      actualizarDisponibilidad();
      setEstado(err.message || 'No se pudo iniciar la cámara. Revisá los permisos del navegador.', true);
    }
  }

  async function detenerCamara() {
    if (!lector || !camaraActiva) return;
    try {
      await lector.stop();
      lector.clear();
    } catch (err) {
      console.warn('No se pudo detener el lector de forma limpia:', err);
    }
    lector = null;
    camaraActiva = false;
    btnDetener.disabled = true;
    actualizarDisponibilidad();
    setEstado('Cámara detenida. Podés volver a activarla o ingresar un código.');
  }

  grupo.addEventListener('change', cargarHorarios);
  fecha.addEventListener('change', cargarHorarios);
  horario.addEventListener('change', actualizarDisponibilidad);
  btnIniciar.addEventListener('click', iniciarCamara);
  btnDetener.addEventListener('click', detenerCamara);
  formManual.addEventListener('submit', event => {
    event.preventDefault();
    procesarCodigo(inputManual.value);
  });
  window.addEventListener('beforeunload', () => {
    if (lector && camaraActiva) lector.stop().catch(() => {});
  });

  cargarGrupos();
})();
