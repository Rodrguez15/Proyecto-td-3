/** Archivo: index.js — Interacciones del navegador relacionadas con index. */
// ============================================================
// INDEX - MMA SYSTEMS
// Control del botón "Cerrar sesión" de index.html (versión legacy).
// ============================================================
document.addEventListener("DOMContentLoaded", function () {
    const btnCerrar = document.getElementById("cerrarSesion");
    if (btnCerrar) {
        btnCerrar.addEventListener("click", function () {
            const token = document.querySelector('meta[name="csrf-token"]')?.content || '';
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'logout.php';
            const campo = document.createElement('input');
            campo.type = 'hidden';
            campo.name = 'csrf_token';
            campo.value = token;
            form.appendChild(campo);
            document.body.appendChild(form);
            form.submit();

});

}
});
