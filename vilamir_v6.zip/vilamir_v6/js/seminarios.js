/** Archivo: seminarios.js — Interacciones del navegador relacionadas con seminarios. */
// Comunicación JSON robusta: si PHP devuelve un error/HTML, mostramos el mensaje en vez de fallar silenciosamente.
async function requestJSON(url, options = {
}) {
    const response = await fetch(url, options);
    const text = await response.text();
    let data;
    try {
        data = JSON.parse(text);

} catch (e) {
        throw new Error(`Respuesta inválida del servidor (${response.status}).`);

}
    if (!response.ok && !data.message) {
        throw new Error(`Error del servidor (${response.status}).`);

}
    return data;
}

// Módulo de seminarios y eventos.
// Permite consultar eventos y, para el administrador, crear, editar y eliminar.

document.addEventListener('DOMContentLoaded', () => {
    const admin = Boolean(document.getElementById('btnGuardarSeminario'));
    const box = document.getElementById('listaSeminarios');
    const msg = document.getElementById('mensajeSeminario');

    // Muestra mensajes al usuario.
    const say = (text, error = false) => {
        if (!msg) {
            return;

}

        msg.textContent = text;
        msg.className = error ? 'error' : 'success';

};

    // Escapa texto antes de insertarlo en HTML.
    const esc = (value) => String(value ?? '').replace(
        /[&<>"']/g,
        (match) => ({
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'

}[match])
    );

    // Acciones administrativas enlazadas mediante atributos data-* escapados,
    // evitando interpolar nombres/descripciones dentro de código JavaScript inline.
    if (box) {
        box.addEventListener('click', (event) => {
            const button = event.target.closest('button[data-action]');
            if (!button) return;
            const id = Number(button.dataset.id);
            if (!Number.isInteger(id) || id <= 0) return;
            if (button.dataset.action === 'editar') {
                window.editarSem(id, button.dataset.nombre || '', button.dataset.descripcion || '',
                    Number(button.dataset.costo || 0), button.dataset.fecha || '',
                    button.dataset.hora || '', button.dataset.lugar || '', Number(button.dataset.cupo || 0));
            } else if (button.dataset.action === 'eliminar') {
                window.delSem(id);
            }
        });
    }

    // Consulta los seminarios disponibles. Devuelve una promesa para que las
    // acciones puedan esperar a que la lista se haya actualizado por completo.
    async function load() {
        try {
            const data = await requestJSON('api/seminarios.php');
            if (data.status !== 'success') {
                say(data.message || 'No se pudieron cargar los seminarios.', true);
                return false;
            }

            const seminarios = Array.isArray(data.seminarios) ? data.seminarios : [];
            box.innerHTML = seminarios.map((item) => {
                const id = Number(item.ID_Seminario);
                const nombre = item.Nombre || item.Titulo || '';
                const descripcion = item.Descripcion || 'Sin descripción';
                const costo = Number(item.Costo || 0).toFixed(2);
                const cupo = Number(item.Cupo || 0);
                const inscritos = Number(item.Inscritos || 0);
                const lleno = cupo > 0 && inscritos >= cupo;
                const horario = item.Hora ? ` · ${esc(item.Hora).slice(0, 5)}` : '';
                const lugar = item.Lugar ? ` · ${esc(item.Lugar)}` : '';
                let actions = '';

                if (admin) {
                    actions = `
                        <button type="button" data-action="editar" data-id="${id}"
                            data-nombre="${esc(nombre)}" data-descripcion="${esc(descripcion)}"
                            data-costo="${Number(item.Costo || 0)}" data-fecha="${esc(item.Fecha)}"
                            data-hora="${esc(item.Hora || '')}" data-lugar="${esc(item.Lugar || '')}"
                            data-cupo="${cupo}">Editar</button>
                        <button type="button" class="danger" data-action="eliminar" data-id="${id}">Eliminar</button>
                    `;
                } else {
                    const inscrito = Number(item.Inscrito) === 1;
                    const ahoraLocal = new Date();
                    const fechaLocal = `${ahoraLocal.getFullYear()}-${String(ahoraLocal.getMonth() + 1).padStart(2, '0')}-${String(ahoraLocal.getDate()).padStart(2, '0')}`;
                    const fechaPasada = String(item.Fecha || '').slice(0, 10) < fechaLocal;
                    const enEspera = Number(item.En_espera) === 1;
                    if (inscrito) {
                        actions = `
                            <p class="success"><strong>Ya estás inscripto</strong></p>
                            <button type="button" class="danger" onclick="cancelarSeminario(${Number(item.ID_Ins_seminario)})">Cancelar inscripción</button>
                        `;
                    } else if (fechaPasada) {
                        actions = '<p class="muted">Este evento ya finalizó.</p>';
                    } else {
                        actions = lleno
                            ? (enEspera
                                ? `<p class="muted"><strong>Estás en lista de espera.</strong> ${Number(item.Espera_total || 0)} persona(s) en espera.</p><button type="button" class="btn-secondary" onclick="salirEsperaSeminario(${id})">Salir de lista de espera</button>`
                                : `<p class="muted"><strong>Cupo completo.</strong> ${Number(item.Espera_total || 0)} persona(s) en espera.</p><button type="button" onclick="entrarEsperaSeminario(${id})">Entrar en lista de espera</button>`)
                            : `<button type="button" onclick="inscribirSeminario(${id}, ${Number(item.Costo || 0)}, '${esc(nombre).replace(/'/g, "&#39;")}')">Inscribirme${cupo>0||Number(item.Costo||0)>0?` (${Number(item.Costo||0)>0?'$ '+costo:'gratis'})`:''}</button>`;
                    }
                }

                return `
                    <div class="member dynamic-card compact">
                        <h2>${esc(nombre)}</h2>
                        <p>${esc(descripcion)}</p>
                        <p><strong>Costo:</strong> $ ${costo}</p>
                        <p><strong>Fecha:</strong> ${esc(item.Fecha)}${horario}${lugar}</p>
                        <p><strong>Cupo:</strong> ${cupo > 0 ? `${inscritos}/${cupo}` : `${inscritos} inscriptos · sin límite`}</p>
                        ${actions}
                    </div>
                `;
            }).join('');

            if (!seminarios.length) {
                box.innerHTML = '<p class="full-grid muted-center">No hay seminarios o eventos.</p>';
            }
            return true;
        } catch (error) {
            say(error.message || 'No se pudieron cargar los seminarios. Revisá la conexión con el servidor.', true);
            return false;
        }
    }

    // Guarda un nuevo seminario.
    const saveButton = document.getElementById('btnGuardarSeminario');

    if (saveButton) {
        saveButton.onclick = () => {
            const form = new FormData();

            form.append(
                'nombre',
                document.getElementById('tituloSeminario').value.trim()
            );
            form.append(
                'descripcion',
                document.getElementById('descripcionSeminario').value.trim()
            );
            form.append(
                'costo',
                document.getElementById('costoSeminario').value || 0
            );
            form.append(
                'fecha',
                document.getElementById('fechaSeminario').value
            );
            form.append('hora', document.getElementById('horaSeminario')?.value || '');
            form.append('lugar', document.getElementById('lugarSeminario')?.value.trim() || '');
            form.append('cupo', document.getElementById('cupoSeminario')?.value || 0);

            requestJSON('api/seminarios.php', { method: 'POST', body: form })
                .then((data) => {
                    say(data.message, data.status !== 'success');

                    if (data.status === 'success') {
                        load();
                    }
                })
                .catch(() => {
                    say('Error en la comunicación con el servidor.', true);
                });
        };
    }

    // Edita un seminario existente.
    window.editarSem = (id, nombre, descripcion, costo, fecha, hora = '', lugar = '', cupo = 0) => {
        const nuevoNombre = prompt('Nombre:', nombre);
        if (nuevoNombre === null) return;
        const nuevaDescripcion = prompt('Descripción:', descripcion);
        if (nuevaDescripcion === null) return;
        const nuevoCosto = prompt('Costo:', costo);
        if (nuevoCosto === null) return;
        const nuevaFecha = prompt('Fecha YYYY-MM-DD:', fecha);
        if (nuevaFecha === null) return;
        const nuevaHora = prompt('Hora HH:MM (opcional):', hora);
        if (nuevaHora === null) return;
        const nuevoLugar = prompt('Lugar (opcional):', lugar);
        if (nuevoLugar === null) return;
        const nuevoCupo = prompt('Cupo máximo (0 = sin límite):', cupo);
        if (nuevoCupo === null) return;

        const form = new FormData();
        form.append('accion', 'editar');
        form.append('id', id);
        form.append('nombre', nuevoNombre);
        form.append('descripcion', nuevaDescripcion);
        form.append('costo', nuevoCosto);
        form.append('fecha', nuevaFecha);
        form.append('hora', nuevaHora);
        form.append('lugar', nuevoLugar);
        form.append('cupo', nuevoCupo);

        requestJSON('api/seminarios.php', { method: 'POST', body: form })
            .then((data) => { say(data.message, data.status !== 'success'); if (data.status === 'success') load(); })
            .catch((error) => say(error.message || 'Error en la comunicación con el servidor.', true));
    };

    // Elimina un seminario después de confirmar la operación.
    window.delSem = (id) => {
        if (!confirm('¿Eliminar este seminario o evento?')) {
            return;
        }

        const form = new FormData();
        form.append('accion', 'eliminar');
        form.append('id', id);

        requestJSON('api/seminarios.php', { method: 'POST', body: form })
            .then(async (data) => {
                say(data.message || 'No se pudo eliminar el evento.', data.status !== 'success');
                if (data.status === 'success') await load();
            })
            .catch((error) => {
                say(error.message || 'No se pudo eliminar el evento.', true);
            });
    };

    // Evita doble clic y solicitudes simultáneas para la misma acción/evento.
    const accionesEnCurso = new Set();
    async function ejecutarAccionSeminario(id, accion, pregunta, mensajeError) {
        const clave = `${accion}:${Number(id)}`;
        if (!Number.isInteger(Number(id)) || Number(id) <= 0 || accionesEnCurso.has(clave)) return;
        if (pregunta && !confirm(pregunta)) return;
        accionesEnCurso.add(clave);
        const botones = [...document.querySelectorAll('button[onclick]')].filter(b => (b.getAttribute('onclick') || '').includes(`(${Number(id)})`));
        botones.forEach(b => { b.disabled = true; b.setAttribute('aria-busy', 'true'); });
        try {
            const form = new FormData();
            form.append('accion', accion);
            form.append('id', String(Number(id)));
            const data = await requestJSON('api/portal.php', { method: 'POST', body: form });
            say(data.message || (data.status === 'success' ? 'Operación realizada.' : mensajeError), data.status !== 'success');
            if (data.status === 'success') await load();
        } catch (error) {
            say(error.message || mensajeError, true);
        } finally {
            accionesEnCurso.delete(clave);
            botones.forEach(b => { b.disabled = false; b.removeAttribute('aria-busy'); });
        }
    }

    // Inscribe al alumno autenticado en un seminario/evento.
    // Si el evento tiene costo, avisa antes de generar el pago pendiente.
    window.inscribirSeminario = async (id, costo = 0, nombre = '') => {
        const costoNum = Number(costo || 0);
        if (costoNum > 0 && !confirm(`Este seminario/evento tiene un costo de $ ${costoNum.toFixed(2)}.\nSe generará un pago pendiente que el administrador va a verificar.\n¿Querés continuar?`)) return;
        await ejecutarAccionSeminario(id, 'inscribir_seminario', null, 'No se pudo completar la inscripción.');
    };

    // Cancela una inscripción existente.
    window.cancelarSeminario = (id) => ejecutarAccionSeminario(id, 'cancelar_seminario', '¿Cancelar tu inscripción a este evento?', 'No se pudo cancelar la inscripción.');

    // Carga inicial.
    load();

    window.entrarEsperaSeminario = (id) => ejecutarAccionSeminario(id, 'entrar_espera_seminario', 'El evento está lleno. ¿Querés entrar en la lista de espera?', 'No se pudo entrar en la lista de espera.');

    window.salirEsperaSeminario = (id) => ejecutarAccionSeminario(id, 'salir_espera_seminario', '¿Salir de la lista de espera de este evento?', 'No se pudo cancelar la espera.');

});
