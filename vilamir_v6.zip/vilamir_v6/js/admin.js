/** Archivo: admin.js — Interacciones del navegador relacionadas con admin. */
// Panel de administración.
// Este archivo controla las pestañas, formularios, tablas y operaciones CRUD.
// La comunicación con PHP se realiza mediante fetch() y la API api/admin.php.

const API = 'api/admin.php';

let current = 'alumnos';
let editing = null;
let rows = [];

// Configuración de los campos de cada módulo.
const modules = {
    alumnos: {
        title: '🎓 Alumnos',
        fields: [
            ['nombre', 'Nombre', 'text', 1],
            ['apellido', 'Apellido', 'text', 1],
            ['email', 'Correo', 'email', 1],
            ['password', 'Contraseña', 'password', 0],
            ['fecha_nacimiento', 'Fecha de nacimiento', 'date', 0],
            ['direccion', 'Dirección', 'text', 0],
            ['telefono', 'Teléfono', 'text', 0],
            ['cobertura_medica', 'Cobertura médica', 'text', 0]
        ]

},

    profesores: {
        title: '🏫 Profesores',
        fields: [
            ['nombre', 'Nombre', 'text', 1],
            ['apellido', 'Apellido', 'text', 1],
            ['telefono', 'Teléfono', 'text', 0],
            ['cedula', 'Cédula', 'text', 0],
            ['direccion', 'Dirección', 'text', 0],
            ['especialidad', 'Especialidad', 'text', 0],
            ['email', 'Correo', 'email', 1],
            ['password', 'Contraseña inicial', 'password', 0]
        ]

},

    responsables: {
        title: 'Responsables',
        fields: [
            ['id_alumno', 'Alumno', 'alumnos', 1],
            ['nombre', 'Nombre', 'text', 1],
            ['apellido', 'Apellido', 'text', 1],
            ['parentesco', 'Parentesco', 'parentesco', 1],
            ['cedula', 'Cédula', 'text', 0],
            ['telefono', 'Teléfono', 'text', 0],
            ['direccion', 'Dirección', 'text', 0]
        ]

},

    disciplinas: {
        title: '🥋 Disciplinas',
        fields: [
            ['nombre', 'Nombre', 'text', 1],
            ['descripcion', 'Descripción', 'textarea', 0],
            ['costo', 'Costo', 'number', 0]
        ]

},

    grupos: {
        title: 'Grupos',
        fields: [
            ['nombre', 'Nombre del grupo', 'text', 1],
            ['id_disciplina', 'Disciplina', 'disciplinas', 1],
            ['nivel', 'Nivel', 'nivel', 1],
            ['cupo_maximo', 'Cupo máximo', 'number', 1],
            ['descripcion', 'Descripción', 'textarea', 0]
        ]

},

    horarios: {
        title: 'Horarios',
        fields: [
            ['id_grupo', 'Grupo', 'grupos', 1],
            ['dia', 'Día', 'dia', 1],
            ['hora_inicio', 'Hora inicio', 'time', 1],
            ['hora_fin', 'Hora fin', 'time', 1]
        ]

},

    pagos: {
        title: 'Pagos',
        fields: [
            ['id_alumno', 'Alumno', 'alumnos', 1],
            ['tipo', 'Tipo', 'text', 1],
            ['fecha', 'Fecha', 'date', 1],
            ['fecha_vencimiento', 'Fecha de vencimiento', 'date', 0],
            ['importe', 'Importe', 'number', 1],
            ['estado', 'Estado', 'pago', 1],
            ['metodo_pago', 'Método de pago', 'metodoPago', 0]
        ]

},

    notificaciones: {
        title: 'Notificaciones',
        fields: [
            ['id_alumno', 'Alumno', 'alumnos', 1],
            ['estado', 'Estado', 'notificacion', 1],
            ['mensaje', 'Mensaje', 'textarea', 1],
            ['fecha', 'Fecha', 'date', 1]
        ]

},

    seminarios: {
        title: '🎓 Seminarios y eventos',
        fields: [
            ['nombre', 'Nombre', 'text', 1],
            ['descripcion', 'Descripción', 'textarea', 0],
            ['costo', 'Costo', 'number', 0],
            ['fecha', 'Fecha', 'date', 1],
            ['hora', 'Hora', 'time', 0],
            ['lugar', 'Lugar', 'text', 0],
            ['cupo', 'Cupo', 'number', 0]
        ]

},

    promociones: {
        title: '🎁 Promociones',
        fields: [
            ['nombre', 'Nombre de la promoción', 'text', 1],
            ['descripcion', 'Descripción para los alumnos', 'textarea', 0],
            ['descuento', 'Precio mensual (UYU)', 'number', 1],
            ['fecha_inicio', 'Fecha de inicio', 'date', 0],
            ['fecha_fin', 'Fecha de vencimiento', 'date', 0],
            ['activa', 'Estado de publicación', 'estadoPromo', 1]
        ]

},

    usuarios: {
        title: ' Usuarios y roles',
        fields: [
            ['email', 'Correo', 'email', 1],
            ['password', 'Contraseña', 'password', 0],
            ['rol', 'Rol', 'rol', 1]
        ]

},

    inscripciones_disciplina: {
        title: 'Inscripciones a disciplinas',
        fields: [
            ['id_alumno', 'Alumno', 'alumnos', 1],
            ['id_disciplina', 'Disciplina', 'disciplinas', 1],
            ['fecha', 'Fecha', 'date', 1],
            ['estado', 'Estado', 'estadoIns', 1]
        ]

},

    inscripciones_seminario: {
        title: '🎓 Inscripciones a seminarios',
        fields: [
            ['id_alumno', 'Alumno', 'alumnos', 1],
            ['id_seminario', 'Seminario', 'seminarios', 1],
            ['fecha', 'Fecha', 'date', 1],
            ['estado', 'Estado', 'estadoIns', 1]
        ]

}

};

// Escapa caracteres especiales para evitar insertar HTML inseguro.
const esc = (value) => String(value ?? '').replace(
    /[&<>"']/g,
    (match) => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'

}[match])
);

// Realiza una consulta GET a la API administrativa.
async function get(entity, params = '') {
    const response = await fetch(
        `${API}?entity=${encodeURIComponent(entity)}${params ? '&' + params : ''}&t=${Date.now()}`,
        {
 cache: 'no-store', credentials: 'same-origin'
}
    );
    let data;
    try {
 data = await response.json();

}
    catch {
 throw new Error('Respuesta inválida del servidor.');

}
    if (!response.ok) throw new Error(data.message || 'Error del servidor.');
    return data;
}

// Inicializa las pestañas, las estadísticas y el primer módulo.
async function init() {
    const tabs = document.getElementById('tabs');

    tabs.innerHTML = Object.entries(modules)
        .map(
            ([key, module]) =>
                `<button type="button" data-module="${key}" onclick="show('${key}')">${module.title}</button>`
        )
        .join('');

    await stats();
    await show('alumnos');
}

// Consulta y muestra los contadores y el resumen operativo del dashboard.
async function stats() {
    const data = await get('dashboard');

    if (data.status !== 'success') return;

    const labels = {
        alumnos: 'Alumnos',
        profesores: 'Profesores',
        responsables: 'Responsables',
        disciplinas: 'Disciplinas',
        grupos: 'Grupos',
        horarios: 'Horarios',
        pagos: 'Pagos',
        notificaciones: 'Notificaciones',
        seminarios: 'Seminarios',
        promociones: 'Promociones',
        usuarios: 'Usuarios'

};

    document.getElementById('stats').innerHTML = Object.entries(labels)
        .map(([key, label]) => `
            <button type="button" class="stat stat-button" onclick="show('${key}')">
                <span>${label}</span>
                <b>${data.counts[key] ?? 0}</b>
            </button>
        `)
        .join('');

    renderDashboardExtra(data);
}

function money(value) {
    return new Intl.NumberFormat('es-UY', {
        style: 'currency',
        currency: 'UYU',
        maximumFractionDigits: 2

}).format(Number(value) || 0);
}

function formatDate(value) {
    if (!value) return 'Sin fecha';
    const parts = String(value).slice(0, 10).split('-');
    return parts.length === 3 ? `${parts[2]}/${parts[1]}/${parts[0]}` : esc(value);
}

function renderDashboardExtra(data) {
    const box = document.getElementById('dashboard-extra');
    if (!box) return;

    const f = data.financial || {
};
    const upcoming = data.upcoming || [];
    const activity = data.activity || [];

    const upcomingHtml = upcoming.length
        ? upcoming.map(item => `
            <div class="dashboard-list-item">
                <div>
                    <strong>${esc(item.Nombre || 'Actividad')}</strong>
                    <span>${formatDate(item.Fecha)}${item.Hora ? ` · ${
esc(item.Hora)
}` : ''}${item.Lugar ? ` · ${
esc(item.Lugar)
}` : ''}</span>
                </div>
                <button type="button" onclick="show('seminarios')">Ver</button>
            </div>`).join('')
        : '<p class="small">No hay actividades próximas.</p>';

    const activityHtml = activity.length
        ? activity.map(item => `
            <div class="dashboard-list-item dashboard-activity-item">
                <div>
                    <strong>${esc(item.Accion || item.Accion_realizada || item.accion || 'Actividad')}</strong>
                    <span>${esc(item.Detalle || item.Descripcion || item.detalle || '')}</span>
                </div>
                <small>${formatDate(item.Fecha || item.Fecha_hora || item.fecha)}</small>
            </div>`).join('')
        : '<p class="small">Todavía no hay actividad registrada.</p>';

    box.innerHTML = `
        <div class="dashboard-alerts">
            <div class="dashboard-card dashboard-card-warning">
                <span class="dashboard-card-label">Pagos pendientes</span>
                <strong>${f.pendientes ?? 0}</strong>
                <small>${money(f.importe_pendiente)} por cobrar</small>
            </div>
            <div class="dashboard-card dashboard-card-danger">
                <span class="dashboard-card-label">Pagos vencidos</span>
                <strong>${f.vencidos ?? 0}</strong>
                <small>${money(f.importe_vencido)} vencidos</small>
            </div>
            <div class="dashboard-card dashboard-card-success">
                <span class="dashboard-card-label">Cobrado este mes</span>
                <strong>${money(f.cobrado_mes)}</strong>
                <small>Pagos registrados como cobrados</small>
            </div>
        </div>

        <div class="dashboard-columns">
            <section class="dashboard-panel">
                <div class="dashboard-panel-head">
                    <div>
                        <h3>Próximas actividades</h3>
                        <p>Seminarios y eventos próximos.</p>
                    </div>
                    <button type="button" onclick="show('seminarios')">Gestionar</button>
                </div>
                <div class="dashboard-list">${upcomingHtml}</div>
            </section>

            <section class="dashboard-panel">
                <div class="dashboard-panel-head">
                    <div>
                        <h3>Actividad reciente</h3>
                        <p>Últimos movimientos registrados.</p>
                    </div>
                    <a href="herramientas.php">Ver todo</a>
                </div>
                <div class="dashboard-list">${activityHtml}</div>
            </section>
        </div>

        <section class="dashboard-quick-actions">
            <div>
                <h3>Accesos rápidos</h3>
                <p>Entrá directamente a las tareas más utilizadas.</p>
            </div>
            <div class="quick-action-buttons">
                <button type="button" data-quick-module="alumnos">+ Alumno</button>
                <button type="button" data-quick-module="profesores">+ Profesor</button>
                <button type="button" data-quick-module="grupos">+ Grupo</button>
                <button type="button" data-quick-module="horarios">+ Horario</button>
                <button type="button" data-quick-module="pagos">+ Pago</button>
                <button type="button" data-quick-module="seminarios">+ Seminario/evento</button>
                <a class="admin-quick-link" href="estadisticas.php"> Asistencia avanzada</a>
                <button type="button" data-quick-action="generar-avisos"> Generar avisos automáticos</button>
                <button type="button" data-quick-action="avisar-alumnos"> Avisar a alumnos</button>
                <button type="button" data-quick-action="avisar-profesores"> Avisar a profesores</button>
                <a href="reportes.php">Abrir reportes</a>
                <a href="herramientas.php">Herramientas</a>
            </div>
        </section>
    `;
}

// Genera el HTML de cada campo del formulario.
function inputHtml([key, label, type, required]) {
    const requiredAttribute = required ? 'required' : '';

    if (type === 'textarea') {
        return `
            <label>
                ${label}
                <textarea id="f_${key}" ${requiredAttribute}></textarea>
            </label>
        `;

}

    const selectTypes = [
        'alumnos',
        'disciplinas',
        'seminarios',
        'grupos',
        'dia',
        'pago',
        'metodoPago',
        'notificacion',
        'rol',
        'estadoIns',
        'nivel',
        'estadoPromo'
    ];

    if (selectTypes.includes(type)) {
        return `
            <label>
                ${label}
                <select id="f_${key}" ${requiredAttribute}></select>
            </label>
        `;

}

    const step = type === 'number' ? 'step="0.01"' : '';
    const min = key === 'importe' ? 'min="0.01"' : '';
    const max = key === 'importe' ? 'max="99999999.99"' : '';

    return `
        <label>
            ${label}
            <input
                id="f_${key}"
                type="${type}"
                ${step}
                ${min}
                ${max}
                ${requiredAttribute}
            >
        </label>
    `;
}

async function cargarResumenPagos() {
    const box = document.getElementById('payment-summary');
    if (!box) return;
    const year = Number(document.getElementById('payment-year')?.value || new Date().getFullYear());
    const month = Number(document.getElementById('payment-month')?.value || new Date().getMonth() + 1);
    try {
        const data = await get('pagos_resumen', `year=${year}&month=${month}`);
        const s = data.summary || {
};
        box.innerHTML = `
            <div class="payment-summary-head">
                <div><span class="panel-kicker">CONTROL FINANCIERO</span><h3>Resumen de pagos</h3><p>Período ${esc(s.periodo || '')}</p></div>
                <div class="payment-summary-total">${money(s.importe_cobrado)} <small>cobrado</small></div>
            </div>
            <div class="payment-summary-grid">
                <div><span>Pagados</span><b>${s.pagados ?? 0}</b><small>${money(s.importe_cobrado)}</small></div>
                <div><span>Pendientes</span><b>${s.pendientes ?? 0}</b><small>${money(s.importe_pendiente)}</small></div>
                <div><span>Vencidos</span><b>${s.vencidos ?? 0}</b><small>${money(s.importe_vencido)}</small></div>
                <div><span>Anulados</span><b>${s.anulados ?? 0}</b><small>${money(s.importe_anulado)}</small></div>
            </div>`;

} catch (e) {
        box.innerHTML = `<p class="admin-error">No se pudo cargar el resumen financiero.</p>`;

}
}

function setupPaymentTools() {
    if (current !== 'pagos') return;
    const now = new Date();
    const y = document.getElementById('payment-year');
    const m = document.getElementById('payment-month');
    if (y && !y.options.length) {
        for (let year = now.getFullYear() - 2; year <= now.getFullYear() + 1; year++) y.insertAdjacentHTML('beforeend', `<option value="${year}">${year}</option>`);
        y.value = now.getFullYear();

}
    if (m && !m.options.length) {
        const months = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
        m.innerHTML = months.map((name,i)=>`<option value="${i+1}">${name}</option>`).join('');
        m.value = now.getMonth()+1;

}
    cargarResumenPagos();
}

function fechaLocalYMDAdmin() {
    const d = new Date();
    const local = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
    return local.toISOString().slice(0, 10);
}

function filterPaymentsAdvanced() {
    if (current !== 'pagos') return;
    if (document.getElementById('payment-from')?.value && document.getElementById('payment-to')?.value && document.getElementById('payment-from').value > document.getElementById('payment-to').value) {
        alert('La fecha Desde no puede ser posterior a la fecha Hasta.');
        return;
    }
    const status = (document.getElementById('payment-status-filter')?.value || '').toLowerCase();
    const from = document.getElementById('payment-from')?.value || '';
    const to = document.getElementById('payment-to')?.value || '';
    const filtered = rows.filter(r => {
        const e = String(r.Estado || '').toLowerCase();
        const f = String(r.Fecha || '').slice(0,10);
        const okStatus = !status || (status === 'vencido' ? e.includes('pend') && r.Fecha_vencimiento && String(r.Fecha_vencimiento) < fechaLocalYMDAdmin() : e.includes(status));
        return okStatus && (!from || f >= from) && (!to || f <= to);

});
    render(filtered);
}

// Cambia de módulo y construye su formulario y tabla.
async function show(entity) {
    current = entity;
    editing = null;
    const module = modules[entity];
    document.querySelectorAll('#tabs button').forEach(btn => btn.classList.toggle('active', btn.dataset.module === entity));

    document.getElementById('module').innerHTML = `
        <h2>${module.title}</h2>
        <p class="small">
            ${entity === 'alumnos' ? 'Crear y editar fichas. La eliminación física está deshabilitada para conservar pagos e historial académico.' : entity === 'promociones' ? 'Administrá nombre, descripción, precio mensual en pesos uruguayos, vigencia y publicación. El precio se guarda como importe, no como porcentaje.' : 'Crear, editar y gestionar registros.'}
            <a href="reportes.php">Ver reportes</a>
        </p>

        ${entity === 'profesores' ? `
        <section id="professor-assignment-host" class="professor-assignment-panel" aria-labelledby="professor-assignment-title">
            <div class="professor-assignment-heading">
                <div>
                    <p class="panel-kicker">ORGANIZACIÓN DOCENTE</p>
                    <h3 id="professor-assignment-title">Clases y grupos por profesor</h3>
                    <p class="small">Seleccioná un profesor para consultar sus disciplinas, grupos asignados y horarios.</p>
                </div>
                <label for="professor-assignment-select">Profesor
                    <select id="professor-assignment-select"><option value="">Cargando profesores…</option></select>
                </label>
            </div>
            <div id="professor-assignment-detail" aria-live="polite"><p class="admin-loading">Cargando asignaciones…</p></div>
        </section>` : ''}

        ${entity === 'pagos' ? `
        <section class="payment-tools">
            <div class="payment-tool-row">
                <label>Mes<select id="payment-month"></select></label>
                <label>Año<select id="payment-year"></select></label>
                <label>Estado<select id="payment-status-filter"><option value="">Todos</option><option value="pagado">Pagados</option><option value="pendiente">Pendientes</option><option value="vencido">Vencidos</option><option value="anulado">Anulados</option></select></label>
                <label>Desde<input type="date" id="payment-from"></label>
                <label>Hasta<input type="date" id="payment-to"></label>
                <button type="button" onclick="filterPaymentsAdvanced()">Filtrar</button>
                <button type="button" class="secondary" onclick="load();cargarResumenPagos()">Restablecer</button>
            </div>
            <div id="payment-summary" class="payment-summary"></div>
        </section>` : ''}

        <div class="form">
            ${module.fields.map(inputHtml).join('')}

            <input type="hidden" id="edit_id">

            <div class="wide actions">
                <button id="save" onclick="save()">Crear</button>
                <button
                    class="cancel"
                    id="cancel"
                    onclick="resetForm()"
                >
                    Cancelar edición
                </button>
                <button onclick="exportCSV()">Exportar CSV</button>
            </div>

            <p id="msg" class="wide"></p>
        </div>

        <input
            class="search"
            id="search"
            oninput="filterTable()"
            placeholder="Buscar en esta tabla..."
        >

        <div id="table" class="table-wrap"></div>`;

    await fillSelects();
    await load();
    if (entity === 'profesores') await setupProfessorAssignments();
    setupPaymentTools();
}

// Consulta en un panel separado las disciplinas, grupos y horarios de cada profesor.
async function setupProfessorAssignments() {
    const select = document.getElementById('professor-assignment-select');
    const detail = document.getElementById('professor-assignment-detail');
    if (!select || !detail) return;

    try {
        detail.innerHTML = '<p class="admin-loading">Consultando profesores, grupos y horarios…</p>';
        const data = await get('profesores_asignaciones');
        if (data.status && data.status !== 'success') {
            throw new Error(data.message || 'La API no devolvió una respuesta correcta.');
        }
        const teacherData = await get('profesores');
        if (teacherData.status && teacherData.status !== 'success') {
            throw new Error(teacherData.message || 'No se pudo consultar la lista de profesores.');
        }
        const teachers = teacherData.rows || [];
        const groupAssignments = data.grupos || [];
        const disciplineAssignments = data.disciplinas || [];
        const assignmentWarning = data.warning ? `<p class="admin-error">${esc(data.warning)}</p>` : '';

        if (!teachers.length) {
            select.innerHTML = '<option value="">No hay profesores registrados</option>';
            detail.innerHTML = '<p class="admin-error">No se encontraron profesores para consultar. Verificá que existan registros en el módulo Profesores.</p>';
            return;
        }

        select.innerHTML = '<option value="">Seleccionar profesor…</option>' + teachers.map((teacher) => {
            const id = Number(teacher.ID_Profesor);
            return `<option value="${id}">${esc(`${teacher.Nombre || ''} ${teacher.Apellido || ''}`.trim())}</option>`;
        }).join('');

        function renderTeacherAssignments() {
            const id = Number(select.value);
            if (!id) {
                detail.innerHTML = '<p class="small">Elegí un profesor para ver sus asignaciones.</p>';
                return;
            }
            const teacher = teachers.find((item) => Number(item.ID_Profesor) === id);
            const groups = groupAssignments.filter((item) => Number(item.ID_Profesor) === id && item.ID_Grupo !== null && item.ID_Grupo !== undefined);
            const disciplines = disciplineAssignments.filter((item) => Number(item.ID_Profesor) === id && item.ID_Disciplina !== null && item.ID_Disciplina !== undefined);
            const uniqueDisciplines = [...new Set(disciplines.map((item) => item.Disciplina).filter(Boolean))];
            const uniqueGroups = new Map();
            groups.forEach((item) => {
                const key = String(item.ID_Grupo);
                if (!uniqueGroups.has(key)) uniqueGroups.set(key, { ...item, horarios: [] });
                if (item.Dia && item.Hora_inicio && item.Hora_fin) {
                    const g = uniqueGroups.get(key);
                    const schedule = `${item.Dia} ${String(item.Hora_inicio).slice(0,5)}–${String(item.Hora_fin).slice(0,5)}`;
                    if (!g.horarios.includes(schedule)) g.horarios.push(schedule);
                }
            });
            const groupList = [...uniqueGroups.values()];
            const groupDisciplines = [...new Set(groupList.map((item) => item.Disciplina).filter(Boolean))];
            const allDisciplines = [...new Set([...uniqueDisciplines, ...groupDisciplines])];

            detail.innerHTML = assignmentWarning + `
                <div class="professor-assignment-summary">
                    <div><span>Profesor</span><strong>${esc(`${teacher?.Nombre || ''} ${teacher?.Apellido || ''}`.trim())}</strong></div>
                    <div><span>Grupos asignados</span><strong>${groupList.length}</strong></div>
                    <div><span>Disciplinas</span><strong>${allDisciplines.length}</strong></div>
                </div>
                <div class="professor-assignment-columns">
                    <section><h4>Disciplinas</h4>${allDisciplines.length
                        ? `<ul>${allDisciplines.map((name) => `<li>${esc(name)}</li>`).join('')}</ul>`
                        : '<p class="small">No tiene disciplinas vinculadas directamente ni por sus grupos.</p>'}</section>
                    <section><h4>Grupos y horarios</h4>${groupList.length
                        ? `<div class="table-wrap"><table><thead><tr><th>Grupo</th><th>Disciplina</th><th>Horarios</th><th>Estado</th></tr></thead><tbody>${groupList.map((item) => `<tr><td>${esc(item.Grupo || 'Grupo sin nombre')}</td><td>${esc(item.Disciplina || 'Sin disciplina')}</td><td>${item.horarios.length ? item.horarios.map(esc).join('<br>') : 'Sin horario cargado'}</td><td>${esc(item.Estado_asignacion || 'Asignado')}</td></tr>`).join('')}</tbody></table></div>`
                        : '<p class="small">Este profesor no tiene grupos asignados.</p>'}</section>
                </div>`;
        }
        select.addEventListener('change', renderTeacherAssignments);
        if (teachers.length === 1) select.value = String(teachers[0].ID_Profesor);
        renderTeacherAssignments();
    } catch (error) {
        if (select) select.innerHTML = '<option value="">No se pudo cargar la lista</option>';
        detail.innerHTML = `<p class="admin-error"><strong>No se pudieron cargar las clases y grupos.</strong><br>${esc(error.message || 'Error desconocido')}. Revisá la conexión a la base de datos y que existan las tablas de asignación de profesores.</p>`;
    }
}

// Carga las opciones de los campos que utilizan listas desplegables.
async function fillSelects() {
    for (const [key, , type] of modules[current].fields) {
        const element = document.getElementById(`f_${key}`);

        if (!element) {
            continue;

}

        let options = [];

        if (type === 'dia') {
            options = [
                'Lunes',
                'Martes',
                'Miércoles',
                'Jueves',
                'Viernes',
                'Sábado',
                'Domingo'
            ];

}

        if (type === 'nivel') {
            options = ['Principiante', 'Intermedio', 'Avanzado', 'Competencia'];

}

        if (type === 'estadoPromo') {
            options = [
                { value: '1', label: 'Activa · visible para alumnos' },
                { value: '0', label: 'Inactiva · no se publica' }
            ];
        }

        if (type === 'pago') {
            options = ['Pendiente', 'Pagado', 'Anulado'];

}

        if (type === 'metodoPago') {
            options = ['Efectivo', 'Transferencia', 'Tarjeta', 'Débito automático', 'Otro'];

}

        if (type === 'notificacion') {
            options = ['Pendiente', 'Leída', 'Enviada'];

}

        if (type === 'rol') {
            options = ['Alumno', 'Profesor', 'Administrador'];

}

        if (type === 'parentesco') {
            options = ['Madre', 'Padre', 'Tutor legal', 'Otro adulto responsable'];

}

        if (type === 'estadoIns') {
            options = ['Activa', 'Pendiente', 'Cancelada'];

}

        if (options.length) {
            element.innerHTML = options
                .map((option) => {
                    if (option && typeof option === 'object') {
                        return `<option value="${esc(option.value)}">${esc(option.label)}</option>`;
                    }
                    return `<option value="${esc(option)}">${esc(option)}</option>`;
                })
                .join('');

}

        // Para estos campos se consultan registros reales de la base de datos.
        if (['alumnos', 'disciplinas', 'seminarios', 'grupos'].includes(type)) {
            const data = await get(type);
            const rows = data.rows || [];

            element.innerHTML = '<option value="">Seleccionar</option>';

            rows.forEach((row) => {
                if (type === 'alumnos') {
                    element.innerHTML += `
                        <option value="${row.ID_Alumno}">
                            ${esc(`${
row.Nombre
} ${
row.Apellido
}`)}
                            — ${esc(row.Email)}
                        </option>
                    `;

}

                if (type === 'disciplinas') {
                    element.innerHTML += `
                        <option value="${row.ID_Disciplina}">
                            ${esc(row.Nombre)}
                        </option>
                    `;

}

                if (type === 'seminarios') {
                    element.innerHTML += `
                        <option value="${row.ID_Seminario}">
                            ${esc(row.Nombre)}
                        </option>
                    `;

}

                if (type === 'grupos') {
                    element.innerHTML += `
                        <option value="${row.ID_Grupo}">
                            ${esc(row.Nombre)}${row.Disciplina ? ' — ' + esc(row.Disciplina) : ''}
                        </option>
                    `;

}

});

}

}
}

// Obtiene los registros del módulo seleccionado.
async function load() {
    const box = document.getElementById('table');
    if (box) box.innerHTML = '<div class="admin-loading">Cargando registros…</div>';
    try {
        const data = await get(current);
        rows = data.rows || [];
        render(rows);

} catch (error) {
        rows = [];
        if (box) box.innerHTML = `<div class="admin-error">${esc(error.message)}</div>`;

}
}

// Acciones administrativas de baja lógica (nunca borran el registro del alumno).
function accionesBajaAlumno(row, index) {
    const estado = String(row.Estado_baja || 'NO_DISPONIBLE');
    if (estado === 'NO_DISPONIBLE') return '<span class="small">Estado de baja no disponible</span>';
    if (estado === 'BAJA_DEFINITIVA') {
        return `<span class="small">Baja definitiva</span> <button type="button" onclick="gestionarBajaAlumno(${index}, 'reactivar')">Reactivar</button>`;
    }
    if (estado === 'BAJA_TEMPORAL') {
        return `<span class="small">Baja temporal</span> <button type="button" onclick="gestionarBajaAlumno(${index}, 'reactivar')">Levantar baja</button> <button type="button" class="danger" onclick="gestionarBajaAlumno(${index}, 'definitiva')">Pasar a definitiva</button>`;
    }
    return `<button type="button" onclick="gestionarBajaAlumno(${index}, 'temporal')">Baja temporal</button> <button type="button" class="danger" onclick="gestionarBajaAlumno(${index}, 'definitiva')">Baja definitiva</button>`;
}

async function gestionarBajaAlumno(index, tipo) {
    const alumno = rows[index];
    if (!alumno || !alumno.ID_Alumno) return;
    const nombre = [alumno.Nombre, alumno.Apellido].filter(Boolean).join(' ');
    const acciones = {
        temporal: {
            accion: 'baja_temporal',
            confirmacion: 'Se cancelarán las inscripciones activas de ' + nombre + '. Conservará su acceso y podrá volver a inscribirse. Pagos y asistencias históricas no se borran. ¿Continuar?'
        },
        definitiva: {
            accion: 'baja_definitiva',
            confirmacion: 'Se cancelarán las inscripciones y se bloqueará el acceso de ' + nombre + '. Pagos y asistencias históricas se conservarán. La reactivación requerirá intervención del administrador. ¿Continuar?'
        },
        reactivar: {
            accion: 'reactivar',
            confirmacion: 'Se levantará la baja de ' + nombre + '. Las inscripciones canceladas no se reactivarán automáticamente. ¿Continuar?'
        }
    };
    const config = acciones[tipo];
    if (!config || !confirm(config.confirmacion)) return;

    const form = new FormData();
    form.append('entity', 'alumnos');
    form.append('accion', config.accion);
    form.append('id', String(alumno.ID_Alumno));

    try {
        const response = await fetch(API, { method: 'POST', body: form });
        const data = await response.json();
        alert(data.message || 'Operación finalizada.');
        if (data.status === 'success') await load();
    } catch (error) {
        alert('No se pudo completar la operación. Verificá la conexión e intentá nuevamente.');
    }
}

// Construye la tabla y sus botones de acción.
function render(data) {
    const box = document.getElementById('table');

    if (!data.length) {
        box.innerHTML = '<p class="small">No hay registros.</p>';
        return;

}

    const keys = Object.keys(data[0]).filter((key) => key !== 'Creado_en');

    let html = `
        <table>
            <thead>
                <tr>
                    ${keys.map((key) => `<th>${
esc(key)
}</th>`).join('')}
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
    `;

    data.forEach((row, index) => {
        html += `
            <tr>
                ${keys
                    .map((key) => `<td>${
esc(row[key])
}</td>`)
                    .join('')}
                <td>
                    ${current === 'pagos' && String(row.Estado || '').toLowerCase() === 'anulado' ? '<span class="small">Anulado · solo consulta</span>' : `<button onclick="edit(${index})">Editar</button>`}
                    ${current === 'pagos' ? `<a class="table-action-link" href="comprobante_pago.php?id=${Number(row.ID_Pago)}" target="_blank" rel="noopener">Comprobante</a>` : ''}
                    ${current === 'alumnos' ? accionesBajaAlumno(row, index) : (current === 'pagos' && String(row.Estado || '').toLowerCase() === 'anulado' ? '' : `<button class="danger" onclick="removeRow(${index})">${current === 'pagos' ? 'Anular' : 'Eliminar'}</button>`)}
                </td>
            </tr>
        `;

});

    html += `
            </tbody>
        </table>
    `;

    box.innerHTML = html;
}

// Filtra los registros que ya están cargados en memoria.
function filterTable() {
    const query = (
        document.getElementById('search')?.value || ''
    ).toLowerCase();

    const filtered = rows.filter((row) =>
        Object.values(row)
            .join(' ')
            .toLowerCase()
            .includes(query)
    );

    render(filtered);
}

// Convierte nombres de campos JavaScript a nombres de columnas SQL.
function map(key) {
    const mapping = {
        id_alumno: 'ID_Alumno',
        id_disciplina: 'ID_Disciplina',
        id_seminario: 'ID_Seminario',
        id_grupo: 'ID_Grupo',
        fecha_nacimiento: 'Fecha_nacimiento',
        cupo_maximo: 'Cupo_maximo',
        hora_inicio: 'Hora_inicio',
        hora_fin: 'Hora_fin',
        nivel: 'Nivel',
        descripcion: 'Descripcion',
        metodo_pago: 'Metodo_pago',
        fecha_vencimiento: 'Fecha_vencimiento',
        cobertura_medica: 'Cobertura_medica',
        descuento: 'Descuento'

};

    return mapping[key] || `${key.charAt(0).toUpperCase()}${key.slice(1)}`;
}

// Carga un registro existente en el formulario para editarlo.
function edit(index) {
    editing = rows[index];

    const firstKey = Object.keys(editing)[0];
    document.getElementById('edit_id').value = editing[firstKey];

    for (const [key] of modules[current].fields) {
        const element = document.getElementById(`f_${key}`);

        if (element) {
            element.value = editing[map(key)] ?? '';

}

}

    document.getElementById('save').textContent = 'Guardar cambios';
    document.getElementById('cancel').classList.add('is-visible');

    window.scrollTo({
        top: document.getElementById('module').offsetTop - 20,
        behavior: 'smooth'

});
}

// Limpia el formulario y vuelve al modo de creación.
function resetForm() {
    editing = null;

    document.getElementById('edit_id').value = '';

    for (const [key] of modules[current].fields) {
        const element = document.getElementById(`f_${key}`);

        if (element) {
            element.value = '';

}

}

    document.getElementById('save').textContent = 'Crear';
    document.getElementById('cancel').classList.remove('is-visible');
    document.getElementById('msg').textContent = '';
}

// Envía un registro nuevo o una modificación a la API mediante POST.
async function save() {
    const button = document.getElementById('save');
    const message = document.getElementById('msg');
    if (button?.disabled) return;

    // No permitir cuentas nuevas con contraseñas compartidas o predecibles.
    if (['alumnos', 'profesores', 'usuarios'].includes(current)) {
        const password = document.getElementById('f_password')?.value ?? '';
        if (!editing && password.trim() === '') {
            message.textContent = 'Ingresá una contraseña inicial de al menos 8 caracteres.';
            message.className = 'wide err';
            document.getElementById('f_password')?.focus();
            return;
        }
        if (password !== '' && (password.trim() === '' || [...password].length < 8)) {
            message.textContent = 'La contraseña debe tener al menos 8 caracteres.';
            message.className = 'wide err';
            document.getElementById('f_password')?.focus();
            return;
        }
    }

    if (current === 'promociones') {
        const precio = Number(document.getElementById('f_descuento')?.value || 0);
        const inicio = document.getElementById('f_fecha_inicio')?.value || '';
        const fin = document.getElementById('f_fecha_fin')?.value || '';
        if (!Number.isFinite(precio) || precio <= 0) {
            message.textContent = 'El precio mensual debe ser mayor que cero.';
            message.className = 'wide err';
            document.getElementById('f_descuento')?.focus();
            return;
        }
        if (inicio && fin && fin < inicio) {
            message.textContent = 'La fecha de vencimiento no puede ser anterior a la fecha de inicio.';
            message.className = 'wide err';
            document.getElementById('f_fecha_fin')?.focus();
            return;
        }
    }

    if (current === 'pagos') {
        const importe = Number(document.getElementById('f_importe')?.value || 0);
        const fecha = document.getElementById('f_fecha')?.value || '';
        const vencimiento = document.getElementById('f_fecha_vencimiento')?.value || '';
        const desde = new Date(`${fecha}T00:00:00`);
        if (!Number.isFinite(importe) || importe <= 0) {
            message.textContent = 'El importe debe ser mayor que cero.';
            message.className = 'wide err';
            return;
        }
        if (!fecha || Number.isNaN(desde.getTime())) {
            message.textContent = 'Seleccioná una fecha de pago válida.';
            message.className = 'wide err';
            return;
        }
        if (vencimiento && Number.isNaN(new Date(`${vencimiento}T00:00:00`).getTime())) {
            message.textContent = 'La fecha de vencimiento no es válida.';
            message.className = 'wide err';
            return;
        }
    }

    const form = new FormData();
    form.append('entity', current);
    form.append('accion', editing ? 'editar' : 'crear');
    form.append('id', document.getElementById('edit_id').value);
    for (const [key] of modules[current].fields) {
        const element = document.getElementById(`f_${key}`);
        form.append(key, element?.value || '');
    }

    if (button) { button.disabled = true; button.dataset.originalText = button.textContent; button.textContent = 'Guardando…'; }
    try {
        const response = await fetch(API, { method: 'POST', body: form });
        const data = await response.json();
        message.textContent = data.message || (response.ok ? 'Operación completada.' : 'No se pudo guardar el registro.');
        message.className = `wide ${data.status === 'success' ? 'ok' : 'err'}`;
        if (data.status === 'success') {
            resetForm();
            await load();
            await stats();
            if (current === 'pagos') await cargarResumenPagos();
        }
    } catch (error) {
        message.textContent = 'No se pudo conectar con el servidor o la respuesta no es válida. Verificá Apache, la sesión y la conexión a MySQL.';
        message.className = 'wide err';
    } finally {
        if (button) { button.disabled = false; button.textContent = editing ? 'Guardar cambios' : 'Crear'; delete button.dataset.originalText; }
    }
}

// Envía la orden de eliminación a la API después de pedir confirmación.
async function removeRow(index) {
    // Defensa adicional: aunque se invoque manualmente desde la consola,
    // el panel nunca debe solicitar el borrado físico de un alumno.
    if (current === 'alumnos') {
        alert('La eliminación física de alumnos está deshabilitada para proteger pagos e historial académico.');
        return;
    }

    const row = rows[index];
    const id = row[Object.keys(row)[0]];

    let confirmText = '¿Seguro que deseas eliminar este registro? Esta acción puede afectar relaciones asociadas.';
    let motivo = '';
    if (current === 'pagos') {
        confirmText = 'Los pagos no se borran: este registro será ANULADO y quedará conservado en el historial. ¿Continuar?';
        if (!confirm(confirmText)) return;
        const respuestaMotivo = prompt('Motivo obligatorio de la anulación (máximo 255 caracteres):', 'Anulado por administrador');
        if (respuestaMotivo === null) return;
        motivo = respuestaMotivo.trim();
        if (!motivo) { alert('Escribe un motivo para anular el pago.'); return; }
        if (motivo.length > 255) { alert('El motivo no puede superar los 255 caracteres.'); return; }

} else if (!confirm(confirmText)) {
        return;

}

    const form = new FormData();
    form.append('entity', current);
    form.append('accion', 'eliminar');
    form.append('id', id);
    if (current === 'pagos') form.append('motivo_anulacion', motivo);

    const response = await fetch(API, {
        method: 'POST',
        body: form

});

    const data = await response.json();

    alert(data.message || 'Operación finalizada');

    if (data.status === 'success') {
        await load();
        await stats();

}
}

// Genera un CSV con los registros actualmente cargados.
function exportCSV() {
    if (!rows.length) {
        return;

}

    const keys = Object.keys(rows[0]);

    // Neutraliza fórmulas para evitar que Excel ejecute contenido exportado
    // desde nombres u otros campos introducidos por usuarios.
    const safeCell = (value) => {
        let text = String(value ?? '');
        if (/^\s*[=+@\-]/.test(text)) text = "'" + text;
        return `"${text.replaceAll('"', '""')}"`;
    };

    const csv = '\uFEFF' + [
        keys.map(safeCell).join(';'),
        ...rows.map((row) => keys.map((key) => safeCell(row[key])).join(';'))
    ].join('\r\n');

    const link = document.createElement('a');
    const objectUrl = URL.createObjectURL(
        new Blob([csv], { type: 'text/csv;charset=utf-8' })
    );
    link.href = objectUrl;
    link.download = `${current}_${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
}

// Accesos rápidos: delegación de eventos para evitar depender de onclick inline.
// También enfoca el primer campo del formulario para que la acción sea directa.
document.addEventListener('click', async (event) => {
    const button = event.target.closest('[data-quick-module], [data-quick-action]');
    if (!button) return;

    event.preventDefault();
    if (button.disabled) return;
    button.disabled = true;

    try {
        const moduleName = button.dataset.quickModule;
        const actionName = button.dataset.quickAction;

        if (moduleName && Object.prototype.hasOwnProperty.call(modules, moduleName)) {
            await show(moduleName);
            const firstField = document.querySelector(
                '#module .form input:not([type="hidden"]):not([type="checkbox"]), #module .form select, #module .form textarea'
            );
            firstField?.focus({ preventScroll: false });
            document.getElementById('module')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        } else if (actionName === 'generar-avisos') {
            await generarAvisosAutomaticos();
        } else if (actionName === 'avisar-alumnos') {
            await difundirAviso('alumnos');
        } else if (actionName === 'avisar-profesores') {
            await difundirAviso('profesores');
        }
    } catch (error) {
        console.error('Error en Accesos rápidos:', error);
        alert('No se pudo ejecutar el acceso rápido. Revisá la conexión y volvé a intentarlo.');
    } finally {
        button.disabled = false;
    }
});

// Inicia el panel cuando se carga el archivo JavaScript.
init();

// V11: acciones explícitas de notificaciones. Los envíos masivos requieren confirmación.
async function ejecutarAccionNotificacion(accion, datos={
}) {
    const fd = new FormData();
 fd.append('accion', accion);
    Object.entries(datos).forEach(([k,v]) => fd.append(k, v));
    const res = await fetch('api/notificaciones.php', {
method:'POST', body:fd, credentials:'same-origin', cache:'no-store'
});
    const data = await res.json();
    if (!res.ok || data.status !== 'success') throw new Error(data.message || 'No se pudo completar la operación.');
    return data;
}
async function generarAvisosAutomaticos() {
    if (!confirm('Se revisarán pagos por vencer/vencidos, próximos eventos y promociones activas. Solo se crearán avisos que todavía no existan. ¿Continuar?')) return;
    try {
 const d=await ejecutarAccionNotificacion('generar_automaticas');
 alert(`${d.message}\nPagos: ${d.creadas.pagos}\nEventos: ${d.creadas.eventos}\nPromociones: ${d.creadas.promociones}\nTotal: ${d.total}`);

}
    catch(e) {
 alert(e.message);

}
}
async function difundirAviso(destino) {
    const etiqueta=destino==='alumnos'?'todos los alumnos':'todos los profesores';
    const mensaje=prompt(`Escribí el aviso que se enviará a ${etiqueta}:`);
    if (mensaje===null) return;
    if (!mensaje.trim()) {
 alert('El mensaje no puede estar vacío.');
 return;

}
    if (!confirm(`¿Confirmás enviar este aviso a ${etiqueta}?\n\n${mensaje.trim()}`)) return;
    try {
 const d=await ejecutarAccionNotificacion(`difundir_${destino}`, {
mensaje:mensaje.trim()
});
 alert(`${d.message} Destinatarios: ${d.cantidad}.`);

}
    catch(e) {
 alert(e.message);

}
}

// ============================================================================
// Notificaciones del administrador: pagos generados por inscripciones de
// alumnos y avisos del sistema. Se cargan al entrar al panel y permiten
// marcar cada aviso como leído.
// ============================================================================
(function () {
    'use strict';

    const contenedor = document.getElementById('listaNotificacionesAdmin');

    if (!contenedor) return;

    const mensaje = document.getElementById('mensajeNotificacionesAdmin');

    const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (m) => ({
        '&': '&', '<': '<', '>': '>', '"': '"', "'": '&#039;'
    }[m]));

    window.cargarNotificacionesAdmin = async function () {

        contenedor.innerHTML = '<p class="muted">Cargando notificaciones…</p>';

        try {

            const res = await fetch('api/notificaciones_usuario.php', {
                credentials: 'same-origin',
                cache: 'no-store'
            });

            const text = await res.text();

            let data;

            try {
                data = JSON.parse(text);
            } catch (e) {
                throw new Error('Respuesta inválida del servidor (' + res.status + ').');
            }

            if (data.status !== 'success') {
                contenedor.innerHTML = '<p class="muted">' + esc(data.message || 'No hay notificaciones disponibles.') + '</p>';
                return;
            }

            const rows = Array.isArray(data.rows) ? data.rows : [];

            if (!rows.length) {
                contenedor.innerHTML = '<p class="muted">Todavía no tenés notificaciones. Cuando un alumno se inscriba en una disciplina o seminario con costo, el aviso del pago aparecerá acá.</p>';
                return;
            }

            contenedor.innerHTML = rows.map((n) => {
                const leida = Number(n.Leida) === 1;
                const fecha = String(n.Fecha || '').slice(0, 16).replace('T', ' ');
                return `
                    <article class="public-card admin-notif-card${leida ? ' leida' : ''}">
                        <div>
                            <strong>${esc(n.Titulo || 'Aviso de VILAMIR')}</strong>
                            <p>${esc(n.Mensaje)}</p>
                            <small>${esc(fecha)}${leida ? ' · leída' : ' · sin leer'}</small>
                        </div>
                        ${leida ? '' : `<button type="button" data-id="${Number(n.ID_Notificacion_Usuario)}" class="btn-secondary">Marcar como leída</button>`}
                    </article>
                `;
            }).join('');

            if (mensaje) {
                const sinLeer = rows.filter((r) => Number(r.Leida) !== 1).length;
                mensaje.textContent = sinLeer ? `${sinLeer} notificación(es) sin leer.` : 'Estás al día: no tenés notificaciones sin leer.';
                mensaje.className = sinLeer ? 'error' : 'success';
            }
        } catch (e) {
            contenedor.innerHTML = '<p class="muted">' + esc(e.message || 'No se pudieron cargar las notificaciones.') + '</p>';
        }
    };

    // Marcar una notificación como leída.
    contenedor.addEventListener('click', async (evento) => {

        const boton = evento.target.closest('button[data-id]');

        if (!boton) return;

        const id = Number(boton.dataset.id);

        if (!Number.isInteger(id) || id <= 0) return;

        boton.disabled = true;

        try {

            const fd = new FormData();

            fd.append('accion', 'leer');
            fd.append('id', String(id));

            const res = await fetch('api/notificaciones_usuario.php', {
                method: 'POST',
                body: fd,
                credentials: 'same-origin'
            });

            const data = await res.json();

            if (data.status !== 'success') throw new Error(data.message || 'No se pudo marcar como leída.');

            await window.cargarNotificacionesAdmin();
        } catch (e) {

            boton.disabled = false;

            if (mensaje) {
                mensaje.textContent = e.message || 'No se pudo marcar como leída.';
                mensaje.className = 'error';
            }
        }
    });

    // Carga inicial junto con el resto del panel.
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', window.cargarNotificacionesAdmin);
    } else {
        window.cargarNotificacionesAdmin();
    }
})();
