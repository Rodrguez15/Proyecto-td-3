/** Gestión administrativa de alumnos: alta, búsqueda, edición y exportación. */
document.addEventListener("DOMContentLoaded", () => {
    const formNuevo = document.getElementById("formNuevoAlumno");
    const formEditar = document.getElementById("formEditarAlumno");
    const panelEditar = document.getElementById("editarAlumnoPanel");
    const lista = document.getElementById("listaAlumnos");
    const mensaje = document.getElementById("mensajeAlumno");
    const busqueda = document.getElementById("buscarAlumno");
    const contador = document.getElementById("contadorAlumnos");
    const btnExportar = document.getElementById("exportarAlumnosCsv");
    let alumnosActuales = [];
    let temporizadorBusqueda;

    const mostrarMensaje = (texto, error = false) => {
        if (!mensaje) return;
        mensaje.textContent = texto;
        mensaje.className = error ? "error message-center" : "success message-center";
    };

    const crearCelda = (fila, texto) => {
        const td = document.createElement("td");
        td.textContent = texto == null || texto === "" ? "—" : String(texto);
        fila.appendChild(td);
        return td;
    };

    const render = alumnos => {
        alumnosActuales = Array.isArray(alumnos) ? alumnos : [];
        lista.replaceChildren();
        contador.textContent = `${alumnosActuales.length} ${alumnosActuales.length === 1 ? "alumno encontrado" : "alumnos encontrados"}`;
        if (!alumnosActuales.length) {
            const vacio = document.createElement("p");
            vacio.className = "js-empty";
            vacio.textContent = "No hay alumnos que coincidan con la búsqueda.";
            lista.appendChild(vacio);
            return;
        }
        const tabla = document.createElement("table");
        tabla.className = "student-management-table";
        const thead = document.createElement("thead");
        const cabecera = document.createElement("tr");
        ["Alumno", "Correo electrónico", "Teléfono", "Fecha de nacimiento", "Acciones"].forEach(t => {
            const th = document.createElement("th"); th.scope = "col"; th.textContent = t; cabecera.appendChild(th);
        });
        thead.appendChild(cabecera);
        const tbody = document.createElement("tbody");
        alumnosActuales.forEach(alumno => {
            const tr = document.createElement("tr");
            crearCelda(tr, `${alumno.Nombre || ""} ${alumno.Apellido || ""}`.trim());
            crearCelda(tr, alumno.Email);
            crearCelda(tr, alumno.Telefono);
            crearCelda(tr, alumno.Fecha_nacimiento);
            const acciones = document.createElement("td");
            const editar = document.createElement("button");
            editar.type = "button"; editar.className = "student-edit-button"; editar.textContent = "Editar";
            editar.addEventListener("click", () => abrirEdicion(alumno));
            acciones.appendChild(editar); tr.appendChild(acciones); tbody.appendChild(tr);
        });
        tabla.append(thead, tbody);
        lista.appendChild(tabla);
    };

    const cargar = async (termino = "") => {
        lista.setAttribute("aria-busy", "true");
        try {
            const url = new URL("api/alumnos.php", window.location.href);
            if (termino.trim()) url.searchParams.set("q", termino.trim());
            const respuesta = await fetch(url, { headers: { "Accept": "application/json" }, cache: "no-store" });
            const data = await respuesta.json();
            if (!respuesta.ok || data.status !== "success") throw new Error(data.message || "No se pudo cargar el listado.");
            render(data.alumnos);
        } catch (error) {
            lista.textContent = error.message || "Error de comunicación con el servidor.";
            mostrarMensaje(error.message || "No se pudo cargar la lista.", true);
        } finally {
            lista.removeAttribute("aria-busy");
        }
    };

    const enviarFormulario = async (form, accion) => {
        const boton = form.querySelector('button[type="submit"]');
        boton.disabled = true;
        const datos = new FormData(form);
        datos.set("accion", accion);
        try {
            const respuesta = await fetch("api/alumnos.php", { method: "POST", body: datos, headers: { "Accept": "application/json" } });
            const data = await respuesta.json();
            if (!respuesta.ok || data.status !== "success") throw new Error(data.message || "No se pudo guardar el alumno.");
            mostrarMensaje(data.message || "Cambios guardados correctamente.");
            form.reset();
            if (accion === "editar") panelEditar.hidden = true;
            await cargar(busqueda.value);
        } catch (error) {
            mostrarMensaje(error.message || "Error de comunicación con el servidor.", true);
        } finally {
            boton.disabled = false;
        }
    };

    function abrirEdicion(alumno) {
        document.getElementById("editarIdAlumno").value = alumno.ID_Alumno;
        document.getElementById("editarNombreAlumno").value = alumno.Nombre || "";
        document.getElementById("editarApellidoAlumno").value = alumno.Apellido || "";
        document.getElementById("editarEmailAlumno").value = alumno.Email || "";
        panelEditar.hidden = false;
        panelEditar.scrollIntoView({ behavior: "smooth", block: "start" });
        document.getElementById("editarNombreAlumno").focus();
    }

    formNuevo?.addEventListener("submit", event => { event.preventDefault(); enviarFormulario(formNuevo, "crear"); });
    formEditar?.addEventListener("submit", event => { event.preventDefault(); enviarFormulario(formEditar, "editar"); });
    document.getElementById("cancelarEdicionAlumno")?.addEventListener("click", () => { formEditar.reset(); panelEditar.hidden = true; });
    busqueda?.addEventListener("input", () => {
        clearTimeout(temporizadorBusqueda);
        temporizadorBusqueda = setTimeout(() => cargar(busqueda.value), 250);
    });

    btnExportar?.addEventListener("click", () => {
        if (!alumnosActuales.length) { mostrarMensaje("No hay alumnos para exportar.", true); return; }
        const columnas = ["ID", "Nombre", "Apellido", "Correo electrónico", "Teléfono", "Fecha de nacimiento"];
        const filas = alumnosActuales.map(a => [a.ID_Alumno, a.Nombre, a.Apellido, a.Email, a.Telefono, a.Fecha_nacimiento]);
        const csv = [columnas, ...filas].map(fila => fila.map(valor => {
            let texto = String(valor ?? "");
            // Evita que una celda controlada por usuario se interprete como fórmula en hojas de cálculo.
            if (/^[=+@\-\t\r]/.test(texto)) texto = "'" + texto;
            return '"' + texto.replace(/"/g, '""') + '"';
        }).join(",")).join("\r\n");
        const blob = new Blob(["\uFEFF", csv], { type: "text/csv;charset=utf-8;" });
        const url = URL.createObjectURL(blob);
        const enlace = document.createElement("a"); enlace.href = url; enlace.download = "alumnos_vilamir.csv";
        document.body.appendChild(enlace); enlace.click(); enlace.remove(); URL.revokeObjectURL(url);
    });

    cargar();
});
