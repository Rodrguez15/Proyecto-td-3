/**
 * Archivo: js/csrf.js — Protección CSRF central para VILAMIR.
 *
 * Envía el token únicamente a destinos del mismo origen. No modifica
 * formularios GET ni agrega el token a solicitudes dirigidas a terceros.
 */
(function () {
    'use strict';

    var meta = document.querySelector('meta[name="csrf-token"]');
    if (!meta) return;

    var TOKEN = meta.getAttribute('content');
    if (!TOKEN) return;

    function esMismoOrigen(destino) {
        try {
            var url = destino instanceof URL
                ? destino
                : new URL(String(destino || window.location.href), window.location.href);
            return url.origin === window.location.origin;
        } catch (_) {
            return false;
        }
    }

    function metodoMutacion(metodo) {
        return ['POST', 'PUT', 'PATCH', 'DELETE'].indexOf(String(metodo || 'GET').toUpperCase()) !== -1;
    }

    // 1) Agregar el token a fetch() solo si la petición modifica datos y es local.
    var fetchOriginal = window.fetch;
    if (typeof fetchOriginal === 'function') {
        window.fetch = function (recurso, opciones) {
            opciones = opciones || {};

            var esRequest = typeof window.Request === 'function' && recurso instanceof window.Request;
            var metodo = opciones.method || (esRequest ? recurso.method : 'GET');
            var destino = esRequest ? recurso.url : recurso;

            if (metodoMutacion(metodo) && esMismoOrigen(destino)) {
                var encabezados;
                try {
                    encabezados = new window.Headers(opciones.headers || (esRequest ? recurso.headers : undefined));
                    if (!encabezados.get('X-CSRF-Token')) {
                        encabezados.set('X-CSRF-Token', TOKEN);
                    }
                    opciones.headers = encabezados;
                } catch (_) {
                    // Si el entorno no permite normalizar Headers, no se envía
                    // el token a ciegas: el servidor rechazará la operación.
                }
            }

            return fetchOriginal.call(this, recurso, opciones);
        };
    }

    // 2) Preparar únicamente formularios mutables que envían al mismo origen.
    function prepararFormulario(form) {
        if (!form || !metodoMutacion(form.method) || !esMismoOrigen(form.action)) return;

        var campo = form.querySelector('input[name="csrf_token"]');
        if (!campo) {
            campo = document.createElement('input');
            campo.type = 'hidden';
            campo.name = 'csrf_token';
            form.appendChild(campo);
        }
        campo.value = TOKEN;
        form.dataset.csrfListo = '1';
    }

    Array.prototype.forEach.call(document.forms, prepararFormulario);
    document.addEventListener('submit', function (evento) {
        prepararFormulario(evento.target);
    }, true);

    // 3) Convertir enlaces heredados a logout.php en un POST local con token.
    document.addEventListener('click', function (evento) {
        if (evento.defaultPrevented || evento.button !== 0 || evento.ctrlKey || evento.metaKey || evento.shiftKey || evento.altKey) return;

        var enlace = evento.target && evento.target.closest ? evento.target.closest('a[href]') : null;
        if (!enlace || (enlace.target && enlace.target !== '_self')) return;

        var destino;
        try {
            destino = new URL(enlace.getAttribute('href'), window.location.href);
        } catch (_) {
            return;
        }

        if (!esMismoOrigen(destino) || !/\/logout\.php$/.test(destino.pathname)) return;

        evento.preventDefault();
        var formulario = document.createElement('form');
        formulario.method = 'POST';
        formulario.action = destino.pathname + destino.search;

        var campo = document.createElement('input');
        campo.type = 'hidden';
        campo.name = 'csrf_token';
        campo.value = TOKEN;
        formulario.appendChild(campo);
        document.body.appendChild(formulario);
        formulario.submit();
    }, true);
})();
