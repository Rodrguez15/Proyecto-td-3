<?php

/*
 * ARCHIVO: perfil_publico.php
 * PROPÓSITO: Página o módulo PHP de perfil publico dentro del sistema Academia VILAMIR.
 */
require_once 'config/conexion.php';

// Necesario para vilamir_enviar_token_csrf() y la seguridad HTTP común.
require_once 'config/sesion.php';

// Página pública: no exige sesión, pero aplica las cabeceras de seguridad.
vilamir_aplicar_seguridad_http();

$codigo = trim((string)($_GET['codigo'] ?? ''));

if ($codigo === '') {

    http_response_code(400);

    exit('Código de identificación no válido.');
    }

$q = $conexion->prepare(
'SELECT a.Nombre, a.Apellido, a.Codigo_qr
     FROM ALUMNO a
     WHERE a.Codigo_qr = ?
     LIMIT 1'
);

$q->execute([$codigo]);

$a = $q->fetch();

if (!$a) {

    http_response_code(404);

    exit('Alumno no encontrado.');
    }

?>
<!doctype html>
<html lang="es">
<head>
<?php vilamir_enviar_token_csrf(); ?>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Perfil VILAMIR</title>
<link rel="stylesheet" href="css/style.css?v=20261026-etapa2-seminarios-galeria-v1">
<script src="js/csrf.js"></script>
</head>
<body class="public-page">
<main class="public-profile">
<div class="profile-logo">
<img src="images/logo-vilamir.jpg" alt="Logo oficial de Academia VILAMIR" class="profile-logo-img">
</div>
<div class="profile-avatar">🥋</div>
<h1><?= htmlspecialchars($a['Nombre'].' '.$a['Apellido'], ENT_QUOTES, 'UTF-8') ?>
</h1>
<p>Alumno de Academia VILAMIR</p>
<h2>Identificación de alumno</h2>
<p>Perfil público de identificación de la Academia VILAMIR.</p>
<p class="small">Código de identificación: <?= htmlspecialchars($a['Codigo_qr'], ENT_QUOTES, 'UTF-8') ?>
</p>
<p class="profile-status">
<span class="badge success">✓ Código válido</span>
</p>
</main>
</body>
</html>
