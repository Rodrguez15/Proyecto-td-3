# Academia VILAMIR — V17

## Limpieza y reorganización de la base de datos

Esta etapa consolida el modelo SQL del proyecto para que las instalaciones nuevas no dependan de una cadena larga de migraciones antiguas.

### Cambios principales

- SQL de instalación consolidado en `sql/mma_systems.sql`.
- Script histórico archivado en `sql/legacy_no_ejecutar/NO_EJECUTAR_migracion_v17_limpieza.sql` (potencialmente destructivo; no ejecutar como parte de V21).
- Migraciones organizadas por versión en `sql/migraciones/`; consultar `sql/README.md` antes de ejecutar cualquiera.
- Eliminadas del modelo vigente las tablas `CLASE` e `INSCRIPCION_CLASE`.
- Eliminados `EXAMEN` y `NIVEL_ALUMNO` del modelo vigente.
- Se conserva `INSCRIPCION_DISCIPLINA` porque el sistema actual todavía la utiliza.
- Se reforzaron índices para alumnos, profesores, grupos, horarios, inscripciones, pagos, asistencia, notificaciones y auditoría.
- Se agregaron al esquema consolidado los datos de alumno `Cedula`, `Peso` y `Categoria` para mantener el modelo académico completo.
- Se mantuvieron las relaciones con borrado controlado mediante claves foráneas.
- Se mantiene el QR del alumno.

### Modelo académico actual

`DISCIPLINA → GRUPO → HORARIO`

Y las inscripciones se separan en:

- `INSCRIPCION_DISCIPLINA`
- `INSCRIPCION_GRUPO_ALUMNO`
- `INSCRIPCION_GRUPO_PROFESOR`
- `INSCRIPCION_SEMINARIO`

### Instalación nueva

Importar únicamente:

`sql/mma_systems.sql`

### Instalación existente

1. Hacer backup de la base `mma_systems`.
2. Este script es histórico y potencialmente destructivo. No ejecutarlo como parte de V21; solo evaluarlo para una instalación antigua con respaldo verificado.
3. Comprobar que el sistema inicia correctamente.
4. No ejecutar migraciones de versiones posteriores si los cambios ya están presentes. No ejecutar esta migración sobre una base V18 o posterior.

### Nota sobre CLASE

La página `clases.php` sigue existiendo porque es la interfaz de administración/consulta de **disciplinas**. El nombre de la página no significa que exista una tabla SQL `CLASE`.

### Nota sobre exámenes

VILAMIR es una academia de entrenamiento práctico. V17 no incluye ningún módulo de exámenes, notas de examen ni niveles asociados a exámenes.
