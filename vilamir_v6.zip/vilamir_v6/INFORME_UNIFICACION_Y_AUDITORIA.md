# Academia VILAMIR — Paquete unificado

## Qué se tomó como base
Se utilizó `vilamir_v4` como base principal por su configuración de seguridad, control de sesión, estructura y correcciones más completas. Se integraron desde `htdocs` los módulos que no estaban en V4: control de acceso/check-in QR, carnet digital y constancia de asistencia. Se conservó el perfil de conexión MySQL de la versión `htdocs` para mantener la conexión prevista con InfinityFree.

## Cambios aplicados
- Se recuperó la gestión ampliada de alumnos (ficha completa, búsqueda, edición, exportación CSV y generación de código QR) junto con su API.
- Se integraron en la API administrativa las operaciones CRUD que faltaban en V4 para alumnos, profesores, responsables, notificaciones e inscripciones a seminarios; se conservó además el resumen financiero mensual de V4.
- Integración de `checkin.php` y `api/checkin.php`; el endpoint de registro ahora acepta únicamente POST y conserva la validación CSRF central.
- Incorporación del carnet digital con acceso limitado al propio alumno o al administrador.
- Incorporación de constancia de asistencia: el alumno solo puede emitir la propia; el administrador puede seleccionar un alumno. Se bloqueó el acceso de profesores a consultas arbitrarias.
- Enlace a la constancia en el portal del alumno y al check-in en el panel administrativo.
- El carnet digital usa QR local generado con la librería QRCodeJS servida desde CDN, evitando depender de una copia minificada que no superó el chequeo sintáctico de Node.
- Refuerzo de escape de datos en la pantalla de check-in.
- La creación de alumnos desde el panel exige contraseña inicial válida; se evita crear cuentas con claves aleatorias que no se informen al administrador.
- Los errores de la API de alumnos ya no devuelven detalles internos de excepciones al navegador.
- El alta de profesores ahora crea la cuenta de acceso con rol Profesor y la vincula al registro docente; la edición sincroniza correo y contraseña de forma transaccional.
- Refuerzo global de desplazamiento horizontal de tablas para móviles, incluyendo tablas agregadas dinámicamente.
- Ajuste de `.htaccess` para el directorio raíz de InfinityFree y bloqueo de carpetas internas, archivos ocultos y respaldos.
- Configuración SMTP desacoplada: se eliminó del paquete la clave de aplicación que venía escrita en el ZIP desplegado. Se añadió `config/smtp_config.php.example` para cargar una clave nueva. La conexión MySQL se mantiene parametrizada, pero las credenciales reales no se incluyen en el paquete y deben cargarse en el archivo privado del entorno.
- Se excluyeron del paquete el directorio `home/` del hosting, `.htpasswd` y respaldos internos; no forman parte de la aplicación y no deben publicarse.

## Base de datos
- Los archivos `sql/mma_systems.sql` de ambos ZIP son idénticos.
- No se modificó `sql/mma_systems.sql`, ninguna migración ni estructura de tablas.
- No se ejecutó SQL ni se conectó a MySQL durante esta revisión.
- No se incluyó ningún proceso automático de migración. Subir este ZIP no debe requerir importar ni recrear la base.

## Validaciones ejecutadas
- Integridad de ambos ZIP originales y extracción.
- `php -l` en todos los PHP del paquete final.
- `node --check` en JavaScript propio del proyecto (la copia local de QRCodeJS del ZIP htdocs presentaba error de parseo, por eso se usa CDN en el carnet digital).
- Comparación de esquema SQL entre los dos paquetes: idéntico.
- Revisión estática de permisos de carnet/constancia, acceso al endpoint de check-in, rutas y recursos.

## Límites de esta auditoría
No se puede certificar funcionamiento al 100% en producción sin ejecutar el sistema contra la base MySQL real de InfinityFree y probar cuentas reales de administrador, profesor y alumno. Tampoco se pueden verificar SMTP, envío de recuperación de contraseña, límites del hosting ni permisos de escritura de `uploads/gallery` desde este entorno. La revisión estática no reemplaza esas pruebas en el sitio.

## Antes de publicar
1. Hacer una copia de seguridad de los archivos actuales y exportar la base de datos desde InfinityFree.
2. Subir el contenido de este ZIP directamente dentro de `htdocs` (no crear una carpeta adicional).
3. Crear en el hosting el archivo privado `config/db_config.local.php` desde `config/db_config.local.php.example` y completar los datos actuales del panel MySQL. `config/db_config.php` ya no contiene credenciales ni valores predeterminados.
4. Configurar SMTP con una clave de aplicación nueva copiando `config/smtp_config.php.example` como `config/smtp_config.php` y completando los datos. No reutilizar la clave de correo incluida en el ZIP original.
5. Probar login, altas/ediciones, pagos, inscripciones, asistencia, check-in QR, carnet y constancia con usuarios de prueba.
6. Confirmar que la carpeta `uploads/gallery` permite las operaciones que ya usa la galería.

## Archivos de base de datos
Los SQL y migraciones se incluyen solo como documentación/backup del proyecto. No ejecutar migraciones para esta actualización.


## Revisión complementaria 16/11/2026

Se continuó sobre una copia del ZIP V5. Se eliminaron valores predeterminados de MySQL del código, se agregó plantilla privada ignorada por Git, se reforzó CSRF para flujos públicos y login, se pasó el cierre de sesión a POST, se bloqueó el borrado de cuentas vinculadas a alumnos y se retiró la clave fija del cron. SMTP ahora falla de forma explícita cuando no está configurado; no se afirma entrega de correo. No se modificó ningún archivo SQL ni se ejecutaron migraciones. Ver `docs/INFORME_CORRECCIONES_2026-11-16.md`.
