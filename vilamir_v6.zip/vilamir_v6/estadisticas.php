<?php
/**
 * ACADEMIA VILAMIR - Panel de estadísticas.
 *
 * Acceso: administradores y profesores.
 * Los profesores solo consultan asistencias de sus grupos asignados.
 * No modifica registros.
 */
require_once __DIR__ . '/config/autenticacion.php';
require_once __DIR__ . '/config/conexion.php';

$rolActual = (string)($_SESSION['usuario_rol'] ?? '');
$esAdmin = strcasecmp($rolActual, 'Administrador') === 0;
$esProfesor = strcasecmp($rolActual, 'Profesor') === 0;
if (!$esAdmin && !$esProfesor) {
    header('Location: index.php');
    exit;
}

$idProfesorActual = 0;
if ($esProfesor) {
    $buscarProfesor = $conexion->prepare('SELECT ID_Profesor FROM PROFESOR WHERE ID_Usuario = ? LIMIT 1');
    $buscarProfesor->execute([(int)($_SESSION['usuario_id'] ?? 0)]);
    $idProfesorActual = (int)$buscarProfesor->fetchColumn();
    // Compatibilidad con perfiles docentes antiguos vinculados por correo,
    // sin modificar automáticamente la base de datos desde esta pantalla.
    if (!$idProfesorActual && !empty($_SESSION['usuario_email'])) {
        $buscarProfesor = $conexion->prepare('SELECT ID_Profesor FROM PROFESOR WHERE LOWER(Email) = LOWER(?) AND (ID_Usuario IS NULL OR ID_Usuario = 0) LIMIT 1');
        $buscarProfesor->execute([(string)$_SESSION['usuario_email']]);
        $idProfesorActual = (int)$buscarProfesor->fetchColumn();
    }
    if (!$idProfesorActual) {
        http_response_code(403);
        exit('Tu cuenta no está vinculada a un perfil de profesor. Pedí a Administración que revise tu perfil docente.');
    }
}

function v21_scalar(PDO $db, string $sql, array $params = [], $fallback = 0) {
    try {
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $value = $stmt->fetchColumn();
        return $value === false ? $fallback : $value;
    } catch (Throwable $e) {
        error_log('VILAMIR estadísticas: ' . $e->getMessage());
        return $fallback;
    }
}

$desde = $_GET['desde'] ?? date('Y-m-01');
$hasta = $_GET['hasta'] ?? date('Y-m-d');
$disciplina = max(0, (int)($_GET['disciplina'] ?? 0));
$grupo = max(0, (int)($_GET['grupo'] ?? 0));
$alumno = max(0, (int)($_GET['alumno'] ?? 0));

// Validar fechas con calendario real: strtotime() acepta fechas como 2026-02-31
// y las normaliza a marzo. createFromFormat permite rechazar esos valores.
foreach (['desde' => &$desde, 'hasta' => &$hasta] as &$fecha) {
    $fechaValida = false;
    if (is_string($fecha) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $fecha)) {
        $objetoFecha = DateTimeImmutable::createFromFormat('!Y-m-d', $fecha);
        $erroresFecha = DateTimeImmutable::getLastErrors();
        $fechaValida = $objetoFecha !== false
            && $objetoFecha->format('Y-m-d') === $fecha
            && ($erroresFecha === false || ($erroresFecha['warning_count'] === 0 && $erroresFecha['error_count'] === 0));
    }
    if (!$fechaValida) {
        $fecha = date('Y-m-d');
    }
}
unset($fecha);
if ($desde > $hasta) {
    [$desde, $hasta] = [$hasta, $desde];
}

$conditions = ['a.Fecha BETWEEN ? AND ?'];
$params = [$desde, $hasta];
if ($esProfesor) {
    // La restricción se aplica en el servidor a todas las consultas,
    // incluso si se manipulan los filtros enviados por URL.
    $conditions[] = "EXISTS (SELECT 1 FROM INSCRIPCION_GRUPO_PROFESOR igp WHERE igp.ID_Grupo = a.ID_Grupo AND igp.ID_Profesor = ? AND igp.Estado = 'Activa')";
    $params[] = $idProfesorActual;
}
if ($disciplina > 0) {
    $conditions[] = 'g.ID_Disciplina = ?';
    $params[] = $disciplina;
}
if ($grupo > 0) {
    $conditions[] = 'a.ID_Grupo = ?';
    $params[] = $grupo;
}
if ($alumno > 0) {
    $conditions[] = 'a.ID_Alumno = ?';
    $params[] = $alumno;
}
$where = implode(' AND ', $conditions);

// Indicadores principales. Los alumnos activos son aquellos con al menos
// una inscripción vigente a disciplina o grupo.
$kpis = [
    'alumnos_activos' => $esAdmin ? (int)v21_scalar($conexion, "SELECT COUNT(DISTINCT a.ID_Alumno) FROM ALUMNO a WHERE EXISTS (SELECT 1 FROM INSCRIPCION_DISCIPLINA i WHERE i.ID_Alumno=a.ID_Alumno AND i.Estado='Activa') OR EXISTS (SELECT 1 FROM INSCRIPCION_GRUPO_ALUMNO g WHERE g.ID_Alumno=a.ID_Alumno AND g.Estado='Activa')") : 0,
    'pagos_pendientes' => $esAdmin ? (int)v21_scalar($conexion, "SELECT COUNT(*) FROM PAGO WHERE Estado='Pendiente'") : 0,
    'importe_pendiente' => $esAdmin ? (float)v21_scalar($conexion, "SELECT COALESCE(SUM(Importe),0) FROM PAGO WHERE Estado='Pendiente'") : 0,
    'inscripciones_disciplina' => $esAdmin ? (int)v21_scalar($conexion, "SELECT COUNT(*) FROM INSCRIPCION_DISCIPLINA WHERE Estado='Activa'") : 0,
    'inscripciones_eventos' => $esAdmin ? (int)v21_scalar($conexion, "SELECT COUNT(*) FROM INSCRIPCION_SEMINARIO WHERE Estado='Activa'") : 0,
    'asistencias' => (int)v21_scalar($conexion, "SELECT COUNT(*) FROM ASISTENCIA a JOIN GRUPO g ON g.ID_Grupo=a.ID_Grupo WHERE $where", $params),
    'presentes' => (int)v21_scalar($conexion, "SELECT COUNT(*) FROM ASISTENCIA a JOIN GRUPO g ON g.ID_Grupo=a.ID_Grupo WHERE $where AND a.Estado='Presente'", $params),
    'ausentes' => (int)v21_scalar($conexion, "SELECT COUNT(*) FROM ASISTENCIA a JOIN GRUPO g ON g.ID_Grupo=a.ID_Grupo WHERE $where AND a.Estado='Ausente'", $params),
    'justificados' => (int)v21_scalar($conexion, "SELECT COUNT(*) FROM ASISTENCIA a JOIN GRUPO g ON g.ID_Grupo=a.ID_Grupo WHERE $where AND a.Estado='Justificado'", $params),
];
$kpis['porcentaje_asistencia'] = $kpis['asistencias'] > 0 ? round($kpis['presentes'] * 100 / $kpis['asistencias']) : 0;

if ($esProfesor) {
    $qDisciplinas = $conexion->prepare("SELECT DISTINCT d.ID_Disciplina, d.Nombre FROM DISCIPLINA d JOIN GRUPO g ON g.ID_Disciplina=d.ID_Disciplina JOIN INSCRIPCION_GRUPO_PROFESOR igp ON igp.ID_Grupo=g.ID_Grupo WHERE igp.ID_Profesor=? AND igp.Estado='Activa' ORDER BY d.Nombre");
    $qDisciplinas->execute([$idProfesorActual]);
    $disciplinas = $qDisciplinas->fetchAll();
    $qGrupos = $conexion->prepare("SELECT g.ID_Grupo, g.Nombre, d.Nombre AS Disciplina FROM GRUPO g LEFT JOIN DISCIPLINA d ON d.ID_Disciplina=g.ID_Disciplina JOIN INSCRIPCION_GRUPO_PROFESOR igp ON igp.ID_Grupo=g.ID_Grupo WHERE igp.ID_Profesor=? AND igp.Estado='Activa' ORDER BY d.Nombre,g.Nombre");
    $qGrupos->execute([$idProfesorActual]);
    $grupos = $qGrupos->fetchAll();
    $qAlumnos = $conexion->prepare("SELECT DISTINCT al.ID_Alumno, al.Nombre, al.Apellido FROM ALUMNO al JOIN ASISTENCIA a ON a.ID_Alumno=al.ID_Alumno JOIN INSCRIPCION_GRUPO_PROFESOR igp ON igp.ID_Grupo=a.ID_Grupo WHERE igp.ID_Profesor=? AND igp.Estado='Activa' ORDER BY al.Apellido,al.Nombre");
    $qAlumnos->execute([$idProfesorActual]);
    $alumnosLista = $qAlumnos->fetchAll();
} else {
    $disciplinas = $conexion->query('SELECT ID_Disciplina, Nombre FROM DISCIPLINA ORDER BY Nombre')->fetchAll();
    $grupos = $conexion->query('SELECT g.ID_Grupo, g.Nombre, d.Nombre AS Disciplina FROM GRUPO g LEFT JOIN DISCIPLINA d ON d.ID_Disciplina=g.ID_Disciplina ORDER BY d.Nombre,g.Nombre')->fetchAll();
    $alumnosLista = $conexion->query('SELECT ID_Alumno, Nombre, Apellido FROM ALUMNO ORDER BY Apellido,Nombre')->fetchAll();
}

$groupSql = "SELECT g.Nombre AS Grupo, COALESCE(d.Nombre,'Sin disciplina') AS Disciplina,
    COUNT(a.ID_Asistencia) AS Total,
    SUM(CASE WHEN a.Estado='Presente' THEN 1 ELSE 0 END) AS Presentes,
    SUM(CASE WHEN a.Estado='Ausente' THEN 1 ELSE 0 END) AS Ausentes,
    SUM(CASE WHEN a.Estado='Justificado' THEN 1 ELSE 0 END) AS Justificados
    FROM ASISTENCIA a JOIN GRUPO g ON g.ID_Grupo=a.ID_Grupo
    LEFT JOIN DISCIPLINA d ON d.ID_Disciplina=g.ID_Disciplina
    WHERE $where GROUP BY g.ID_Grupo,g.Nombre,d.Nombre ORDER BY d.Nombre,g.Nombre";
$stmt = $conexion->prepare($groupSql);
$stmt->execute($params);
$porGrupo = $stmt->fetchAll();

$studentSql = "SELECT CONCAT(al.Nombre,' ',al.Apellido) AS Alumno,
    COALESCE(d.Nombre,'Sin disciplina') AS Disciplina, g.Nombre AS Grupo,
    COUNT(a.ID_Asistencia) AS Total,
    SUM(CASE WHEN a.Estado='Presente' THEN 1 ELSE 0 END) AS Presentes,
    SUM(CASE WHEN a.Estado='Ausente' THEN 1 ELSE 0 END) AS Ausentes,
    SUM(CASE WHEN a.Estado='Justificado' THEN 1 ELSE 0 END) AS Justificados
    FROM ASISTENCIA a JOIN ALUMNO al ON al.ID_Alumno=a.ID_Alumno
    JOIN GRUPO g ON g.ID_Grupo=a.ID_Grupo LEFT JOIN DISCIPLINA d ON d.ID_Disciplina=g.ID_Disciplina
    WHERE $where GROUP BY al.ID_Alumno,al.Nombre,al.Apellido,d.Nombre,g.ID_Grupo,g.Nombre
    ORDER BY al.Apellido,al.Nombre,d.Nombre,g.Nombre";
$stmt = $conexion->prepare($studentSql);
$stmt->execute($params);
$porAlumno = $stmt->fetchAll();

$disciplineSql = "SELECT COALESCE(d.Nombre,'Sin disciplina') AS Disciplina,
    COUNT(a.ID_Asistencia) AS Total,
    SUM(CASE WHEN a.Estado='Presente' THEN 1 ELSE 0 END) AS Presentes,
    SUM(CASE WHEN a.Estado='Ausente' THEN 1 ELSE 0 END) AS Ausentes,
    SUM(CASE WHEN a.Estado='Justificado' THEN 1 ELSE 0 END) AS Justificados
    FROM ASISTENCIA a JOIN GRUPO g ON g.ID_Grupo=a.ID_Grupo
    LEFT JOIN DISCIPLINA d ON d.ID_Disciplina=g.ID_Disciplina
    WHERE $where GROUP BY d.ID_Disciplina,d.Nombre ORDER BY d.Nombre";
$stmt = $conexion->prepare($disciplineSql);
$stmt->execute($params);
$porDisciplina = $stmt->fetchAll();

if (($_GET['export'] ?? '') === 'csv') {
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="vilamir_asistencia' . $desde . '_' . $hasta . '.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, ['Alumno','Disciplina','Grupo','Registros','Presentes','Ausentes','Justificados','% asistencia'], ';');
    foreach ($porAlumno as $row) {
        $total = (int)$row['Total'];
        fputcsv($out, [csvSafeText($row['Alumno']),csvSafeText($row['Disciplina']),csvSafeText($row['Grupo']),$total,(int)$row['Presentes'],(int)$row['Ausentes'],(int)$row['Justificados'],$total ? round((int)$row['Presentes'] * 100 / $total) : 0], ';');
    }
    fclose($out);
    exit;
}

function h($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function csvSafeText($value): string {
    $text = (string)$value;
    // Evita que Excel interprete nombres o etiquetas como fórmulas al abrir CSV.
    return preg_match('/^[\s]*[=+@\-]/u', $text) ? "'" . $text : $text;
}
function pct(array $row): int { return (int)$row['Total'] > 0 ? (int)round((int)$row['Presentes'] * 100 / (int)$row['Total']) : 0; }
?>
<!DOCTYPE html>
<html lang="es">
<head>
<?php vilamir_enviar_token_csrf(); ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estadísticas | Academia VILAMIR</title>
    <link rel="stylesheet" href="css/style.css?v=20261026-etapa2-seminarios-galeria-v1">
<script src="js/csrf.js"></script>
</head>
<body class="reports-page">
<header class="navbar">
    <div class="logo"><img src="images/logo-vilamir.jpg" alt="Escuela Vilamir" class="logo-img"></div>
    <nav>
        <a href="index.php">Inicio</a>
        <?php if ($esAdmin): ?><a href="admin.php">Administración</a><a href="reportes.php">Reportes</a><?php else: ?><a href="profesor.php">Mi espacio</a><?php endif; ?>
        <a class="active" href="estadisticas.php">Asistencia avanzada</a>
        <a href="logout.php">Cerrar sesión</a>
    </nav>
</header>
<main class="v21-statistics-wrap">
    <section class="reports-head">
        <div><span class="eyebrow">ACADEMIA VILAMIR</span><h1><?= $esProfesor ? 'Mis asistencias avanzadas' : 'Panel de estadísticas' ?></h1><p><?= $esProfesor ? 'Consultá el historial y los indicadores de asistencia de tus grupos asignados.' : 'Indicadores de alumnos, pagos, inscripciones y asistencia por período.' ?></p></div>
        <a class="report-export" href="?<?= h(http_build_query(array_merge($_GET, ['export'=>'csv']))) ?>">Exportar asistencia CSV</a>
    </section>

    <?php if ($esAdmin): ?>
    <section class="v21-kpi-grid" aria-label="Indicadores generales">
        <article class="v21-kpi"><span>Alumnos activos</span><strong><?= number_format($kpis['alumnos_activos']) ?></strong><small>Con una inscripción vigente</small></article>
        <article class="v21-kpi"><span>Pagos pendientes</span><strong><?= number_format($kpis['pagos_pendientes']) ?></strong><small><?= h(number_format($kpis['importe_pendiente'], 2, ',', '.')) ?> UYU por cobrar</small></article>
        <article class="v21-kpi"><span>Inscripciones a disciplinas</span><strong><?= number_format($kpis['inscripciones_disciplina']) ?></strong><small>Inscripciones activas</small></article>
        <article class="v21-kpi"><span>Inscripciones a eventos</span><strong><?= number_format($kpis['inscripciones_eventos']) ?></strong><small>Seminarios y eventos activos</small></article>
    </section>
    <?php endif; ?>

    <section class="v21-stat-panel">
        <div class="v21-panel-heading"><div><span class="panel-kicker">FILTROS</span><h2>Período y actividad</h2></div><p><?= $esProfesor ? 'Los filtros se aplican únicamente a tus grupos asignados.' : 'Los filtros afectan las estadísticas detalladas de asistencia.' ?></p></div>
        <form class="v21-filter-grid" method="get">
            <label>Desde <input type="date" name="desde" value="<?= h($desde) ?>" required></label>
            <label>Hasta <input type="date" name="hasta" value="<?= h($hasta) ?>" required></label>
            <label>Disciplina <select name="disciplina"><option value="0">Todas</option><?php foreach ($disciplinas as $d): ?><option value="<?= (int)$d['ID_Disciplina'] ?>" <?= $disciplina === (int)$d['ID_Disciplina'] ? 'selected' : '' ?>><?= h($d['Nombre']) ?></option><?php endforeach; ?></select></label>
            <label>Grupo <select name="grupo"><option value="0">Todos</option><?php foreach ($grupos as $g): ?><option value="<?= (int)$g['ID_Grupo'] ?>" <?= $grupo === (int)$g['ID_Grupo'] ? 'selected' : '' ?>><?= h($g['Disciplina'] . ' · ' . $g['Nombre']) ?></option><?php endforeach; ?></select></label>
            <label>Alumno <select name="alumno"><option value="0">Todos</option><?php foreach ($alumnosLista as $a): ?><option value="<?= (int)$a['ID_Alumno'] ?>" <?= $alumno === (int)$a['ID_Alumno'] ? 'selected' : '' ?>><?= h($a['Apellido'] . ', ' . $a['Nombre']) ?></option><?php endforeach; ?></select></label>
            <div class="v21-filter-actions"><button type="submit">Aplicar filtros</button><a class="secondary" href="estadisticas.php">Restablecer</a></div>
        </form>
    </section>

    <section class="v21-kpi-grid v21-attendance-kpis">
        <article class="v21-kpi"><span>Registros de asistencia</span><strong><?= number_format($kpis['asistencias']) ?></strong><small><?= h($desde) ?> al <?= h($hasta) ?></small></article>
        <article class="v21-kpi"><span>Presentes</span><strong><?= number_format($kpis['presentes']) ?></strong><small><?= $kpis['porcentaje_asistencia'] ?>% del total filtrado</small></article>
        <article class="v21-kpi"><span>Ausentes</span><strong><?= number_format($kpis['ausentes']) ?></strong><small>Inasistencias registradas</small></article>
        <article class="v21-kpi"><span>Justificados</span><strong><?= number_format($kpis['justificados']) ?></strong><small>Ausencias justificadas</small></article>
    </section>

    <section class="v21-stat-panel"><h2>Asistencia por disciplina</h2>
        <?php if (!$porDisciplina): ?><p class="small">No hay registros para los filtros seleccionados.</p><?php else: ?><div class="table-wrap"><table><thead><tr><th>Disciplina</th><th>Total</th><th>Presentes</th><th>Ausentes</th><th>Justificados</th><th>% presentes</th></tr></thead><tbody><?php foreach ($porDisciplina as $r): ?><tr><td><?= h($r['Disciplina']) ?></td><td><?= (int)$r['Total'] ?></td><td><?= (int)$r['Presentes'] ?></td><td><?= (int)$r['Ausentes'] ?></td><td><?= (int)$r['Justificados'] ?></td><td><?= pct($r) ?>%</td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
    </section>

    <section class="v21-stat-panel"><h2>Asistencia por grupo</h2>
        <?php if (!$porGrupo): ?><p class="small">No hay registros para los filtros seleccionados.</p><?php else: ?><div class="table-wrap"><table><thead><tr><th>Disciplina</th><th>Grupo</th><th>Total</th><th>Presentes</th><th>Ausentes</th><th>Justificados</th><th>% presentes</th></tr></thead><tbody><?php foreach ($porGrupo as $r): ?><tr><td><?= h($r['Disciplina']) ?></td><td><?= h($r['Grupo']) ?></td><td><?= (int)$r['Total'] ?></td><td><?= (int)$r['Presentes'] ?></td><td><?= (int)$r['Ausentes'] ?></td><td><?= (int)$r['Justificados'] ?></td><td><?= pct($r) ?>%</td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
    </section>

    <section class="v21-stat-panel"><h2>Asistencia por alumno</h2>
        <?php if (!$porAlumno): ?><p class="small">No hay registros para los filtros seleccionados.</p><?php else: ?><div class="table-wrap"><table><thead><tr><th>Alumno</th><th>Disciplina</th><th>Grupo</th><th>Total</th><th>Presentes</th><th>Ausentes</th><th>Justificados</th><th>% presentes</th></tr></thead><tbody><?php foreach ($porAlumno as $r): ?><tr><td><?= h($r['Alumno']) ?></td><td><?= h($r['Disciplina']) ?></td><td><?= h($r['Grupo']) ?></td><td><?= (int)$r['Total'] ?></td><td><?= (int)$r['Presentes'] ?></td><td><?= (int)$r['Ausentes'] ?></td><td><?= (int)$r['Justificados'] ?></td><td><?= pct($r) ?>%</td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
    </section>
</main>
<script src="js/mobile.js"></script>
</body>
</html>
