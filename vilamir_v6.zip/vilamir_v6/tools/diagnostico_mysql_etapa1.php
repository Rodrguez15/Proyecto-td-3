<?php
/**
 * Diagnóstico de solo lectura para la Etapa 1 de Academia VILAMIR.
 * Ejecutar desde la terminal de PHP/XAMPP: php tools/diagnostico_mysql_etapa1.php
 * No crea, modifica ni elimina datos. No debe exponerse como página web.
 */
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit("Este diagnóstico solo se puede ejecutar desde la terminal.\\n");
}

if (!extension_loaded('pdo_mysql')) {
    fwrite(STDERR, "ERROR: PHP no tiene habilitado pdo_mysql. En XAMPP, habilitá extension=pdo_mysql en php.ini y reiniciá Apache/terminal.\\n");
    exit(2);
}

require_once __DIR__ . '/../config/conexion.php';

$errores = 0;
$comprobaciones = 0;
function comprobar(bool $ok, string $mensaje): void {
    global $errores, $comprobaciones;
    $comprobaciones++;
    echo ($ok ? '[OK] ' : '[ERROR] ') . $mensaje . PHP_EOL;
    if (!$ok) $errores++;
}

$tablas = [
    'USUARIO' => ['ID_Usuario', 'Email', 'Contraseña', 'Rol'],
    'ALUMNO' => ['ID_Usuario', 'Nombre', 'Apellido'],
    'PROFESOR' => ['ID_Usuario', 'Nombre', 'Apellido'],
    'DISCIPLINA' => ['ID_Disciplina'],
    'GRUPO' => ['ID_Grupo'],
    'HORARIO' => ['ID_Horario'],
    'INSCRIPCION_GRUPO_ALUMNO' => ['ID_Alumno', 'ID_Grupo'],
    'PAGO' => ['ID_Pago'],
    'ASISTENCIA' => ['ID_Asistencia'],
    'SEMINARIO' => ['ID_Seminario'],
    'INSCRIPCION_SEMINARIO' => ['ID_Seminario'],
];

try {
    comprobar($conexion instanceof PDO, 'Conexión PDO creada.');
    $conexion->query('SELECT 1')->fetchColumn();
    comprobar(true, 'Consulta de prueba SELECT 1 ejecutada.');

    foreach ($tablas as $tabla => $columnasEsperadas) {
        // Los nombres proceden de esta lista fija, no de entrada del usuario.
        $stmt = $conexion->query("SHOW COLUMNS FROM `{$tabla}`");
        $columnasReales = array_column($stmt->fetchAll(PDO::FETCH_ASSOC), 'Field');
        comprobar(count($columnasReales) > 0, "Tabla {$tabla} accesible.");
        foreach ($columnasEsperadas as $columna) {
            comprobar(in_array($columna, $columnasReales, true), "{$tabla}.{$columna} existe.");
        }
    }

    // Preparar y ejecutar consultas críticas de autenticación sin modificar datos.
    $consultas = [
        'autenticación de usuario' => "SELECT ID_Usuario, Email, Contraseña, Rol FROM USUARIO WHERE LOWER(Email) = LOWER(:email) LIMIT 1",
        'perfil de alumno' => 'SELECT Nombre, Apellido FROM ALUMNO WHERE ID_Usuario = :id_usuario LIMIT 1',
        'perfil de profesor' => 'SELECT Nombre, Apellido FROM PROFESOR WHERE ID_Usuario = :id_usuario LIMIT 1',
    ];
    foreach ($consultas as $nombre => $sql) {
        $stmt = $conexion->prepare($sql);
        if (str_contains($sql, ':email')) {
            $stmt->execute([':email' => 'vilamir-diagnostico-no-existe@example.invalid']);
        } else {
            $stmt->execute([':id_usuario' => 0]);
        }
        $stmt->fetch(PDO::FETCH_ASSOC);
        comprobar(true, "Consulta SQL preparada y ejecutada: {$nombre}.");
    }
} catch (Throwable $e) {
    comprobar(false, 'Fallo de diagnóstico: ' . $e->getMessage());
}

echo PHP_EOL . "Resultado: {$comprobaciones} comprobaciones, {$errores} error(es)." . PHP_EOL;
if ($errores > 0) exit(1);
echo "Diagnóstico finalizado sin errores detectados en las comprobaciones incluidas." . PHP_EOL;
