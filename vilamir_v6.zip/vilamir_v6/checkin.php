<?php
/*
 * Pantalla de recepción: lector QR por cámara o lector físico/teclado.
 * Disponible para Administrador y Profesor; los profesores sólo ven sus grupos asignados.
 */
require_once 'config/autenticacion.php';
$rol = strtolower(trim((string)($_SESSION['usuario_rol'] ?? '')));
if (!in_array($rol, ['administrador', 'profesor'], true)) {
    http_response_code(403);
    exit('Acceso denegado.');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <?php vilamir_enviar_token_csrf(); ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recepción QR | Academia VILAMIR</title>
    <link rel="stylesheet" href="css/style.css?v=20261120-qr-redesign">
    <script src="js/csrf.js"></script>
    <style>
        :root{--qr-red:#d71920;--qr-red-dark:#8e1017;--qr-panel:#151519;--qr-line:rgba(255,255,255,.1);--qr-muted:#a9a9b2}
        body.qr-checkin-page{background:radial-gradient(ellipse at 50% -15%,rgba(215,25,32,.22),transparent 48%),#0b0b0e;color:#f7f7f8;min-height:100vh}
        .checkin-container{width:min(1120px,calc(100% - 32px));margin:34px auto 54px}
        .checkin-hero{position:relative;overflow:hidden;text-align:left;padding:30px 34px;margin-bottom:22px;border:1px solid var(--qr-line);border-radius:22px;background:linear-gradient(115deg,rgba(215,25,32,.2),rgba(25,25,30,.97) 54%,rgba(45,16,19,.9));box-shadow:0 18px 48px rgba(0,0,0,.22)}
        .checkin-hero:after{content:'QR';position:absolute;right:36px;top:50%;transform:translateY(-50%);font-size:clamp(72px,12vw,132px);font-weight:1000;letter-spacing:-9px;color:rgba(255,255,255,.045);pointer-events:none}
        .checkin-hero .eyebrow{display:inline-flex;align-items:center;gap:8px;color:#ff777c;font-weight:900;letter-spacing:2px;font-size:.72rem}
        .checkin-hero h1{font-size:clamp(1.65rem,3vw,2.35rem);margin:10px 0 7px!important;line-height:1.12}
        .checkin-help{color:#c4c4cc;font-size:.94rem;line-height:1.6;margin:0;max-width:690px}
        .checkin-layout{display:grid;grid-template-columns:minmax(0,1.12fr) minmax(300px,.88fr);gap:20px;align-items:start}
        .checkin-card{background:linear-gradient(160deg,rgba(25,25,30,.98),rgba(15,15,18,.98));border:1px solid var(--qr-line);border-radius:20px;padding:24px;box-shadow:0 14px 38px rgba(0,0,0,.22)}
        .checkin-card h2{display:flex;align-items:center;gap:10px;font-size:1.05rem;text-align:left;margin:0 0 17px;color:#fff}
        .step-number{display:inline-grid;place-items:center;width:28px;height:28px;border-radius:9px;background:rgba(215,25,32,.18);border:1px solid rgba(215,25,32,.42);color:#ff777c;font-size:.82rem;font-weight:900}
        .checkin-fields{display:grid;grid-template-columns:1fr 1fr;gap:13px}
        .checkin-field{display:flex;flex-direction:column;gap:7px;text-align:left;min-width:0}
        .checkin-field.full{grid-column:1/-1}
        .checkin-field label{font-size:.82rem;font-weight:800;color:#dedee3}
        .checkin-field select,.checkin-field input{width:100%;min-height:46px;background:#202026;color:#fff;border:1px solid #414149;border-radius:11px;padding:11px 12px;outline:none}
        .checkin-field select:focus,.checkin-field input:focus,.manual-form input:focus{border-color:#e0444a;box-shadow:0 0 0 3px rgba(215,25,32,.14)}
        .small-note{color:var(--qr-muted);font-size:.78rem;line-height:1.55;margin:12px 0 0}
        .qr-reader-wrap{position:relative;margin-top:4px;border:1px solid rgba(255,255,255,.13);border-radius:17px;padding:12px;background:linear-gradient(145deg,#080809,#17171b);overflow:hidden}
        .qr-reader-wrap:before{content:'ÁREA DE LECTURA';display:block;text-align:center;color:#888891;font-size:.66rem;font-weight:900;letter-spacing:2px;padding:4px 0 11px}
        #qrReader{width:100%;min-height:90px;overflow:hidden;border-radius:12px;background:#050505}
        #qrReader video{width:100%!important;max-height:360px;object-fit:cover;border-radius:12px}
        #qrReader__scan_region{min-height:0!important}
        #qrReader__dashboard{color:#ddd!important}
        #qrReader__dashboard_section_csr button{background:#333!important;color:#fff!important;border:1px solid #555!important;border-radius:8px!important;padding:7px 12px!important}
        #qrReader img{object-fit:contain}
        .checkin-actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:13px}
        .checkin-actions button{flex:1;min-width:145px}
        .checkin-btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;border:1px solid transparent;border-radius:11px;padding:12px 16px;font-weight:900;cursor:pointer;background:linear-gradient(135deg,#e1262d,#a80f17);color:white;transition:transform .18s ease,filter .18s ease}
        .checkin-btn:hover:not(:disabled){filter:brightness(1.1);transform:translateY(-1px)}
        .checkin-btn.secondary{background:#29292f;border-color:#4a4a53;color:#eee}
        .checkin-btn:disabled{opacity:.42;cursor:not-allowed;transform:none}
        .scan-status{display:flex;align-items:flex-start;gap:10px;margin-top:13px;padding:13px 14px;border-radius:12px;background:rgba(255,255,255,.045);border:1px solid rgba(255,255,255,.08);border-left:3px solid var(--qr-red);color:#ddd;font-size:.86rem;line-height:1.5;text-align:left}
        .manual-divider{display:flex;align-items:center;gap:12px;color:#85858e;font-size:.72rem;font-weight:800;letter-spacing:1px;margin:17px 0 10px}
        .manual-divider:before,.manual-divider:after{content:'';height:1px;flex:1;background:rgba(255,255,255,.1)}
        .manual-form{display:flex;gap:9px;margin-top:0}
        .manual-form input{flex:1;min-width:0;padding:12px 13px;border:1px solid #45454e;border-radius:11px;background:#202026;color:#fff;outline:none}
        .result-card{display:none;margin-top:0;border-radius:16px;padding:18px;text-align:left;border:1px solid #555;background:#202024}
        .result-card.success{border-color:rgba(57,217,138,.6);background:linear-gradient(145deg,rgba(57,217,138,.1),rgba(20,28,24,.7))}
        .result-card.warning{border-color:rgba(255,200,87,.55);background:linear-gradient(145deg,rgba(255,200,87,.1),rgba(35,29,18,.7))}
        .result-card.danger{border-color:rgba(255,91,91,.6);background:rgba(255,91,91,.09)}
        .result-title{font-size:1.22rem;font-weight:950;margin-bottom:12px;color:#fff}
        .result-row{padding:12px 0;border-top:1px solid rgba(255,255,255,.09);line-height:1.6;font-size:.88rem;color:#e5e5e8}
        .result-row:first-of-type{border-top:0}
        .fee-pill{display:inline-flex;align-items:center;border-radius:999px;padding:5px 11px;font-size:.76rem;font-weight:950;letter-spacing:.5px;margin:6px 0}
        .fee-paid{background:#134d36;color:#8df0bd}.fee-pending{background:#58451b;color:#ffe08a}.fee-overdue{background:#651f25;color:#ffb3b7}.fee-none{background:#3b3b42;color:#ddd}
        .result-placeholder{display:grid;place-items:center;text-align:center;min-height:290px;padding:25px;color:#9b9ba4}
        .result-placeholder .placeholder-icon{display:grid;place-items:center;width:76px;height:76px;border-radius:22px;background:rgba(215,25,32,.12);border:1px solid rgba(215,25,32,.24);font-size:2rem;margin-bottom:16px}
        .result-placeholder strong{color:#e7e7eb;font-size:1rem;margin-bottom:6px}
        .result-placeholder p{max-width:270px;font-size:.83rem;line-height:1.55;margin:0}
        .checkin-side-note{margin-top:15px;padding:14px;border-radius:13px;background:rgba(255,255,255,.035);border:1px solid rgba(255,255,255,.07);color:#aaa;font-size:.8rem;line-height:1.55}
        @media(max-width:820px){.checkin-layout{grid-template-columns:1fr}.result-placeholder{min-height:190px}}
        @media(max-width:560px){.checkin-container{width:calc(100% - 22px);margin:18px auto 34px}.checkin-hero{padding:23px 20px;border-radius:17px}.checkin-hero:after{right:15px;opacity:.65}.checkin-card{padding:17px;border-radius:16px}.checkin-fields{grid-template-columns:1fr}.checkin-field.full{grid-column:auto}.manual-form{flex-direction:column}.checkin-actions{flex-direction:column}.checkin-actions button{width:100%}}
    </style>
</head>
<body class="about-page qr-checkin-page">
<header class="navbar">
    <div class="logo"><img src="images/logo-vilamir.jpg" alt="Vilamir" class="logo-img"></div>
    <nav>
        <a href="index.php">Inicio</a>
        <?php if ($rol === 'administrador'): ?>
            <a href="admin.php">Administración</a>
        <?php else: ?>
            <a href="profesor.php">Mi panel</a>
        <?php endif; ?>
        <a class="active" href="checkin.php">Lector QR</a>
        <a href="logout.php">Cerrar sesión</a>
    </nav>
</header>

<main class="checkin-container">
    <section class="checkin-hero">
        <span class="eyebrow">🥋 RECEPCIÓN · ACADEMIA VILAMIR</span>
        <h1>Control de acceso y asistencia</h1>
        <p class="checkin-help">Escaneá el carnet del alumno para registrar su presente y consultar el estado de su cuota mensual en un solo paso.</p>
    </section>

    <div class="checkin-layout">
        <section class="checkin-card">
            <h2><span class="step-number">1</span> Preparar la clase</h2>
            <div class="checkin-fields">
                <div class="checkin-field full">
                    <label for="grupoCheckin">Grupo / disciplina</label>
                    <select id="grupoCheckin"><option value="">Cargando grupos…</option></select>
                </div>
                <div class="checkin-field">
                    <label for="fechaCheckin">Fecha</label>
                    <input type="date" id="fechaCheckin" value="<?= htmlspecialchars(date('Y-m-d'), ENT_QUOTES, 'UTF-8') ?>" max="<?= htmlspecialchars(date('Y-m-d'), ENT_QUOTES, 'UTF-8') ?>">
                </div>
                <div class="checkin-field">
                    <label for="horarioCheckin">Horario de clase</label>
                    <select id="horarioCheckin" disabled><option value="">Seleccioná un grupo</option></select>
                </div>
            </div>
            <p class="small-note">Los profesores solo pueden seleccionar sus grupos asignados. Administración puede elegir cualquier grupo.</p>

            <h2 style="margin-top:25px"><span class="step-number">2</span> Escanear carnet del alumno</h2>
            <div class="qr-reader-wrap"><div id="qrReader"></div></div>
            <div class="checkin-actions">
                <button type="button" class="checkin-btn" id="btnIniciarCamara" disabled>📷 Activar cámara</button>
                <button type="button" class="checkin-btn secondary" id="btnDetenerCamara" disabled>Detener cámara</button>
            </div>
            <div class="scan-status" id="estadoLector" role="status" aria-live="polite">Elegí el grupo, la fecha y el horario para habilitar el lector.</div>
            <div class="manual-divider">ALTERNATIVA MANUAL</div>
            <form id="formCodigoManual" class="manual-form">
                <input type="text" id="codigoQrManual" placeholder="Ingresá o escaneá el código QR" autocomplete="off" maxlength="300" aria-label="Código QR del alumno">
                <button type="submit" class="checkin-btn" id="btnVerificarManual" disabled>Verificar</button>
            </form>
            <p class="small-note">La cámara requiere permiso del navegador y HTTPS o localhost. También podés usar un lector QR USB.</p>
        </section>

        <section class="checkin-card">
            <h2><span class="step-number">3</span> Resultado del escaneo</h2>
            <div id="resultadoCheckin" class="result-card" aria-live="polite"></div>
            <div class="result-placeholder" id="resultadoVacio">
                <div>
                    <div class="placeholder-icon">▦</div>
                    <strong>Esperando el primer alumno</strong>
                    <p>Cuando escanees un carnet, acá vas a ver la asistencia, el grupo y el estado de la cuota del mes.</p>
                </div>
            </div>
            <div class="checkin-side-note">El sistema registra presente solo si el alumno está inscripto activamente en el grupo. Si ya existe una asistencia, conserva el estado anterior y evita duplicados.</div>
        </section>
    </div>
</main>
<footer>© 2026 Academia VILAMIR · Recepción y asistencia</footer>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html5-qrcode/2.3.8/html5-qrcode.min.js" referrerpolicy="no-referrer"></script>
<script src="js/checkin.js?v=20261120-qr-redesign"></script>
<script>
(() => {
  const resultado = document.getElementById('resultadoCheckin');
  const vacio = document.getElementById('resultadoVacio');
  if (!resultado || !vacio) return;
  const observer = new MutationObserver(() => {
    vacio.style.display = resultado.style.display === 'block' ? 'none' : 'grid';
  });
  observer.observe(resultado, { attributes: true, attributeFilter: ['style', 'class'] });
})();
</script>
</body>
</html>
