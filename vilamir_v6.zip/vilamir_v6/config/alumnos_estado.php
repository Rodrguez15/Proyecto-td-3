<?php
/**
 * Estado administrativo de alumnos usando exclusivamente la tabla existente
 * ACTIVIDAD_SISTEMA. No agrega columnas ni tablas.
 * Detalle identifica el alumno con el prefijo estable ALUMNO_ID=<id>;
 */
if (!function_exists('vilamir_estado_baja_alumno')) {
    function vilamir_estado_baja_alumno(PDO $conexion, int $idAlumno): string {
        if ($idAlumno <= 0) return 'NO_DISPONIBLE';
        try {
            $stmt = $conexion->prepare("SELECT Accion
                FROM ACTIVIDAD_SISTEMA
                WHERE Accion IN ('ALUMNO_BAJA_TEMPORAL','ALUMNO_BAJA_DEFINITIVA','ALUMNO_REACTIVADO')
                  AND Detalle LIKE ?
                ORDER BY ID_Actividad DESC
                LIMIT 1");
            $stmt->execute(['ALUMNO_ID=' . $idAlumno . ';%']);
            $accion = (string)($stmt->fetchColumn() ?: '');
            if ($accion === 'ALUMNO_BAJA_TEMPORAL') return 'BAJA_TEMPORAL';
            if ($accion === 'ALUMNO_BAJA_DEFINITIVA') return 'BAJA_DEFINITIVA';
            if ($accion === 'ALUMNO_REACTIVADO' || $accion === '') return 'ACTIVO';
            return 'NO_DISPONIBLE';
        } catch (Throwable $e) {
            error_log('VILAMIR estado de alumno no disponible: ' . $e->getMessage());
            return 'NO_DISPONIBLE';
        }
    }

    function vilamir_estado_baja_usuario(PDO $conexion, int $idUsuario): string {
        try {
            $stmt = $conexion->prepare('SELECT ID_Alumno FROM ALUMNO WHERE ID_Usuario = ? LIMIT 1');
            $stmt->execute([$idUsuario]);
            $idAlumno = (int)$stmt->fetchColumn();
            return $idAlumno > 0 ? vilamir_estado_baja_alumno($conexion, $idAlumno) : 'ACTIVO';
        } catch (Throwable $e) {
            error_log('VILAMIR no pudo vincular usuario con alumno: ' . $e->getMessage());
            return 'NO_DISPONIBLE';
        }
    }
}
