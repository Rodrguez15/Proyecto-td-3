<?php
/*
 * Conexión PDO central de Academia VILAMIR.
 * No contiene credenciales por defecto y no modifica el esquema de la BD.
 */
require_once __DIR__ . '/db_config.php';

$host = getenv('DB_HOST') ?: (defined('VILAMIR_DB_HOST') ? (string)VILAMIR_DB_HOST : '');
$dbName = getenv('DB_NAME') ?: (defined('VILAMIR_DB_NAME') ? (string)VILAMIR_DB_NAME : '');
$username = getenv('DB_USER') ?: (defined('VILAMIR_DB_USER') ? (string)VILAMIR_DB_USER : '');
$passwordEnv = getenv('DB_PASS');
$password = $passwordEnv !== false ? (string)$passwordEnv : (defined('VILAMIR_DB_PASS') ? (string)VILAMIR_DB_PASS : '');

$entorno = strtolower(trim((string)(getenv('APP_ENV') ?: (defined('VILAMIR_ENV') ? VILAMIR_ENV : (getenv('VILAMIR_ENV') ?: 'development')))));
$esProduccion = in_array($entorno, ['production', 'prod', 'produccion', 'producción'], true);

$faltantes = [];
foreach (['DB_HOST' => $host, 'DB_NAME' => $dbName, 'DB_USER' => $username] as $nombre => $valor) {
    if (trim($valor) === '') $faltantes[] = $nombre;
}
// Una contraseña vacía puede ser válida en una instalación XAMPP local,
// por eso se exige que la variable/constante esté definida, no que sea no vacía.
if ($passwordEnv === false && !defined('VILAMIR_DB_PASS')) {
    $faltantes[] = 'DB_PASS';
} elseif ($esProduccion && trim($password) === '') {
    $faltantes[] = 'DB_PASS (no vacía en producción)';
}

if ($faltantes) {
    error_log('Configuración de base de datos incompleta. Faltan: ' . implode(', ', $faltantes));
    http_response_code(500);
    exit('Error de configuración del servidor. Contacte al administrador.');
}

try {
    $dsn = 'mysql:host=' . $host . ';dbname=' . $dbName . ';charset=utf8mb4';
    $conexion = new PDO($dsn, $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    error_log('Error de conexión a la base de datos: ' . $e->getMessage());
    http_response_code(500);
    exit('Error crítico de conexión. Verifique la configuración de la base de datos.');
}
