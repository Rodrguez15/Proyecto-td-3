<?php

/*
 * ARCHIVO: autenticacion.php
 * PROPÓSITO: Configuración compartida de autenticacion para el funcionamiento seguro del sistema.
 */
// Autenticación y sesión unificada de VILAMIR.
require_once __DIR__ . '/sesion.php';

if (!isset($_SESSION['usuario_id'])) {

    header('Location: ' . (basename(dirname($_SERVER['PHP_SELF'])) === 'config' ? '../login.php' : 'login.php'));

    exit;
    }

// Normalizar el rol guardado en sesión.
$_SESSION['usuario_rol'] = normalizarRol((string)($_SESSION['usuario_rol'] ?? ''));

?>
