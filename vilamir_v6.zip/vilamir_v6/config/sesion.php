<?php

/*
 * ARCHIVO: sesion.php
 * PROPÓSITO: Configuración compartida de sesion para el funcionamiento seguro del sistema.
 */
// ============================================================
// SESIÓN ÚNICA + SEGURIDAD V14 - ACADEMIA VILAMIR
// ============================================================
require_once __DIR__ . '/seguridad.php';

if (session_status() !== PHP_SESSION_ACTIVE) {

    session_name('VILAMIRSESSID');

    session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'httponly' => true,
    'samesite' => 'Lax'
    ]);

    session_start();
    }

vilamir_aplicar_seguridad_http();

// Una baja definitiva se comprueba en el servidor en cada petición autenticada.
// La baja temporal no bloquea el acceso. El estado se guarda como evento en la
// tabla ya existente ACTIVIDAD_SISTEMA, sin modificar el esquema.
if (!empty($_SESSION['usuario_id'])
    && strcasecmp(trim((string)($_SESSION['usuario_rol'] ?? '')), 'Alumno') === 0
    && basename((string)($_SERVER['SCRIPT_NAME'] ?? '')) !== 'logout.php') {
    require_once __DIR__ . '/conexion.php';
    require_once __DIR__ . '/alumnos_estado.php';
    $estadoCuentaAlumno = vilamir_estado_baja_usuario($conexion, (int)$_SESSION['usuario_id']);
    if ($estadoCuentaAlumno === 'BAJA_DEFINITIVA') {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'] ?? '', $params['secure'], $params['httponly']);
        }
        session_destroy();
        $esApi = strpos(str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? '')), '/api/') !== false
            || strpos(strtolower((string)($_SERVER['HTTP_ACCEPT'] ?? '')), 'application/json') !== false;
        if ($esApi) {
            http_response_code(403);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['status' => 'error', 'message' => 'La cuenta tiene baja definitiva. Comunicate con la administración.'], JSON_UNESCAPED_UNICODE);
        } else {
            header('Location: ' . (str_contains((string)($_SERVER['SCRIPT_NAME'] ?? ''), '/config/') ? '../login.html?estado=cuenta_inactiva' : 'login.html?estado=cuenta_inactiva'));
        }
        exit;
    }
}

/**
 * Normaliza el rol de usuario a uno de los tres valores canónicos:
 * 'Administrador', 'Profesor' o 'Alumno' (por defecto si no coincide).
 */
function normalizarRol(string $rol): string {

    $rol = trim($rol);

    if (strcasecmp($rol, 'Administrador') === 0) return 'Administrador';

    if (strcasecmp($rol, 'Profesor') === 0) return 'Profesor';

    return 'Alumno';
    }

// Caducidad por inactividad: 8 horas. Evita sesiones abandonadas indefinidamente.
$ahora = time();

$ultimo = (int)($_SESSION['ultima_actividad'] ?? 0);

$maxInactividad = 8 * 60 * 60;

if ($ultimo > 0 && ($ahora - $ultimo) > $maxInactividad) {

    $_SESSION = [];

    if (ini_get('session.use_cookies')) {

        $params = session_get_cookie_params();

        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'] ?? '', $params['secure'], $params['httponly']);
        }

    session_destroy();

    session_name('VILAMIRSESSID');

    session_start();
    }

$_SESSION['ultima_actividad'] = $ahora;

// Normalización central del rol para impedir comparaciones inconsistentes.
if (isset($_SESSION['usuario_rol'])) {

    $_SESSION['usuario_rol'] = normalizarRol((string)$_SESSION['usuario_rol']);
    }

// Para operaciones que modifican datos, rechazamos explícitamente peticiones
// cross-site. Las peticiones normales del sistema siguen funcionando igual.
if (in_array($_SERVER['REQUEST_METHOD'] ?? 'GET', ['POST','PUT','PATCH','DELETE'], true) && !vilamir_peticion_segura()) {

    http_response_code(403);

    if (strpos((string)($_SERVER['HTTP_ACCEPT'] ?? ''), 'application/json') !== false || str_starts_with((string)($_SERVER['REQUEST_URI'] ?? ''), '/api/')) {

        header('Content-Type: application/json; charset=utf-8');

        echo json_encode(['status'=>'error','message'=>'Petición rechazada por política de seguridad.'], JSON_UNESCAPED_UNICODE);
        }
    else {

        echo 'Petición rechazada por política de seguridad.';
        }

    exit;
    }

// Verificación CSRF central para toda operación web que modifica datos,
// incluso antes de iniciar sesión (registro, recuperación y check-in público).
// login.php realiza la misma verificación explícitamente para mantener clara
// la excepción de flujo de autenticación.
$metodo = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
$scriptLogin = stripos((string)($_SERVER['SCRIPT_NAME'] ?? ''), 'login.php') !== false;

if (in_array($metodo, ['POST', 'PUT', 'PATCH', 'DELETE'], true) && !$scriptLogin) {
    vilamir_verificar_csrf();
}

