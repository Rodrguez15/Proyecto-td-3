<?php
/**
 * Cargador de configuración privada de base de datos.
 *
 * Este archivo no contiene credenciales ni valores predeterminados.
 * Para XAMPP o InfinityFree, crear config/db_config.local.php a partir de
 * config/db_config.local.php.example y completar los datos de esa instalación.
 * También se admiten variables de entorno DB_HOST, DB_NAME, DB_USER y DB_PASS.
 * El archivo local real está excluido del paquete y del control de versiones.
 */
$archivoCredencialesLocales = __DIR__ . '/db_config.local.php';
if (is_file($archivoCredencialesLocales)) {
    require_once $archivoCredencialesLocales;
}
