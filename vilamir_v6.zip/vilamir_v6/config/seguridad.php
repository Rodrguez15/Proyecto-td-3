<?php

/*
 * ARCHIVO: seguridad.php
 * PROPÓSITO: Configuración compartida de seguridad para el funcionamiento seguro del sistema.
 */
// ============================================================
// SEGURIDAD V14 - ACADEMIA VILAMIR
// Capa común de seguridad para sesiones y peticiones HTTP.
// ============================================================

if (!function_exists('vilamir_aplicar_seguridad_http')) {

    function vilamir_aplicar_seguridad_http(): void {

        if (headers_sent()) return;

        header('X-Content-Type-Options: nosniff');

        header('X-Frame-Options: SAMEORIGIN');

        header('Referrer-Policy: strict-origin-when-cross-origin');

        // Permite que la propia aplicación use la cámara sólo cuando el usuario lo autoriza.
        header('Permissions-Policy: camera=(self), microphone=(), geolocation=()');

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

        header('Pragma: no-cache');

        if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {

            header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
            }
        }
    }

if (!function_exists('vilamir_peticion_segura')) {

    function vilamir_peticion_segura(): bool {

        // Los navegadores modernos envían Sec-Fetch-Site en peticiones fetch/form.
        // Solo bloqueamos explícitamente peticiones cross-site; no exigimos Origin
        // porque algunos navegadores/entornos locales no lo envían.
        $fetchSite = strtolower(trim((string)($_SERVER['HTTP_SEC_FETCH_SITE'] ?? '')));

        if ($fetchSite === 'cross-site') return false;

        $origin = trim((string)($_SERVER['HTTP_ORIGIN'] ?? ''));

        if ($origin !== '') {

            $host = strtolower((string)($_SERVER['HTTP_HOST'] ?? ''));

            $parsed = parse_url($origin);

            $originHost = strtolower((string)($parsed['host'] ?? ''));

            $originPort = isset($parsed['port']) ? ':' . $parsed['port'] : '';

            $hostOnly = preg_replace('/:\d+$/', '', $host);

            $hostWithPort = $host;

            if ($originHost !== $hostOnly && $originHost !== $hostWithPort) return false;

            if ($originPort !== '' && $originPort !== (strpos($host, ':') !== false ? substr($host, strpos($host, ':')) : '')) return false;
            }

        // Verificación adicional por Referer cuando ni Origin ni Sec-Fetch-Site
        // están presentes (navegadores antiguos). Si hay Referer y es de otro
        // sitio, la petición se rechaza.
        $referer = trim((string)($_SERVER['HTTP_REFERER'] ?? ''));

        if ($referer !== '') {

            $host = strtolower((string)($_SERVER['HTTP_HOST'] ?? ''));

            $parsed = parse_url($referer);

            $refererHost = strtolower((string)($parsed['host'] ?? ''));

            if ($refererHost !== '' && $refererHost !== preg_replace('/:\\d+$/', '', $host)) return false;
            }

        return true;
        }
    }

if (!function_exists('vilamir_token_csrf')) {

    /** Token CSRF por sesión, generado perezosamente. */
    function vilamir_token_csrf(): string {

        if (empty($_SESSION['csrf_token'])) {

            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            }

        return $_SESSION['csrf_token'];
        }
    }

if (!function_exists('vilamir_verificar_csrf')) {

    /**
     * Verifica el token CSRF en peticiones que modifican datos.
     * Acepta el token por header 'X-CSRF-Token', campo POST 'csrf_token' o
     * JSON body 'csrf_token'. Falla con 403 si el token no coincide.
     */
    function vilamir_verificar_csrf(): void {

        $token = '';

        $header = trim((string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''));

        if ($header !== '') {

            $token = $header;
            }
        elseif (isset($_POST['csrf_token'])) {

            $token = (string)$_POST['csrf_token'];
            }
        else {

            $tipo = strtolower(trim((string)($_SERVER['CONTENT_TYPE'] ?? '')));

            if (strpos($tipo, 'application/json') !== false) {

                $cuerpo = file_get_contents('php://input');

                $datos = json_decode((string)$cuerpo, true);

                if (is_array($datos) && isset($datos['csrf_token'])) {

                    $token = (string)$datos['csrf_token'];
                    }
                }
            }

        $esperado = $_SESSION['csrf_token'] ?? '';

        if ($esperado === '' || $token === '' || !hash_equals($esperado, $token)) {

            http_response_code(403);

            header('Content-Type: application/json; charset=utf-8');

            echo json_encode(['status'=>'error','message'=>'Token de seguridad inválido. Recargue la página e intente de nuevo.'], JSON_UNESCAPED_UNICODE);

            exit;
            }
        }
    }

if (!function_exists('vilamir_enviar_token_csrf')) {

    /** Imprime el token CSRF como meta tag para las páginas HTML. */
    function vilamir_enviar_token_csrf(): void {

        $token = vilamir_token_csrf();

        echo '<meta name="csrf-token" content="' . htmlspecialchars($token, ENT_QUOTES, 'UTF-8') . '">';
        }
    }

if (!function_exists('vilamir_rol')) {

    function vilamir_rol(): string {

        return trim((string)($_SESSION['usuario_rol'] ?? ''));
        }
    }

if (!function_exists('vilamir_tiene_rol')) {

    function vilamir_tiene_rol(string ...$roles): bool {

        $rol = strtolower(vilamir_rol());

        foreach ($roles as $permitido) {

            if ($rol === strtolower($permitido)) return true;
            }

        return false;
        }
    }

if (!function_exists('vilamir_requerir_sesion')) {

    function vilamir_requerir_sesion(bool $json = false): void {

        if (isset($_SESSION['usuario_id'])) return;

        if ($json) {

            http_response_code(401);

            header('Content-Type: application/json; charset=utf-8');

            echo json_encode(['status'=>'error','message'=>'Sesión requerida.'], JSON_UNESCAPED_UNICODE);

            exit;
            }

        header('Location: login.html');

        exit;
        }
    }

if (!function_exists('vilamir_requerir_rol')) {

    function vilamir_requerir_rol(array $roles, bool $json = true): void {

        if (vilamir_tiene_rol(...$roles)) return;

        if ($json) {

            http_response_code(403);

            header('Content-Type: application/json; charset=utf-8');

            echo json_encode(['status'=>'error','message'=>'No tienes permisos para realizar esta acción.'], JSON_UNESCAPED_UNICODE);

            exit;
            }

        http_response_code(403);

        exit('Acceso denegado.');
        }
    }
// Polyfills de compatibilidad para servidores con PHP < 8.0
if (!function_exists('str_contains')) {
    function str_contains(string $haystack, string $needle): bool {
        return $needle === '' || strpos($haystack, $needle) !== false;
    }
}
if (!function_exists('str_starts_with')) {
    function str_starts_with(string $haystack, string $needle): bool {
        return strncmp($haystack, $needle, strlen($needle)) === 0;
    }
}