<?php

/*
 * ARCHIVO: admin.php
 * PROPÓSITO: Configuración compartida de admin para el funcionamiento seguro del sistema.
 */
// Descripción: endpoint/configuración de admin. Gestiona la comunicación entre la interfaz y la base de datos.
require_once __DIR__ . '/autenticacion.php';

if (strcasecmp(trim((string)($_SESSION['usuario_rol'] ?? '')), 'Administrador') !== 0) {

    header('Location: index.php');

    exit;
    }

