<?php

/*
 * ARCHIVO: cupos.php
 * PROPÓSITO: Configuración compartida de cupos para el funcionamiento seguro del sistema.
 */
/**
 * V20 - Gestión de cupos y listas de espera.
 * Promueve automáticamente al primer alumno en espera cuando se libera un lugar.
 */
require_once __DIR__.'/notificaciones.php';

function vilamirPromoverListaGrupo(PDO $conexion, int $idGrupo): int {

    if ($idGrupo <= 0) return 0;

    $promovidos = 0;

    $promovidosIds = [];

    try {

        $conexion->beginTransaction();

        $q=$conexion->prepare('SELECT ID_Grupo,Nombre,Cupo_maximo FROM GRUPO WHERE ID_Grupo=? FOR UPDATE');

        $q->execute([$idGrupo]);

        $grupo=$q->fetch();

        if(!$grupo) {
            $conexion->rollBack();
            return 0;
            }

        $cupo=(int)$grupo['Cupo_maximo'];

        if($cupo<=0) {
            $conexion->commit();
            return 0;
            }

        $q=$conexion->prepare("SELECT COUNT(*) FROM INSCRIPCION_GRUPO_ALUMNO WHERE ID_Grupo=? AND Estado='Activa'");

        $q->execute([$idGrupo]);

        $actual=(int)$q->fetchColumn();

        while($actual<$cupo) {

            $q=$conexion->prepare("SELECT le.ID_Espera,le.ID_Alumno FROM LISTA_ESPERA le WHERE le.ID_Grupo=? AND le.Estado='En espera' ORDER BY le.Fecha_solicitud ASC,le.ID_Espera ASC LIMIT 1 FOR UPDATE");

            $q->execute([$idGrupo]);

            $fila=$q->fetch();

            if(!$fila) break;

            $idAlumno=(int)$fila['ID_Alumno'];

            $chk=$conexion->prepare("SELECT ID_Inscripcion FROM INSCRIPCION_GRUPO_ALUMNO WHERE ID_Alumno=? AND ID_Grupo=? AND Estado='Activa' LIMIT 1");

            $chk->execute([$idAlumno,$idGrupo]);

            if($chk->fetchColumn()) {

                $conexion->prepare("UPDATE LISTA_ESPERA SET Estado='Admitido' WHERE ID_Espera=?")->execute([(int)$fila['ID_Espera']]);

                continue;
                }

            $ins=$conexion->prepare("SELECT ID_Inscripcion FROM INSCRIPCION_GRUPO_ALUMNO WHERE ID_Alumno=? AND ID_Grupo=? LIMIT 1");

            $ins->execute([$idAlumno,$idGrupo]);

            $exist=$ins->fetchColumn();

            if($exist) {

                $conexion->prepare("UPDATE INSCRIPCION_GRUPO_ALUMNO SET Estado='Activa',Fecha_inscripcion=CURRENT_TIMESTAMP WHERE ID_Inscripcion=?")->execute([(int)$exist]);
                }
            else {

                $conexion->prepare("INSERT INTO INSCRIPCION_GRUPO_ALUMNO(ID_Alumno,ID_Grupo,Estado) VALUES(?,?,'Activa')")->execute([$idAlumno,$idGrupo]);
                }

            $conexion->prepare("UPDATE LISTA_ESPERA SET Estado='Admitido' WHERE ID_Espera=?")->execute([(int)$fila['ID_Espera']]);

            $actual++;
            $promovidos++;
            $promovidosIds[]=$idAlumno;
            }

        $conexion->commit();

        if($promovidos>0) {

            foreach($promovidosIds as $idAlumnoPromovido) {

                vilamirNotificarAlumno($conexion,(int)$idAlumnoPromovido,'Se liberó un lugar en el grupo '.$grupo['Nombre'].' y fuiste promovido automáticamente desde la lista de espera.','Pendiente');
                }
            }
        }
    catch(Throwable $e) {
        if($conexion->inTransaction())$conexion->rollBack();
        error_log('VILAMIR promoción grupo: '.$e->getMessage());
        }

    return $promovidos;
    }

function vilamirPromoverListaSeminario(PDO $conexion, int $idSeminario): int {

    if ($idSeminario <= 0) return 0;

    $promovidos=0;

    $promovidosIds=[];

    try {

        $conexion->beginTransaction();

        $q=$conexion->prepare('SELECT ID_Seminario,COALESCE(NULLIF(Nombre,\'\'),Titulo) AS Nombre,Cupo FROM SEMINARIO WHERE ID_Seminario=? FOR UPDATE');

        $q->execute([$idSeminario]);
        $evento=$q->fetch();

        if(!$evento) {
            $conexion->rollBack();
            return 0;
            }

        $cupo=(int)($evento['Cupo']??0);

        if($cupo<=0) {
            $conexion->commit();
            return 0;
            }

        $q=$conexion->prepare("SELECT COUNT(*) FROM INSCRIPCION_SEMINARIO WHERE ID_Seminario=? AND Estado='Activa'");
        $q->execute([$idSeminario]);
        $actual=(int)$q->fetchColumn();

        while($actual<$cupo) {

            $q=$conexion->prepare("SELECT le.ID_Espera,le.ID_Alumno FROM LISTA_ESPERA_SEMINARIO le WHERE le.ID_Seminario=? AND le.Estado='En espera' ORDER BY le.Fecha_solicitud ASC,le.ID_Espera ASC LIMIT 1 FOR UPDATE");
            $q->execute([$idSeminario]);
            $fila=$q->fetch();
            if(!$fila)break;

            $idAlumno=(int)$fila['ID_Alumno'];

            $chk=$conexion->prepare("SELECT ID_Ins_seminario FROM INSCRIPCION_SEMINARIO WHERE ID_Alumno=? AND ID_Seminario=? AND Estado='Activa' LIMIT 1");
            $chk->execute([$idAlumno,$idSeminario]);

            if($chk->fetchColumn()) {
                $conexion->prepare("UPDATE LISTA_ESPERA_SEMINARIO SET Estado='Admitido' WHERE ID_Espera=?")->execute([(int)$fila['ID_Espera']]);
                continue;
                }

            $ins=$conexion->prepare("SELECT ID_Ins_seminario FROM INSCRIPCION_SEMINARIO WHERE ID_Alumno=? AND ID_Seminario=? LIMIT 1");
            $ins->execute([$idAlumno,$idSeminario]);
            $exist=$ins->fetchColumn();

            if($exist)$conexion->prepare("UPDATE INSCRIPCION_SEMINARIO SET Estado='Activa',Fecha_ins=CURDATE() WHERE ID_Ins_seminario=?")->execute([(int)$exist]);

            else $conexion->prepare("INSERT INTO INSCRIPCION_SEMINARIO(ID_Alumno,ID_Seminario,Fecha_ins,Estado) VALUES(?,?,CURDATE(),'Activa')")->execute([$idAlumno,$idSeminario]);

            $conexion->prepare("UPDATE LISTA_ESPERA_SEMINARIO SET Estado='Admitido' WHERE ID_Espera=?")->execute([(int)$fila['ID_Espera']]);

            $actual++;
            $promovidos++;
            $promovidosIds[]=$idAlumno;
            }

        $conexion->commit();

        if($promovidos>0) {

            foreach($promovidosIds as $idAlumnoPromovido) vilamirNotificarAlumno($conexion,(int)$idAlumnoPromovido,'Se liberó un lugar en el evento '.$evento['Nombre'].' y fuiste promovido automáticamente desde la lista de espera.','Pendiente');
            }
        }
    catch(Throwable $e) {
        if($conexion->inTransaction())$conexion->rollBack();
        error_log('VILAMIR promoción evento: '.$e->getMessage());
        }

    return $promovidos;
    }

