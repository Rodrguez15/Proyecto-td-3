<?php
/**
 * PLANTILLA PRIVADA: copiar como db_config.local.php y completar.
 * No subir db_config.local.php a repositorios ni compartirlo públicamente.
 *
 * XAMPP habitual (solo si coincide con tu instalación):
 *   host 127.0.0.1, base mma_systems, usuario root, contraseña vacía.
 * InfinityFree: usar exactamente el host, nombre de base, usuario y clave
 * que aparecen en el panel de MySQL de la cuenta.
 */
if (!defined('VILAMIR_ENV')) define('VILAMIR_ENV', 'production');
if (!defined('VILAMIR_DB_HOST')) define('VILAMIR_DB_HOST', '127.0.0.1');
if (!defined('VILAMIR_DB_NAME')) define('VILAMIR_DB_NAME', 'mma_systems');
if (!defined('VILAMIR_DB_USER')) define('VILAMIR_DB_USER', 'vilamir');
if (!defined('VILAMIR_DB_PASS')) define('VILAMIR_DB_PASS', 'Admin1234');

// En producción, usar la URL HTTPS pública completa, incluido el subdirectorio.
// No completar con una URL inventada: copiar la URL real de la instalación.
if (!defined('VILAMIR_BASE_URL')) define('VILAMIR_BASE_URL', 'https://academiavilamir.rf.gd');

// Solo si se habilita el cron web. Preferir ejecución CLI cuando el hosting lo permita.
// Generar una clave larga y aleatoria; no reutilizar contraseñas de cuentas.
// if (!defined('VILAMIR_CRON_KEY')) define('VILAMIR_CRON_KEY', 'GENERAR_CLAVE_ALEATORIA');
