<?php
/**
 * Generación y asignación de identificadores QR de alumnos.
 * No modifica el esquema: utiliza ALUMNO.Codigo_qr, ya existente.
 */

if (!function_exists('vilamir_nuevo_codigo_qr')) {
    function vilamir_nuevo_codigo_qr(PDO $conexion): string
    {
        $buscar = $conexion->prepare('SELECT 1 FROM ALUMNO WHERE Codigo_qr = ? LIMIT 1');
        for ($intento = 0; $intento < 10; $intento++) {
            // Token aleatorio no predecible; el QR no contiene datos personales ni credenciales.
            $codigo = 'VIL-' . strtoupper(bin2hex(random_bytes(12)));
            $buscar->execute([$codigo]);
            if (!$buscar->fetchColumn()) return $codigo;
        }
        throw new RuntimeException('No se pudo generar un código QR único.');
    }
}

if (!function_exists('vilamir_asignar_qr_alumno')) {
    function vilamir_asignar_qr_alumno(PDO $conexion, int $idAlumno): ?string
    {
        if ($idAlumno <= 0) return null;
        $consulta = $conexion->prepare('SELECT Codigo_qr FROM ALUMNO WHERE ID_Alumno = ? LIMIT 1');
        $consulta->execute([$idAlumno]);
        $actual = $consulta->fetchColumn();
        if ($actual === false) return null;
        if (is_string($actual) && trim($actual) !== '') return trim($actual);

        $codigo = vilamir_nuevo_codigo_qr($conexion);
        $actualizar = $conexion->prepare("UPDATE ALUMNO SET Codigo_qr = ? WHERE ID_Alumno = ? AND (Codigo_qr IS NULL OR Codigo_qr = '')");
        $actualizar->execute([$codigo, $idAlumno]);

        // Si otra petición lo asignó simultáneamente, devolver el valor persistido.
        $consulta->execute([$idAlumno]);
        $persistido = $consulta->fetchColumn();
        return is_string($persistido) && trim($persistido) !== '' ? trim($persistido) : null;
    }
}


if (!function_exists('vilamir_obtener_qr_usuario')) {
    function vilamir_obtener_qr_usuario(PDO $conexion, int $idUsuario): ?string
    {
        if ($idUsuario <= 0) return null;
        $q = $conexion->prepare('SELECT ID_Alumno FROM ALUMNO WHERE ID_Usuario = ? LIMIT 1');
        $q->execute([$idUsuario]);
        $idAlumno = $q->fetchColumn();
        return $idAlumno === false ? null : vilamir_asignar_qr_alumno($conexion, (int)$idAlumno);
    }
}

if (!function_exists('vilamir_generar_qr_pendientes')) {
    function vilamir_generar_qr_pendientes(PDO $conexion): int
    {
        $ids = $conexion->query("SELECT ID_Alumno FROM ALUMNO WHERE Codigo_qr IS NULL OR Codigo_qr = '' ORDER BY ID_Alumno ASC")->fetchAll(PDO::FETCH_COLUMN);
        $generados = 0;
        foreach ($ids as $id) {
            if (vilamir_asignar_qr_alumno($conexion, (int)$id) !== null) $generados++;
        }
        return $generados;
    }
}
