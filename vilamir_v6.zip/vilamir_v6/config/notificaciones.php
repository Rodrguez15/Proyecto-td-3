<?php

/*
 * ARCHIVO: notificaciones.php
 * PROPÓSITO: Configuración compartida de notificaciones para el funcionamiento seguro del sistema.
 */
/**
 * Utilidades de notificaciones VILAMIR. Requiere $conexion (PDO).
 * Las bajas se consultan en ACTIVIDAD_SISTEMA, sin modificar el esquema.
 */
require_once __DIR__ . '/alumnos_estado.php';

function vilamirAlumnoPuedeRecibirNotificaciones(PDO $conexion, int $idAlumno): bool {
    if ($idAlumno <= 0) return false;
    $estado = vilamir_estado_baja_alumno($conexion, $idAlumno);
    if ($estado !== 'ACTIVO') {
        if (!in_array($estado, ['BAJA_TEMPORAL', 'BAJA_DEFINITIVA'], true)) {
            error_log('VILAMIR: se omitieron notificaciones porque no se pudo verificar el estado del alumno ID ' . $idAlumno);
        }
        return false;
    }
    return true;
}


/**
 * Notifica a todos los administradores activos del sistema.
 * Se usa para avisos operativos: pagos nuevos, inscripciones con pago, etc.
 */
function vilamirNotificarAdministradores(PDO $conexion, string $titulo, string $mensaje, string $clave=''): void {

    if (trim($mensaje)==='') return;

    try {

        // NOTIFICACION_USUARIO apunta a USUARIO; filtramos por rol Administrador.
        $check=$conexion->query("SHOW TABLES LIKE 'NOTIFICACION_USUARIO'");

        if (!$check->fetchColumn()) return;

        $q=$conexion->query("SELECT ID_Usuario FROM USUARIO WHERE Rol='Administrador'");

        foreach ($q->fetchAll(PDO::FETCH_COLUMN) as $idUsuario) {

            $idUsuario=(int)$idUsuario;

            if ($idUsuario<=0) continue;

            if ($clave==='') $clave=sha1($idUsuario.'|'.$titulo.'|'.$mensaje);

            try {

                $q=$conexion->prepare('INSERT IGNORE INTO NOTIFICACION_USUARIO(ID_Usuario,Titulo,Mensaje,Fecha,Leida,Clave) VALUES(?,?,?,NOW(),0,?)');

                $q->execute([$idUsuario, $titulo, $mensaje, $clave]);
                }
            catch (Throwable $inner) {

                error_log('VILAMIR notificacion admin (usuario '.$idUsuario.'): '.$inner->getMessage());
                }
            }
        }
    catch (Throwable $e) {

        error_log('VILAMIR notificacion admins: '.$e->getMessage());
        }
    }

function vilamirNotificarAlumno(PDO $conexion, int $idAlumno, string $mensaje, string $estado='Pendiente'): bool {

    if ($idAlumno <= 0 || trim($mensaje)==='') return false;
    if (!vilamirAlumnoPuedeRecibirNotificaciones($conexion, $idAlumno)) return false;

    try {
        $q=$conexion->prepare('SELECT ID_Notificacion FROM NOTIFICACION WHERE ID_Alumno=? AND Mensaje=? LIMIT 1');
        $q->execute([$idAlumno, $mensaje]);
        if ($q->fetchColumn()) return false;

        $q=$conexion->prepare('INSERT INTO NOTIFICACION(ID_Alumno,Estado,Mensaje,Fecha) VALUES(?,?,?,CURDATE())');
        $q->execute([$idAlumno, $estado, $mensaje]);
        return $q->rowCount() > 0;
    } catch (Throwable $e) {
        error_log('VILAMIR notificación alumno: '.$e->getMessage());
        return false;
    }
}

function vilamirNotificarTodosAlumnos(PDO $conexion, string $mensaje): void {

    try {

        $ids=$conexion->query('SELECT ID_Alumno FROM ALUMNO')->fetchAll(PDO::FETCH_COLUMN);

        foreach ($ids as $id) vilamirNotificarAlumno($conexion, (int)$id, $mensaje);
        }
    catch (Throwable $e) {
        error_log('VILAMIR notificación general: '.$e->getMessage());
        }
    }

function vilamirNotificarProfesor(PDO $conexion, int $idUsuario, string $titulo, string $mensaje, string $clave=''): void {

    if ($idUsuario <= 0 || trim($mensaje)==='') return;

    try {

        $check=$conexion->query("SHOW TABLES LIKE 'NOTIFICACION_USUARIO'");

        if (!$check->fetchColumn()) return;

        if ($clave==='') $clave=sha1($idUsuario.'|'.$titulo.'|'.$mensaje);

        $q=$conexion->prepare('INSERT IGNORE INTO NOTIFICACION_USUARIO(ID_Usuario,Titulo,Mensaje,Fecha,Leida,Clave) VALUES(?,?,?,NOW(),0,?)');

        $q->execute([$idUsuario, $titulo, $mensaje, $clave]);
        }
    catch (Throwable $e) {
        error_log('VILAMIR notificación profesor: '.$e->getMessage());
        }
    }

function vilamirNotificarGrupo(PDO $conexion, int $idGrupo, string $mensaje, string $titulo='Cambio de horario'): void {

    try {

        $q=$conexion->prepare('SELECT DISTINCT ID_Alumno FROM INSCRIPCION_GRUPO_ALUMNO WHERE ID_Grupo=? AND Estado=\'Activa\'');

        $q->execute([$idGrupo]);

        foreach ($q->fetchAll(PDO::FETCH_COLUMN) as $id) vilamirNotificarAlumno($conexion,(int)$id,$mensaje);
        }
    catch (Throwable $e) {
        error_log('VILAMIR aviso grupo alumnos: '.$e->getMessage());
        }

    try {

        $q=$conexion->prepare('SELECT DISTINCT p.ID_Usuario FROM INSCRIPCION_GRUPO_PROFESOR i JOIN PROFESOR p ON p.ID_Profesor=i.ID_Profesor WHERE i.ID_Grupo=? AND i.Estado=\'Activa\' AND p.ID_Usuario IS NOT NULL');

        $q->execute([$idGrupo]);

        foreach ($q->fetchAll(PDO::FETCH_COLUMN) as $uid) vilamirNotificarProfesor($conexion,(int)$uid,$titulo,$mensaje,sha1('grupo-'.$idGrupo.'-'.$titulo.'-'.$mensaje.'-'.$uid));
        }
    catch (Throwable $e) {
        error_log('VILAMIR aviso grupo profesores: '.$e->getMessage());
        }
    }

function vilamirGenerarAvisosAlumno(PDO $conexion, int $idAlumno): array {

    $resultado = ['pagos_proximos' => 0, 'pagos_vencidos' => 0, 'eventos' => 0];
    if ($idAlumno <= 0 || !vilamirAlumnoPuedeRecibirNotificaciones($conexion, $idAlumno)) return $resultado;

    try {
        $q = $conexion->prepare("SELECT ID_Pago,Tipo,Fecha_vencimiento,Importe
            FROM PAGO
            WHERE ID_Alumno=? AND Estado='Pendiente'
              AND Fecha_vencimiento IS NOT NULL
              AND Fecha_vencimiento<=DATE_ADD(CURDATE(), INTERVAL 7 DAY)
            ORDER BY Fecha_vencimiento,ID_Pago");
        $q->execute([$idAlumno]);
        foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $p) {
            $vencimiento = (string)$p['Fecha_vencimiento'];
            $vencido = $vencimiento < date('Y-m-d');
            $mensaje = ($vencido ? 'Pago vencido' : 'Recordatorio de pago')
                . ': ' . ($p['Tipo'] ?: 'Pago')
                . ' por $' . number_format((float)$p['Importe'], 2, ',', '.')
                . '. Vencimiento: ' . $vencimiento
                . '. [Pago #' . (int)$p['ID_Pago'] . ']';
            if (vilamirNotificarAlumno($conexion, $idAlumno, $mensaje)) {
                $resultado[$vencido ? 'pagos_vencidos' : 'pagos_proximos']++;
            }
        }
    } catch (Throwable $e) {
        error_log('VILAMIR avisos pagos: ' . $e->getMessage());
    }

    try {
        $q = $conexion->query("SELECT ID_Seminario,
                COALESCE(NULLIF(Nombre,''),Titulo) AS Nombre,Fecha
            FROM SEMINARIO
            WHERE Fecha>=CURDATE()
              AND Fecha<=DATE_ADD(CURDATE(), INTERVAL 7 DAY)
            ORDER BY Fecha,ID_Seminario");
        foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $evento) {
            $mensaje = 'Próximo seminario/evento: '
                . ($evento['Nombre'] ?: 'Actividad')
                . ' el ' . $evento['Fecha']
                . '. Revisá los detalles e inscripción en la sección de eventos.'
                . ' [Evento #' . (int)$evento['ID_Seminario'] . ']';
            if (vilamirNotificarAlumno($conexion, $idAlumno, $mensaje)) $resultado['eventos']++;
        }
    } catch (Throwable $e) {
        error_log('VILAMIR avisos eventos: ' . $e->getMessage());
    }
    return $resultado;
}
