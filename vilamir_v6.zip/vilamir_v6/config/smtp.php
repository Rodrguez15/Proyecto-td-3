<?php
/**
 * Cliente SMTP autenticado para correos transaccionales.
 * Las credenciales se cargan desde variables de entorno o config/smtp_config.php.
 * No se considera que el correo funciona hasta completar una prueba real de entrega.
 */
$configSmtpLocal = __DIR__ . '/smtp_config.php';
if (is_file($configSmtpLocal)) {
    require_once $configSmtpLocal;
}

function vilamirLeerRespuestaSmtp($socket): string {
    $respuesta = '';
    while (!feof($socket)) {
        $linea = fgets($socket, 512);
        if ($linea === false) break;
        $respuesta .= $linea;
        if (isset($linea[3]) && $linea[3] === ' ') break;
    }
    return $respuesta;
}

function vilamirDatosSmtp(): array {
    $host = trim((string)(getenv('SMTP_HOST') ?: (defined('VILAMIR_SMTP_HOST') ? VILAMIR_SMTP_HOST : '')));
    $portRaw = getenv('SMTP_PORT');
    $port = (int)($portRaw !== false && $portRaw !== '' ? $portRaw : (defined('VILAMIR_SMTP_PORT') ? VILAMIR_SMTP_PORT : 587));
    $user = trim((string)(getenv('SMTP_USER') ?: (defined('VILAMIR_SMTP_USER') ? VILAMIR_SMTP_USER : '')));
    $passEnv = getenv('SMTP_PASS');
    $pass = $passEnv !== false ? (string)$passEnv : (defined('VILAMIR_SMTP_PASS') ? (string)VILAMIR_SMTP_PASS : '');
    $from = trim((string)(getenv('VILAMIR_MAIL_FROM') ?: (defined('VILAMIR_SMTP_FROM') ? VILAMIR_SMTP_FROM : $user)));
    return compact('host', 'port', 'user', 'pass', 'from');
}

function vilamirSmtpConfigurado(): bool {
    $cfg = vilamirDatosSmtp();
    return $cfg['host'] !== ''
        && in_array($cfg['port'], [465, 587], true)
        && $cfg['user'] !== ''
        && $cfg['pass'] !== ''
        && filter_var($cfg['from'], FILTER_VALIDATE_EMAIL) !== false;
}

function vilamirEnviarCorreo(string $destinatario, string $asunto, string $mensajeTexto): bool {
    $cfg = vilamirDatosSmtp();
    if (!vilamirSmtpConfigurado()) {
        error_log('VILAMIR: SMTP no configurado; no se intentó enviar el correo.');
        return false;
    }
    if (filter_var($destinatario, FILTER_VALIDATE_EMAIL) === false) {
        error_log('VILAMIR: destinatario de correo no válido.');
        return false;
    }

    $host = $cfg['host'];
    $port = $cfg['port'];
    $user = $cfg['user'];
    $pass = $cfg['pass'];
    $from = $cfg['from'];
    $timeout = 15;
    $contexto = stream_context_create([
        'ssl' => [
            'verify_peer' => true,
            'verify_peer_name' => true,
            'allow_self_signed' => false,
        ],
    ]);

    $remoto = $port === 465 ? "ssl://{$host}:{$port}" : "tcp://{$host}:{$port}";
    $smtp = @stream_socket_client($remoto, $errno, $errstr, $timeout, STREAM_CLIENT_CONNECT, $contexto);
    if (!$smtp) {
        error_log("VILAMIR SMTP: no se pudo conectar a {$remoto}: {$errstr} ({$errno}).");
        return false;
    }
    stream_set_timeout($smtp, $timeout);

    $leerCodigo = static function ($socket): string {
        $r = vilamirLeerRespuestaSmtp($socket);
        return substr(trim($r), 0, 3);
    };
    $enviar = static function ($socket, string $comando) use ($leerCodigo): string {
        if (fputs($socket, $comando . "\r\n") === false) return '';
        return $leerCodigo($socket);
    };
    $cerrar = static function ($socket): void {
        if (is_resource($socket)) fclose($socket);
    };

    try {
        if ($leerCodigo($smtp) !== '220') throw new RuntimeException('Saludo SMTP inesperado.');
        $helo = preg_replace('/[^A-Za-z0-9.-]/', '', (string)(gethostname() ?: 'localhost')) ?: 'localhost';
        if ($enviar($smtp, "EHLO {$helo}") !== '250') throw new RuntimeException('EHLO rechazado.');

        if ($port === 587) {
            if ($enviar($smtp, 'STARTTLS') !== '220') throw new RuntimeException('STARTTLS rechazado.');
            if (!stream_socket_enable_crypto($smtp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
                throw new RuntimeException('No se pudo establecer TLS.');
            }
            if ($enviar($smtp, "EHLO {$helo}") !== '250') throw new RuntimeException('EHLO posterior a TLS rechazado.');
        }

        if ($enviar($smtp, 'AUTH LOGIN') !== '334') throw new RuntimeException('AUTH LOGIN rechazado.');
        if ($enviar($smtp, base64_encode($user)) !== '334') throw new RuntimeException('Usuario SMTP rechazado.');
        if ($enviar($smtp, base64_encode($pass)) !== '235') throw new RuntimeException('Autenticación SMTP fallida.');
        if ($enviar($smtp, "MAIL FROM:<{$from}>") !== '250') throw new RuntimeException('MAIL FROM rechazado.');
        $codigoRcpt = $enviar($smtp, "RCPT TO:<{$destinatario}>");
        if (!in_array($codigoRcpt, ['250', '251'], true)) throw new RuntimeException('RCPT TO rechazado.');
        if ($enviar($smtp, 'DATA') !== '354') throw new RuntimeException('DATA rechazado.');

        $asuntoCodificado = '=?UTF-8?B?' . base64_encode($asunto) . '?=';
        $cuerpo = str_replace(["\r\n", "\r"], "\n", $mensajeTexto);
        $cuerpo = preg_replace('/^\./m', '..', $cuerpo);
        $contenido = "From: Academia VILAMIR <{$from}>\r\n"
            . "To: <{$destinatario}>\r\n"
            . "Subject: {$asuntoCodificado}\r\n"
            . "MIME-Version: 1.0\r\n"
            . "Content-Type: text/plain; charset=UTF-8\r\n\r\n"
            . str_replace("\n", "\r\n", $cuerpo) . "\r\n.";
        if (fputs($smtp, $contenido . "\r\n") === false || $leerCodigo($smtp) !== '250') {
            throw new RuntimeException('El servidor SMTP no confirmó el mensaje.');
        }
        $enviar($smtp, 'QUIT');
        $cerrar($smtp);
        return true;
    } catch (Throwable $e) {
        error_log('VILAMIR SMTP: ' . $e->getMessage());
        $cerrar($smtp);
        return false;
    }
}
