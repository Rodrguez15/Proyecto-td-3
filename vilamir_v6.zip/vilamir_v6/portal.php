<?php

/*
 * ARCHIVO: portal.php
 * PROPÓSITO: Portal del alumno dentro del sistema Academia VILAMIR.
 * Incluye gestión de suscripciones, cuotas promocionales (RN-06 / TC-05) y cambio de plan.
 */
require_once 'config/autenticacion.php';

$rolPortal = trim((string)($_SESSION['usuario_rol'] ?? ''));
if (strcasecmp($rolPortal, 'Administrador') === 0) {
    header('Location: admin.php');
    exit;
}
if (strcasecmp($rolPortal, 'Profesor') === 0) {
    header('Location: profesor.php');
    exit;
}
if (strcasecmp($rolPortal, 'Alumno') !== 0) {
    header('Location: login.html');
    exit;
}

$nombre = $_SESSION['usuario_nombre'] ?? 'Alumno';

?>
<!DOCTYPE html>
<html lang="es">
<head>
<?php vilamir_enviar_token_csrf(); ?>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Mi cuenta | VILAMIR</title>
<link rel="stylesheet" href="css/style.css?v=20261115-unificado-v1">
<script src="js/csrf.js"></script>
</head>
<body class="account-page portal-page">
<header class="navbar">
<div class="logo">
<img src="images/logo-vilamir.jpg" alt="Escuela Vilamir" class="logo-img">
</div>
<nav>
<a href="index.php">Inicio</a>
<a href="clases.php">Clases</a>
<a href="mis_clases.php">Mis clases</a>
<a href="horarios.php">Horarios</a>
<a href="seminarios.php">Seminarios</a>
<a href="calendario.php">Calendario</a>
<a class="active" href="portal.php">Mi cuenta</a>
<a href="logout.php">Cerrar sesión</a>
</nav>
</header>
<main class="account-shell">
<section class="account-welcome">
<div>
<span class="account-eyebrow">MI CUENTA</span>
<h1>Hola, <?= htmlspecialchars($nombre) ?> 👋</h1>
<p>Todo lo importante de tu actividad en VILAMIR, en un solo lugar.</p>
</div>
<div class="account-actions">
<a href="horarios.php" class="account-btn">📅 Mis horarios</a>
<a href="seminarios.php" class="account-btn account-btn-dark">🎓 Seminarios y eventos</a>
</div>
</section>
<div id="accountMessage" class="account-message" hidden>
</div>
<section id="resumenCards" class="account-stats">
</section>
<div class="account-layout">
<section class="account-panel account-profile-panel">
<div class="account-panel-head">
<div>
<span class="panel-kicker">PERFIL</span>
<h2>Mis datos</h2>
</div>
<span class="profile-mark">👤</span>
</div>
<div id="perfil" class="profile-details">
<div class="account-loading">Cargando datos...</div>
</div>
<div class="profile-edit-actions">
<button type="button" id="toggleEditarPerfil" class="account-btn">✏️ Editar mis datos</button>
</div>
<form id="formEditarPerfil" class="profile-edit-form" hidden>
<div class="profile-edit-grid">
<label>Nombre<input name="nombre" maxlength="100" required autocomplete="given-name"></label>
<label>Apellido<input name="apellido" maxlength="100" required autocomplete="family-name"></label>
<label>Correo electrónico<input name="email" type="email" maxlength="150" required autocomplete="email"></label>
<label>Teléfono<input name="telefono" type="tel" maxlength="40" autocomplete="tel"></label>
<label>Fecha de nacimiento<input name="fecha_nacimiento" type="date" autocomplete="bday"></label>
<label>Dirección<input name="direccion" maxlength="255" autocomplete="street-address"></label>
<label class="profile-edit-wide">Cobertura médica<input name="cobertura_medica" maxlength="150"></label>
</div>
<p class="profile-edit-note">Por seguridad, la cédula, el peso, la categoría y el código QR no se pueden modificar desde esta pantalla. Si necesitás corregirlos, contactá a la administración.</p>
<div class="profile-edit-actions">
<button type="submit" class="account-btn">Guardar cambios</button>
<button type="button" id="cancelarEditarPerfil" class="account-btn account-btn-dark">Cancelar</button>
</div>
</form>
<section class="password-change-section">
<div class="password-change-summary">
<div class="account-panel-head">
<div>
<span class="panel-kicker">SEGURIDAD</span>
<h3>Contraseña</h3>
</div>
<span class="profile-mark">🔒</span>
</div>
<p class="profile-edit-note">Mantené tu cuenta protegida actualizando tu contraseña cuando lo necesites.</p>
<button type="button" id="toggleCambiarContrasena" class="account-btn">🔑 Cambiar contraseña</button>
</div>
<form id="formCambiarContrasena" class="profile-edit-form" hidden>
<p class="profile-edit-note">Ingresá tu contraseña actual y elegí una nueva de al menos 8 caracteres.</p>
<div class="profile-edit-grid">
<label class="profile-edit-wide">Contraseña actual<input type="password" name="contrasena_actual" required autocomplete="current-password" maxlength="4096"></label>
<label>Nueva contraseña<input type="password" name="contrasena_nueva" required minlength="8" autocomplete="new-password" maxlength="4096"></label>
<label>Confirmar nueva contraseña<input type="password" name="confirmar_contrasena" required minlength="8" autocomplete="new-password" maxlength="4096"></label>
</div>
<div class="profile-edit-actions"><button type="submit" class="account-btn">Guardar nueva contraseña</button><button type="button" id="cancelarCambiarContrasena" class="account-btn account-btn-dark">Cancelar</button></div>
</form>
</section>
<div class="qr-box account-qr">
<div>
<span class="panel-kicker">IDENTIFICACIÓN</span>
<h3>Mi código QR</h3>
<p>Podés presentarlo en la academia para identificar tu cuenta.</p>
</div>
<div id="qrAlumno" aria-label="Código QR personal del alumno"></div>
<a class="account-btn account-btn-dark" id="linkCarnetDigital" href="carnet_digital.php" style="display:none">🎫 Ver / imprimir carnet digital</a>
<a class="account-btn" href="certificado_asistencia.php" target="_blank" rel="noopener">📄 Descargar constancia de asistencia</a>
</div>
</section>
<section class="account-panel">
<div class="account-panel-head">
<div>
<span class="panel-kicker">ESTADO</span>
<h2>Resumen de tu actividad</h2>
</div>
<span class="profile-mark">📊</span>
</div>
<div id="estadoActividad" class="activity-summary">
<div class="account-loading">Cargando...</div>
</div>
</section>
</div>

<!-- ============================================================ -->
<!-- PANEL DE PLAN VIGENTE, PROMOCIONES Y DISCIPLINAS (RN-06) -->
<!-- ============================================================ -->
<section class="account-panel" id="panelPromocionesPlan">
    <div class="account-panel-head">
        <div>
            <span class="panel-kicker">ESTADO DE MEMBRESÍA</span>
            <h2>Tu Plan y Promoción Vigente</h2>
            <p class="panel-subtitle">Según la cantidad de disciplinas activas, el sistema te otorga automáticamente aranceles bonificados.</p>
        </div>
        <button type="button" id="btnAbrirModalPlanes" class="account-btn" style="cursor:pointer;">
            🔄 Cambiar de Plan o Disciplinas
        </button>
    </div>

    <!-- TARJETA DEL PLAN EXACTO (CARGADA AUTOMÁTICAMENTE CON JS) -->
    <div id="contenedorPlanActual" style="margin-bottom: 20px;">
        <div class="account-loading">Analizando tus disciplinas y descuentos activos...</div>
    </div>

    <div class="account-panel-head" style="border-top: 1px solid rgba(255,255,255,0.08); padding-top: 15px; margin-top: 15px;">
        <div>
            <span class="panel-kicker">ENTRENAMIENTO</span>
            <h3>Disciplinas en las que estás entrenando</h3>
        </div>
        <a href="clases.php" class="account-link">Explorar catálogo →</a>
    </div>
    <div id="disciplinas" class="account-cards">
    </div>
</section>

<!-- MODAL PARA CAMBIO DE PLAN Y SELECCIÓN DE DISCIPLINAS -->
<div id="modalSelectorPlanes" class="modal-vilamir-backdrop" style="display:none;">
    <div class="modal-vilamir-card" style="max-width: 650px;">
        <div class="modal-vilamir-head">
            <h3>🥋 Elegir Plan y Disciplinas</h3>
            <button type="button" class="modal-vilamir-close" id="btnCerrarModalPlanes">&times;</button>
        </div>
        <form id="formSeleccionPaquete">
            <p style="font-size:13px; color:#bbb; margin-bottom:15px;">
                Seleccioná el plan que deseas cursar y marca las disciplinas correspondientes:
            </p>

            <div class="modal-field">
                <label for="selectTipoPlan">Seleccionar Tipo de Plan</label>
                <select id="selectTipoPlan" name="tipo_plan" required style="font-weight:700;">
                    <option value="1">Plan 1 Disciplina — $1.500 / mes</option>
                    <option value="2" selected>⭐ Promoción 2 Disciplinas — $1.900 / mes (Ahorras $1.100)</option>
                    <option value="3">🔥 Promoción 3 Disciplinas — $2.100 / mes (Ahorras $2.400)</option>
                    <option value="libre">👑 Pase Libre Total (Todas) — $2.500 / mes</option>
                </select>
            </div>

            <div class="modal-field" style="margin-top: 14px;">
                <label id="labelInstruccionDisciplinas">Elegí 2 disciplinas:</label>
                <div id="listaCheckDisciplinas" style="display:grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 8px;">
                    <!-- Cargado dinámicamente con JS -->
                </div>
            </div>

            <div id="resumenModalPlan" style="background:#121215; border:1px solid #2d2d35; border-radius:8px; padding:12px; margin:16px 0; font-size:13px;">
                Total a abonar: <strong id="montoTotalPlanModal" style="color:#39d98a; font-size:16px;">$1.900 UYU</strong> por mes.
            </div>

            <div class="modal-actions">
                <button type="button" class="btn secondary" id="btnCancelarModalPlanes">Cancelar</button>
                <button type="submit" class="btn btn-confirmar-submit" id="btnConfirmarPaquete">Confirmar y Aplicar Promoción</button>
            </div>
        </form>
    </div>
</div>

<div class="account-layout account-layout-wide">
<section class="account-panel">
<div class="account-panel-head">
<div>
<span class="panel-kicker">AGENDA</span>
<h2>Próximas clases</h2>
</div>
<a href="horarios.php" class="account-link">Ver horarios →</a>
</div>
<div id="proximasClases" class="account-list">
</div>
</section>
<section class="account-panel">
<div class="account-panel-head">
<div>
<span class="panel-kicker">AVISOS</span>
<h2>Notificaciones</h2>
</div>
<button class="account-link account-notif-all" type="button" onclick="leerTodasNotificaciones()">Marcar todas como leídas</button>
</div>
<div id="notificaciones" class="account-list">
</div>
</section>
</div>

<div class="account-layout account-layout-wide">
<section class="account-panel">
<div class="account-panel-head">
<div>
<span class="panel-kicker">OPORTUNIDADES</span>
<h2>Promociones disponibles</h2>
<p class="panel-subtitle">Beneficios que podés aprovechar actualmente.</p>
</div>
</div>
<div id="promociones" class="account-cards">
</div>
</section>
<section class="account-panel">
<div class="account-panel-head">
<div>
<span class="panel-kicker">PRÓXIMAMENTE</span>
<h2>Próximos eventos</h2>
<p class="panel-subtitle">Seminarios y actividades que se acercan.</p>
</div>
<a href="seminarios.php" class="account-link">Ver actividades →</a>
</div>
<div id="proximosEventos" class="account-list">
</div>
</section>
</div>

<div class="account-layout account-layout-wide">
<section class="account-panel">
<div class="account-panel-head">
<div>
<span class="panel-kicker">FINANZAS</span>
<h2>Estado de pagos</h2>
</div>
</div>
<div id="resumenPagosAlumno" class="payment-account-summary">
</div>
<div id="pagos" class="account-list">
</div>
</section>
<section class="account-panel">
<div class="account-panel-head">
<div>
<span class="panel-kicker">ACTIVIDADES</span>
<h2>Seminarios y eventos</h2>
</div>
<a href="seminarios.php" class="account-link">Ver todos →</a>
</div>
<div id="seminarios" class="account-cards">
</div>
</section>
</div>

<section class="account-panel">
<div class="account-panel-head">
<div>
<span class="panel-kicker">HISTORIAL</span>
<h2>Mi historial</h2>
<p class="panel-subtitle">Consultá tus pagos, actividades y asistencia registrada.</p>
</div>
</div>
<div class="account-history-grid">
<div>
<h3>💳 Pagos</h3>
<div id="historialPagos" class="account-list">
</div>
</div>
<div>
<h3>🎓 Actividades</h3>
<div id="historialActividades" class="account-list">
</div>
</div>
<div>
<h3>🥋 Asistencia</h3>
<div id="historialAsistencia" class="account-list">
</div>
</div>
</div>
</section>

<section class="account-panel">
<div class="account-panel-head">
<div>
<span class="panel-kicker">DOCUMENTOS</span>
<h2>Mis certificados</h2>
<p class="panel-subtitle">Certificados de participación y actividades realizadas.</p>
</div>
</div>
<div id="certificadosAlumno" class="account-cards">
</div>
</section>
</main>
<footer>© 2026 Academia VILAMIR</footer>
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script src="js/portal.js?v=20261115-unificado-v1"></script>
<script src="js/mobile.js?v=20261115-unificado-v1"></script>
</body>
</html>