<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Portal de consulta para padres y tutores de Academia VILAMIR. Consultá cuotas, vencimientos y asistencia de tus hijos.">
    <title>Portal del Tutor | Academia VILAMIR</title>
    <link rel="stylesheet" href="css/style.css?v=20261026-tutor-v1">
</head>
<body class="account-page tutor-page">
<header class="navbar">
    <a class="logo" href="publica.php">
        <img src="images/logo-vilamir.jpg" alt="Academia VILAMIR" class="logo-img">
    </a>
    <nav>
        <a href="publica.php">Web pública</a>
        <a href="login.html">Ingresar como usuario</a>
    </nav>
</header>

<main class="account-shell">
    <section class="account-welcome">
        <div>
            <span class="account-eyebrow">PORTAL DE PADRES Y TUTORES</span>
            <h1>Seguimiento de Cuotas y Asistencia</h1>
            <p>Consultá el estado financiero, próximos vencimientos y el presentismo a clase de tu hijo en Academia VILAMIR.</p>
        </div>
    </section>

    <!-- Buscador por Cédula -->
    <section class="account-panel tutor-search-panel">
        <div class="account-panel-head">
            <div>
                <span class="panel-kicker">CONSULTA RÁPIDA</span>
                <h2>Ingresá tu Cédula de Identidad</h2>
                <p class="panel-subtitle">Podés ingresar la cédula del padre/tutor o la del alumno (con o sin puntos ni guiones).</p>
            </div>
        </div>
        <form id="formConsultaTutor" class="tutor-search-form">
            <input type="text" id="ciTutor" placeholder="Ej: 4.567.890-1 o 45678901" required autocomplete="off">
            <button type="submit" class="account-btn" id="btnConsultarTutor">🔍 Consultar datos</button>
        </form>
        <p id="mensajeTutor" class="message-center" style="display:none;"></p>
    </section>

    <!-- Contenedor donde se dibuja la información del alumno/tutor -->
    <div id="contenedorDatosTutor" style="display:none;"></div>
</main>

<footer>© 2026 Academia VILAMIR · Portal de Seguimiento Familiar</footer>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('formConsultaTutor');
    const inputCi = document.getElementById('ciTutor');
    const btn = document.getElementById('btnConsultarTutor');
    const mensaje = document.getElementById('mensajeTutor');
    const contenedor = document.getElementById('contenedorDatosTutor');

    // Comprobar si vino la CI en la URL (?ci=...) para cargar automáticamente
    const urlParams = new URLSearchParams(window.location.search);
    const ciParam = urlParams.get('ci');
    if (ciParam) {
        inputCi.value = ciParam;
        consultar(ciParam);
    }

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        consultar(inputCi.value.trim());
    });

    async function consultar(ci) {
        if (!ci) return;
        btn.disabled = true;
        btn.textContent = 'Buscando…';
        mensaje.style.display = 'none';
        contenedor.style.display = 'none';
        contenedor.innerHTML = '';

        try {
            const res = await fetch(`api/tutor.php?ci=${encodeURIComponent(ci)}`);
            const data = await res.json();

            if (data.status === 'success' && data.datos.length > 0) {
                renderizarDatos(data.datos);
            } else {
                mensaje.style.display = 'block';
                mensaje.className = 'message-center err';
                mensaje.textContent = data.message || 'No se encontraron registros.';
            }
        } catch (err) {
            console.error(err);
            mensaje.style.display = 'block';
            mensaje.className = 'message-center err';
            mensaje.textContent = 'Ocurrió un error al conectar con el servidor.';
        } finally {
            btn.disabled = false;
            btn.textContent = '🔍 Consultar datos';
        }
    }

    function renderizarDatos(lista) {
        contenedor.innerHTML = '';
        contenedor.style.display = 'block';

        lista.forEach(item => {
            const al = item.alumno;
            const tut = item.tutor;
            const fin = item.finanzas;
            const asis = item.asistencia;
            const grupos = item.grupos;

            const wrap = document.createElement('article');
            wrap.className = 'tutor-student-card';

            // HTML de Cuotas
            let pagosHtml = '';
            if (fin.pagos.length === 0) {
                pagosHtml = '<p class="small muted">No hay registros de cuotas emitidas.</p>';
            } else {
                pagosHtml = fin.pagos.map(p => {
                    const est = p.EstadoCalculado;
                    const badgeClass = est === 'Pagado' ? 'success' : (est === 'Vencido' ? 'danger' : 'warning');
                    const linkComp = (est === 'Pagado' && p.Numero_comprobante)
                        ? `<a href="verificar_comprobante.php?codigo=${encodeURIComponent(p.Numero_comprobante)}" target="_blank" class="tutor-btn-comprobante">📄 Recibo oficial</a>`
                        : '';
                    const botonAvisoPago = (est !== 'Pagado')
                        ? `<a href="https://wa.me/59899123456?text=Hola%20Academia%20VILAMIR,%20adjunto%20comprobante%20de%20pago%20de%20la%20cuota%20de%20${encodeURIComponent(al.Nombre)}%20(${encodeURIComponent(p.Tipo)})" target="_blank" class="tutor-btn-whatsapp-pago">📲 Informar pago</a>`
                        : '';

                    return `
                        <div class="tutor-payment-row">
                            <div>
                                <strong>${p.Tipo}</strong>
                                <small>Vencimiento: ${p.Fecha_vencimiento ? p.Fecha_vencimiento.split('-').reverse().join('/') : '—'}</small>
                            </div>
                            <div class="tutor-payment-meta">
                                <span class="badge ${badgeClass}">${est}</span>
                                <b>$${Number(p.Importe).toLocaleString('es-UY', {minimumFractionDigits: 2})}</b>
                                ${linkComp}
                                ${botonAvisoPago}
                            </div>
                        </div>
                    `;
                }).join('');
            }

            // HTML de Asistencia
            let asistenciasHtml = '';
            if (asis.historial.length === 0) {
                asistenciasHtml = '<p class="small muted">No hay asistencias registradas en los últimos 60 días.</p>';
            } else {
                asistenciasHtml = asis.historial.map(a => {
                    const badgeClass = a.Estado === 'Presente' ? 'success' : (a.Estado === 'Ausente' ? 'danger' : 'warning');
                    return `
                        <div class="tutor-attendance-row">
                            <div>
                                <strong>${a.Fecha.split('-').reverse().join('/')} — ${a.Grupo || a.Disciplina}</strong>
                                ${a.Observacion ? `<small>${a.Observacion}</small>` : ''}
                            </div>
                            <span class="badge ${badgeClass}">${a.Estado}</span>
                        </div>
                    `;
                }).join('');
            }

            // HTML de Grupos
            let gruposHtml = grupos.map(g => `
                <div class="tutor-group-pill">
                    <strong>🥋 ${g.Disciplina} · ${g.Grupo}</strong>
                    <small>${g.Horarios.join(' | ') || 'Horario a confirmar'}</small>
                </div>
            `).join('');

            wrap.innerHTML = `
                <div class="tutor-card-header">
                    <div>
                        <span class="eyebrow">ALUMNO VILAMIR</span>
                        <h2>${al.Nombre}</h2>
                        <p class="small">Tutor a cargo: <strong>${tut.Nombre} (${tut.Parentesco})</strong> · Cobertura: <strong>${al.Cobertura_medica}</strong></p>
                    </div>
                    <div class="tutor-kpis">
                        <div class="tutor-kpi ${fin.cuotas_pendientes > 0 ? 'warning' : 'success'}">
                            <span>Estado de cuotas</span>
                            <strong>${fin.cuotas_pendientes > 0 ? `$${fin.total_pendiente.toLocaleString('es-UY', {minimumFractionDigits: 2})}` : 'Al día'}</strong>
                            <small>${fin.cuotas_pendientes > 0 ? `${fin.cuotas_pendientes} pendiente(s)` : 'Sin deudas'}</small>
                        </div>
                        <div class="tutor-kpi">
                            <span>Presentismo (60 días)</span>
                            <strong>${asis.porcentaje}%</strong>
                            <small>${asis.presentes} de ${asis.total_clases} clases</small>
                        </div>
                    </div>
                </div>

                <div class="tutor-groups-list">
                    ${gruposHtml}
                </div>

                <div class="account-layout account-layout-wide">
                    <!-- Columna Cuotas -->
                    <section class="account-panel">
                        <div class="account-panel-head">
                            <div>
                                <span class="panel-kicker">ESTADO FINANCIERO</span>
                                <h3>Cuotas y Vencimientos</h3>
                            </div>
                        </div>
                        <div class="tutor-payments-wrap">
                            ${pagosHtml}
                        </div>
                    </section>

                    <!-- Columna Asistencia -->
                    <section class="account-panel">
                        <div class="account-panel-head">
                            <div>
                                <span class="panel-kicker">CONTROL DE PRESENTISMO</span>
                                <h3>Últimas Clases (60 días)</h3>
                            </div>
                        </div>
                        <div class="tutor-attendance-wrap">
                            ${asistenciasHtml}
                        </div>
                    </section>
                </div>
            `;
            contenedor.appendChild(wrap);
        });
    }
});
</script>
</body>
</html>