# Academia VILAMIR V21 — Ajuste de centrado y colores del calendario

## Cambios
- Se centró el contenido del calendario y se estableció un ancho máximo para evitar que la interfaz quede pegada a un lado en pantallas grandes.
- Se reorganizó la barra de navegación semanal: período centrado, navegación a los lados y botón Hoy claramente visible.
- Se aplicó la paleta institucional negro, rojo y gris a botones, encabezados, filtros y tarjetas.
- Se mantuvo el desplazamiento horizontal de la grilla semanal en pantallas estrechas para no comprimir excesivamente los siete días.
- Se limitaron las reglas al módulo `calendario.php` mediante selectores específicos; no se modificó la base de datos ni la lógica JavaScript.

## Validación
- La modificación es CSS y no cambia consultas, permisos ni datos.
- Se recomienda comprobar en el navegador las vistas de escritorio y móvil, la navegación entre semanas y los filtros.
- No se afirma una prueba visual automatizada en navegador real.
