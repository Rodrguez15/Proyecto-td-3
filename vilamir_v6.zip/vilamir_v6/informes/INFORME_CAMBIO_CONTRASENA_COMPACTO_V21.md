# Academia VILAMIR V21 — Cambio de contraseña compacto

- Se redujo el ancho máximo de la tarjeta de cambio de contraseña.
- Se compactaron el título, texto explicativo, campos, separaciones y botón.
- La contraseña actual queda en una fila y los campos de nueva contraseña/confirmación comparten dos columnas en pantallas amplias.
- En pantallas pequeñas, los campos se apilan para mantener la legibilidad.
- No se modificó la lógica PHP ni el envío del formulario de cambio de contraseña.

Validación realizada: revisar sintaxis PHP y estructura ZIP. No se realizó prueba visual en navegador ni prueba de integración con MySQL/XAMPP.
