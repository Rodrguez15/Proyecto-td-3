# Academia VILAMIR V21 — Mejoras administrativas

## Cambio aplicado

- El dashboard administrativo ya no convierte automáticamente los errores de consulta de conteos en un cero que parece real.
- Cuando no se puede consultar una tabla, la API devuelve `null` para ese indicador y una advertencia genérica sin exponer detalles internos de MySQL.
- La interfaz muestra `—` para indicadores no disponibles y presenta una advertencia accesible cuando uno o más indicadores no pudieron cargarse.
- La API informa si falló el resumen financiero, sin mostrar al usuario mensajes internos de excepción.

## Compatibilidad

- No se cambió el esquema SQL ni se agregaron migraciones.
- No se eliminaron módulos ni operaciones CRUD existentes.
- No se agregaron módulos de exámenes ni niveles.

## Verificación realizada

- Se revisará la sintaxis PHP y JavaScript y la integridad del ZIP final.
- Esta entrega no se ha ejecutado contra la base MySQL/MariaDB del entorno local; se debe probar con una copia de la base real en XAMPP.

## Prueba manual recomendada

1. Abrir el panel administrador con la base de datos normal y comprobar que los contadores sigan mostrándose.
2. En una copia de prueba únicamente, simular una tabla o consulta no disponible y verificar que el indicador muestre `—` y aparezca el aviso.
3. Restaurar la base de prueba y confirmar que desaparezca la advertencia.
4. Comprobar que los módulos Alumnos, Profesores, Grupos y Pagos sigan abriendo normalmente.
