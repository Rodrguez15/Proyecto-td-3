# Academia VILAMIR V21 — Galería de eventos: editar y borrar

## Cambios
- Se agregaron controles **Editar** y **Borrar** visibles únicamente para administradores.
- La edición permite cambiar título, descripción y evento asociado, y opcionalmente reemplazar la imagen.
- La eliminación solicita confirmación, elimina el registro y luego intenta borrar el archivo de imagen asociado dentro de `uploads/gallery`.
- Se añadieron validaciones de título, longitud de descripción, existencia del seminario, tamaño máximo de 5 MB y contenido real JPEG/PNG/WebP.
- Las operaciones de agregar/editar/borrar se realizan con `fetch` y muestran el resultado sin dejar al usuario en una respuesta JSON suelta.
- La galería se dibuja mediante `textContent`/creación de nodos para evitar interpretar títulos o descripciones como HTML.
- Se conservan las columnas existentes de `GALERIA_EVENTO`; no se necesita migración SQL.

## Verificaciones realizadas
- `php -l` en `galeria.php` y `api/avanzadas.php`: correcto.
- `php -l` en todos los archivos PHP del paquete: correcto.
- `node --check` en todos los archivos JavaScript existentes: correcto.
- `node --check` del JavaScript embebido de `galeria.php` después de sustituir las expresiones PHP: correcto.
- Integridad del ZIP: comprobada.

## Limitaciones
No se pudo realizar una prueba de integración con MySQL/MariaDB, sesiones reales ni navegador en este entorno. Antes de usarlo en producción, probar en XAMPP con una copia de seguridad y una imagen de prueba.

## Prueba manual recomendada
1. Entrar como administrador y abrir `galeria.php`.
2. Editar título, descripción y evento sin cambiar la imagen.
3. Editar y reemplazar la imagen con un JPEG/PNG/WebP válido.
4. Intentar subir un archivo que no sea imagen o una imagen mayor a 5 MB; debe rechazarse.
5. Borrar una imagen de prueba y comprobar que desaparezca la tarjeta y el archivo asociado.
6. Entrar como alumno/profesor y confirmar que no se muestran botones administrativos.
