# Informe de revisión general — Academia VILAMIR V21

## Alcance

Revisión estática del paquete V21, ampliada con correcciones de asistencia y mejoras del espacio del profesor. Se preservan las funciones existentes, se reorganiza la documentación SQL y no se agregan módulos de exámenes.

## Comprobaciones ejecutadas

- 50 archivos PHP: comprobación de sintaxis con `php -l` sin errores.
- 17 archivos JavaScript: comprobación de sintaxis con `node --check` sin errores.
- Archivo ZIP original: prueba de integridad sin errores.
- Esquema SQL consolidado: la tabla `PAGO` contiene los campos que consumen los reportes financieros (`Fecha_vencimiento`, `Importe`, `Estado`, `Metodo_pago`, `Numero_comprobante`, `Anulado_en`, `Anulado_por` y `Motivo_anulacion`).
- Migraciones activas: no se encontraron sentencias `DROP TABLE`, `TRUNCATE TABLE` ni `DELETE FROM` en `sql/migraciones/` ni en el esquema de instalación.
- Organización SQL: el script V17 potencialmente destructivo se movió a `sql/legacy_no_ejecutar/` y se añadió una advertencia visible al propio archivo y a la documentación.
- Asistencia: la consulta de marcas se limita al horario elegido, además de grupo, alumno y fecha; se evita cruzar registros de dos clases del mismo grupo en un mismo día. Se valida que el horario pertenezca al grupo y al día indicados.
- Espacio del profesor: se añade la lista de alumnos activos y los horarios por cada grupo asignado; desde la tarjeta del grupo se puede saltar al control de asistencia. La API solo devuelve listas de grupos asignados al profesor.
- SQL de asistencia: se agregó `migraciones/migracion_asistencia_v21.sql` y se alineó el índice del esquema de instalación nueva con el índice utilizado por la aplicación.
- Se aclaró en los README que `profesor.php` y `profesores.php` son páginas distintas por función y no deben eliminarse por similitud de nombre: el portal del profesor y la administración de profesores no son lo mismo.

## Hallazgos y decisiones

1. **Riesgo de ejecutar migraciones antiguas por error — corregido en la organización.** El script V17 contiene eliminaciones de tablas heredadas. Ya no está en la carpeta de migraciones activas; quedó archivado, con nombre de advertencia y documentación que indica que no debe ejecutarse como parte de V21.
2. **Actualización de base existente — requiere diagnóstico del esquema.** `sql/mma_systems.sql` es para instalaciones nuevas, no para importarlo encima de la base de la academia. Las migraciones V18/V19/V20 deben aplicarse solo si faltan sus cambios y después de probar una copia.
3. **Compatibilidad financiera — validación estática completada.** Las columnas usadas por comprobantes e informes están presentes en el esquema consolidado. La sintaxis correcta no demuestra que una base local existente tenga esas mismas columnas.
4. **Páginas de profesor — no se fusionan por nombre.** `profesor.php` y `profesores.php` cumplen funciones distintas; fusionarlas podría romper la navegación o los permisos.
5. **Pruebas de integración pendientes.** Este entorno no dispone del controlador `pdo_mysql`, por lo que no se pudo conectar a MySQL/MariaDB, importar el esquema ni probar pagos reales, claves foráneas, filtros, permisos o impresión en un navegador.

## Lista de pruebas manuales en XAMPP

1. Respaldar la carpeta del proyecto y exportar la base desde phpMyAdmin.
2. Probar sobre una copia, nunca sobre la única base de trabajo.
3. Iniciar sesión como administrador, profesor y alumno; confirmar que cada rol solo acceda a sus funciones.
4. Crear un pago pendiente y uno pagado; verificar que el código del comprobante se guarde y que el enlace de verificación muestre el registro correcto.
5. Anular un pago y confirmar que permanezca en el historial, que figure como anulado y que no se contabilice como ingreso cobrado.
6. Exportar el reporte financiero por mes y año; comparar sus totales con los registros filtrados en la base.
7. Abrir e imprimir un comprobante desde el alumno propietario y confirmar que otro alumno no pueda acceder al comprobante por ID.
8. En una copia de prueba, comprobar primero si están aplicadas las columnas V19; después evaluar `migraciones/migracion_asistencia_v21.sql` solo si corresponde.
9. En el portal del profesor, comprobar un grupo con un horario y otro grupo con dos horarios en el mismo día; marcar asistencia en ambos y verificar que cada lista conserva sus estados por separado.
10. Confirmar que el profesor solo vea alumnos de sus grupos asignados y que no pueda registrar asistencia para un grupo ajeno.
11. Probar inscripciones, seminarios, perfil y cambio de contraseña para detectar regresiones generales.

## Recomendación

No importar el esquema consolidado sobre una base existente ni ejecutar todas las migraciones automáticamente. Para una revisión completa de datos reales hace falta el volcado SQL actual (sin contraseñas ni datos personales innecesarios) o una copia de prueba de la base, además de la versión de XAMPP/MariaDB. La versión del ZIP se considera revisada estáticamente, no certificada por pruebas de integración.
