# Academia VILAMIR V21 — Fondo radial rojo y gris

## Cambio realizado
- Se aplicó al fondo general el formato solicitado:
  - `radial-gradient(circle at top right, rgba(179, 0, 0, 0.35), transparent 35%)`
  - `radial-gradient(circle at bottom left, rgba(120, 0, 0, 0.25), transparent 30%)`
  - `#666666` como color base.
- Se aplicó también a `.public-page` para mantener el mismo fondo en la web pública.
- Se añadió `background-attachment: fixed` para que el fondo permanezca visualmente estable al desplazarse.
- No se modificaron funciones PHP, JavaScript ni la base de datos.


**Ajuste adicional:** la web pública ya no reemplaza el fondo del `body` con un color sólido; usa el fondo radial solicitado.
