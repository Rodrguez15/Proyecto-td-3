# Academia VILAMIR V21 — Gestión de alumnos y cuenta

## Alcance

Se trabajó sobre la última versión V21 de asistencia y espacio del profesor. Se conservaron los módulos existentes y no se agregaron módulos de exámenes ni niveles.

## Cambios

1. **Gestión de alumnos:** alta mediante formulario validado, listado tabular, búsqueda por nombre/apellido/correo/teléfono, edición de nombre/apellido/correo y exportación CSV de los resultados filtrados.
2. **Privacidad:** el listado y CSV excluyen cédula, dirección, cobertura médica, peso, categoría, QR y cualquier contraseña/hash. La salida se crea con APIs DOM seguras y la exportación escapa celdas de hoja de cálculo.
3. **Consistencia de datos:** la edición administrativa de alumno y correo se realiza dentro de una transacción; las verificaciones de correo duplicado son insensibles a mayúsculas/minúsculas.
4. **Mi cuenta:** se conserva el formulario de perfil y cambio de contraseña. La comprobación de correo duplicado en el perfil también es insensible a mayúsculas/minúsculas y la actualización queda limitada al usuario autenticado.
5. **Organización:** se documentó el alcance de la gestión de alumnos en `sql/migraciones/README_GESTION_ALUMNOS_V21.md` y se enlazó desde `sql/README.md`.
6. **Base de datos:** no se agrega una migración SQL porque los campos e índices necesarios ya están en el esquema V21. Evitar cambios innecesarios en una base con datos reales es intencional.

## Verificaciones

- Se revisó la sintaxis de PHP y JavaScript tras los cambios.
- Se verificó la integridad del ZIP generado.
- No fue posible probar consultas reales contra MySQL/MariaDB en este entorno, por lo que se requiere validación funcional en XAMPP.

## Pruebas manuales recomendadas

1. Ingresar como administrador y buscar por nombre, apellido, correo y teléfono.
2. Exportar resultados filtrados y abrir el CSV en Excel/LibreOffice.
3. Editar nombre, apellido y correo; verificar que el cambio se conserve tras recargar.
4. Intentar usar un correo que ya pertenezca a otra cuenta; la API debe rechazarlo.
5. Crear un alumno con correo válido y luego comprobar que puede iniciar sesión según el flujo actual de contraseñas temporales.
6. Como alumno, editar teléfono/dirección/cobertura desde Mi cuenta y comprobar que no se puedan cambiar los datos administrativos restringidos.
7. Cambiar contraseña con clave actual incorrecta, confirmación distinta y clave válida.
8. Confirmar que profesores y alumnos no puedan abrir la gestión administrativa de alumnos.

## Base de datos

No ejecutar `sql/mma_systems.sql` sobre una base existente. Hacer respaldo de archivos y exportación SQL antes de probar en XAMPP.

### Revisión adicional antes de entregar

- Se bloqueó también en el endpoint cualquier intento directo de eliminación física (`accion=eliminar`), aunque se envíe una petición manual. La interfaz no ofrece ese botón, pero la protección del servidor evita saltarse la interfaz.
- Se reforzó la validación del servidor para nombre, apellido y longitud máxima del correo al registrar o editar, sin depender únicamente de las validaciones del navegador.
- Estas modificaciones no requieren migración SQL.
