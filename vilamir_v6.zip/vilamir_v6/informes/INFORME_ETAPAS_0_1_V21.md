# Academia VILAMIR V21 — Etapas 0 y 1

## Objetivo

Establecer una base de trabajo identificable y auditar el proyecto antes de aplicar nuevas modificaciones funcionales. Esta entrega parte de `Academia_VILAMIR_V21_Diseno_Adaptable_Celulares.zip`.

## Etapa 0 — Base segura

- Se conserva el proyecto y sus módulos existentes.
- No se reemplazó ni se recreó ninguna base de datos.
- No se ejecutaron migraciones SQL.
- No se agregaron módulos de exámenes ni niveles.
- Se recomienda guardar una copia de la carpeta `vilamir_v3` y exportar la base desde phpMyAdmin antes de instalar esta o cualquier otra versión.

## Etapa 1 — Auditoría estática

| Comprobación | Resultado |
|---|---|
| Archivos PHP revisados con `php -l` | 50, sin errores de sintaxis |
| Archivos JavaScript revisados con `node --check` | 17, sin errores de sintaxis |
| Integridad del ZIP de entrada | Correcta |
| Balance de llaves y paréntesis de `css/style.css` | Cantidades equilibradas |
| Archivos SQL localizados | 7 |
| Sentencias destructivas en `sql/migraciones/` y `sql/mma_systems.sql` | No se encontraron `DROP TABLE`, `TRUNCATE TABLE` ni `DELETE FROM` |
| Migración histórica destructiva | Permanece aislada en `sql/legacy_no_ejecutar/` con nombre de advertencia |
| Prueba de conexión MySQL/MariaDB | No disponible en este entorno: falta `pdo_mysql` |

## Alcance y limitaciones

Estas comprobaciones son estáticas. No demuestran por sí solas que los flujos funcionen en el navegador ni que las consultas sean compatibles con la base real. No se afirma que se hayan completado pruebas integrales de roles, formularios, asistencia, pagos, seminarios o responsive en XAMPP.

## Pruebas funcionales siguientes en XAMPP

1. Iniciar sesión con cuentas de administrador, profesor y alumno.
2. Comprobar que cada rol solo vea las acciones que le corresponden.
3. Revisar inscripción y baja de una disciplina sin perder el historial relacionado.
4. Registrar asistencia en grupos con uno y varios horarios por día.
5. Abrir el perfil del alumno y cambiar la contraseña.
6. Registrar un pago, abrir su comprobante y revisar los informes.
7. Probar inscripción a seminarios y los cupos.
8. Repetir navegación y formularios en una pantalla móvil.

## Reglas para las siguientes etapas

- Trabajar sobre una copia de seguridad.
- Revisar primero el esquema real antes de proponer migraciones.
- No ejecutar todas las migraciones de forma automática.
- Mantener el código existente salvo que haya una razón concreta y comprobable para cambiarlo.
- No agregar exámenes ni niveles.
