# Ajuste visual del inicio — Academia VILAMIR V21

## Cambios
- Se modernizó el inicio autenticado (`index.php`) para alinearlo con el panel administrativo y la identidad negro, rojo y gris.
- Se diseñó una tarjeta de bienvenida con jerarquía visual más clara, borde rojo, fondo oscuro y tamaños compactos.
- Los accesos rápidos ahora usan una cuadrícula adaptable de tarjetas, con icono, descripción, acción y estados hover/focus.
- Los accesos son enlaces HTML reales, mejorando navegación por teclado y accesibilidad respecto de las tarjetas que dependían de `onclick`.
- Se conserva la lógica PHP por rol (administrador, profesor y alumno), destinos y sesión. No se agregan módulos ni se modifica la base de datos.
- Se mantiene el fondo radial global existente.

## Verificación
- Revisar sintaxis PHP con `php -l`.
- Revisar integridad del archivo ZIP.
- No se ejecutó una prueba funcional en navegador ni conexión real con MySQL en este entorno.
