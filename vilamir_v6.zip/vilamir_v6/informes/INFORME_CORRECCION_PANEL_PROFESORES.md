# Informe de corrección — Panel de profesores

## Objetivo
Hacer visible dentro del módulo **Profesores** del panel administrador el apartado **Clases y grupos por profesor**, y mostrar los errores de consulta de forma comprensible.

## Cambios realizados
- El panel se inserta directamente en el contenido que construye `js/admin.js` al seleccionar el módulo `profesores`. Ya no depende de una sección fija oculta en `admin.php`.
- Se actualizó la versión de caché de `admin.php` para `css/style.css` y `js/admin.js` para forzar que el navegador solicite los archivos corregidos.
- La lista de profesores se consulta directamente a la API, sin depender de la variable global que utiliza la tabla CRUD.
- Las consultas de grupos/horarios y disciplinas son independientes en `api/admin.php`. Si falta una tabla o falla una consulta, el panel puede seguir mostrando los profesores y explica qué asignaciones no se pudieron consultar.
- Se mantienen las operaciones CRUD y los módulos existentes. No se agregan módulos de exámenes ni niveles.

## Pruebas realizadas
- `php -l` en todos los archivos PHP del proyecto.
- `node --check` en todos los archivos JavaScript del proyecto.
- Verificación estática de que el panel se construye al seleccionar `profesores` y de que la API devuelve una respuesta parcial con aviso ante fallos de asignaciones.
- Verificación de integridad del archivo ZIP.

## Pruebas pendientes
No fue posible ejecutar pruebas reales de navegador ni conectar contra la base MySQL/MariaDB del usuario desde este entorno. En XAMPP, iniciar sesión como administrador y abrir **Profesores**; confirmar que aparece el panel, elegir un profesor y comprobar grupos, disciplinas y horarios. Si faltan tablas de asignación, el panel debe mostrar un aviso con las tablas que deben revisarse.
