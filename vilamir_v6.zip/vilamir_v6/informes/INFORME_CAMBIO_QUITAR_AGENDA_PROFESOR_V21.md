# Academia VILAMIR V21 — Retirar Agenda del espacio del profesor

## Cambio realizado
- Se quitó del `profesor.php` el panel **AGENDA / Mis próximas clases**.
- Se eliminó de `js/profesor.js` el renderizado que dependía de ese panel, para evitar errores por referencias a un elemento retirado.
- Se conservan los grupos asignados, las listas de alumnos, las disciplinas, las notificaciones, el calendario semanal, el cronograma y el control de asistencia.
- No se modificaron la base de datos, los permisos ni las API. No se agregaron módulos de exámenes ni niveles.

## Verificación
Se realizaron comprobaciones estáticas de sintaxis PHP y JavaScript y se revisó la integridad del ZIP. No se ejecutó una prueba funcional en navegador con MySQL/MariaDB en esta sesión.
