# Academia VILAMIR V21 — Etapa 4: diseño adaptable y organización de informes

## Objetivo
Reforzar la experiencia en móviles y tabletas, mantener accesible la navegación y centralizar los informes técnicos en `informes/`, sin alterar las funciones académicas ni el esquema de base de datos.

## Cambios realizados
- Se conservaron los comportamientos accesibles ya presentes en `js/mobile.js`: botón con `aria-expanded`/`aria-controls`, cierre con Escape, cierre al seleccionar enlaces, al tocar fuera y al volver a escritorio.
- Se añadieron reglas CSS responsive complementarias para impedir que grids, filas, controles y medios excedan el ancho disponible.
- Se reforzó el desplazamiento horizontal dentro de los contenedores de tablas y calendarios en pantallas pequeñas, evitando depender del desplazamiento de toda la página.
- Se movieron todos los archivos `INFORME*.md` a la carpeta raíz `informes/` y se actualizaron las referencias Markdown encontradas. Los archivos ejecutables y sus rutas no se movieron.
- No se modificó PHP, JavaScript de negocio, permisos, consultas ni el esquema SQL. No requiere migración de base de datos.
- No se añadieron módulos de exámenes ni niveles.

## Verificación estática
- Se verificó la sintaxis PHP con `php -l` para todos los archivos PHP.
- Se verificó la sintaxis JavaScript con `node --check` para los archivos JavaScript.
- Se verificó el balance de llaves CSS y la integridad del ZIP.
- Se comprobó que los informes `INFORME*.md` estén centralizados en `informes/`.

## Pruebas manuales pendientes en XAMPP
1. Probar el menú móvil a 360, 390, 600, 768 y 900 píxeles.
2. Abrir/cerrar el menú con ratón, teclado, Escape y toque fuera; comprobar que los enlaces sigan navegando correctamente.
3. Revisar panel administrativo, portal de alumno, espacio docente, calendario, reportes y web pública.
4. Confirmar que las tablas se desplacen dentro de su contenedor y no ensanchen toda la página.
5. Probar formularios, filtros, botones y enlaces en escritorio y móvil.

## Limitaciones
La verificación estática no sustituye las pruebas visuales en un navegador real. No fue posible probar MySQL/MariaDB ni sesiones reales en este entorno. La versión debe probarse primero en una copia del proyecto y de la base de datos en XAMPP.

## Instalación segura
1. Conservar la copia de seguridad previa a esta etapa.
2. Extraer el ZIP en una carpeta de prueba.
3. No importar el SQL inicial ni ejecutar migraciones para esta etapa.
4. Tras completar las pruebas manuales, trasladar a producción los archivos aprobados.
