# Academia VILAMIR V21 — Etapa 1: Auditoría y estabilidad general

**Fecha:** 23/10/2026  
**ZIP base auditado:** `vilamir_v3(2).zip` (archivo original conservado sin modificar)  
**Alcance:** sintaxis PHP/JavaScript, referencias a archivos, autenticación y sesiones, configuración, consultas y esquema SQL estático, áreas administrativas, profesor y alumno.  
**Tipo de revisión:** estática. No equivale a una prueba funcional en navegador ni a una validación de consultas contra la base de datos real.

## 1. Resultado ejecutivo

- Se revisó la estructura del proyecto extraído del ZIP más reciente.
- Los 51 archivos PHP pasaron `php -l`.
- Los 17 archivos JavaScript pasaron `node --check`.
- No se encontraron destinos ausentes en las instrucciones estáticas `include`/`require`.
- Se detectaron referencias a `login.html`, pero ese archivo no está incluido en el proyecto. `login.php` procesa solicitudes POST y no presenta por sí solo una pantalla de acceso.
- `logout.php` inicia una sesión PHP sin cargar la configuración compartida que establece el nombre `VILAMIRSESSID`; por eso puede cerrar una sesión distinta de la sesión autenticada de la aplicación.
- El proyecto tiene credenciales predeterminadas en `config/conexion.php`; son un riesgo si se publica sin configurar variables de entorno.
- No se declara el sistema funcionalmente validado: el entorno de revisión no tiene el controlador `pdo_mysql`, por lo que no fue posible probar consultas con MySQL/MariaDB ni los flujos con sesiones reales.

**Conclusión:** la sintaxis pasa las comprobaciones estáticas, pero hay un problema prioritario en el flujo de inicio/cierre de sesión que debe corregirse y probarse antes de considerar cerrada la estabilidad general. Esta etapa documenta los hallazgos y no introduce correcciones de código mezcladas con la auditoría.

## 2. Hallazgos por prioridad

### E1-01 — Referencias a una pantalla de inicio de sesión inexistente
**Prioridad: Alta (P1). Estado: confirmado por inspección del ZIP.**

`config/autenticacion.php`, `config/seguridad.php` y `logout.php` redirigen a `login.html`. La web pública también enlaza a `login.html` y `js/registrar.js` redirige allí. El archivo no existe en la entrega inspeccionada. `login.php` contiene el procesamiento POST de credenciales y respuestas JSON, no una pantalla GET equivalente.

**Impacto:** un visitante que necesite iniciar sesión o un usuario redirigido tras salir/inactividad puede terminar en una ruta inexistente; el acceso de los usuarios puede quedar interrumpido.

**Corrección recomendada:** acordar una única ruta real para la pantalla de acceso. Actualizar los enlaces y redirecciones de forma consistente, preservando el endpoint POST y el comportamiento JSON de `login.php`. Verificar registro, recuperación de contraseña y salida.

### E1-02 — Cierre de sesión no usa la configuración de sesión de la aplicación
**Prioridad: Alta (P1). Estado: confirmado por inspección del código; no se pudo probar en navegador.**

`config/sesion.php` establece el nombre `VILAMIRSESSID` antes de iniciar la sesión. `logout.php` llama directamente a `session_start()` y no incluye `config/sesion.php`, por lo que PHP puede abrir la sesión predeterminada (`PHPSESSID`) y destruir esa sesión, en lugar de la sesión autenticada de VILAMIR.

**Impacto:** el botón “Cerrar sesión” podría no invalidar la sesión correcta, especialmente si el navegador conserva la cookie `VILAMIRSESSID`.

**Corrección recomendada:** hacer que `logout.php` use la misma configuración central de sesión; borrar la cookie correcta con sus parámetros y destruir la sesión autenticada. Probar después el acceso a páginas privadas usando el botón Atrás y solicitudes directas.

### E1-03 — Credenciales de base de datos predeterminadas
**Prioridad: Alta si se publica; media en entorno local aislado. Estado: confirmado.**

`config/conexion.php` utilizaba valores alternativos de desarrollo cuando faltaban `DB_USER` y `DB_PASS`; esa configuración histórica fue retirada en la revisión del 16/11/2026.

**Impacto:** una instalación desplegada por error sin variables de entorno puede intentar conectarse con credenciales conocidas o de ejemplo.

**Corrección recomendada:** en producción, exigir las variables de entorno y fallar de forma segura si faltan; usar un usuario de base de datos con privilegios mínimos. No cambiar las credenciales de la instalación local sin coordinarlo con la configuración real de XAMPP.

### E1-04 — Validación funcional de consultas SQL pendiente
**Prioridad: Alta para dar la etapa por cerrada. Estado: no comprobable en este entorno.**

Se inspeccionó el esquema de `sql/mma_systems.sql` y se realizaron comprobaciones estáticas, pero no se pudo ejecutar el sistema contra MySQL/MariaDB. El entorno PHP dispone de PDO, pero no del controlador `pdo_mysql`.

**Impacto:** la sintaxis PHP correcta no garantiza que todas las consultas usen columnas existentes en la base real, que las migraciones coincidan con el esquema instalado o que las transacciones se comporten correctamente.

**Prueba requerida:** exportar una copia de la base de datos real, restaurarla en una base de pruebas y ejecutar los flujos listados en la sección 4. No importar el SQL de instalación sobre una base existente.

### E1-05 — Protección CSRF basada en origen, sin tokens observados
**Prioridad: Media/alta según exposición. Estado: observación estática.**

`config/sesion.php` rechaza algunas solicitudes cross-site y `config/seguridad.php` comprueba `Origin` cuando se envía. En la inspección de los archivos no se encontró una implementación general de tokens CSRF para formularios y operaciones sensibles.

**Impacto:** los controles actuales ayudan, pero no sustituyen completamente tokens CSRF validados en servidor.

**Acción recomendada:** planificar una revisión de seguridad específica después de cerrar los fallos de estabilidad. No se incorporaron tokens en esta etapa para evitar cambios transversales sin pruebas de regresión.

## 3. Comprobaciones ejecutadas

| Comprobación | Resultado |
|---|---|
| Integridad del ZIP original y de la entrega final | Correcta: ambos pasaron `unzip -t`; el original se conserva por separado |
| Sintaxis PHP | 51/51 archivos sin errores reportados por `php -l` |
| Sintaxis JavaScript | 17/17 archivos sin errores reportados por `node --check` |
| Destinos estáticos de `include`/`require` | 0 destinos ausentes |
| Referencias `href`/`src` literales | Una referencia dinámica de imagen de galería quedó fuera de la comprobación literal; requiere validación con datos reales |
| Consultas contra MySQL/MariaDB | No ejecutadas: falta el controlador `pdo_mysql` en el entorno |
| Login/logout en navegador | No ejecutado |
| Permisos con cuentas reales de los tres roles | No ejecutado |
| Formularios, pagos, asistencia e inscripciones | No ejecutados funcionalmente |

## 4. Plan de pruebas funcionales para XAMPP

Antes de reemplazar archivos en la instalación activa, crear una copia de `C:\xampp\htdocs\vilamir_v3` y exportar la base desde phpMyAdmin. Usar una carpeta y una base de pruebas separadas.

1. **Acceso:** abrir el enlace de ingreso desde la web pública; verificar que exista una pantalla real, que un usuario válido pueda entrar y que las credenciales incorrectas muestren un error controlado.
2. **Cierre de sesión:** entrar como administrador, profesor y alumno; cerrar sesión; intentar volver a `admin.php`, `profesor.php` y `portal.php` con la misma sesión y comprobar que se solicite acceso nuevamente.
3. **Caducidad:** probar la redirección tras caducar la sesión y confirmar que el destino de login existe.
4. **Permisos:** con cada rol, intentar abrir páginas y llamar directamente a APIs de otros roles; confirmar que se deniegue el acceso no autorizado.
5. **Administrador:** alta/edición de alumnos y profesores, grupos, disciplinas, horarios, seminarios, pagos, comprobantes, asistencia, notificaciones, reportes y exportaciones.
6. **Profesor:** consultar solo grupos asignados; registrar y volver a consultar asistencia por fecha y horario; comprobar que no se dupliquen marcas.
7. **Alumno:** entrar a su cuenta; consultar clases; inscribirse y cancelar según las reglas existentes; consultar pagos, comprobantes y notificaciones.
8. **Base de datos:** verificar columnas y tablas contra el esquema real; probar duplicados, valores inválidos, transacciones y restricciones de integridad con datos de prueba.
9. **Errores:** comprobar que los errores internos se registren en el log del servidor y no expongan contraseñas, consultas SQL ni rutas internas al navegador.

## 5. Alcance y límites

- No se modificó el código funcional en esta etapa: el objetivo es aislar y documentar fallos antes de mezclar correcciones.
- No se modificó ni migró la base de datos.
- No se eliminaron funciones existentes.
- No se agregaron módulos de exámenes ni niveles.
- Los hallazgos marcados como confirmados se basan en la estructura y el código de este ZIP; los resultados de navegador, permisos y base de datos quedan pendientes de ejecución en XAMPP.

## 6. Criterio para cerrar la etapa

La Etapa 1 se podrá cerrar cuando se corrijan y prueben E1-01 y E1-02, se valide la configuración de conexión para el entorno real y se completen las pruebas funcionales prioritarias de los tres roles contra una copia de la base de datos. Esta entrega documenta la auditoría estática; no debe interpretarse como certificación de funcionamiento integral.


## Correcciones posteriores a la auditoría

- **Flujo de inicio de sesión:** verificado en el ZIP que `login.html` sí existe en la raíz del proyecto y carga `js/login.js`, que envía las credenciales a `login.php`. Por tanto, el hallazgo anterior de que faltaba `login.html` era incorrecto y queda rectificado. Se mantienen las redirecciones a ese archivo válido.
- **Cierre de sesión:** `logout.php` ahora incluye `config/sesion.php`, usa la sesión `VILAMIRSESSID` y elimina la cookie con los mismos atributos configurados para la sesión antes de redirigir a `login.html`.
- **Contraseña:** `js/login.js` ya no recorta espacios al inicio o al final de la contraseña; solo normaliza el correo.
- **Validación MySQL:** se agregó `tools/diagnostico_mysql_etapa1.php`, un diagnóstico de solo lectura para ejecutar desde la terminal de XAMPP. Comprueba la conexión, tablas/columnas principales y consultas SQL críticas de inicio de sesión. Se bloquea cuando se intenta ejecutar desde el navegador.

### Limitación de verificación
En el entorno donde se preparó este ZIP no hay ningún controlador PDO instalado (`PDO drivers =>` vacío), ni cliente/servidor MySQL disponible. Por eso no sería correcto afirmar que las consultas se probaron contra un servidor real aquí. Para completar esa parte, iniciar MySQL en XAMPP, verificar `config/conexion.php` y ejecutar desde la carpeta del proyecto: `php tools/diagnostico_mysql_etapa1.php`. Este diagnóstico no reemplaza las pruebas manuales de inscripción/cancelación, pagos, recibos ni permisos con cuentas de prueba.
