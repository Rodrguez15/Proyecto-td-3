# Academia VILAMIR V21 — Mejoras del portal del alumno

## Alcance
Se hicieron mejoras acotadas al portal del alumno, tomando como base la versión anterior del proyecto. No se modificó el esquema de la base de datos ni se agregaron módulos de exámenes o niveles.

## Cambios
- El portal comprueba la respuesta de la API de resumen antes de intentar cargar información complementaria.
- Si el resumen no puede cargarse después de los reintentos, los paneles dejan de quedar indefinidamente vacíos/cargando y muestran un estado de error entendible, junto con un botón para reintentar.
- Si falla únicamente la consulta de horarios, el resto de la cuenta continúa cargando y se informa que los horarios no están disponibles.
- La tarjeta de resumen cuenta grupos únicos en vez de contar cada horario como si fuera un grupo diferente.
- Los contadores de disciplinas y seminarios distinguen las inscripciones activas.
- En la lista de seminarios del portal, el botón de cancelar se muestra solamente para inscripciones activas; las canceladas conservan su estado visible sin ofrecer una cancelación repetida.
- Se corrigió el manejo del temporizador de avisos para que un aviso anterior no oculte prematuramente uno más reciente.
- Se actualizaron las versiones de las referencias a CSS y JavaScript en `portal.php` para reducir problemas de caché del navegador.

## Archivos modificados
- `portal.php`
- `js/portal.js`

## Verificación
Se realizaron comprobaciones estáticas de sintaxis PHP y JavaScript, revisión de referencias del portal y verificación de integridad del ZIP. No se ejecutaron transacciones reales contra MySQL/MariaDB porque este entorno de construcción no dispone del controlador `pdo_mysql` ni de la base de datos del usuario.

## Pruebas manuales pendientes en XAMPP
1. Iniciar Apache y MySQL, entrar como alumno y abrir `portal.php`.
2. Confirmar que perfil, pagos, notificaciones, disciplinas, seminarios y QR carguen.
3. Confirmar que los grupos con varios horarios no se cuenten como varios grupos.
4. Confirmar que una inscripción cancelada no muestre el botón de cancelar.
5. Detener MySQL temporalmente en una copia de prueba y comprobar que el portal muestre un error recuperable; volver a iniciar MySQL y pulsar reintentar.
6. Probar actualización de perfil y cambio de contraseña con una cuenta de prueba.

## Recomendación de instalación
Descomprimir en una carpeta separada de `htdocs`, configurar la base de datos de prueba y conservar la copia de seguridad previa. No importar el SQL inicial sobre una base existente.
