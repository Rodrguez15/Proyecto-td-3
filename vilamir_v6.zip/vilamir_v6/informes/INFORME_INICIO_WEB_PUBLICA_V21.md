# Mejora de inicio: web pública de Academia VILAMIR V21

## Objetivo
Al abrir la raíz del sitio, mostrar la página pública (`publica.php`) cuando no existe una sesión autenticada. Si el usuario ya inició sesión, se conserva el panel interno (`index.php`) según su rol.

## Cambios
- `index.php`: inicia la sesión con la configuración central y redirige a `publica.php` si no hay `usuario_id`; para sesiones válidas conserva la autenticación y el panel existente.
- `index.html`: se convierte en una redirección de respaldo hacia `publica.php` para alojamientos que prioricen `index.html`.
- No se modifica la base de datos ni se agregan módulos.

## Pruebas realizadas
- Comprobación de sintaxis PHP de `index.php`.
- Revisión del destino de redirección en ambos archivos de entrada.
- Integridad del ZIP verificada.

## Pruebas manuales pendientes
1. Abrir la raíz del sitio sin sesión: debe aparecer la web pública.
2. Pulsar «Ingresar»: debe abrir el inicio de sesión.
3. Iniciar sesión con administrador, profesor y alumno: deben conservar su acceso al panel correspondiente.
4. Cerrar sesión y volver a la raíz: debe mostrarse la web pública.

Las pruebas con sesiones reales deben completarse en XAMPP.
