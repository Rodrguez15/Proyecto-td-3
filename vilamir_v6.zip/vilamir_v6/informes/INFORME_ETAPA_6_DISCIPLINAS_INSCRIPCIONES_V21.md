# Academia VILAMIR V21 — Informe de etapa 6

## Alcance

Revisión de disciplinas e inscripciones de alumnos, conservando el modelo existente y sin incorporar módulos de exámenes ni niveles.

## Cambios aplicados

- La lista de disciplinas del alumno marca como inscrito únicamente cuando existe una inscripción con estado `Activa`.
- La baja de una disciplina cambia el estado de la inscripción a `Cancelada` en lugar de borrar físicamente el registro, preservando el historial.
- Al volver a inscribirse, una inscripción cancelada existente se reactiva y se actualiza su fecha, respetando la clave única alumno-disciplina del esquema actual.
- Las operaciones de inscripción en los endpoints de disciplinas usan transacción y bloquean la fila existente durante la comprobación para reducir condiciones de carrera.
- Se valida que la disciplina exista antes de inscribir al alumno.
- La inscripción a un grupo vuelve a activar la inscripción de disciplina si ya existía cancelada.
- Las rutas administrativas de eliminación de disciplinas bloquean el borrado cuando existen grupos asociados o inscripciones históricas.
- La gestión administrativa de inscripciones de disciplinas cancela el registro y conserva su historial.
- La API de listado de disciplinas del administrador devuelve tanto `ID_Disciplina` como el alias heredado `ID_Clase`, evitando romper pantallas que usan el identificador de disciplina.
- Se rechazan costos negativos al crear o editar disciplinas.

## Base de datos

No se agregó ninguna migración SQL. Los cambios utilizan la columna `Estado` y la restricción única alumno-disciplina que ya existen en el esquema actual. No importar `sql/mma_systems.sql` ni ejecutar migraciones para instalar esta etapa.

## Verificación estática

- 50 archivos PHP pasaron `php -l`.
- 17 archivos JavaScript pasaron `node --check`.
- Se revisó que las rutas modificadas no borren físicamente inscripciones de disciplina.
- Se debe probar la integración con MySQL/MariaDB y navegador en el XAMPP de destino; esta revisión no reemplaza las pruebas de ejecución.

## Pruebas manuales recomendadas

1. Entrar como alumno y revisar que solo una inscripción `Activa` se muestre como inscrita.
2. Inscribirse en una disciplina y verificar que aparezca en “Mis clases”.
3. Darse de baja y comprobar que el registro permanece en la base de datos con estado `Cancelada`.
4. Volver a inscribirse y confirmar que se reactive el registro existente sin generar duplicados.
5. Inscribirse a un grupo y comprobar que la disciplina relacionada quede activa.
6. Intentar eliminar desde administración una disciplina con grupos o historial; debe rechazarse con un mensaje claro.
7. Intentar guardar una disciplina con costo negativo; debe rechazarse.
8. Verificar que alumno, profesor y administrador sigan viendo sus listados correspondientes.

## Instalación segura

1. Hacer copia del proyecto y exportar la base de datos desde phpMyAdmin.
2. Extraer el ZIP en una carpeta de prueba, no encima del proyecto original.
3. Probar las operaciones anteriores con cuentas de prueba.
4. No importar el SQL de instalación ni ejecutar migraciones para esta etapa.
