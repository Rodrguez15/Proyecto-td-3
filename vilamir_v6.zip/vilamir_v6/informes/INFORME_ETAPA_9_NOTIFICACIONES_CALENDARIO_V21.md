# Academia VILAMIR V21 — Informe de etapa 9

## Alcance

Mejoras centradas en notificaciones automáticas y calendario, manteniendo las tablas existentes y sin añadir módulos de exámenes o niveles.

## Cambios realizados

- Se unificó el formato de los avisos automáticos de pagos entre la tarea programada (`cron_notificaciones.php`) y la acción administrativa (`api/notificaciones.php`). Cuando ambos procesos revisan el mismo pago, la comprobación por alumno y mensaje evita generar dos avisos iguales.
- Se unificó el texto de recordatorios de seminarios/eventos entre el cron y la generación manual, incluyendo el identificador del evento para diferenciar actividades con el mismo nombre y fecha.
- Se conservó la ventana de recordatorio del cron de hasta siete días para pagos y eventos; el panel administrativo conserva su ventana de pagos de tres días.
- Se añadieron regiones `aria-live` al calendario semanal y a las próximas actividades para que las actualizaciones dinámicas puedan anunciarse a tecnologías de asistencia.
- No se modificó el esquema SQL ni se añadió una migración.

## Verificaciones

- Comprobación de sintaxis PHP con `php -l` en todos los archivos PHP del proyecto.
- Comprobación de sintaxis JavaScript con `node --check` en todos los archivos JS.
- Integridad del ZIP con `unzip -t`.
- Revisión estática de cambios.

## Límites

No fue posible ejecutar pruebas de integración contra MySQL/MariaDB ni pruebas de navegador en esta sesión. Por ello, el funcionamiento final debe validarse en la instalación XAMPP del usuario.

## Pruebas manuales recomendadas

1. Hacer copia de seguridad del proyecto y exportar la base de datos.
2. Ejecutar el cron desde PHP CLI y después usar el botón administrativo de generar avisos; verificar que no se repitan los mismos avisos de pago/evento.
3. Verificar pagos con vencimiento dentro de 7 días, dentro de 3 días y vencidos.
4. Confirmar que el calendario muestre clases según el rol y los eventos próximos.
5. Cambiar de semana, usar filtros y probar navegación por teclado y lector de pantalla si está disponible.

No importar `sql/mma_systems.sql` ni ejecutar migraciones para esta etapa.
