# Academia VILAMIR V21 — Mejora visual del calendario

## Objetivo
Mejorar la presentación del calendario semanal, sus filtros y las tarjetas de próximas actividades sin cambiar el contrato de la API, el modelo de datos ni los permisos actuales.

## Cambios
- Se reorganizó visualmente la barra de navegación semanal, con título central y botones de navegación más claros.
- Se mejoraron los filtros con campos más legibles, estados de foco y mejor distribución en pantallas pequeñas.
- Se rediseñaron las cabeceras de los días y el resaltado del día actual usando la identidad negro/rojo/gris de VILAMIR.
- Se actualizaron las tarjetas de clases y eventos para diferenciar sus tipos, resaltar la hora y mejorar la lectura de los detalles.
- Se renovaron las tarjetas de próximas actividades.
- Se añadieron ajustes responsive y respeto a la preferencia de movimiento reducido.
- Los estilos se agregaron como una sección nueva al final de `css/style.css` para reducir el riesgo de afectar otros módulos.

## Compatibilidad
- No se modificó la base de datos ni se requiere migración SQL.
- No se modificaron `calendario.php`, `js/calendario.js` ni los endpoints de API.
- Se conserva la navegación semanal, el botón Hoy, los filtros y la lista de próximas actividades.
- No se añadieron módulos de exámenes ni niveles.

## Verificaciones
- Revisar balance de llaves CSS.
- Revisar integridad del ZIP.
- La comprobación visual final debe hacerse en navegador, porque el entorno de construcción no reproduce la sesión ni los datos reales de MySQL.

## Prueba recomendada
1. Abrir `calendario.php` con una sesión válida.
2. Verificar anterior/siguiente semana y botón Hoy.
3. Probar los tres filtros y Limpiar filtros.
4. Comprobar que las clases, seminarios y actividades se distingan visualmente.
5. Probar anchos de 360 px, 390 px, 768 px y escritorio. En móvil, la semana conserva desplazamiento horizontal para que los siete días sigan siendo legibles.
