# Academia VILAMIR V21 — Mejoras funcionales del portal del alumno

## Cambios aplicados

- Se corrigió el cálculo de la fecha actual usada para mostrar pagos vencidos: ahora se utiliza la fecha local del navegador y no la fecha UTC, que podía cambiar el día según la zona horaria.
- Se añadió `rel="noopener noreferrer"` a los enlaces que abren comprobantes y certificados en otra pestaña.
- Se evita enviar dos solicitudes de cancelación de la misma inscripción simultáneamente y se valida el identificador antes de enviarlo.
- Se conservan el perfil, cambio de contraseña, QR, pagos, historial, asistencia, disciplinas, promociones, seminarios y certificados existentes.
- No se modificó el esquema SQL ni se agregaron módulos de exámenes o niveles.

## Verificación realizada

- Comprobación sintáctica de JavaScript con `node --check`.
- Comprobación sintáctica PHP del proyecto completo con `php -l`.
- Comprobación de integridad del ZIP resultante.

## Pruebas funcionales pendientes

No se pudo conectar a la base MySQL/MariaDB ni ejecutar el portal con sesiones reales en esta sesión. En XAMPP, probar: perfil y correo duplicado; cambio de contraseña; pago vencido/al día; cancelación de seminario; notificaciones; QR; certificados; y vista móvil. Probar primero en una copia del proyecto y de la base de datos.
