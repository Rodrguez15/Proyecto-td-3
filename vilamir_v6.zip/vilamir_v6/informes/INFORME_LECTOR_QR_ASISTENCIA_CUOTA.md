# Informe de actualización — Lector QR, asistencia y cuota mensual

## Objetivo
Incorporar en el módulo Check-in una lectura de los carnets QR de alumnos para agilizar el pase de lista y consultar el estado de la cuota del mes vigente.

## Funcionamiento
1. El administrador o profesor entra a `checkin.php`.
2. Selecciona grupo, fecha y horario.
3. Puede activar la cámara del dispositivo para leer el QR del carnet o utilizar un lector QR USB/teclado y el campo manual.
4. El navegador extrae el código de la URL de perfil QR o acepta el código plano.
5. El servidor identifica al alumno, verifica su inscripción activa al grupo seleccionado y registra `Presente` en `ASISTENCIA`.
6. Si ya existe asistencia para alumno + grupo + fecha + horario, la operación informa el estado existente y no duplica ni sobrescribe el registro.
7. Se consulta y muestra el estado de la cuota mensual vigente: `Pagada`, `Pendiente`, `Vencida` o `Sin cuota generada`.

## Permisos
- Administrador: puede seleccionar cualquiera de los grupos registrados.
- Profesor: sólo puede consultar y tomar asistencia en grupos asignados mediante `INSCRIPCION_GRUPO_PROFESOR` con estado `Activa`.
- Alumno: no tiene acceso al lector.

## Reglas de seguridad
- La API verifica sesión, rol, grupo, horario, matrícula activa y CSRF en el servidor.
- La cuota pendiente/vencida es informativa; no bloquea el registro de asistencia.
- El índice único existente de asistencia evita duplicados por alumno, grupo, fecha y horario.
- La cámara queda autorizada sólo para el mismo origen (`camera=(self)`). Micrófono y geolocalización siguen bloqueados.
- No se agregaron contraseñas, datos personales ni información financiera al QR. El QR sigue conteniendo un código aleatorio de alumno.

## Base de datos
No requiere scripts SQL, migraciones ni cambios del esquema. Reutiliza `ALUMNO.Codigo_qr`, `INSCRIPCION_GRUPO_ALUMNO`, `INSCRIPCION_GRUPO_PROFESOR`, `HORARIO`, `ASISTENCIA`, `PAGO` y `ACTIVIDAD_SISTEMA` existentes.

## Archivos modificados
- `checkin.php`: interfaz adaptada al pase de lista y lectura por cámara.
- `js/checkin.js`: lectura QR, validación de selección, interacción con API y presentación de resultados.
- `api/checkin.php`: consulta grupos/horarios, autorización de grupo, verificación de cuota mensual y registro de asistencia no duplicada.
- `config/seguridad.php`: permiso de cámara limitado al mismo origen.
- `LEEME_QR_AUTOMATICOS.txt`: instrucciones y pruebas recomendadas.

## Dependencia de cámara
Se utiliza `html5-qrcode` versión 2.3.8 desde cdnjs. Se requiere permiso del usuario y contexto seguro: HTTPS en hosting o `localhost` en desarrollo. Si la biblioteca/CDN o cámara no están disponibles, el lector mantiene el campo manual y el soporte para lector USB/teclado.

## Estado de validación
Se realizó revisión estática de los cambios y se deben ejecutar pruebas funcionales en XAMPP y posteriormente en InfinityFree: lectura real de cámara, grupos por rol, asistencia nueva, relectura duplicada, alumno no inscripto y exactitud de la cuota mensual mostrada. No se afirma que esas pruebas físicas o contra la base de datos del usuario ya hayan sido realizadas.
