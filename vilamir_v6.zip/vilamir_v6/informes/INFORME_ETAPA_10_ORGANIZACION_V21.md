# Informe de etapa 10 — Organización de archivos y base de datos

## Objetivo

Mejorar la mantenibilidad del proyecto Academia VILAMIR V21 sin arriesgar rutas de la aplicación ni alterar datos existentes.

## Cambios de esta etapa

- Se creó `docs/` para guías técnicas de mantenimiento.
- Se agregó un índice de documentación, mapa del proyecto y guía segura de base de datos.
- Se documentaron las diferencias entre instalación nueva, actualización incremental, datos de demostración y scripts históricos.
- Se reforzó la advertencia de no ejecutar el script histórico de limpieza como una migración normal.
- Se conservó la estructura actual de páginas, API, configuración, JavaScript, CSS y SQL para evitar romper rutas relativas, formularios, `fetch`, tareas programadas o enlaces de documentación.
- Se mantiene la distinción entre `profesor.php` (espacio del profesor) y `profesores.php` (administración).
- No se modificó el esquema SQL ni se agregó una migración nueva.
- No se agregaron módulos de exámenes ni niveles.

## Verificaciones

Las comprobaciones deben registrarse con el entorno real disponible. En esta entrega se revisará sintaxis PHP/JavaScript, integridad del ZIP y consistencia básica de rutas/documentación. Estas comprobaciones estáticas no sustituyen pruebas con MySQL/MariaDB y navegador.

## Pruebas manuales pendientes en XAMPP

1. Abrir el proyecto de prueba e iniciar sesión con los roles existentes.
2. Verificar menú, páginas, endpoints y archivos estáticos tras extraer el ZIP.
3. Probar las operaciones clave de alumnos, inscripciones, asistencia, pagos, seminarios, calendario e informes.
4. Confirmar que la base existente sigue intacta; no importar el esquema consolidado sobre ella.
5. Confirmar que los archivos de documentación se abren y que las rutas de las páginas principales funcionan.

## Instalación segura

Respaldar carpeta y base de datos, extraer en una carpeta de prueba y comparar el comportamiento antes de sustituir el proyecto de trabajo. No ejecutar migraciones SQL en esta etapa.
