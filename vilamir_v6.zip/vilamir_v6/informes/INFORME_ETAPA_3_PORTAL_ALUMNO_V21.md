# Academia VILAMIR V21 — Etapa 3: Portal del alumno

## Alcance

Mejoras funcionales y de acceso al portal del alumno, sobre la entrega de la Etapa 2. Se conservan las funciones existentes y no se agregan módulos de exámenes ni niveles. No se modifica el esquema de base de datos ni se requiere migración SQL.

## Cambios aplicados

1. **Fechas de vencimiento:** el cálculo de la fecha actual del portal usa la fecha local del navegador (`YYYY-MM-DD`) en vez de convertirla a UTC. Evita clasificar un pago como vencido/al día por un cambio de día cerca de la medianoche.
2. **Enlaces seguros:** los enlaces de comprobantes y certificados que abren otra pestaña incluyen `rel="noopener noreferrer"`.
3. **Cancelaciones repetidas:** se valida el tipo y el identificador antes de enviar una cancelación y se bloquean solicitudes simultáneas de la misma inscripción desde la interfaz. El servidor sigue validando que la inscripción pertenezca al alumno autenticado.
4. **Acceso por rol:** `portal.php` dirige a cada rol a su espacio correspondiente y solo permite que un usuario con rol Alumno entre al portal. `api/portal.php` rechaza solicitudes de otros roles con HTTP 403.
5. **Funciones conservadas:** perfil, cambio de contraseña, clases, asistencia, pagos, comprobantes, seminarios, notificaciones, promociones, QR e historial permanecen en el proyecto.

## Verificaciones realizadas

- Se ejecutó `php -l` para todos los archivos PHP del proyecto.
- Se ejecutó `node --check` para todos los archivos JavaScript del proyecto.
- Se revisó que `js/portal.js` ya no use `toISOString()` para decidir vencimientos y que los enlaces a comprobantes/certificados tengan `noopener noreferrer`.
- Se comprobó la integridad del ZIP con `unzip -t`.

## Limitaciones

No se pudo ejecutar una prueba real contra MySQL/MariaDB ni una prueba de navegador con sesiones reales en este entorno porque PHP no dispone del controlador `pdo_mysql`. Por ello, la entrega no se declara validada funcionalmente contra una base real.

## Pruebas manuales recomendadas en XAMPP

1. Entrar como alumno y verificar carga de Mi cuenta, perfil, clases, asistencia, pagos y notificaciones.
2. Editar el perfil, recargar la página y confirmar que los cambios persisten.
3. Probar correo duplicado y fecha de nacimiento futura; ambas solicitudes deben rechazarse.
4. Cambiar la contraseña con clave actual incorrecta, confirmación distinta y datos válidos.
5. Probar pagos con vencimiento anterior, actual y futuro, especialmente cerca de medianoche.
6. Abrir comprobantes y certificados en otra pestaña.
7. Cancelar una inscripción y volver a pulsar rápidamente; no debe enviarse una segunda solicitud concurrente ni cancelarse la inscripción de otra persona.
8. Intentar abrir `portal.php` y `api/portal.php` con cuentas de administrador y profesor; deben redirigirse o recibir acceso denegado.
9. Verificar que el alumno pueda seguir inscribiéndose/cancelando conforme a las reglas actuales y que se conserve el historial.

## Instalación segura

Respaldar la carpeta del proyecto y exportar la base desde phpMyAdmin. Instalar y probar el ZIP en una carpeta de prueba. No importar `sql/mma_systems.sql` sobre una base existente ni ejecutar migraciones para esta etapa.
