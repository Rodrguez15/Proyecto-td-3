# Informe de cambios — Academia VILAMIR V21 (pagos, comprobantes e informes)

## Cambios incluidos

- `reportes.php`: añade el detalle de pagos del período seleccionado, con alumno, concepto, fecha, vencimiento, importe, estado, número de comprobante y acceso al comprobante.
- El CSV del reporte incluye indicadores generales, saldos pendientes/vencidos actuales y el detalle de pagos del período seleccionado. Los estados pendientes vencidos se muestran como `Vencido` sin modificar el registro original.
- Los meses del informe se muestran en español y los indicadores distinguen el saldo actual del importe cobrado en el período.
- `exportar.php`: el historial financiero exportado incluye vencimiento, número de comprobante y datos de anulación, además de los campos existentes.
- `verificar_comprobante.php`: admite números de comprobante con IDs de seis o más dígitos y permite verificar comprobantes antiguos cuyo número todavía no está guardado, siempre que coincidan ID y fecha.
- Se centraliza el estilo de la tabla financiera en `css/style.css`.
- Se reorganiza `sql/` en `sql/migraciones/` y `sql/datos_demo/`, se actualizan las rutas documentadas y se añade un índice SQL con advertencias de actualización.
- `sql/mma_systems.sql` deja de ejecutar eliminaciones automáticas de tablas heredadas al importarse. Sigue siendo un esquema para instalaciones nuevas, no una herramienta de actualización.

## Compatibilidad y datos

- No se añadió ninguna migración SQL nueva: las funciones usan columnas ya incluidas en el esquema V21.
- No se borran pagos ni se modifica automáticamente el historial financiero.
- Los pagos anulados deben conservarse y no borrarse físicamente.
- No se añadieron módulos de exámenes.

## Verificaciones realizadas

- Sintaxis PHP: todos los archivos `.php` pasan `php -l`.
- JavaScript: todos los archivos `js/*.js` pasan `node --check`.
- Revisión estática de rutas SQL y de la estructura del archivo ZIP.

## Pruebas pendientes en XAMPP

En este entorno no hay controlador PDO disponible ni servidor MySQL/MariaDB; por eso no fue posible ejecutar consultas reales ni comprobar la interfaz con datos. Antes de sustituir el proyecto activo, probar en una copia con la base `mma_systems`:

1. Filtrar reportes por mes y año.
2. Exportar el CSV y abrirlo en Excel/LibreOffice.
3. Abrir e imprimir un comprobante de un alumno y verificar el código.
4. Comprobar el detalle de pagos pagados, pendientes, vencidos y anulados.
5. Confirmar que el historial completo exportado contiene los campos de anulación.
