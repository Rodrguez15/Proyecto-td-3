# Informe de seguridad — Academia VILAMIR V21, Etapa 11

## Alcance
Revisión estática de la entrega de la etapa 10, con cambios conservadores que no requieren modificar el esquema de base de datos. Se mantuvieron las rutas y los módulos existentes. No se añadieron exámenes ni niveles.

## Cambios aplicados
1. **Errores internos de API:** `api/admin.php` y `api/avanzadas.php` ya no devuelven mensajes de excepción/SQL al navegador. Los detalles continúan en el log del servidor.
2. **Errores de base de datos en seminarios:** `api/seminarios.php` devuelve un mensaje genérico si la excepción procede de PDO, evitando filtrar información SQL; los errores de validación de la aplicación mantienen su mensaje.
3. **Carpeta de galería:** `uploads/gallery/.htaccess` desactiva el listado de directorios y deniega acceso a nombres de archivo típicos de scripts; se eliminan asociaciones de manejadores PHP en esa carpeta.
4. **Índice de la carpeta de galería:** se agregó `uploads/gallery/index.html` para evitar una vista de directorio si la configuración del servidor no respeta `Options -Indexes`.

## Controles existentes observados
- `config/sesion.php` configura cookies HttpOnly y SameSite, usa HTTPS para la marca Secure cuando detecta HTTPS y aplica caducidad por inactividad.
- `config/seguridad.php` define cabeceras HTTP y rechaza algunas solicitudes cross-site.
- `login.php` utiliza `password_verify`, `password_hash` para el alta (en `registrar.php`), regeneración del identificador de sesión tras autenticar y limitación básica de intentos por sesión.
- Varias API validan rol y utilizan consultas preparadas.

## Riesgos y acciones necesarias antes de publicar
- **Credenciales de base de datos:** `config/conexion.php` conserva valores predeterminados para facilitar la instalación local. No publicar con esos valores. Configurar `DB_HOST`, `DB_NAME`, `DB_USER` y `DB_PASS` en el entorno del servidor y usar una cuenta MySQL con privilegios mínimos. En producción, eliminar los valores predeterminados y fallar de forma segura si faltan variables.
- **Reglas Apache:** confirmar que el alojamiento utiliza Apache y permite `.htaccess` (`AllowOverride` adecuado). Si se usa Nginx u otro servidor, configurar reglas equivalentes en el servidor.
- **HTTPS:** publicar únicamente con certificado TLS válido; comprobar que `HTTPS` se detecte correctamente detrás de proxy si lo hubiera.
- **Prueba de permisos:** probar con cuentas reales de los tres roles que no se pueda acceder a registros ajenos manipulando IDs o llamando directamente a las API.
- **CSRF:** probar formularios y `fetch` desde el navegador. La comprobación de origen ayuda, pero no sustituye tokens CSRF en operaciones sensibles.
- **Subidas:** verificar en XAMPP/producción que un archivo con extensión de script no se ejecute, y que las imágenes válidas sigan cargándose.
- **Errores y registros:** configurar `display_errors=Off` en producción y mantener `log_errors=On`; no almacenar logs dentro de una carpeta pública.
- **Dependencias/servidor:** mantener PHP, MySQL/MariaDB y Apache actualizados; eliminar archivos de prueba, copias y datos de demostración antes de publicar.

## Pruebas estáticas ejecutadas
- 50 archivos PHP: `php -l` sin errores.
- 17 archivos JavaScript: `node --check` sin errores.
- Archivo ZIP: integridad comprobada.
- No se ejecutaron pruebas de integración con MySQL/MariaDB ni pruebas reales de navegador en este entorno. Por tanto, la aplicación no debe considerarse lista para producción hasta completar la lista manual.

## Lista de prueba manual en XAMPP
1. Hacer copia de la carpeta del proyecto y exportar la base de datos.
2. Iniciar sesión y cerrar sesión para cada rol.
3. Como alumno, intentar acceder a datos de otro alumno modificando el ID en URL o solicitudes.
4. Como profesor, intentar modificar datos o grupos que no tiene asignados.
5. Como alumno y profesor, intentar invocar endpoints administrativos directamente; deben responder 401/403.
6. Subir una imagen JPEG/PNG/WebP válida y confirmar que aparece en la galería.
7. Intentar subir un PHP renombrado como imagen y una imagen falsa; ambas deben rechazarse.
8. Intentar abrir un archivo `.php` de prueba dentro de `uploads/gallery`; el servidor debe denegar la ejecución/acceso.
9. Confirmar que los errores del servidor no muestran consultas SQL, rutas ni credenciales.
10. Revisar pagos, comprobantes, asistencia, inscripciones, seminarios, promociones y calendario después de las pruebas.

## Base de datos
No se cambió el esquema SQL y no se requiere migración. No importar `sql/mma_systems.sql` sobre una base existente como parte de esta etapa.

## Estado
Cambios estáticos aplicados y sintaxis comprobada. La validación de seguridad en ejecución, permisos reales del servidor y conexión a MySQL queda pendiente en el entorno local/hosting.


## Addendum de revisión 16/11/2026

Las observaciones de esta sección describen una versión anterior. En la copia corregida actual se retiraron las credenciales predeterminadas, se exige configuración privada de DB, se añadió validación CSRF para peticiones de escritura también en flujos anónimos, login y logout, y se bloqueó el borrado de cuentas USUARIO vinculadas a ALUMNO. Las pruebas funcionales siguen pendientes; consultar `../docs/MATRIZ_DE_PRUEBAS.md`.
