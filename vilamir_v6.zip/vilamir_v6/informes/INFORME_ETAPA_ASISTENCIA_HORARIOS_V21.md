# Academia VILAMIR V21 — Etapa: asistencia y horarios

## Alcance

Se trabajó sobre la entrega completa de la Etapa 5 (portal del alumno mejorado), preservando los módulos y rutas existentes. No se agregaron módulos de exámenes ni niveles.

## Cambios

### Asistencia del profesor

- Los alumnos que aún no tienen registro se muestran con el estado **Seleccionar estado**, no preseleccionados como «Presente».
- El guardado del lado del navegador exige marcar a cada alumno antes de enviar el lote; el servidor también valida los estados recibidos.
- El resumen de marcados, presentes y porcentaje se actualiza al cambiar los estados, antes de guardar.
- Si no hay alumnos activos, se informa y se oculta el botón de guardado para evitar envíos vacíos.
- La API rechaza métodos HTTP distintos de GET y POST.
- Se conserva la validación del servidor por profesor, grupo, día, horario y lista completa de alumnos activos, junto con el guardado transaccional existente.

### Administración de horarios

- Validación estricta del formato de hora y confirmación de que el horario a editar exista.
- Se impiden franjas que se superponen con otro horario del mismo grupo en el mismo día.
- Cuando la tabla de asignaciones docentes está disponible, se comprueban conflictos de horario de un mismo profesor entre grupos distintos.
- Los errores de conflicto se devuelven con mensajes claros para el administrador.

## Verificaciones

- Se ejecutó `php -l` sobre los archivos PHP del proyecto.
- Se ejecutó `node --check` sobre los archivos JavaScript.
- Se comprobó la integridad del ZIP generado con `unzip -t`.
- Se revisaron estáticamente las rutas de asistencia y administración de horarios.

## Pruebas pendientes en XAMPP

Este entorno no dispone de conexión a la base MySQL real de la academia, por lo que no se afirma que se hayan ejecutado pruebas de integración. En una copia de la base, verificar:

1. Cargar asistencia con registros ya existentes y con alumnos sin marcar.
2. Intentar guardar sin marcar todos los alumnos (debe bloquearse sin escribir cambios).
3. Guardar presente, ausente y justificado; recargar y confirmar que cada estado persista.
4. Crear dos horarios del mismo grupo que se superpongan (el segundo debe rechazarse); comprobar que horarios consecutivos sí se acepten.
5. Asignar un mismo profesor a dos grupos y probar que no se puedan programar franjas superpuestas.
6. Confirmar que el calendario y los portales alumno/profesor sigan mostrando los horarios correctos.

## Instalación segura

1. Descomprimir el ZIP en una carpeta nueva dentro de `C:\xampp\htdocs\`.
2. Configurar la conexión a una copia de la base de datos existente.
3. No importar de nuevo `sql/mma_systems.sql` sobre una base con datos ni ejecutar migraciones sin revisar el esquema.
4. Mantener la copia de seguridad previa hasta terminar las pruebas.
