# Informe — Consulta de clases y grupos por profesor

## Objetivo
Permitir que el administrador consulte las disciplinas vinculadas, los grupos asignados y los horarios de cada profesor desde el módulo **Profesores** del panel administrativo.

## Cambios
- Se agregó el endpoint de consulta `profesores_asignaciones` a `api/admin.php`, protegido por la autorización administrativa ya existente.
- Se consultan las asignaciones de `INSCRIPCION_GRUPO_PROFESOR`, los grupos, disciplinas y horarios, además de las disciplinas relacionadas mediante `PROFESOR_DISCIPLINA`.
- Se añadió al módulo Profesores un selector y una vista de resumen con grupos, disciplinas, horarios y estado de asignación.
- El contenido que viene de la base se escapa antes de insertarse en la interfaz.
- Se añadieron estilos adaptables a pantallas pequeñas.

## Base de datos
No se agregaron tablas ni se modificó el esquema. La consulta utiliza las relaciones existentes del archivo `sql/mma_systems.sql`.

## Verificación y límites
Se debe validar en una instalación de XAMPP conectada a MySQL/MariaDB que los nombres de tablas y estados coincidan con la base real, y comprobar el módulo con profesores con y sin grupos asignados. La verificación estática no reemplaza una prueba funcional con base de datos.
