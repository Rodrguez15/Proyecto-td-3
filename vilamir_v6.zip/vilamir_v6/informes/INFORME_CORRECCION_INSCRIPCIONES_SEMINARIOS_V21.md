# Corrección de inscripciones a seminarios — Academia VILAMIR V21

## Cambios realizados

1. `seminarios.php`: el área de mensajes `mensajeSeminario` ahora aparece también a los alumnos y profesores que consultan seminarios. Antes estaba dentro del bloque exclusivo del administrador, por lo que las respuestas de inscripción, cancelación y lista de espera no se veían para alumnos.
2. `api/portal.php`: se incluye `config/cupos.php`, donde está definida la promoción automática de la lista de espera de seminarios cuando se cancela una inscripción y queda un lugar libre.
3. `sql/migraciones/migracion_inscripciones_seminarios_v21.sql`: crea `LISTA_ESPERA_SEMINARIO` si no existe, tabla utilizada por el listado y las acciones de espera.
4. `sql/migraciones/README_INSCRIPCIONES_SEMINARIOS_V21.md`: instrucciones de aplicación y prueba.

## Cómo comprobarlo

- Entrar con una cuenta de alumno.
- Abrir «Seminarios y eventos» y elegir un seminario futuro con cupo disponible.
- Pulsar «Inscribirme». Debe aparecer un mensaje de confirmación y la tarjeta debe indicar «Ya estás inscripto».
- Si se cancela la inscripción, debe aparecer el mensaje correspondiente; si hay personas esperando, el sistema intentará promover a la primera.
- Si el cupo está completo, debe poder ingresarse a la lista de espera.

## Verificación realizada

Se comprobaron sintácticamente los archivos PHP y JavaScript del paquete y la integridad del ZIP. No se ejecutó una prueba real contra MySQL/XAMPP; esa comprobación requiere la base de datos instalada y una sesión real de alumno.
