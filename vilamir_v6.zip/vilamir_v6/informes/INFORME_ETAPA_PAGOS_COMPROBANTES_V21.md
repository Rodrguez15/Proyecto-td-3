# Academia VILAMIR V21 — Mejoras de pagos y comprobantes

## Cambios de esta entrega
- La API rechaza conceptos vacíos o mayores a 80 caracteres y métodos de pago mayores a 60 caracteres. El importe debe ser estrictamente mayor que cero tanto al crear como al editar.
- La anulación exige un motivo no vacío y de hasta 255 caracteres; se conserva el usuario, la fecha y el motivo. La actualización de estado comprueba que el pago no haya sido anulado por otra solicitud simultánea.
- La interfaz pide un motivo obligatorio y permite cancelar la operación si el administrador cierra el cuadro de diálogo.
- Los pagos anulados se muestran como solo consulta y ya no ofrecen el botón de edición. Su comprobante sigue disponible para consulta histórica.
- El filtro de vencidos usa la fecha local del navegador y valida que la fecha Desde no sea posterior a Hasta.
- El formulario impide importes no positivos, evita doble envío mientras guarda y presenta un mensaje claro si la conexión o la respuesta del servidor falla.
- La página autenticada del comprobante incluye directivas para evitar que el navegador o un proxy conserve datos financieros en caché.
- Se mantienen el historial financiero, los códigos de comprobante, la verificación pública limitada, los informes y las exportaciones existentes. No se agrega una migración SQL.

## Verificaciones estáticas
- Ejecutar `php -l` en todos los archivos PHP del proyecto.
- Ejecutar `node --check` en todos los archivos JavaScript.
- Comprobar la integridad del ZIP.

## Pruebas manuales pendientes en XAMPP
1. Registrar un pago con importe positivo y abrir/imprimir el comprobante.
2. Intentar guardar importe cero o negativo y confirmar que se rechaza.
3. Anular un pago con motivo; probar motivo vacío y más de 255 caracteres.
4. Confirmar que un pago anulado ya no se puede editar y que sigue visible en historial.
5. Filtrar vencidos cerca de medianoche local y probar un rango de fechas invertido.
6. Abrir comprobantes con una sesión de administrador y de alumno propietario; confirmar que un alumno no puede abrir el comprobante de otro.
7. Exportar CSV y revisar estados, importes, tildes y códigos.

## Instalación segura
Probar primero en una carpeta independiente, con copia de la base de datos. No importar `sql/mma_systems.sql` ni ejecutar migraciones para esta entrega. El entorno de desarrollo no dispone de controlador PDO MySQL, por lo que no se pudieron realizar pruebas de integración contra la base real.
