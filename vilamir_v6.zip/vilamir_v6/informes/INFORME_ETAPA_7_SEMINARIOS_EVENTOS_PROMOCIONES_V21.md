# Academia VILAMIR V21 — Informe de etapa 7

## Alcance
Revisión y endurecimiento de seminarios/eventos, inscripciones y administración de promociones. Se conserva el modelo existente y no se agregan módulos de exámenes ni niveles.

## Cambios realizados

### Seminarios y eventos
- La API valida fechas de calendario reales, importes no negativos, cupos enteros no negativos y formato de hora.
- Al editar, verifica que el evento exista y evita reducir el cupo por debajo de las inscripciones activas.
- El endpoint de eliminación ya no borra un evento que tenga inscripciones activas o personas en lista de espera. Devuelve un conflicto claro para evitar que el borrado en cascada destruya registros relacionados.
- Los mensajes de validación se devuelven al cliente para facilitar la corrección de los datos.
- Se cambió la edición administrativa del navegador para usar atributos `data-*` escapados en lugar de interpolar nombres y descripciones directamente dentro de manejadores JavaScript inline, reduciendo riesgo de ruptura de interfaz/inyección.

### Promociones
- El descuento debe ser numérico y estar entre 0 y 100 %.
- Las operaciones de edición y desactivación verifican que la promoción exista.
- La acción administrativa de eliminar ahora desactiva la promoción (`Activa=0`) en vez de borrarla físicamente, conservando el registro histórico. Las consultas de alumno y web pública ya filtran por vigencia y estado activo.

## Base de datos
No se agregó migración ni se cambió el esquema. La versión actual no tiene una relación explícita entre promociones y uno o varios seminarios; esta etapa mejora el manejo de las promociones generales existentes sin inventar asociaciones que la base de datos no representa todavía.

## Comprobaciones realizadas
- Se ejecutó `php -l` sobre todos los archivos PHP incluidos en el proyecto.
- Se ejecutó `node --check` sobre los archivos JavaScript.
- Se verificó la integridad del ZIP final.
- Se inspeccionaron las consultas SQL y las rutas de inscripción, lista de espera y promociones.

Estas comprobaciones son estáticas. No se pudo ejecutar una prueba integrada contra MySQL/MariaDB ni pruebas de navegador con sesiones reales en este entorno.

## Pruebas manuales recomendadas en XAMPP
1. Respaldar la carpeta `vilamir_v3` y exportar la base de datos desde phpMyAdmin.
2. Extraer el ZIP en una carpeta de prueba; no sobrescribir el proyecto original todavía.
3. Crear un evento con fecha válida, costo cero y cupo limitado; comprobar que se muestra a alumnos.
4. Intentar guardar una fecha imposible, costo negativo o cupo negativo y confirmar que se rechace.
5. Inscribir un alumno y comprobar que el sistema no permita eliminar el evento mientras existan inscripciones activas.
6. Comprobar que el cupo no pueda reducirse por debajo de las inscripciones activas y que la lista de espera continúe funcionando.
7. Crear una promoción con fechas de vigencia y descuento válido; comprobar su visualización durante el período activo.
8. Desactivar una promoción y confirmar que desaparezca de las vistas públicas/de alumno, pero siga en administración.

## Instalación
No ejecutar `sql/mma_systems.sql` ni importar una base de datos nueva para esta etapa. No hay migraciones nuevas.
