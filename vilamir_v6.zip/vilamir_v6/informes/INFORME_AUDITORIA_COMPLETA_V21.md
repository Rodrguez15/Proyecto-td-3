# Academia VILAMIR V21 — Auditoría estática y correcciones

**Fecha de revisión:** 25/10/2026  
**Base:** `Academia_VILAMIR_V21_Etapa_Pagos_Comprobantes.zip`  
**Entorno de auditoría:** PHP 8.4.24, Node.js disponible; sin controlador PDO MySQL y sin servidor MySQL/MariaDB accesible.

## Resumen

La auditoría estática se ejecutó sobre el proyecto completo. Se corrigieron tres hallazgos identificados en el informe previo: contraseñas iniciales fijas devueltas por la API, uso inadvertido de credenciales de desarrollo cuando el servidor se declara en producción y construcción de enlaces de recuperación usando un `HTTP_HOST` no validado.

**Estado: revisión estática aprobada con pendientes de seguridad e integración. No declarar el sistema listo para producción hasta completar las pruebas indicadas.** No se agregaron módulos de exámenes ni niveles y se conservaron las funciones existentes.

## Comprobaciones ejecutadas

- Integridad del ZIP de entrada: correcta.
- PHP: 52 archivos comprobados con `php -l`, sin errores de sintaxis después de los cambios.
- JavaScript: 17 archivos comprobados con `node --check`, sin errores de sintaxis después de los cambios.
- Todos los archivos `api/*.php` incluyen la configuración compartida de sesión.
- Búsqueda estática de `eval`, `shell_exec`, `system`, `proc_open`, `passthru` y `unserialize` en PHP: sin coincidencias.
- Búsqueda de las claves predeterminadas conocidas (`Alumno123!`, `Usuario123!`, `Profesor123!`) y de respuestas que devuelvan contraseñas en `api/admin.php`: sin coincidencias.
- Prueba aislada de `config/conexion.php` con `APP_ENV=production` y variables de base de datos ausentes: la aplicación detiene la conexión y muestra un error genérico, sin intentar usar las credenciales locales.
- PDO está disponible, pero `PDO::getAvailableDrivers()` devuelve una lista vacía; por tanto, no se pudo conectar a MySQL/MariaDB ni ejecutar pruebas de integración.

## Correcciones realizadas

### A1 — Contraseñas iniciales compartidas y devueltas por la API

**Corregido en esta entrega.** La creación de alumnos, profesores y usuarios exige una contraseña individual de al menos ocho caracteres. Se eliminan los valores de contraseña fijos de las rutas de creación y las respuestas JSON ya no devuelven contraseñas. Las contraseñas no se recortan antes de almacenarse, para no alterar claves que incluyan espacios. En edición, una contraseña vacía conserva la actual.

**Prueba manual pendiente:** crear cada tipo de cuenta con contraseña válida, vacía, demasiado corta y con espacios; verificar inicio de sesión posterior.

### A2 — Credenciales de base de datos de desarrollo

**Estado histórico al 25/10/2026; ver addendum del 16/11/2026.** En aquella versión, la conexión exigía variables de entorno al declararse producción. La copia actual ya no conserva credenciales predeterminadas y admite un archivo privado local excluido del ZIP.

**Pendiente:** confirmar la configuración real del servidor antes de publicar. Ver `docs/CONFIGURACION_SEGURA_V21.md`.

### A3 — Protección CSRF

**Pendiente.** La sesión ya rechaza peticiones marcadas como `cross-site` y valida `Origin` cuando se envía, pero esto no sustituye tokens CSRF sincronizados para todas las operaciones que modifican datos. La implementación transversal requiere actualizar formularios y llamadas AJAX de los tres roles, y probarlas juntas para evitar regresiones. No se declara corregido en esta entrega.

### A4 — URL de recuperación derivada de `HTTP_HOST`

**Corregido en esta entrega.** Los enlaces de recuperación usan `VILAMIR_BASE_URL` cuando está configurada y validan que sea una URL base HTTP(S) sin credenciales, consulta ni fragmento. Solo en desarrollo local se permite inferir la URL para `localhost`, `127.0.0.1` o `[::1]`. En producción, si la URL base no está configurada, no se crea un token que dependa de un encabezado `Host` arbitrario.

**Prueba manual pendiente:** verificar solicitud, entrega del correo, caducidad, uso único y cambio de contraseña en XAMPP con SMTP configurado.

## Otros riesgos y pruebas pendientes

- No se pudo comprobar compatibilidad de todas las consultas con el esquema y los datos reales de `mma_systems`.
- No se ejecutaron las migraciones ni se verificaron claves foráneas, índices, duplicados o transacciones en MySQL/MariaDB.
- Falta comprobar autorización por rol e intentos de acceso a IDs ajenos en cada API.
- Falta probar XSS almacenado/reflejado, CSRF, rate limiting de login y recuperación, subida de archivos y configuración HTTPS.
- La búsqueda estática de funciones peligrosas no equivale a una auditoría dinámica ni garantiza ausencia de vulnerabilidades.

## Pruebas funcionales recomendadas en XAMPP

Usá una carpeta independiente y una copia exportada de la base de datos. No importes de nuevo `sql/mma_systems.sql` sobre una base existente.

1. Inicio/cierre de sesión para administrador, profesor y alumno.
2. Altas, ediciones y bajas de cada módulo; permisos de acceso entre roles.
3. Inscripciones, cancelaciones, cupos, lista de espera y concurrencia.
4. Asistencia por grupo/horario y conflictos de horarios.
5. Registro, edición permitida, anulación y comprobante de pagos.
6. Notificaciones, calendario, reportes, exportaciones y certificados.
7. Recuperación de contraseña: correo correcto, enlace vencido, token usado y correo no entregado.
8. Restauración de copia de seguridad y comprobación de integridad referencial.

## Criterio de cierre

Estado histórico de la auditoría original: aquella entrega contenía pendientes CSRF y de integración. La situación actual se detalla en el addendum del 16/11/2026; siguen pendientes las pruebas funcionales y de integración.


## Addendum de seguimiento 16/11/2026

Este informe conserva el estado histórico de la auditoría original. En la copia corregida de esta fecha ya no hay valores predeterminados MySQL en el código; `config/db_config.php` carga un archivo local privado excluido del ZIP. CSRF se exige en las operaciones web de escritura, con token explícito para login/registro y cierre de sesión por POST. El borrado de usuarios vinculados a alumnos queda bloqueado por riesgo de cascadas hacia pagos e historial. SMTP no se considera operativo sin configuración y prueba real. La sintaxis debe volver a validarse sobre esta copia y todas las pruebas de integración continúan pendientes.
