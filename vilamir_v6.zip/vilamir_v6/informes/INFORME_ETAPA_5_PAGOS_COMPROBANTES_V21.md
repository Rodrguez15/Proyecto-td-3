# Academia VILAMIR V21 — Etapa 5: pagos y comprobantes

## Objetivo
Reforzar el registro de pagos, la conservación del historial financiero, la emisión/verificación de comprobantes y la exportación del historial, manteniendo las funciones existentes.

## Cambios realizados
- `api/admin.php`: valida que la fecha de pago y la fecha de vencimiento tengan formato válido; exige importes mayores que cero para altas/ediciones; comprueba que el alumno seleccionado exista; y evita que el estado `Anulado` se aplique desde el formulario común. La anulación debe pasar por la acción dedicada, que conserva fecha, usuario y motivo.
- `api/admin.php`: el alta de pago y la asignación de su número de comprobante se guardan en una transacción. Si una de las operaciones falla, se revierte el alta para evitar registros parciales.
- `exportar.php`: el CSV del historial completo muestra `Vencido` cuando el pago sigue almacenado como `Pendiente` pero su fecha de vencimiento ya pasó. Esto es un estado calculado para consulta; no modifica la base de datos.
- Revisados `comprobante_pago.php`, `verificar_comprobante.php` y `reportes.php`: se conserva la autorización del comprobante para administrador/alumno propietario, la consulta pública limitada para verificar el código, la compatibilidad con pagos antiguos sin código guardado y los enlaces de comprobante del historial.
- No se requiere migración SQL nueva. No se agregaron módulos de exámenes ni niveles.

## Verificación estática
- `php -l` ejecutado para todos los archivos PHP.
- `node --check` ejecutado para todos los archivos JavaScript.
- CSS revisado por balance de llaves.
- ZIP comprobado con `unzip -t`.
- El entorno de validación no tiene el controlador `pdo_mysql`; por eso no se pudieron ejecutar pruebas reales contra MySQL/MariaDB ni navegar la aplicación con sesiones de prueba.

## Pruebas manuales pendientes en XAMPP
1. Registrar un pago pendiente con vencimiento futuro; comprobar que se crea un único número `VIL-AAAA-MM-DD-000001` (con el ID real) y que abre el comprobante.
2. Probar un importe cero/negativo, fecha inválida y alumno inexistente: deben rechazarse sin crear un registro.
3. Registrar un pago pagado y verificar que figura en el historial y en el CSV.
4. Anular un pago con motivo; comprobar que deja de contarse como cobrado/pendiente y que conserva usuario, fecha y motivo de anulación.
5. Intentar editar un pago anulado: debe rechazarse.
6. Verificar un comprobante actual y, si hay pagos antiguos, uno cuyo `Numero_comprobante` esté vacío.
7. Entrar como alumno A e intentar abrir el comprobante de alumno B: debe responder acceso denegado.
8. Revisar el CSV de historial completo, importes, tildes, estados vencidos y códigos.

## Instalación segura
1. Hacer copia de `C:\xampp\htdocs\vilamir_v3` y exportar la base desde phpMyAdmin.
2. Extraer el ZIP en una carpeta de prueba y comparar las funciones antes de reemplazar archivos en la instalación activa.
3. No importar `sql/mma_systems.sql` ni ejecutar migraciones para esta etapa.
4. Confirmar las pruebas manuales antes de publicar.
