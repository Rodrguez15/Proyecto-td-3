# Academia VILAMIR V21 — Informe de implementación, etapa 2

## Alcance
- Revisión del espacio docente (`profesor.php`, `api/profesor_portal.php`, `js/profesor.js`).
- Revisión y endurecimiento del registro de asistencia (`api/asistencia.php`).
- Sin módulos de exámenes ni niveles.
- No se modifica el esquema SQL en esta etapa; el cambio principal es de validación de datos en el servidor.

## Cambio aplicado a la asistencia
Antes de esta modificación, el servidor podía ignorar silenciosamente algunos elementos inválidos del lote y aun así responder que la asistencia se había guardado. Ahora:
1. Rechaza elementos con estructura, alumno o estado inválidos.
2. Rechaza alumnos repetidos en el mismo envío.
3. Comprueba que cada alumno siga inscrito activamente en el grupo asignado al profesor.
4. Compara los IDs enviados con la lista completa de alumnos activos del grupo y pide recargar si la lista cambió o está incompleta.
5. Solo después de validar el lote, guarda los registros dentro de una transacción y devuelve la cantidad guardada.
6. Conserva la identificación de cada clase por alumno, grupo, fecha y horario.

## Permisos revisados
- La API de asistencia exige una sesión con rol Profesor.
- Verifica que el profesor esté vinculado a su perfil y que tenga asignado el grupo.
- Valida que el horario corresponda al grupo y al día de la fecha seleccionada.
- El portal consulta horarios, listas de alumnos y resúmenes únicamente para grupos asignados activamente.

## Verificaciones automáticas
- Sintaxis PHP revisada con `php -l`.
- Sintaxis JavaScript revisada con `node --check`.
- ZIP final revisado con `unzip -t`.

## Limitaciones
No fue posible realizar pruebas de integración con MySQL/MariaDB ni pruebas de navegador en este entorno porque PHP no dispone del controlador `pdo_mysql`. Por lo tanto, esta entrega no se declara validada funcionalmente contra una base real. La prueba final debe hacerse en una copia del proyecto y de la base de datos en XAMPP.

## Pruebas manuales en XAMPP
1. Profesor con un grupo y un horario: cargar alumnos, marcar estados, guardar y volver a cargar.
2. Grupo con dos horarios en un mismo día: verificar que las marcas no se mezclen entre horarios.
3. Intentar guardar con un alumno duplicado o con una lista desactualizada: el servidor debe rechazarlo sin guardar parcialmente.
4. Intentar abrir la API con una cuenta que no sea profesor o con un grupo no asignado: debe denegar el acceso.
5. Confirmar que el profesor solo vea los alumnos de sus grupos asignados.
6. Confirmar que siguen funcionando calendario, cronograma y notificaciones.

## Instalación segura
Hacer copia de la carpeta y exportar la base de datos antes de reemplazar archivos. Esta etapa no requiere ejecutar una migración SQL nueva. No importar `sql/mma_systems.sql` sobre una base existente.

## Revisión adicional de la entrega Etapa 2

Al retomar esta etapa sobre la versión corregida de Etapa 1, se confirmó que el proyecto ya incluía las validaciones principales descritas arriba. Se agregó una validación adicional en `api/asistencia.php`: cualquier petición `POST` debe incluir `asistencias` como texto JSON; si falta o llega con otro tipo, se rechaza con HTTP 400 antes de consultar o guardar registros. Esto evita que una petición de escritura mal formada termine tratándose como una consulta de lectura.

### Resultado de la verificación de esta entrega

- Se conserva una copia ZIP de la versión corregida de Etapa 1 antes de modificar el código.
- Se mantiene el esquema de base de datos; no se requiere migración SQL nueva.
- Se mantienen las funciones existentes del portal docente.
- No se agregaron módulos de exámenes ni niveles.
- Las verificaciones estáticas de PHP, JavaScript y ZIP se ejecutan antes de entregar.
- La integración real con MySQL/MariaDB sigue pendiente en XAMPP porque el entorno de trabajo no dispone de `pdo_mysql`.
