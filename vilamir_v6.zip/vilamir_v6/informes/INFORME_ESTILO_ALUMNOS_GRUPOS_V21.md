# Informe de actualización visual — Academia VILAMIR V21

## Objetivo
Unificar la presentación de las pantallas **Alumnos** y **Grupos** con el estilo que utiliza **Responsables de alumnos**.

## Cambios realizados
- Se aplicó el fondo institucional `about-page` a la pantalla de alumnos.
- Las pantallas Alumnos y Grupos ahora utilizan el contenedor administrativo `admin`.
- Se incorporó una cabecera visual `hero` con título y texto descriptivo, igual al patrón usado en Responsables.
- Los bloques de registro, edición, listado y creación de grupos utilizan el estilo de panel `module`.
- Se conservaron los IDs y nombres de los controles que utilizan `js/alumnos.js` y `js/grupos.js`.
- Se conservaron las APIs, consultas, reglas de permisos, funciones de inscripción, cupos y lista de espera.
- No se añadieron módulos de exámenes ni niveles nuevos; se mantuvo el campo de nivel que ya existía en el formulario de grupos.

## Verificaciones
- Se verificó la integridad del ZIP de origen antes de modificarlo.
- Se ejecutaron comprobaciones de sintaxis PHP y JavaScript después de los cambios.
- Estas comprobaciones no sustituyen una prueba real en navegador con la base MySQL de la instalación.

## Pruebas manuales pendientes
1. Abrir `alumnos.php` como administrador; crear, buscar, editar y exportar alumnos.
2. Abrir `grupos.php` como administrador; crear un grupo y revisar las tarjetas.
3. Ingresar como alumno y profesor y verificar que las acciones permitidas por rol sigan visibles y funcionales.
4. Revisar las dos pantallas en escritorio y en un celular.
