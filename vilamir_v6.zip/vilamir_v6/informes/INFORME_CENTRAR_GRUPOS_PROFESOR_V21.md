# Academia VILAMIR V21 — Centrar organización de grupos del profesor

## Cambios realizados
- Se centró horizontalmente el panel **Organización / Mis grupos** dentro de “Mi espacio como profesor”.
- Se limitó el ancho máximo del panel a 1120 px para que la sección quede equilibrada en pantallas grandes.
- Las tarjetas de grupos se distribuyen en columnas centradas y con ancho consistente.
- En móviles, la sección y las tarjetas pasan a una sola columna.
- Se conservaron la carga dinámica de grupos, horarios, lista de alumnos y acceso al control de asistencia.
- No se modificó la lógica PHP/JavaScript ni la base de datos; tampoco se añadieron módulos de exámenes o niveles.

## Verificación
Se realizaron comprobaciones estáticas de sintaxis PHP/JavaScript y de integridad del ZIP. La visualización final debe comprobarse en el navegador con XAMPP.
