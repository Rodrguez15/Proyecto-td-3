# Bajas temporales y definitivas de alumnos — VILAMIR V6

## Alcance y protección de datos

La gestión se implementa sin agregar, eliminar ni alterar tablas, columnas, índices, claves foráneas o datos históricos del esquema. No se ejecuta ningún SQL de migración. La baja física de alumnos continúa bloqueada.

El estado administrativo se registra como eventos en la tabla existente `ACTIVIDAD_SISTEMA`, usando las acciones `ALUMNO_BAJA_TEMPORAL`, `ALUMNO_BAJA_DEFINITIVA` y `ALUMNO_REACTIVADO`. El detalle comienza con `ALUMNO_ID=<id>;` para identificar el alumno. La acción queda asociada al ID del administrador que la realizó.

## Baja temporal

- Cambia a `Cancelada` únicamente las filas `Activa` de `INSCRIPCION_DISCIPLINA` e `INSCRIPCION_GRUPO_ALUMNO` del alumno.
- No borra filas de inscripción; conserva su fecha e identificadores.
- No modifica `PAGO`, `ASISTENCIA`, datos personales ni cuenta de usuario.
- El alumno conserva acceso y puede volver a inscribirse. Las inscripciones anteriores no se reactivan automáticamente.

## Baja definitiva

- Realiza las mismas cancelaciones no destructivas de inscripciones activas.
- Registra el estado definitivo en `ACTIVIDAD_SISTEMA`.
- `config/sesion.php` comprueba el estado en cada petición autenticada de una sesión de alumno y cierra la sesión si la baja es definitiva. `login.php` también rechaza nuevos inicios de sesión.
- La recuperación de contraseña no debe reactivar cuentas con baja definitiva.

## Reactivación

El administrador puede levantar una baja temporal o definitiva. La cuenta vuelve a estar habilitada si era definitiva. Las inscripciones que fueron canceladas no se restauran automáticamente: el alumno deberá volver a inscribirse para que el profesor lo vea en sus listas de asistencia. No se generan pagos ni asistencias retroactivas.

## Dependencia del esquema

La implementación necesita que ya existan `ACTIVIDAD_SISTEMA`, `INSCRIPCION_DISCIPLINA` e `INSCRIPCION_GRUPO_ALUMNO` con las columnas que utiliza el proyecto (`ID_Actividad`, `ID_Usuario`, `Accion`, `Detalle`, `Estado`, `ID_Alumno`). Si falta alguna, la API rechaza la operación antes de modificar datos. No se instala ni ejecuta una migración.

## Pruebas pendientes

No se ejecutó contra una base MySQL real. Antes de producción, probar en una copia de la base: baja temporal, baja definitiva, cierre de sesión activa, rechazo de login, rechazo de inscripción en definitiva, reactivación, reinscripción, roster de profesor y conservación de pagos/asistencias.
