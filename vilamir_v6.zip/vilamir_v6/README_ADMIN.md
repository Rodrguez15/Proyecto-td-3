# Academia VILAMIR — Panel administrativo

El panel permite gestionar alumnos, profesores, responsables, disciplinas, grupos, horarios, pagos, notificaciones, seminarios/eventos, promociones, usuarios e inscripciones.

## Acceso inicial

Las credenciales iniciales dependen de la base de datos que hayas importado y de si ya existían cuentas antes de ejecutar los datos de demostración. No des por válida una contraseña escrita en esta documentación sin comprobar el script SQL que usaste. Si no podés ingresar, verificá el usuario en phpMyAdmin y restablecé la contraseña de forma segura. Cambiá cualquier credencial de prueba antes de publicar el sitio.

El archivo `sql/datos_demo/datos_demo_v20.sql` documenta sus cuentas de demostración por separado. Esas credenciales son públicas y solo deben usarse en entornos de prueba.

## Módulos actuales

- Alumnos y responsables.
- Profesores y disciplinas que enseñan.
- Disciplinas, grupos y horarios.
- Pagos, comprobantes e historial.
- Seminarios/eventos con cupos y listas de espera.
- Promociones, notificaciones y asistencia.
- Reportes, estadísticas, exportaciones, certificados, QR y galería.
- Calendario, herramientas y web pública.

## Base de datos

Para una instalación nueva, usar `sql/mma_systems.sql`.

Para una base existente, hacé una copia de seguridad y revisá el estado de las tablas antes de ejecutar las migraciones disponibles en `sql/`. No ejecutes todas automáticamente ni importes el esquema inicial sobre una base con datos. Las migraciones que correspondan dependen de la versión real de la base instalada.

**La academia no utiliza exámenes ni niveles de examen.**
