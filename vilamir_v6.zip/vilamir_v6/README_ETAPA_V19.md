# Academia VILAMIR — V19

## Asistencia avanzada + logo oficial

Esta versión parte de V18 y agrega:

- Registro de asistencia vinculado al profesor que la realiza.
- Selección obligatoria de grupo, fecha y horario.
- Validación de que el horario pertenece al grupo y coincide con el día seleccionado.
- El profesor solo puede registrar asistencia en grupos que tiene asignados.
- El alumno debe estar activo en el grupo para poder recibir una marca.
- Estadística de asistencia de los últimos 30 días por alumno.
- Resumen de alumnos marcados, presentes y porcentaje del día.
- Índices adicionales para consultas de asistencia.
- Migración `sql/migraciones/migracion_asistencia_v19.sql` para bases existentes.
- El esquema consolidado `sql/mma_systems.sql` ya incluye `ID_Profesor` en `ASISTENCIA`.
- Logo oficial proporcionado por la academia integrado en los encabezados y comprobantes.

## Migración

Sobre una base V18/V17 existente, ejecutar:

`sql/migraciones/migracion_asistencia_v19.sql`

Para una instalación nueva usar `sql/mma_systems.sql`.

No se agregan exámenes ni niveles de examen.


## Revisión V19.1

Durante la revisión integral se corrigió la clave única de `ASISTENCIA`: ahora permite registrar correctamente más de una clase del mismo grupo en un mismo día cuando corresponden a horarios diferentes.

También se centralizaron los estilos específicos del portal docente, exportaciones y asistencia en `css/style.css`.
